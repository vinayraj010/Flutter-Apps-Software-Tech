import 'dart:ui';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_app/application/profile/profile_bloc.dart';
import 'package:flutter_app/application/providers/profile_provider.dart';
import 'package:flutter_app/presentation/core/pages/loading_page.dart';
import 'package:flutter_app/presentation/core/palette.dart';
import 'package:flutter_app/presentation/profile/widgets/about_section.dart';
import 'package:flutter_app/presentation/profile/widgets/certificate_section.dart';
import 'package:flutter_app/presentation/profile/widgets/education_section.dart';
import 'package:flutter_app/presentation/profile/widgets/header_section.dart';
import 'package:flutter_app/presentation/profile/widgets/skill_section.dart';
import 'package:flutter_app/presentation/profile/widgets/social_media_section.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:provider/provider.dart';

class ProfilePage extends StatelessWidget {
  // final ProfileListeners _listeners = ProfileListeners();
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: Palette.onBackground,
        body: ClipRRect(
          borderRadius: BorderRadius.circular(18),
          child: Consumer<ProfileProvider>(
            builder: (context, provider, child) {
              return BlocConsumer<ProfileBloc, ProfileState>(
                listener: (context, state) {},
                builder: (context, state) {
                  if (provider.loadingOption.isSome()) {
                    return Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Stack(
                        alignment: Alignment.center,
                        children: [
                          Column(
                            children: [
                              Expanded(child: HeaderBackground()),
                              Expanded(child:AboutBackground()),
                              Expanded(child:EducationBackground()),
                              Expanded(child:SkillBackground()),
                            ],
                          ),
                          BackdropFilter(
                              filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
                              child: LoadingPage()),
                        ],
                      ),
                    );
                  } else {
                    final ValueKey<String> _educationKey =
                        ValueKey(state.profile.educationStandard
                                    .toList()
                                    .map((edu) => {
                                          'institute_name':
                                              edu.instituteName.toJson(),
                                          'standard_name':
                                              edu.standardName.toJson(),
                                        })
                                    .toString() ==
                                "()"
                            ? 'Empty Education'
                            : state.profile.educationStandard
                                .toList()
                                .map((edu) => {
                                      'institute_name':
                                          edu.instituteName.toJson(),
                                      'standard_name':
                                          edu.standardName.toJson(),
                                    })
                                .toString());

                    final ValueKey<String> _skillKey = ValueKey(state
                                .profile.domains
                                .toList()
                                .map((skill) => skill.toJson())
                                .toString() ==
                            "()"
                        ? "Empty Skill"
                        : state.profile.domains
                            .toList()
                            .map((skill) => skill.toJson())
                            .toString());

                    final ValueKey<String> _certificateKey = ValueKey(state
                                .profile.certificates
                                .toList()
                                .map((ce) => ce.toJson())
                                .toString() ==
                            "()"
                        ? "Empty Certificate"
                        : state.profile.certificates
                            .toList()
                            .map((ce) => ce.toJson())
                            .toString());

                    return SingleChildScrollView(
                      padding: const EdgeInsets.only(bottom: 40),
                      child: Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Column(
                          children: [
                            Header(
                              state: state,
                            ),
                            About(
                              state: state,
                            ),
                            Education(
                              key: _educationKey,
                              state: state,
                            ),
                            Skill(
                              key: _skillKey,
                              state: state,
                            ),
                            SocialMedia(
                              state: state,
                            ),
                            CertificateSection(
                              state: state,
                              key: _certificateKey,
                            ),
                          ],
                        ),
                      ),
                    );
                  }
                },
              );
            },
          ),
        ),
      ),
    );
  }
}
