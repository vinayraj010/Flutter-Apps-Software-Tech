import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart'
    hide DropdownButton, DropdownMenuItem, DropdownButtonFormField, Checkbox;
import 'package:flutter_app/application/profile/profile_bloc.dart';
import 'package:flutter_app/core/routes/route.gr.dart' as route;
import 'package:flutter_app/core/utils/clean_string.dart';
import 'package:flutter_app/core/utils/month_map.dart';
import 'package:flutter_app/domain/core/validators/maxmin_validators.dart';
import 'package:flutter_app/domain/core/validators/phonenumber_validator.dart';
import 'package:flutter_app/domain/core/validators/required_validator.dart';
import 'package:flutter_app/domain/profile/profile.dart';
import 'package:flutter_app/presentation/core/palette.dart';
import 'package:flutter_app/presentation/profile/widgets/circle_checkbox.dart';
import 'package:flutter_app/presentation/profile/widgets/drop_down_form_field.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_svg/svg.dart';
import 'package:form_validators/form_validators.dart';
import 'package:geocoder/geocoder.dart';
import 'package:geolocator/geolocator.dart';
import 'package:google_fonts/google_fonts.dart';

import '../add_dialog.dart';
import '../countries.dart';

final BuildContext context = route.Router.navigator.key.currentContext;

class AboutSectionDialog {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  bool _showErrors = false;

  void call() async {
    String selectedMonth;
    String selectedDay;
    String selectedYear;
    String selectedCountry;
    String selectedState;
    String selectedDialCode = '+91';
    String selectedPhonNumber;
    bool isShowMyCurrentLocation = false;
    int incrementStateValue = 1;
    final EdgeInsets fromPadding = const EdgeInsets.all(0).copyWith(left: 8);

    void _initilizeVariablesIfPresent(Profile profile) {
      selectedMonth =
          profile.dob != null ? mapIntToMonth(profile.dob.split('-')[1]) : null;
      if (profile.dob != null) {
        selectedDay = profile.dob.split('-').last;
      }
      if (profile.dob != null) {
        selectedYear = profile.dob.split('-').first;
      }
      if (profile.countryId != null) {
        selectedCountry = profile.countryId.toString();
      }
      if (profile.stateId != "null") {
        selectedState = profile.stateId;
      }
      if (profile.phone != null) {
        if (profile.phone.contains('+')) {
          selectedDialCode =
              profile.phone.substring(0, profile.phone.length - 10);
        } else {
          selectedDialCode = "";
        }
      } else {
        selectedDialCode = "+91";
      }
      if (profile.phone != null) {
        if (!profile.phone.contains('+')) {
          selectedPhonNumber = profile.phone;
        } else {
          selectedPhonNumber = profile.phone
              .substring(profile.phone.length - 10, profile.phone.length);
        }
      }
    }

    return await showDialog(
        context: context,
        builder: (_) => BlocBuilder<ProfileBloc, ProfileState>(
              builder: (context, state) {
                _initilizeVariablesIfPresent(state.profile);

                return StatefulBuilder(
                  builder: (context, setMState) {
                    void _getLocation(ProfileState state) {
                      Geolocator.getCurrentPosition().then((value) {
                        Geocoder.local
                            .findAddressesFromCoordinates(
                                Coordinates(value.latitude, value.longitude))
                            .then((value) {
                          selectedCountry = state.countries
                              .firstWhere((element) =>
                                  element.name.toLowerCase() ==
                                  value.last.countryName.toLowerCase())
                              .id
                              .toString();

                          selectedState = value.first.adminArea;
                          incrementStateValue++;
                          setMState(() {});
                          Navigator.pop(context);
                        });
                      }).catchError((onError) {
                        Navigator.pop(context);
                        showModalBottomSheet(
                          context: context,
                          isDismissible: false,
                          barrierColor: Colors.black54,
                          backgroundColor: Colors.black,
                          builder: (context) => WillPopScope(
                            onWillPop: () async {
                              return Future.value(false);
                            },
                            child: Padding(
                              padding: const EdgeInsets.all(20),
                              child: Row(children: [
                                Text(
                                  'Permission Denied\nPlease enable permission manually',
                                  style: TextStyle(color: Palette.greyWhite),
                                ),
                              ]),
                            ),
                          ),
                        ).timeout(const Duration(seconds: 2), onTimeout: () {
                          isShowMyCurrentLocation = false;
                          setMState(() {});
                          Navigator.pop(context);
                        });
                      });
                    }

                    //Month
                    final bool _isMonthNotFilled = selectedMonth == null;
                    final Color _monthDropDownBorder =
                        _isMonthNotFilled ? Palette.c686868 : Palette.onBlue;
                    final Color _monthDropDownFillColor = _isMonthNotFilled
                        ? Palette.cafafafa
                        : Palette.onBackground;

                    //Day
                    final bool _isDayNotFilled =
                        selectedDay == null || cleanString(selectedDay).isEmpty;
                    final InputBorder _dayTextFieldBorder = OutlineInputBorder(
                        borderSide: BorderSide(
                            color: _isDayNotFilled
                                ? Palette.c686868
                                : Palette.onBlue),
                        borderRadius: BorderRadius.circular(3));

                    //Year
                    final bool _isYearNotFilled = selectedYear == null ||
                        cleanString(selectedYear).isEmpty;
                    final InputBorder _yearTextFieldBorder = OutlineInputBorder(
                        borderSide: BorderSide(
                            color: _isYearNotFilled
                                ? Palette.c686868
                                : Palette.onBlue),
                        borderRadius: BorderRadius.circular(3));

                    //Location
                    final bool _isCountryNotFilled = selectedCountry == null;
                    final Color _countryDropDownBorder =
                        _isCountryNotFilled ? Palette.c686868 : Palette.onBlue;
                    final Color _countryDropDownFillColor = _isCountryNotFilled
                        ? Palette.cafafafa
                        : Palette.onBackground;

                    //State
                    final bool _isStateNotFilled = (selectedState == null ||
                        cleanString(selectedState).isEmpty);
                    final InputBorder _stateTextFieldBorder =
                        OutlineInputBorder(
                            borderSide: BorderSide(
                                color: _isStateNotFilled
                                    ? Palette.c686868
                                    : Palette.onBlue),
                            borderRadius: BorderRadius.circular(3));

                    //Phonenumber
                    final bool _isPhoneNotFilled = selectedPhonNumber == null ||
                        cleanString(selectedPhonNumber).isEmpty;
                    final InputBorder _phoneTextFieldBorder =
                        OutlineInputBorder(
                            borderSide: BorderSide(
                                color: _isPhoneNotFilled
                                    ? Palette.c686868
                                    : Palette.onBlue),
                            borderRadius: BorderRadius.circular(3));

                    return AddDialog(
                      asset: 'about',
                      heading: 'About',
                      child: Form(
                        key: _formKey,
                        autovalidate: _showErrors,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                SvgPicture.asset('assets/profile/dob.svg'),
                                const SizedBox(
                                  width: 10,
                                ),
                                Text(
                                  'Date of Birth',
                                  style: TextStyle(
                                      fontSize: 14,
                                      fontWeight: FontWeight.w400,
                                      color: Palette.c686868,
                                      fontFamily:
                                          GoogleFonts.poppins().fontFamily),
                                ),
                              ],
                            ),
                            const SizedBox(
                              height: 10,
                            ),
                            Padding(
                              padding: const EdgeInsets.only(left: 10),
                              child: Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Expanded(
                                    flex: 2,
                                    child: Container(
                                      alignment: Alignment.centerLeft,
                                      padding: const EdgeInsets.only(left: 10),
                                      decoration: BoxDecoration(
                                        color: _monthDropDownFillColor,
                                        borderRadius: BorderRadius.circular(3),
                                        border: Border.all(
                                          color: _monthDropDownBorder,
                                        ),
                                      ),
                                      child: DropdownButtonFormField<String>(
                                        itemHeight: 45,
                                        iconSize: 18,
                                        value: selectedMonth,
                                        validator: validate([
                                          NonEmptyValidator("* Required"),
                                        ]) as String Function(String value),
                                        isExpanded: true,
                                        focusColor: Colors.red,
                                        hint: const Text('Month'),
                                        items: months
                                            .map((e) =>
                                                DropdownMenuItem<String>(
                                                  value: e,
                                                  child: Text(
                                                    e,
                                                    overflow: TextOverflow.clip,
                                                  ),
                                                ))
                                            .toList(),
                                        onChanged: (value) {
                                          setMState(() {
                                            selectedMonth = value;
                                          });
                                        },
                                      ),
                                    ),
                                  ),
                                  const SizedBox(width: 10),
                                  Expanded(
                                    child: TextFormField(
                                      initialValue: selectedDay,
                                      validator: validate([
                                        NonEmptyValidator("* Required"),
                                        const MinMaxValidator(
                                            min: 1,
                                            max: 31,
                                            message: 'Invalid Day'),
                                      ]) as String Function(String value),
                                      onChanged: (value) {
                                        selectedDay = cleanString(value);
                                        setMState(() {});
                                      },
                                      keyboardType: TextInputType.number,
                                      decoration: InputDecoration(
                                        contentPadding: fromPadding,
                                        hintText: 'Day',
                                        hintStyle: TextStyle(
                                            color: Palette.cafadad,
                                            fontSize: 16),
                                        filled: true,
                                        fillColor: _isDayNotFilled
                                            ? Palette.cafafafa
                                            : Palette.onBackground,
                                        border: _dayTextFieldBorder,
                                        focusedBorder: _dayTextFieldBorder,
                                        enabledBorder: _dayTextFieldBorder,
                                      ),
                                    ),
                                  ),
                                  const SizedBox(width: 10),
                                  Expanded(
                                    child: TextFormField(
                                      initialValue: selectedYear,
                                      validator: validate([
                                        NonEmptyValidator("* Required"),
                                        const MinMaxValidator(
                                            min: 1800,
                                            max: 9999,
                                            message: 'Invalid Year')
                                      ]) as String Function(String value),
                                      onChanged: (value) {
                                        selectedYear = cleanString(value);
                                        setMState(() {});
                                      },
                                      keyboardType: TextInputType.number,
                                      decoration: InputDecoration(
                                        contentPadding: fromPadding,
                                        hintText: 'Year',
                                        hintStyle: TextStyle(
                                            color: Palette.cafadad,
                                            fontSize: 16),
                                        filled: true,
                                        fillColor: _isYearNotFilled
                                            ? Palette.cafafafa
                                            : Palette.onBackground,
                                        border: _yearTextFieldBorder,
                                        focusedBorder: _yearTextFieldBorder,
                                        enabledBorder: _yearTextFieldBorder,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            const SizedBox(
                              height: 20,
                            ),
                            Row(
                              children: [
                                SvgPicture.asset('assets/profile/location.svg'),
                                const SizedBox(
                                  width: 10,
                                ),
                                Text(
                                  'Location',
                                  style: TextStyle(
                                      fontSize: 14,
                                      fontWeight: FontWeight.w400,
                                      color: Palette.c686868,
                                      fontFamily:
                                          GoogleFonts.poppins().fontFamily),
                                ),
                              ],
                            ),
                            const SizedBox(
                              height: 10,
                            ),
                            Padding(
                              padding: const EdgeInsets.only(left: 10),
                              child: Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Expanded(
                                    child: Container(
                                      alignment: Alignment.centerLeft,
                                      padding: const EdgeInsets.only(left: 10),
                                      decoration: BoxDecoration(
                                        color: _countryDropDownFillColor,
                                        borderRadius: BorderRadius.circular(3),
                                        border: Border.all(
                                          color: _countryDropDownBorder,
                                        ),
                                      ),
                                      child: DropdownButtonFormField<String>(
                                        itemHeight: 45,
                                        iconSize: 18,
                                        value: selectedCountry,
                                        validator: validate([
                                          NonEmptyValidator("* Required"),
                                        ]) as String Function(String value),
                                        isExpanded: true,
                                        hint: const Text('Country'),
                                        items: BlocProvider.of<ProfileBloc>(
                                                context)
                                            .state
                                            .countries
                                            .map((e) =>
                                                DropdownMenuItem<String>(
                                                  value: e.id.toString(),
                                                  child: Text(
                                                    e.name,
                                                    overflow: TextOverflow.clip,
                                                  ),
                                                ))
                                            .toList(),
                                        onChanged: (value) {
                                          setMState(() {
                                            selectedCountry = value;
                                            isShowMyCurrentLocation = false;
                                          });
                                        },
                                      ),
                                    ),
                                  ),
                                  const SizedBox(width: 10),
                                  Expanded(
                                    child: Container(
                                      alignment: Alignment.centerLeft,
                                      padding: const EdgeInsets.only(left: 10),
                                      child: TextFormField(
                                        key: ValueKey(incrementStateValue),
                                        initialValue: selectedState,
                                        validator: validate([
                                          NonEmptyValidator("* Required"),
                                        ]) as String Function(String value),
                                        onChanged: (value) {
                                          selectedState = cleanString(value);
                                          setMState(() {});
                                        },
                                        decoration: InputDecoration(
                                          contentPadding: fromPadding,
                                          hintText: 'State',
                                          hintStyle: TextStyle(
                                              color: Palette.cafadad,
                                              fontSize: 16),
                                          filled: true,
                                          fillColor: _isStateNotFilled
                                              ? Palette.cafafafa
                                              : Palette.onBackground,
                                          border: _stateTextFieldBorder,
                                          focusedBorder: _stateTextFieldBorder,
                                          enabledBorder: _stateTextFieldBorder,
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            const SizedBox(
                              height: 15,
                            ),
                            Padding(
                              padding: const EdgeInsets.only(left: 10),
                              child: Row(
                                children: [
                                  Container(
                                    padding: const EdgeInsets.all(4),
                                    decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(6),
                                      border: Border.all(width: 1.2),
                                    ),
                                    child: Theme(
                                      data: Theme.of(context).copyWith(
                                        unselectedWidgetColor: Colors.white,
                                      ),
                                      child: Checkbox(
                                        value: isShowMyCurrentLocation,
                                        activeColor: Palette.onBlue,
                                        materialTapTargetSize:
                                            MaterialTapTargetSize.shrinkWrap,
                                        checkColor: Palette.onBlue,
                                        onChanged: (value) {
                                          if (value) {
                                            _getLocation(state);
                                            showModalBottomSheet(
                                              context: context,
                                              isDismissible: false,
                                              barrierColor: Colors.black54,
                                              backgroundColor: Colors.black,
                                              builder: (context) =>
                                                  WillPopScope(
                                                onWillPop: () async {
                                                  return Future.value(false);
                                                },
                                                child: Padding(
                                                  padding:
                                                      const EdgeInsets.all(20),
                                                  child: Row(children: [
                                                    Text(
                                                      'Locating you',
                                                      style: TextStyle(
                                                          color: Palette
                                                              .greyWhite),
                                                    ),
                                                    const SizedBox(width: 8),
                                                    SizedBox(
                                                      height: 10,
                                                      width: 10,
                                                      child:
                                                          CircularProgressIndicator(
                                                        strokeWidth: 1,
                                                        valueColor:
                                                            AlwaysStoppedAnimation(
                                                                Palette.onBlue),
                                                      ),
                                                    )
                                                  ]),
                                                ),
                                              ),
                                            );
                                          }

                                          setMState(() {
                                            isShowMyCurrentLocation = value;
                                          });
                                        },
                                      ),
                                    ),
                                  ),
                                  const SizedBox(
                                    width: 10,
                                  ),
                                  Text(
                                    'show my current location',
                                    style: TextStyle(
                                        fontSize: 16, color: Palette.c1d1d1d),
                                  ),
                                ],
                              ),
                            ),
                            const SizedBox(
                              height: 30,
                            ),
                            Row(
                              children: [
                                SvgPicture.asset('assets/profile/phone.svg'),
                                const SizedBox(
                                  width: 10,
                                ),
                                Text(
                                  'Contact no.',
                                  style: TextStyle(
                                      fontSize: 14,
                                      fontWeight: FontWeight.w400,
                                      color: Palette.c686868,
                                      fontFamily:
                                          GoogleFonts.poppins().fontFamily),
                                ),
                              ],
                            ),
                            const SizedBox(
                              height: 10,
                            ),
                            Row(
                              children: [
                                Container(
                                  margin: const EdgeInsets.only(
                                      right: 20, left: 10),
                                  padding: const EdgeInsets.only(left: 10),
                                  alignment: Alignment.centerLeft,
                                  decoration: BoxDecoration(
                                      color: const Color(0xffD7D4D4)
                                          .withOpacity(.5),
                                      borderRadius: BorderRadius.circular(5)),
                                  width: 100,
                                  child: DropdownButton(
                                    underline: const SizedBox.shrink(),
                                    value: selectedDialCode,
                                    autofocus: false,
                                    isExpanded: true,
                                    // selectedItemBuilder: (context) => [],
                                    items: countries
                                        .map(
                                          (country) => DropdownMenuItem(
                                            value: country['dial_code'],
                                            child: Text(
                                              country['dial_code'],
                                            ),
                                          ),
                                        )
                                        .toList(),
                                    onChanged: (value) {
                                      selectedDialCode = value as String;
                                      setMState(() {});
                                    },
                                  ),
                                ),
                                Flexible(
                                  child: TextFormField(
                                    initialValue: selectedPhonNumber,
                                    keyboardType: TextInputType.phone,
                                    validator: validate([
                                      const NonEmptyValidator("* Required"),
                                      const PhoneValidator(
                                          "Invalid Phone Number")
                                    ]) as String Function(String value),
                                    style: TextStyle(
                                        color: Palette.c686868,
                                        fontWeight: FontWeight.w200),
                                    decoration: InputDecoration(
                                      contentPadding:
                                          fromPadding.copyWith(left: 20),
                                      hintText: 'xxxxxxxxxx',
                                      hintStyle: TextStyle(
                                          color: Palette.cafadad, fontSize: 16),
                                      filled: true,
                                      fillColor: _isPhoneNotFilled
                                          ? Palette.cafafafa
                                          : Palette.onBackground,
                                      border: _phoneTextFieldBorder,
                                      focusedBorder: _phoneTextFieldBorder,
                                      enabledBorder: _phoneTextFieldBorder,
                                    ),
                                    onChanged: (value) {
                                      selectedPhonNumber = cleanString(value);
                                      setMState(() {});
                                    },
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(
                              height: 50,
                            ),
                            Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Padding(
                                  padding: const EdgeInsets.only(top: 6),
                                  child: SvgPicture.asset(
                                      'assets/profile/info.svg'),
                                ),
                                const SizedBox(
                                  width: 10,
                                ),
                                Text(
                                  'This information will get\nreflected in your public profile',
                                  style: TextStyle(
                                      fontSize: 12,
                                      fontWeight: FontWeight.w400,
                                      color: Palette.onBlue,
                                      fontFamily:
                                          GoogleFonts.poppins().fontFamily),
                                ),
                              ],
                            ),
                            const SizedBox(
                              height: 25,
                            ),
                            Padding(
                              padding: const EdgeInsets.only(left: 10),
                              child: RaisedButton(
                                elevation: 0,
                                color: Palette.onBlue,
                                onPressed: () {
                                  if (_formKey.currentState.validate()) {
                                    BlocProvider.of<ProfileBloc>(context).add(
                                        ProfileEvent.saveAbout(
                                            month: selectedMonth,
                                            day: selectedDay,
                                            year: selectedYear,
                                            country: selectedCountry.toString(),
                                            state: selectedState,
                                            phoneNumber:
                                                "$selectedDialCode$selectedPhonNumber"));
                                    // Bloc
                                  } else {
                                    setMState(() {
                                      _showErrors = true;
                                    });
                                  }
                                },
                                shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(16)),
                                child: Container(
                                    alignment: Alignment.center,
                                    height: 50,
                                    width: 100,
                                    child: SvgPicture.asset(
                                        'assets/profile/about_save.svg')),
                              ),
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                );
              },
            ));
  }
}
