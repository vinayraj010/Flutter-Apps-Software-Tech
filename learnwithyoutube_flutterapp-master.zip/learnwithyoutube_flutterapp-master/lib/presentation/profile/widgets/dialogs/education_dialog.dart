import 'package:flutter/material.dart';
import 'package:flutter_app/application/profile/profile_bloc.dart';
import 'package:flutter_app/application/providers/education_provider.dart';
import 'package:flutter_app/core/routes/route.gr.dart' as route;
import 'package:flutter_app/presentation/core/palette.dart';
import 'package:flutter_app/presentation/profile/widgets/dialogs/validation_textfield.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_svg/svg.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

import '../add_dialog.dart';

final BuildContext context = route.Router.navigator.key.currentContext;

class EducationDialog {
  void call() async {
    Provider.of<EducationProvider>(context, listen: false)
        .addAllPreviousEducationsToList();
    return await showDialog(
        context: context,
        barrierDismissible: false,
        builder: (_) => BlocBuilder<ProfileBloc, ProfileState>(
              builder: (context, state) {
                return Consumer<EducationProvider>(
                  builder: (context, provider, child) {
                    return AddDialog(
                      asset: 'education',
                      heading: 'Education',
                      onExit: provider.resetAll,
                      child: Form(
                        key: provider.formKey,
                        autovalidate: provider.showErrors,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            for (int i = 0;
                                i < provider.recentlyAdededEducations.length;
                                i++)
                              _Field(index: i, provider: provider),
                            const SizedBox(
                              height: 16,
                            ),
                            Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Padding(
                                  padding: const EdgeInsets.only(top: 6),
                                  child: SvgPicture.asset(
                                      'assets/profile/info.svg'),
                                ),
                                const SizedBox(
                                  width: 10,
                                ),
                                Text(
                                  'This information will get\nreflected in your public profile',
                                  style: TextStyle(
                                      fontSize: 12,
                                      fontWeight: FontWeight.w400,
                                      color: Palette.onBlue,
                                      fontFamily:
                                          GoogleFonts.poppins().fontFamily),
                                ),
                              ],
                            ),
                            const SizedBox(
                              height: 25,
                            ),
                            Padding(
                              padding: const EdgeInsets.only(left: 10),
                              child: Row(
                                children: [
                                  Expanded(
                                    child: OutlinedButton(
                                      style: ButtonStyle(
                                          elevation:
                                              MaterialStateProperty.all(0),
                                          side: provider.addFieldBorder(),
                                          shape: MaterialStateProperty.all(
                                              RoundedRectangleBorder(
                                                  borderRadius:
                                                      BorderRadius.circular(
                                                          16)))),
                                      onPressed: provider.onAddFieldPressed,
                                      child: SizedBox(
                                        height: 50,
                                        child: SvgPicture.asset(
                                          'assets/profile/add_field.svg',
                                          color: provider
                                                  .checkWhetherAllFieldsAllFilled()
                                              ? Palette.cc4c4c4
                                              : null,
                                        ),
                                      ),
                                    ),
                                  ),
                                  const SizedBox(width: 12),
                                  Expanded(
                                    child: RaisedButton(
                                      elevation: 0,
                                      color: Palette.onBlue,
                                      onPressed: provider.onSavePressed,
                                      shape: RoundedRectangleBorder(
                                          borderRadius:
                                              BorderRadius.circular(16)),
                                      child: SizedBox(
                                        height: 50,
                                        child: SvgPicture.asset(
                                          'assets/profile/about_save.svg',
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                );
              },
            ));
  }
}

class _Field extends StatelessWidget {
  const _Field({
    Key key,
    @required this.index,
    @required this.provider,
  }) : super(key: key);

  final int index;
  final EducationProvider provider;

  @override
  Widget build(BuildContext context) {
    provider.checkWhetherFieldsFilled(index: index);
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Row(
          children: [
            SvgPicture.asset('assets/profile/education_small.svg'),
            const SizedBox(
              width: 10,
            ),
            Text(
              'Class / Degree',
              style: TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                  color: Palette.c686868,
                  fontFamily: GoogleFonts.poppins().fontFamily),
            ),
          ],
        ),
        const SizedBox(
          height: 10,
        ),
        Row(
          mainAxisSize: MainAxisSize.min,
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Flexible(
              child: ValidationTextField(
                  key: ValueKey(provider.recentlyAdededEducations[index].id),
                  formKey: provider.formKey,
                  keyboardType: TextInputType.text,
                  initialValue: provider
                      .recentlyAdededEducations[index].instituteName.name,
                  hintText: 'eg.class 8',
                  isNotFilled: provider.isClassNotFilled,
                  border: provider.classTextFieldBorder,
                  validator: (input) =>
                      provider.validatorForClass(value: input, index: index),
                  onChanged: (value) =>
                      provider.onClassChanged(index: index, value: value)),
            ),
            const SizedBox(
              width: 10,
            ),
            Visibility(
              visible: provider.isOnline(index),
              maintainSize: true,
              maintainAnimation: true,
              maintainState: true,
              child: GestureDetector(
                onTap: () => provider.removeAndAddToDelete(index),
                child: SvgPicture.asset(
                  'assets/profile/bin.svg',
                ),
              ),
            ),
          ],
        ),
        const SizedBox(
          height: 20,
        ),
        Row(
          children: [
            const SizedBox(
              width: 20,
            ),
            Text(
              'School / Institute',
              style: TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                  color: Palette.c686868,
                  fontFamily: GoogleFonts.poppins().fontFamily),
            ),
          ],
        ),
        const SizedBox(
          height: 10,
        ),
        Row(
          children: [
            Flexible(
              child: ValidationTextField(
                  key: ValueKey(provider.recentlyAdededEducations[index].id),
                  formKey: provider.formKey,
                  keyboardType: TextInputType.text,
                  initialValue: provider
                      .recentlyAdededEducations[index].standardName.name,
                  hintText: 'XYZ School',
                  isNotFilled: provider.isSchoolNotFilled,
                  border: provider.schoolTextFieldBorder,
                  validator: (input) =>
                      provider.validatorForSchool(value: input, index: index),
                  onChanged: (value) =>
                      provider.onSchoolChanged(index: index, value: value)),
            ),
            const SizedBox(
              width: 10,
            ),
            Visibility(
              visible: false,
              maintainSize: true,
              maintainAnimation: true,
              maintainState: true,
              child: SvgPicture.asset(
                'assets/profile/bin.svg',
              ),
            ),
          ],
        ),
        const SizedBox(
          height: 34,
        ),
      ],
    );
  }
}
