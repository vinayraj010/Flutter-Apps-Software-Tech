import 'package:flutter/material.dart';
import 'package:flutter_app/application/profile/profile_bloc.dart';
import 'package:flutter_app/domain/profile/profile.dart';
import 'package:flutter_app/presentation/core/palette.dart';
import 'package:flutter_app/presentation/profile/widgets/dialogs/skill_dialog.dart';
import 'package:flutter_app/presentation/profile/widgets/section_holder.dart';
import 'package:flutter_app/presentation/profile/widgets/size_reporting_widget.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:scrolling_page_indicator/scrolling_page_indicator.dart';

class Skill extends StatefulWidget {
  const Skill({
    Key key,
    this.state,
  }) : super(key: key);

  final ProfileState state;

  @override
  _SkillState createState() => _SkillState();
}

class _SkillState extends State<Skill> {
  PageController _pageController;

  List<double> _heights;
  int _currentPage = 0;
  final List<List<Domain>> _threeList = [];

  double get _currentHeight => _heights[_currentPage];

  @override
  void initState() {
    _splitDomainsPerThree();
    _heights = _threeList.map((e) => 0.0).toList();
    super.initState();
    _pageController = PageController() //
      ..addListener(() {
        final _newPage = _pageController.page.round();
        if (_currentPage != _newPage) {
          setState(() => _currentPage = _newPage);
        }
      });
  }

  void _splitDomainsPerThree() {
    _threeList.clear();
    final List<Domain> _domains = widget.state.profile.domains;

    for (int i = 0; i < _domains.length; i += 3) {
      if (i + 3 <= _domains.length) {
        _threeList.add(_domains.sublist(i, i + 3));
      } else {
        _threeList.add(_domains.sublist(i));
      }
    }
  }

  List<Widget> get _sizeReportingChildren => _threeList
      .map((threeDomains) => OverflowBox(
            //needed, so that parent won't impose its constraints on the children, thus skewing the measurement results.
            minHeight: 0,
            maxHeight: double.infinity,
            alignment: Alignment.topCenter,
            child: SizeReportingWidget(
              onSizeChange: (size) => setState(() =>
                  _heights[_threeList.indexOf(threeDomains)] =
                      size?.height ?? 0),
              child: Align(
                  child: Column(
                children: threeDomains
                    .map(
                      (domains) => _Child(
                        asset: 'skill_small',
                        title: domains.name,
                        value: double.parse(domains.pivot.experience),
                        color: [
                          Palette.sliderGreen,
                          Palette.sliderYellow,
                          Palette.sliderRed,
                        ][threeDomains.indexOf(domains)],
                      ),
                    )
                    .toList(),
              )),
            ),
          ))
      .toList();

  @override
  Widget build(BuildContext context) {
    return SectionHolder(
      title: 'Skills',
      icon: 'skills',
      onEditPressed: SkillDialog(),
      child: widget.state.profile.domains.isEmpty
          ? const _Empty()
          : Column(
              children: [
                TweenAnimationBuilder<double>(
                  curve: Curves.decelerate,
                  duration: const Duration(milliseconds: 550),
                  tween: Tween<double>(begin: _heights[0], end: _currentHeight),
                  builder: (context, value, child) =>
                      SizedBox(height: value, child: child),
                  child: PageView(
                    controller: _pageController,
                    children: _sizeReportingChildren
                        .asMap() //
                        .map((index, child) => MapEntry(index, child))
                        .values
                        .toList(),
                  ),
                ),
                const SizedBox(
                  height: 10,
                ),
                ScrollingPageIndicator(
                  dotSelectedColor: Palette.onBlue,
                  dotSelectedSize: 8,
                  controller: _pageController,
                  visibleDotCount: 7,
                  itemCount: (widget.state.profile.domains.length / 3).ceil(),
                )
              ],
            ),
    );
  }
}

class _Empty extends StatelessWidget {
  const _Empty({
    Key key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        SvgPicture.asset('assets/profile/empty_pen.svg'),
        const SizedBox(
          height: 5,
        ),
        const Text(
          'Add your skills and\nboost up your profile',
          textAlign: TextAlign.center,
          style: TextStyle(
            color: Color(0xffAFADAD),
            fontSize: 11,
            fontWeight: FontWeight.w400,
          ),
        ),
      ],
    );
  }
}

class _Child extends StatefulWidget {
  final String title;
  final double value;
  final String asset;
  final Color color;

  const _Child({Key key, this.title, this.asset, this.value, this.color})
      : super(key: key);

  @override
  __ChildState createState() => __ChildState();
}

class __ChildState extends State<_Child> {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(left: 6, right: 6),
      child: Row(
        children: [
          Flexible(
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.baseline,
              children: [
                Padding(
                  padding: const EdgeInsets.only(top: 6.0),
                  child: SvgPicture.asset('assets/profile/${widget.asset}.svg'),
                ),
                const SizedBox(
                  width: 11,
                ),
                Flexible(
                  child: Text(
                    widget.title,
                    style: TextStyle(
                      color: Palette.c1d1d1d,
                      fontSize: 14,
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                ),
              ],
            ),
          ),
          Flexible(
            child: SliderTheme(
              data: SliderThemeData(
                trackHeight: 7,
                disabledActiveTrackColor: widget.color,
                disabledInactiveTrackColor: const Color(0xffC4C4C4),
                disabledThumbColor: widget.color,
                thumbShape: const RoundSliderThumbShape(
                    enabledThumbRadius: 4, elevation: 0.0),
                trackShape: SkillTrackShape(),
              ),
              child: Slider(
                onChanged: null,
                value: widget.value,
                max: 5,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class SkillTrackShape extends RoundedRectSliderTrackShape {
  @override
  Rect getPreferredRect({
    @required RenderBox parentBox,
    Offset offset = Offset.zero,
    @required SliderThemeData sliderTheme,
    bool isEnabled = false,
    bool isDiscrete = false,
  }) {
    final double trackHeight = sliderTheme.trackHeight;
    final double trackLeft = offset.dx;
    final double trackTop =
        offset.dy + (parentBox.size.height - trackHeight) / 2;
    final double trackWidth = parentBox.size.width;
    return Rect.fromLTWH(trackLeft, trackTop, trackWidth, trackHeight);
  }
}

class SkillBackground extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return SectionHolder(
        title: 'Skill',
        icon: 'skills',
        onEditPressed: SkillDialog(),
        child: const _Empty());
  }
}
