import 'package:flushbar/flushbar_helper.dart';
import 'package:flutter/material.dart';
import 'package:flutter_app/application/profile/profile_bloc.dart';
import 'package:flutter_app/core/routes/route.gr.dart' as route;

class ProfileListeners {
  void listenToGetProfile(ProfileState state) {
    state.getProfileOption.fold(
      () => showDialog(
          context: route.Router.navigator.key.currentContext, child: Dialog()),
      (either) => either.fold(
        (failure) => FlushbarHelper.createError(
          message: failure.maybeMap(
              orElse: () => null, serverError: (_) => 'Server Error'),
        ).show(route.Router.navigator.key.currentContext),
        (_) => Navigator.canPop(route.Router.navigator.key.currentContext),
      ),
    );
  }

  void listenToName(ProfileState state) {
    state.nameOption.fold(
      () => null,
      (either) => either.fold(
        (failure) => FlushbarHelper.createError(
          message: failure.maybeMap(
            orElse: () => null,
            allFieldsNotFilledError: (value) => 'Invalid Name',
          ),
        ).show(route.Router.navigator.key.currentContext),
        (_) => null,
      ),
    );
  }

  void listenToCollege(ProfileState state) {
    state.collegeOption.fold(
      () => null,
      (either) => either.fold(
        (failure) => FlushbarHelper.createError(
          message: failure.maybeMap(
            orElse: () => null,
            allFieldsNotFilledError: (value) => 'Invalid Institute',
          ),
        ).show(route.Router.navigator.key.currentContext),
        (_) => null,
      ),
    );
  }

  void listenToTwitter(ProfileState state) {
    state.twitterOption.fold(
      () => null,
      (either) => either.fold(
        (failure) => FlushbarHelper.createError(
          message: failure.maybeMap(
            orElse: () => null,
            invalidUrlError: (value) => 'Twitter: Only usernames are allowed',
          ),
        ).show(route.Router.navigator.key.currentContext),
        (_) => null,
      ),
    );
  }

  void listenToInstagram(ProfileState state) {
    state.instagramOption.fold(
      () => null,
      (either) => either.fold(
        (failure) => FlushbarHelper.createError(
          message: failure.maybeMap(
            orElse: () => null,
            invalidUrlError: (value) => 'Instagram: Only usernames are allowed',
          ),
        ).show(route.Router.navigator.key.currentContext),
        (_) => null,
      ),
    );
  }

  void listenToFacebook(ProfileState state) {
    state.facebookOption.fold(
      () => null,
      (either) => either.fold(
        (failure) => FlushbarHelper.createError(
          message: failure.maybeMap(
            orElse: () => null,
            invalidUrlError: (value) => 'Facebook: Only usernames are allowed',
          ),
        ).show(route.Router.navigator.key.currentContext),
        (_) => null,
      ),
    );
  }
}
