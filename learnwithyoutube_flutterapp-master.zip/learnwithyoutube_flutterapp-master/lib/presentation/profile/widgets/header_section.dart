import 'dart:ui';

import 'package:flutter/material.dart' hide DropdownButton, DropdownMenuItem;
import 'package:flutter_app/application/profile/profile_bloc.dart';
import 'package:flutter_app/presentation/core/palette.dart';
import 'package:flutter_app/presentation/profile/widgets/avatar.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:google_fonts/google_fonts.dart';

import 'custom_dropdown.dart' as custom;

class Header extends StatefulWidget {
  final ProfileState state;
  const Header({
    Key key,
    this.state,
  }) : super(key: key);

  @override
  _HeaderState createState() => _HeaderState();
}

class _HeaderState extends State<Header> {
  String selectedValue = '3';

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.only(bottom: 21, top: 14, left: 30, right: 20),
      decoration: BoxDecoration(
          color: Palette.onBlue, borderRadius: BorderRadius.circular(18)),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.end,
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Flexible(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Avatar(
                  state: widget.state,
                ),
                const SizedBox(height: 8),
                Text(
                  widget.state.profile.name,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                      color: Palette.white,
                      fontSize: 18,
                      fontWeight: FontWeight.w700),
                ),
                Row(
                  children: [
                    SvgPicture.asset('assets/profile/mail.svg'),
                    SizedBox(
                      width: 5,
                    ),
                    Flexible(
                      child: Text(
                        widget.state.profile.email,
                        textAlign: TextAlign.start,
                        style: TextStyle(
                            color: Palette.onBackground,
                            fontSize: 11,
                            fontWeight: FontWeight.w500),
                      ),
                    ),
                  ],
                )
              ],
            ),
          ),
          Column(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              FlatButton(
                height: 29,
                minWidth: 71,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(11)),
                color: Palette.white,
                onPressed: () {},
                child: Row(
                  children: [
                    SvgPicture.asset('assets/profile/arrow_left.svg'),
                    SizedBox(
                      width: 5,
                    ),
                    Text(
                      'Skip',
                      textAlign: TextAlign.center,
                      style: const TextStyle(
                          color: Color(0xff1d1d1d),
                          fontSize: 11,
                          fontWeight: FontWeight.w500),
                    ),
                  ],
                ),
              ),
              Container(
                height: 60,
                width: 90,
                // alignment: Alignment.center,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: Colors.black),
                ),
                child: Column(
                  children: [
                    Expanded(
                      child: Container(
                        decoration: const BoxDecoration(
                            color: Color(0xffFEBE16),
                            borderRadius: BorderRadius.only(
                              topLeft: Radius.circular(10),
                              topRight: Radius.circular(10),
                            )),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            const Text(
                              'class',
                              style: TextStyle(
                                  color: Color(0xff1d1d1d),
                                  fontSize: 14,
                                  fontWeight: FontWeight.w600),
                            ),
                            const SizedBox(
                              width: 7,
                            ),
                            custom.DropdownButton(
                                border: Border.all(),
                                value: selectedValue,
                                selectedItemBuilder: (context) => [],
                                onChanged: (String value) {
                                  setState(() {
                                    selectedValue = value;
                                  });
                                },
                                style: TextStyle(
                                    color: const Color(0xff1d1d1d),
                                    fontSize: 14,
                                    fontFamily:
                                        GoogleFonts.poppins().fontFamily,
                                    fontWeight: FontWeight.w500),
                                items: [
                                  '1',
                                  '2',
                                  '3',
                                  '4',
                                  '5',
                                  '6',
                                  '7',
                                  '8',
                                  '9'
                                ]
                                    .map((e) => custom.DropdownMenuItem(
                                          value: e,
                                          child: Container(
                                            height: 27,
                                            alignment: Alignment.center,
                                            decoration: BoxDecoration(
                                                color: e == selectedValue
                                                    ? Palette.onBackground
                                                    : Colors.transparent,
                                                borderRadius:
                                                    BorderRadius.circular(100)),
                                            child: Text(
                                              e,
                                              style: TextStyle(
                                                  color: e == selectedValue
                                                      ? Colors.black
                                                      : Palette.c686868,
                                                  fontSize: 12,
                                                  fontWeight: FontWeight.w500),
                                            ),
                                          ),
                                        ))
                                    .toList(),
                                icon: SvgPicture.asset(
                                    'assets/profile/drop down.svg'))
                          ],
                        ),
                      ),
                    ),
                    Expanded(
                        child: Container(
                      alignment: Alignment.center,
                      decoration: BoxDecoration(
                          color: Palette.white,
                          borderRadius: const BorderRadius.only(
                            bottomLeft: Radius.circular(10),
                            bottomRight: Radius.circular(10),
                          )),
                      child: Text(
                        selectedValue,
                        style: const TextStyle(
                            color: Color(0xff1d1d1d),
                            fontSize: 18,
                            fontWeight: FontWeight.bold),
                      ),
                    )),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class HeaderBackground extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      height: 170,
      padding: const EdgeInsets.only(bottom: 21, top: 14, left: 30, right: 20),
      decoration: BoxDecoration(
          color: Palette.onBlue, borderRadius: BorderRadius.circular(18)),
    );
  }
}
