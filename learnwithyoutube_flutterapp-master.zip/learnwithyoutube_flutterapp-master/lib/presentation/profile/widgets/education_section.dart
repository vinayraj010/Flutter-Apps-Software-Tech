import 'package:flutter/material.dart';
import 'package:flutter_app/application/profile/profile_bloc.dart';
import 'package:flutter_app/domain/profile/profile.dart';
import 'package:flutter_app/presentation/core/palette.dart';
import 'package:flutter_app/presentation/profile/widgets/dialogs/education_dialog.dart';
import 'package:flutter_app/presentation/profile/widgets/section_holder.dart';
import 'package:flutter_app/presentation/profile/widgets/size_reporting_widget.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:scrolling_page_indicator/scrolling_page_indicator.dart';

class Education extends StatefulWidget {
  const Education({
    Key key,
    this.state,
  }) : super(key: key);

  final ProfileState state;

  @override
  _EducationState createState() => _EducationState();
}

class _EducationState extends State<Education> {
  PageController _pageController;
  final List<List<EducationStandard>> _threeList = [];

  List<double> _heights;
  int _currentPage = 0;

  double get _currentHeight => _heights[_currentPage];

  @override
  void initState() {
    _splitEducationsPerThree();

    super.initState();
    _pageController = PageController() //
      ..addListener(() {
        final _newPage = _pageController.page.round();
        if (_currentPage != _newPage) {
          setState(() => _currentPage = _newPage);
        }
      });
  }

  void _splitEducationsPerThree() {
    _threeList.clear();
    final List<EducationStandard> _educations =
        widget.state.profile.educationStandard;

    for (int i = 0; i < _educations.length; i += 3) {
      if (i + 3 <= _educations.length) {
        _threeList.add(_educations.sublist(i, i + 3));
      } else {
        _threeList.add(_educations.sublist(i));
      }
    }
    _heights = _threeList.map((e) => 0.0).toList();
  }

  List<Widget> get _sizeReportingChildren => _threeList
      .map((threeEducations) => OverflowBox(
            //needed, so that parent won't impose its constraints on the children, thus skewing the measurement results.
            minHeight: 0,
            maxHeight: double.infinity,
            alignment: Alignment.topCenter,
            child: SizeReportingWidget(
              onSizeChange: (size) => setState(() =>
                  _heights[_threeList.indexOf(threeEducations)] =
                      size?.height ?? 0),
              child: Align(
                  child: Column(
                children: threeEducations
                    .map(
                      (education) => _Child(
                        asset: 'education_small',
                        title: education.instituteName.name,
                        value: education.standardName.name,
                      ),
                    )
                    .toList(),
              )),
            ),
          ))
      .toList();

  @override
  Widget build(BuildContext context) {
    // _splitEducationsPerThree();
    return SectionHolder(
      title: 'Education',
      icon: 'education',
      onEditPressed: EducationDialog(),
      child: widget.state.profile.educationStandard.isEmpty
          ? const _Empty()
          : Column(
              children: [
                TweenAnimationBuilder<double>(
                  curve: Curves.decelerate,
                  duration: const Duration(milliseconds: 550),
                  tween: Tween<double>(begin: _heights[0], end: _currentHeight),
                  builder: (context, value, child) =>
                      SizedBox(height: value, child: child),
                  child: PageView(
                    controller: _pageController,
                    children: _sizeReportingChildren
                        .asMap() //
                        .map((index, child) => MapEntry(index, child))
                        .values
                        .toList(),
                  ),
                ),
                const SizedBox(
                  height: 30,
                ),
                ScrollingPageIndicator(
                  dotSelectedColor: Palette.onBlue,
                  dotSelectedSize: 8,
                  controller: _pageController,
                  visibleDotCount: 7,
                  itemCount: (widget.state.profile.educationStandard.length / 3)
                      .ceil(),
                )
              ],
            ),
    );
  }
}

class _Empty extends StatelessWidget {
  const _Empty({
    Key key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        SvgPicture.asset('assets/profile/empty_pen.svg'),
        const SizedBox(
          height: 5,
        ),
        Text(
          'Add your education and\nboost up your profile',
          textAlign: TextAlign.center,
          style: const TextStyle(
            color: Color(0xffAFADAD),
            fontSize: 11,
            fontWeight: FontWeight.w400,
          ),
        ),
      ],
    );
  }
}

class _Child extends StatelessWidget {
  final String title;
  final String value;
  final String asset;

  const _Child({
    Key key,
    this.title,
    this.asset,
    this.value,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 9, left: 6, right: 6),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.baseline,
              children: [
                Padding(
                  padding: const EdgeInsets.only(top: 7.0),
                  child: SvgPicture.asset('assets/profile/$asset.svg'),
                ),
                const SizedBox(
                  width: 11,
                ),
                Flexible(
                  child: Text(
                    title,
                    style: TextStyle(
                      color: Palette.c1d1d1d,
                      fontSize: 14,
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: Text(
              value,
              style: TextStyle(
                color: Palette.c1d1d1d,
                fontSize: 14,
                fontWeight: FontWeight.w400,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class EducationBackground extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return SectionHolder(
        title: 'Education',
        icon: 'education',
        onEditPressed: EducationDialog(),
        child: const _Empty());
  }
}
