import 'package:flutter/material.dart';
import 'package:lottie/lottie.dart';

class LoadingPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Lottie.asset('assets/loading_clock.json',
        height: 250, width: 250, frameRate: FrameRate.max);
  }
}
