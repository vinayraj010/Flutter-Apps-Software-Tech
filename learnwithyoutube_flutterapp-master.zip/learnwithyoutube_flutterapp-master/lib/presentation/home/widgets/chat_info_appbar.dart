import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:flutter_app/application/chat/chat_bloc.dart';
import 'package:flutter_app/application/message/message_bloc.dart';
import 'package:flutter_app/core/strings.dart';
import 'package:flutter_app/domain/core/token_model.dart';
import 'package:flutter_app/injection.dart';
import 'package:flutter_app/presentation/core/palette.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_svg/svg.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:hive/hive.dart';

import 'emoji_picker.dart';

class ChatInfoAppbar extends StatefulWidget with PreferredSizeWidget {
  const ChatInfoAppbar({
    Key key,
  }) : super(key: key);

  @override
  _ChatInfoAppbarState createState() => _ChatInfoAppbarState();

  @override
  // TODO: implement preferredSize
  Size get preferredSize => const Size.fromHeight(60);
}

class _ChatInfoAppbarState extends State<ChatInfoAppbar> {
  @override
  Widget build(BuildContext context) {
    Future<void> _takeAttandance() async {
      if (getIt<Box<ResponseTokenModel>>().get(HiveBoxNames.token).roleId ==
          1) {
        await showDialog(
            context: context,
            barrierDismissible: false,
            builder: (context) {
              bool isAttendanceMarked = false;
              String lastSecond = '';
              return StatefulBuilder(
                builder: (BuildContext context,
                    void Function(void Function()) setStateM) {
                  return BackdropFilter(
                    filter: ImageFilter.blur(sigmaX: 8, sigmaY: 8),
                    child: Dialog(
                      backgroundColor: Palette.onBackground,
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(15)),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          const SizedBox(
                            height: 56,
                          ),
                          TweenAnimationBuilder<Duration>(
                            duration: const Duration(minutes: 1),
                            tween: Tween(
                                begin: const Duration(minutes: 1),
                                end: Duration.zero),
                            onEnd: () {
                              Navigator.pop(context);
                            },
                            builder: (BuildContext context, Duration value,
                                Widget child) {
                              final seconds = value.inSeconds % 60;
                              if (!isAttendanceMarked) {
                                lastSecond = seconds.toString();
                              }
                              return Column(
                                children: [
                                  FittedBox(
                                    child: Padding(
                                      padding: const EdgeInsets.symmetric(
                                          horizontal: 60),
                                      child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        children: [
                                          Text(
                                            '00',
                                            textAlign: TextAlign.center,
                                            style: TextStyle(
                                                color: Colors.black,
                                                fontWeight: FontWeight.bold,
                                                fontFamily:
                                                    GoogleFonts.poppins()
                                                        .fontFamily,
                                                fontSize: 48,
                                                letterSpacing: 5),
                                          ),
                                          Padding(
                                            padding: const EdgeInsets.symmetric(
                                                horizontal: 5),
                                            child: Column(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.end,
                                              children: [
                                                Container(
                                                  height: 8,
                                                  width: 8,
                                                  decoration: BoxDecoration(
                                                      shape: BoxShape.circle,
                                                      color: Colors.black),
                                                ),
                                                const SizedBox(
                                                  height: 7,
                                                ),
                                                Container(
                                                  height: 8,
                                                  width: 8,
                                                  decoration: BoxDecoration(
                                                      shape: BoxShape.circle,
                                                      color: Colors.black),
                                                ),
                                              ],
                                            ),
                                          ),
                                          Text(
                                            '00',
                                            textAlign: TextAlign.center,
                                            style: TextStyle(
                                                color: Colors.black,
                                                fontWeight: FontWeight.bold,
                                                fontFamily:
                                                    GoogleFonts.poppins()
                                                        .fontFamily,
                                                fontSize: 48,
                                                letterSpacing: 5),
                                          ),
                                          Padding(
                                            padding: const EdgeInsets.symmetric(
                                                horizontal: 5),
                                            child: Column(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.end,
                                              children: [
                                                Container(
                                                  height: 8,
                                                  width: 8,
                                                  decoration: BoxDecoration(
                                                      shape: BoxShape.circle,
                                                      color: Colors.black),
                                                ),
                                                const SizedBox(
                                                  height: 7,
                                                ),
                                                Container(
                                                  height: 8,
                                                  width: 8,
                                                  decoration: BoxDecoration(
                                                      shape: BoxShape.circle,
                                                      color: Colors.black),
                                                ),
                                              ],
                                            ),
                                          ),
                                          if (isAttendanceMarked)
                                            Text(
                                              lastSecond.padLeft(2, '0'),
                                              textAlign: TextAlign.center,
                                              style: TextStyle(
                                                  color: Colors.black,
                                                  fontWeight: FontWeight.bold,
                                                  fontFamily:
                                                      GoogleFonts.poppins()
                                                          .fontFamily,
                                                  fontSize: 48,
                                                  letterSpacing: 5),
                                            )
                                          else
                                            AnimatedSwitcher(
                                              duration: const Duration(
                                                  milliseconds: 250),
                                              layoutBuilder: (currentChild,
                                                      previousChildren) =>
                                                  currentChild,
                                              transitionBuilder:
                                                  (child, animation) =>
                                                      FadeTransition(
                                                opacity: animation,
                                                child: SlideTransition(
                                                  position: Tween(
                                                    begin:
                                                        const Offset(0.0, 0.2),
                                                    end: const Offset(0.0, 0.0),
                                                  ).animate(animation),
                                                  child: child,
                                                ),
                                              ),
                                              child: Text(
                                                lastSecond.padLeft(2, '0'),
                                                textAlign: TextAlign.center,
                                                style: TextStyle(
                                                    color: Colors.black,
                                                    fontWeight: FontWeight.bold,
                                                    fontFamily:
                                                        GoogleFonts.poppins()
                                                            .fontFamily,
                                                    fontSize: 48,
                                                    letterSpacing: 5),
                                                key: ValueKey(seconds),
                                              ),
                                            ),
                                        ],
                                      ),
                                    ),
                                  ),
                                  const SizedBox(height: 30),
                                  child
                                ],
                              );
                            },
                            child: Column(
                              children: [
                                AnimatedSwitcher(
                                  duration: const Duration(milliseconds: 250),
                                  layoutBuilder:
                                      (currentChild, previousChildren) =>
                                          currentChild,
                                  transitionBuilder: (child, animation) =>
                                      FadeTransition(
                                    opacity: animation,
                                    child: SlideTransition(
                                      position: Tween(
                                        begin: const Offset(0.0, 0.2),
                                        end: const Offset(0.0, 0.0),
                                      ).animate(animation),
                                      child: child,
                                    ),
                                  ),
                                  child: Text(
                                    isAttendanceMarked
                                        ? 'Saved!'
                                        : 'Mark your attendance',
                                    style: const TextStyle(
                                      color: Color(0xff1D1D1D),
                                    ),
                                    key: ValueKey(isAttendanceMarked),
                                  ),
                                ),
                                const SizedBox(height: 40),
                                GestureDetector(
                                  onTap: () async {
                                    setStateM(() {
                                      isAttendanceMarked = true;
                                    });
                                    await Future.delayed(
                                            const Duration(milliseconds: 1200))
                                        .whenComplete(
                                            () => Navigator.pop(context));
                                  },
                                  child: AnimatedCrossFade(
                                    secondChild: Stack(
                                      alignment: Alignment.center,
                                      children: [
                                        SvgPicture.asset(
                                            'assets/chat/saved.svg'),
                                        SvgPicture.asset(
                                            'assets/chat/tick.svg'),
                                      ],
                                    ),
                                    crossFadeState: isAttendanceMarked
                                        ? CrossFadeState.showSecond
                                        : CrossFadeState.showFirst,
                                    firstChild:
                                        SvgPicture.asset('assets/chat/go.svg'),
                                    duration: const Duration(milliseconds: 250),
                                  ),
                                )
                              ],
                            ),
                          ),
                          const SizedBox(
                            height: 56,
                          ),
                        ],
                      ),
                    ),
                  );
                },
              );
            });
      } else {
        BlocProvider.of<ChatBloc>(context)
            .add(const ChatEvent.addTeacherAttendance(chatId: 56));
      }
    }

    Future<void> _feedback() async {
      await showDialog(
          context: context,
          barrierDismissible: false,
          builder: (context) {
            return BackdropFilter(
              filter: ImageFilter.blur(sigmaX: 8, sigmaY: 8),
              child: Dialog(
                backgroundColor: Palette.onBackground,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(15)),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const SizedBox(
                      height: 56,
                    ),
                    Text(
                      'How was your experience with us?',
                      style: const TextStyle(
                          color: Color(0xff1D1D1D), fontSize: 16),
                    ),
                    const SizedBox(
                      height: 31,
                    ),
                    const Padding(
                      padding: EdgeInsets.symmetric(horizontal: 10),
                      child: FittedBox(child: EmojiFeedback()),
                    ),
                    const SizedBox(
                      height: 50,
                    ),
                    RaisedButton(
                      elevation: 0,
                      color: Palette.onBlue,
                      onPressed: () => Navigator.pop(context),
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(16)),
                      child: Container(
                        alignment: Alignment.center,
                        height: 50,
                        width: 130,
                        child: Text(
                          'Submit',
                          textAlign: TextAlign.center,
                          style: TextStyle(
                              color: Palette.white,
                              fontSize: 18,
                              fontWeight: FontWeight.w600),
                        ),
                      ),
                    ),
                    const SizedBox(
                      height: 42,
                    ),
                  ],
                ),
              ),
            );
          });
    }

    return PreferredSize(
      preferredSize: const Size.fromHeight(60),
      child: DecoratedBox(
        decoration: const BoxDecoration(boxShadow: [
          BoxShadow(
              color: Color.fromRGBO(21, 12, 58, 0.21),
              blurRadius: 33,
              spreadRadius: 15,
              offset: Offset(0, 15))
        ]),
        child: AppBar(
          toolbarHeight: 60,
          backgroundColor: Palette.onBlue,
          elevation: 0,
          titleSpacing: 0.0,
          title: Padding(
            padding: const EdgeInsets.only(left: 30),
            child: Row(
              children: <Widget>[
                GestureDetector(
                  onTap: () async {
                    await _takeAttandance();
                  },
                  child: SvgPicture.asset('assets/chat/appbar/members.svg'),
                ),
                const SizedBox(width: 16),
                Text(
                  '19',
                  style: TextStyle(
                      color: Colors.white,
                      fontFamily: GoogleFonts.poppins().fontFamily,
                      fontSize: 16,
                      fontWeight: FontWeight.w500),
                ),
                const SizedBox(width: 55),
                GestureDetector(
                    onTap: () async {
                      await _feedback();
                    },
                    child:
                        SvgPicture.asset('assets/chat/appbar/user_online.svg')),
                const SizedBox(width: 16),
                Text(
                  '17',
                  style: TextStyle(
                      color: Colors.white,
                      fontFamily: GoogleFonts.poppins().fontFamily,
                      fontSize: 16,
                      fontWeight: FontWeight.w500),
                ),
              ],
            ),
          ),
          actions: <Widget>[
            GestureDetector(
              onTap: () {
                BlocProvider.of<MessageBloc>(context)
                    .add(const MessageEvent.switchToStandardAppBar());
              },
              child: RotatedBox(
                  quarterTurns: 2,
                  child: SvgPicture.asset('assets/chat/arrow.svg')),
            ),
            const SizedBox(width: 28),
          ],
        ),
      ),
    );
  }
}
