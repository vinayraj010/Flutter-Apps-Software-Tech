import 'dart:collection';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter_app/domain/chat/message.dart';
import 'package:flutter_app/presentation/core/palette.dart';
import 'package:just_audio/just_audio.dart';

class AudioMessage extends StatefulWidget {
  final MessageBody element;

  const AudioMessage({Key key, this.element}) : super(key: key);

  @override
  _AudioMessageState createState() => _AudioMessageState();
}

class _AudioMessageState extends State<AudioMessage>
    with SingleTickerProviderStateMixin {
  final AudioPlayer player = AudioPlayer();
  HashMap<String, Widget> _hashMap;

  final ValueNotifier<int> _progress = ValueNotifier<int>(0);
  final ValueNotifier<Size> _size = ValueNotifier<Size>(const Size(0, 0));

  AnimationController _controller;
  BorderRadius _messageBorderRadius;

  Color _headingColor;

  final GlobalKey _sizeKey = GlobalKey();

  @override
  void dispose() {
    player.dispose();
    _controller.dispose();
    super.dispose();
  }

  @override
  void initState() {
    _headingColor =
        widget.element.isSent ? Colors.transparent : const Color(0xffFEBE16);
    _hashMap = HashMap<String, Widget>();
    if (widget.element.isSent) {
      _messageBorderRadius = const BorderRadius.only(
        topLeft: Radius.circular(10),
        bottomRight: Radius.circular(10),
        bottomLeft: Radius.circular(10),
      );
    } else {
      _messageBorderRadius = const BorderRadius.only(
        topRight: Radius.circular(10),
        bottomRight: Radius.circular(10),
        bottomLeft: Radius.circular(10),
      );
    }
    _controller = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 400));
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    Future _future(String url) async {
      await player.setUrl(url);
      final _totalDuration = await player.durationFuture;
      _progress.value = _totalDuration.inSeconds;
    }

    if (_hashMap[widget.element.message] == null) {
      _hashMap[widget.element.message] = FutureBuilder(
        future: _future(widget.element.message),
        builder: (BuildContext context, AsyncSnapshot snapshot) {
          if (snapshot.connectionState == ConnectionState.done) {
            return StreamBuilder(
              stream: player.getPositionStream(),
              initialData: const Duration(seconds: 0),
              builder:
                  (BuildContext context, AsyncSnapshot<Duration> snapshot) {
                return AnimatedBuilder(
                  animation: Listenable.merge([_progress, _size]),
                  builder: (BuildContext context, Widget child) {
                    SchedulerBinding.instance.addPostFrameCallback((timeStamp) {
                      _size.value = _sizeKey.currentContext.size;
                      print(
                          '////////////////////////////////////${_size.value}');
                    });
                    final constraints = BoxConstraints(
                      maxWidth: MediaQuery.of(context)
                          .size
                          .width, // maxwidth calculated
                      minHeight: 0.0,
                      minWidth: 0.0,
                    );

                    final RenderParagraph renderParagraph = RenderParagraph(
                        TextSpan(
                          text: widget.element.sender.name,
                          style: const TextStyle(
                            fontSize: 16,
                          ),
                        ),
                        maxLines: 1,
                        textDirection: TextDirection.ltr);
                    renderParagraph.layout(constraints);
                    final double nameWidth =
                        renderParagraph.getMinIntrinsicWidth(16).ceilToDouble();

                    final RenderParagraph renderTime = RenderParagraph(
                        TextSpan(
                          text:
                              "${widget.element.createdAt.toString().split(' ')[1].split(':')[0]}:${widget.element.createdAt.toString().split(' ')[1].split(':')[1]}",
                          style: const TextStyle(
                            fontSize: 14,
                          ),
                        ),
                        maxLines: 1,
                        textDirection: TextDirection.ltr);
                    renderParagraph.layout(constraints);
                    final double timeWidth =
                        (MediaQuery.of(context).size.width * 0.75) -
                            renderTime.getMinIntrinsicWidth(16).ceilToDouble();

                    final String currentSecondsStr = snapshot.data
                        .toString()
                        .split('.')
                        .first
                        .padLeft(8, "0");
                    final String totalSecondsStr =
                        Duration(seconds: _progress.value)
                            .toString()
                            .split('.')
                            .first
                            .padLeft(8, "0");

                    double _currentWidth = (snapshot.data.inMicroseconds /
                            Duration(seconds: _progress.value).inMicroseconds) *
                        MediaQuery.of(context).size.width *
                        0.75;

                    final Color _nameColor = _currentWidth > (nameWidth + 15)
                        ? Colors.white
                        : _headingColor;

                    final Color _timeColor = _currentWidth > (timeWidth + 25)
                        ? const Color(0xff6646E7)
                        : const Color(0xff6646E7);
                    double smallPlayerWidth = (snapshot.data.inMicroseconds /
                            Duration(seconds: _progress.value).inMicroseconds) *
                        _size.value.width;

                    if (player.playbackState == AudioPlaybackState.completed) {
                      _controller.reverse();
                      _currentWidth = 0.0;
                      smallPlayerWidth = 0.0;
                      SchedulerBinding.instance
                          .addPostFrameCallback((timeStamp) {
                        setState(() {});
                      });
                      player.stop();
                    }

                    return Stack(
                      children: [
                        Container(
                          height: 98,
                          width: MediaQuery.of(context).size.width * 0.75,
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(
                            color: widget.element.isSent
                                ? Palette.userChatColor
                                : Colors.white,
                            borderRadius: _messageBorderRadius,
                          ),
                        ),
                        AnimatedContainer(
                          decoration: BoxDecoration(
                              color: const Color(0xff8ACA50),
                              borderRadius: _messageBorderRadius),
                          curve: Curves.easeOutExpo,
                          duration: const Duration(milliseconds: 1000),
                          constraints: BoxConstraints.tightFor(
                            width: _currentWidth,
                            height: 98,
                          ),
                        ),
                        Positioned(
                          bottom: 10,
                          child: Container(
                            width: MediaQuery.of(context).size.width * 0.75,
                            padding: const EdgeInsets.symmetric(horizontal: 15),
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                IconButton(
                                  icon: Container(
                                    height: 30,
                                    width: 30,
                                    alignment: Alignment.center,
                                    decoration: const BoxDecoration(
                                        shape: BoxShape.circle,
                                        color: Colors.black12),
                                    child: AnimatedIcon(
                                      icon: AnimatedIcons.play_pause,
                                      color: Colors.white,
                                      progress: _controller,
                                    ),
                                  ),
                                  onPressed: () {
                                    if (_controller.isCompleted) {
                                      _controller.reverse();
                                      player.pause();
                                    } else {
                                      _controller.forward();
                                      player.play();
                                    }
                                  },
                                ),
                                Expanded(
                                  key: _sizeKey,
                                  child: GestureDetector(
                                    onTapUp: (details) {
                                      print(details.localPosition.dx);
                                    },
                                    child: Stack(
                                      alignment: Alignment.centerLeft,
                                      children: [
                                        Container(
                                          margin:
                                              const EdgeInsets.only(right: 12),
                                          height: 6,
                                          decoration: BoxDecoration(
                                              color: const Color(0xff8ACA50),
                                              borderRadius:
                                                  BorderRadius.circular(3)),
                                        ),
                                        AnimatedContainer(
                                          curve: Curves.easeOutExpo,
                                          duration: const Duration(
                                              milliseconds: 1000),
                                          width: smallPlayerWidth,
                                          margin:
                                              const EdgeInsets.only(right: 12),
                                          height: 6,
                                          decoration: BoxDecoration(
                                              color: Colors.white,
                                              borderRadius:
                                                  BorderRadius.circular(3)),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                                Text(
                                  '$currentSecondsStr / $totalSecondsStr',
                                  style:
                                      const TextStyle(color: Color(0xff1D1D1D)),
                                  key: ValueKey(currentSecondsStr),
                                )
                              ],
                            ),
                          ),
                        ),
                        Positioned(
                          top: 10,
                          left: 15,
                          height: 40,
                          width: MediaQuery.of(context).size.width * 0.7,
                          child: Align(
                            alignment: Alignment.centerLeft,
                            child: Column(
                              children: [
                                Row(
                                  mainAxisSize: MainAxisSize.min,
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    if (widget.element.isSent)
                                      AnimatedSwitcher(
                                        duration:
                                            const Duration(milliseconds: 150),
                                        child: Text(
                                          widget.element.sender.name,
                                          style: TextStyle(
                                              color: widget.element.isSent
                                                  ? Colors.transparent
                                                  : _nameColor),
                                          key: ValueKey(_nameColor),
                                        ),
                                      )
                                    else
                                      const Text(''),
                                    const Spacer(),
                                    AnimatedSwitcher(
                                      duration: const Duration(milliseconds: 1),
                                      child: Text(
                                        "${widget.element.createdAt.toString().split(' ')[1].split(':')[0]}:${widget.element.createdAt.toString().split(' ')[1].split(':')[1]}",
                                        style: TextStyle(
                                          color: _timeColor,
                                          fontSize: 14,
                                        ),
                                        key: ValueKey(_timeColor),
                                      ),
                                    ),
                                  ],
                                ),
                                const SizedBox(
                                  height: 10,
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    );
                  },
                );
              },
            );
          } else {
            return const CupertinoActivityIndicator();
          }
        },
      );

      return _hashMap[widget.element.message];
    } else {
      return _hashMap[widget.element.message];
    }
  }
}
