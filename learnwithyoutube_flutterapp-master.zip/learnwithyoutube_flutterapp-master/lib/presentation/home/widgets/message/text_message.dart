import 'package:flutter/material.dart';
import 'package:flutter_app/domain/chat/message.dart';
import 'package:flutter_linkify/flutter_linkify.dart';
import 'package:linkify/linkify.dart';
import 'package:url_launcher/url_launcher.dart';

class TextMessage extends StatelessWidget {
  final MessageBody element;

  const TextMessage({Key key, this.element}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    

    String extractLink() {
      final List<LinkifyElement> elements = linkify(element.message,
          options: LinkifyOptions(
            humanize: false,
            looseUrl: true,
          ));
      for (final LinkifyElement e in elements) {
        if (e is LinkableElement) {
          return e.url;
        }
      }
      return null;
    }

    if (extractLink() == null) {
      return Text(
        element.message,
        softWrap: true,
        style: const TextStyle(color: Color(0xff000000), fontSize: 16),
      );
    } else {
      return Linkify(
        onOpen: (link) async {
          if (await canLaunch(link.url)) {
            await launch(extractLink());
          } else {
            throw 'Could not launch ${link.url}';
          }
        },
        text: element.message,
        style: TextStyle(color: Colors.white),
      );
    }
  }
}
