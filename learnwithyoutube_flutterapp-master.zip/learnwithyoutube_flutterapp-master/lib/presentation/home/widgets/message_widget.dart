import 'dart:developer';

import 'package:date_format/date_format.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter_app/application/message/message_bloc.dart';
import 'package:flutter_app/domain/chat/message.dart';
import 'package:flutter_app/presentation/core/palette.dart';
import 'package:flutter_app/presentation/home/widgets/sticky_grouped_header.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:vs_scrollbar/vs_scrollbar.dart';

import 'message/audio_message.dart';
import 'message/document_message.dart';
import 'message/image_message.dart';
import 'message/text_message.dart';
import 'message/video_message.dart';

class MessageWidget extends StatefulWidget {
  final List<MessageBody> messages;
  final int chatId;
  final MessageState state;
  final bool isLoading;

  MessageWidget(
      {Key key, this.messages, this.chatId, this.isLoading, this.state})
      : super(key: key);

  @override
  _MessageWidgetState createState() => _MessageWidgetState();
}

class _MessageWidgetState extends State<MessageWidget>
    with SingleTickerProviderStateMixin {
  AnimationController _animationController;

  MessageBody selectedElement;

  void _onMessageTapped(MessageBody element) {
    if (widget.state.someOrNOSelectedElements
        .fold(() => false, (a) => a.contains(element) && a.length > 1)) {
      BlocProvider.of<MessageBloc>(context)
          .add(MessageEvent.removeFromSelectedMessages(element: element));
    } else if (widget.state.someOrNOSelectedElements
        .fold(() => false, (a) => a.contains(element) && a.length == 1)) {
      BlocProvider.of<MessageBloc>(context)
          .add(const MessageEvent.switchToStandardAppBar());
    } else if (widget.state.someOrNOSelectedElements
        .fold(() => false, (a) => !a.contains(element) && a.isNotEmpty)) {
      BlocProvider.of<MessageBloc>(context)
          .add(MessageEvent.addToSelectedMessages(element: element));
    } else if (widget.state.someOrNOSelectedElements
        .fold(() => false, (a) => !a.contains(element))) {
    } else {}
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  @override
  void initState() {
    _animationController = AnimationController(
        duration: const Duration(milliseconds: 300), vsync: this)
      ..addStatusListener((status) async {
        if (status == AnimationStatus.completed) {
          await Future.delayed(const Duration(seconds: 2));
          _animationController.reverse();
        }
      });

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: NotificationListener<ScrollNotification>(
        onNotification: (scrollInfo) {
          if (scrollInfo is UserScrollNotification) {
          } else {
            _animationController.forward();
          }
          if (scrollInfo.metrics.pixels == scrollInfo.metrics.maxScrollExtent) {
            if (!widget.isLoading) {
              BlocProvider.of<MessageBloc>(context)
                  .add(MessageEvent.getChatMessages(chatId: widget.chatId));
              return false;
            }
            return true;
          }
          return true;
        },
        child: VsScrollbar(
          scrollDirection: Axis.vertical,
          radius: 10,
          thickness: 5,
          color: Palette.onBlue,
          child: StickyGroupedListView<MessageBody, DateTime>(
            reverse: true,
            elements: widget.messages,
            order: StickyGroupedListOrder.ASC,
            groupBy: (MessageBody element) {
              return DateTime(element.createdAt.year, element.createdAt.month,
                  element.createdAt.day);
            },
            groupComparator: (DateTime value1, DateTime value2) =>
                value2.compareTo(value1),
            itemComparator: (MessageBody element1, MessageBody element2) {
              return element2.createdAt.compareTo(element1.createdAt);
            },
            floatingHeader: true,
            headerAnimation: Tween<Offset>(
              begin: const Offset(0.0, -1.0),
              end: const Offset(0.0, 0.0),
            ).animate(_animationController),
            groupSeparatorBuilder: (MessageBody element) {
              final int _year = int.parse(
                  element.createdAt.toString().split(' ')[0].split('-')[0]);
              final int _month = int.parse(
                  element.createdAt.toString().split(' ')[0].split('-')[1]);
              final int _day = int.parse(
                  element.createdAt.toString().split(' ')[0].split('-')[2]);

              final DateTime _dateTime = DateTime(_year, _month, _day);
              final DateTime now = DateTime.now();

              final String _formatedDate =
                  formatDate(_dateTime, ['M', ' ', 'd', ' ', 'yyyy']);

              String _returnDate() {
                if (_dateTime
                        .difference(DateTime(now.year, now.month, now.day))
                        .inDays ==
                    0) {
                  return 'Today';
                } else if (_dateTime
                        .difference(DateTime(now.year, now.month, now.day))
                        .inDays ==
                    -1) {
                  return 'Yesterday';
                } else {
                  return _formatedDate;
                }
              }

              return Padding(
                padding: const EdgeInsets.symmetric(vertical: 15),
                child: Text(
                  _returnDate() ?? '',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                      color: const Color(0xff686868),
                      fontFamily: GoogleFonts.poppins().fontFamily),
                ),
              );
            },
            itemBuilder: (_, MessageBody element) {
              final GlobalKey _key = GlobalKey();
              BorderRadius _messageBorderRadius;

              if (element.isSent) {
                _messageBorderRadius = const BorderRadius.only(
                  topLeft: Radius.circular(10),
                  bottomRight: Radius.circular(10),
                  bottomLeft: Radius.circular(10),
                );
              } else {
                _messageBorderRadius = const BorderRadius.only(
                  topRight: Radius.circular(10),
                  bottomRight: Radius.circular(10),
                  bottomLeft: Radius.circular(10),
                );
              }

              return GestureDetector(
                onLongPress: () {
                  BlocProvider.of<MessageBloc>(context).add(
                      MessageEvent.addToSelectedMessages(element: element));
                },
                onTap: () => _onMessageTapped(element),
                child: DecoratedBox(
                  decoration: BoxDecoration(
                      color: widget.state.someOrNOSelectedElements
                              .fold(() => false, (a) => a.contains(element))
                          ? const Color.fromRGBO(102, 70, 231, 0.48)
                          : Colors.transparent),
                  child: Container(
                      margin: const EdgeInsets.symmetric(
                          vertical: 8, horizontal: 15),
                      alignment: element.isSent
                          ? Alignment.topRight
                          : Alignment.topLeft,
                      // width: MediaQuery.of(context).size.width * 0.75,

                      child: Container(
                          padding: const EdgeInsets.all(12),
                          constraints: BoxConstraints(
                              maxWidth:
                                  MediaQuery.of(context).size.width * 0.75),
                          decoration: BoxDecoration(
                            color: (element.isSent)
                                ? Palette.userChatColor
                                : Colors.white,
                            borderRadius: _messageBorderRadius,
                          ),
                          child: _message(element))),
                ),
              );
            },
          ),
        ),
      ),
    );
  }

  Size _textSize(String text) {
    final TextPainter textPainter = TextPainter(
        text: TextSpan(
            text: text,
            style: const TextStyle(color: Color(0xff000000), fontSize: 16)),
        textDirection: TextDirection.ltr)
      ..layout(minWidth: 0, maxWidth: MediaQuery.of(context).size.width * 0.75);
    return textPainter.size;
  }

  Widget _message(MessageBody element) {
    if (element.typeId == 1) {
      log(_textSize(element.message).width.toString());
      if (_textSize(element.message).width >
          MediaQuery.of(context).size.width * 0.72) {
        return Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Row(
              children: [
                Text(
                  element.sender.name,
                  style: TextStyle(
                    color: element.isSent
                        ? const Color(0xff6646E7)
                        : const Color(0xffFEBE16),
                    fontSize: 14,
                  ),
                ),
                Spacer(),
                Text(
                  "${element.createdAt.toString().split(' ')[1].split(':')[0]}:${element.createdAt.toString().split(' ')[1].split(':')[1]}",
                  style: TextStyle(
                    color: element.isSent
                        ? const Color(0xff6646E7)
                        : const Color(0xffFEBE16),
                    fontSize: 14,
                  ),
                ),
              ],
            ),
            const SizedBox(
              height: 10,
            ),
            MessageDeciderChild(
              element: element,
            ),
          ],
        );
      } else {
        return Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            MessageDeciderChild(
              element: element,
            ),
            const SizedBox(
              width: 15,
            ),
            Text(
              "${element.createdAt.toString().split(' ')[1].split(':')[0]}:${element.createdAt.toString().split(' ')[1].split(':')[1]}",
              style: TextStyle(
                color: element.isSent
                    ? const Color(0xff6646E7)
                    : const Color(0xffFEBE16),
                fontSize: 14,
              ),
            ),
          ],
        );
      }
    } else {
      return Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Text(
                element.sender.name,
                style: TextStyle(
                  color: element.isSent
                      ? const Color(0xff6646E7)
                      : const Color(0xffFEBE16),
                  fontSize: 14,
                ),
              ),
              Spacer(),
              Text(
                "${element.createdAt.toString().split(' ')[1].split(':')[0]}:${element.createdAt.toString().split(' ')[1].split(':')[1]}",
                style: TextStyle(
                  color: element.isSent
                      ? const Color(0xff6646E7)
                      : const Color(0xffFEBE16),
                  fontSize: 14,
                ),
              ),
            ],
          ),
          const SizedBox(
            height: 10,
          ),
          MessageDeciderChild(
            element: element,
          ),
        ],
      );
    }
  }
}

class MessageDeciderChild extends StatelessWidget {
  final MessageBody element;

  const MessageDeciderChild({Key key, this.element}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return _child();
  }

  Widget _child() {
    switch (element.typeId) {
      case 1:
        return TextMessage(element: element);
        break;
      case 2:
        return ImageMessage(element: element);
        break;
      case 3:
        return VideoMessage(element: element);
        break;
      case 4:
        return AudioMessage(element: element);
        break;
      case 5:
        return DocumentMessage(element: element);
        break;
      default:
        return TextMessage(
          element: element,
        );
    }
  }
}
