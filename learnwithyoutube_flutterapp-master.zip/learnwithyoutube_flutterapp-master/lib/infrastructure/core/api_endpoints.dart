const String _domain = "https://api.beyondexams.org/api/v1";

mixin ApiEndpoint {
  static const String verifyFirebaseAccessToken =
      '$_domain/verifyFirebaseAccessToken';
  static const String refreshFirebase = '$_domain/refreshFirebase';
  static const String logout = '$_domain/logout';

  //Chats
  static const String createChat = '$_domain/create_chat';
  static const String getAllChats = '$_domain/get_all_chats';
  static const String getChatMessages = '$_domain/get_chat_messages';
  static const String sendMessage = '$_domain/send_message';
  static const String sendMultiMedia = '$_domain/send_multimedia_message';
  static const String addTeacherAttendance = '$_domain/add_teacher_attendance';
  static const String addStudentAttendance = '$_domain/add_student_attendance';

  //Profile
  static const String submitUserProfile = '$_domain/submit_user_profile';
  static const String getUserProfile = '$_domain/get_user_profile';
  static const String updateUserProfile = '$_domain/update_user_profile';
  static const String getAllCountries = '$_domain/get_all_countries';
  static const String addUserFacebookLink = '$_domain/add_user_facebook_link';
  static const String addUserTwitterLink = '$_domain/add_user_twitter_url';
  static const String addUserInstagramLink = '$_domain/add_user_instagram_link';
  static const String addUserCertificate = '$_domain/add_user_certificate';
  static const String updateUserCertificate =
      '$_domain/update_user_certificate';
  static const String updateDomain = '$_domain/update_user_skill';
  static const String updateEducationInstitute =
      '$_domain/update_user_education_institute';
  static const String updateEducationStandard =
      '$_domain/update_user_education_standard';
  static const String deleteDomain = '$_domain/delete_skill';
  static const String deleteEducation = '$_domain/delete_education';
  static const String deleteCertificate = '$_domain/delete_certificate';
}
