// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies

part of 'profile_failure.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

/// @nodoc
class _$ProfileFailureTearOff {
  const _$ProfileFailureTearOff();

// ignore: unused_element
  _ServerError serverError() {
    return const _ServerError();
  }

// ignore: unused_element
  _InvalidEmailError invalidEmailError() {
    return const _InvalidEmailError();
  }

// ignore: unused_element
  _InvalidUrlError invalidUrlError() {
    return const _InvalidUrlError();
  }

// ignore: unused_element
  _AllFieldsNotFilledError allFieldsNotFilledError({String message}) {
    return _AllFieldsNotFilledError(
      message: message,
    );
  }
}

/// @nodoc
// ignore: unused_element
const $ProfileFailure = _$ProfileFailureTearOff();

/// @nodoc
mixin _$ProfileFailure {
  @optionalTypeArgs
  Result when<Result extends Object>({
    @required Result serverError(),
    @required Result invalidEmailError(),
    @required Result invalidUrlError(),
    @required Result allFieldsNotFilledError(String message),
  });
  @optionalTypeArgs
  Result maybeWhen<Result extends Object>({
    Result serverError(),
    Result invalidEmailError(),
    Result invalidUrlError(),
    Result allFieldsNotFilledError(String message),
    @required Result orElse(),
  });
  @optionalTypeArgs
  Result map<Result extends Object>({
    @required Result serverError(_ServerError value),
    @required Result invalidEmailError(_InvalidEmailError value),
    @required Result invalidUrlError(_InvalidUrlError value),
    @required Result allFieldsNotFilledError(_AllFieldsNotFilledError value),
  });
  @optionalTypeArgs
  Result maybeMap<Result extends Object>({
    Result serverError(_ServerError value),
    Result invalidEmailError(_InvalidEmailError value),
    Result invalidUrlError(_InvalidUrlError value),
    Result allFieldsNotFilledError(_AllFieldsNotFilledError value),
    @required Result orElse(),
  });
}

/// @nodoc
abstract class $ProfileFailureCopyWith<$Res> {
  factory $ProfileFailureCopyWith(
          ProfileFailure value, $Res Function(ProfileFailure) then) =
      _$ProfileFailureCopyWithImpl<$Res>;
}

/// @nodoc
class _$ProfileFailureCopyWithImpl<$Res>
    implements $ProfileFailureCopyWith<$Res> {
  _$ProfileFailureCopyWithImpl(this._value, this._then);

  final ProfileFailure _value;
  // ignore: unused_field
  final $Res Function(ProfileFailure) _then;
}

/// @nodoc
abstract class _$ServerErrorCopyWith<$Res> {
  factory _$ServerErrorCopyWith(
          _ServerError value, $Res Function(_ServerError) then) =
      __$ServerErrorCopyWithImpl<$Res>;
}

/// @nodoc
class __$ServerErrorCopyWithImpl<$Res>
    extends _$ProfileFailureCopyWithImpl<$Res>
    implements _$ServerErrorCopyWith<$Res> {
  __$ServerErrorCopyWithImpl(
      _ServerError _value, $Res Function(_ServerError) _then)
      : super(_value, (v) => _then(v as _ServerError));

  @override
  _ServerError get _value => super._value as _ServerError;
}

/// @nodoc
class _$_ServerError implements _ServerError {
  const _$_ServerError();

  @override
  String toString() {
    return 'ProfileFailure.serverError()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) || (other is _ServerError);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  Result when<Result extends Object>({
    @required Result serverError(),
    @required Result invalidEmailError(),
    @required Result invalidUrlError(),
    @required Result allFieldsNotFilledError(String message),
  }) {
    assert(serverError != null);
    assert(invalidEmailError != null);
    assert(invalidUrlError != null);
    assert(allFieldsNotFilledError != null);
    return serverError();
  }

  @override
  @optionalTypeArgs
  Result maybeWhen<Result extends Object>({
    Result serverError(),
    Result invalidEmailError(),
    Result invalidUrlError(),
    Result allFieldsNotFilledError(String message),
    @required Result orElse(),
  }) {
    assert(orElse != null);
    if (serverError != null) {
      return serverError();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  Result map<Result extends Object>({
    @required Result serverError(_ServerError value),
    @required Result invalidEmailError(_InvalidEmailError value),
    @required Result invalidUrlError(_InvalidUrlError value),
    @required Result allFieldsNotFilledError(_AllFieldsNotFilledError value),
  }) {
    assert(serverError != null);
    assert(invalidEmailError != null);
    assert(invalidUrlError != null);
    assert(allFieldsNotFilledError != null);
    return serverError(this);
  }

  @override
  @optionalTypeArgs
  Result maybeMap<Result extends Object>({
    Result serverError(_ServerError value),
    Result invalidEmailError(_InvalidEmailError value),
    Result invalidUrlError(_InvalidUrlError value),
    Result allFieldsNotFilledError(_AllFieldsNotFilledError value),
    @required Result orElse(),
  }) {
    assert(orElse != null);
    if (serverError != null) {
      return serverError(this);
    }
    return orElse();
  }
}

abstract class _ServerError implements ProfileFailure {
  const factory _ServerError() = _$_ServerError;
}

/// @nodoc
abstract class _$InvalidEmailErrorCopyWith<$Res> {
  factory _$InvalidEmailErrorCopyWith(
          _InvalidEmailError value, $Res Function(_InvalidEmailError) then) =
      __$InvalidEmailErrorCopyWithImpl<$Res>;
}

/// @nodoc
class __$InvalidEmailErrorCopyWithImpl<$Res>
    extends _$ProfileFailureCopyWithImpl<$Res>
    implements _$InvalidEmailErrorCopyWith<$Res> {
  __$InvalidEmailErrorCopyWithImpl(
      _InvalidEmailError _value, $Res Function(_InvalidEmailError) _then)
      : super(_value, (v) => _then(v as _InvalidEmailError));

  @override
  _InvalidEmailError get _value => super._value as _InvalidEmailError;
}

/// @nodoc
class _$_InvalidEmailError implements _InvalidEmailError {
  const _$_InvalidEmailError();

  @override
  String toString() {
    return 'ProfileFailure.invalidEmailError()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) || (other is _InvalidEmailError);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  Result when<Result extends Object>({
    @required Result serverError(),
    @required Result invalidEmailError(),
    @required Result invalidUrlError(),
    @required Result allFieldsNotFilledError(String message),
  }) {
    assert(serverError != null);
    assert(invalidEmailError != null);
    assert(invalidUrlError != null);
    assert(allFieldsNotFilledError != null);
    return invalidEmailError();
  }

  @override
  @optionalTypeArgs
  Result maybeWhen<Result extends Object>({
    Result serverError(),
    Result invalidEmailError(),
    Result invalidUrlError(),
    Result allFieldsNotFilledError(String message),
    @required Result orElse(),
  }) {
    assert(orElse != null);
    if (invalidEmailError != null) {
      return invalidEmailError();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  Result map<Result extends Object>({
    @required Result serverError(_ServerError value),
    @required Result invalidEmailError(_InvalidEmailError value),
    @required Result invalidUrlError(_InvalidUrlError value),
    @required Result allFieldsNotFilledError(_AllFieldsNotFilledError value),
  }) {
    assert(serverError != null);
    assert(invalidEmailError != null);
    assert(invalidUrlError != null);
    assert(allFieldsNotFilledError != null);
    return invalidEmailError(this);
  }

  @override
  @optionalTypeArgs
  Result maybeMap<Result extends Object>({
    Result serverError(_ServerError value),
    Result invalidEmailError(_InvalidEmailError value),
    Result invalidUrlError(_InvalidUrlError value),
    Result allFieldsNotFilledError(_AllFieldsNotFilledError value),
    @required Result orElse(),
  }) {
    assert(orElse != null);
    if (invalidEmailError != null) {
      return invalidEmailError(this);
    }
    return orElse();
  }
}

abstract class _InvalidEmailError implements ProfileFailure {
  const factory _InvalidEmailError() = _$_InvalidEmailError;
}

/// @nodoc
abstract class _$InvalidUrlErrorCopyWith<$Res> {
  factory _$InvalidUrlErrorCopyWith(
          _InvalidUrlError value, $Res Function(_InvalidUrlError) then) =
      __$InvalidUrlErrorCopyWithImpl<$Res>;
}

/// @nodoc
class __$InvalidUrlErrorCopyWithImpl<$Res>
    extends _$ProfileFailureCopyWithImpl<$Res>
    implements _$InvalidUrlErrorCopyWith<$Res> {
  __$InvalidUrlErrorCopyWithImpl(
      _InvalidUrlError _value, $Res Function(_InvalidUrlError) _then)
      : super(_value, (v) => _then(v as _InvalidUrlError));

  @override
  _InvalidUrlError get _value => super._value as _InvalidUrlError;
}

/// @nodoc
class _$_InvalidUrlError implements _InvalidUrlError {
  const _$_InvalidUrlError();

  @override
  String toString() {
    return 'ProfileFailure.invalidUrlError()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) || (other is _InvalidUrlError);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  Result when<Result extends Object>({
    @required Result serverError(),
    @required Result invalidEmailError(),
    @required Result invalidUrlError(),
    @required Result allFieldsNotFilledError(String message),
  }) {
    assert(serverError != null);
    assert(invalidEmailError != null);
    assert(invalidUrlError != null);
    assert(allFieldsNotFilledError != null);
    return invalidUrlError();
  }

  @override
  @optionalTypeArgs
  Result maybeWhen<Result extends Object>({
    Result serverError(),
    Result invalidEmailError(),
    Result invalidUrlError(),
    Result allFieldsNotFilledError(String message),
    @required Result orElse(),
  }) {
    assert(orElse != null);
    if (invalidUrlError != null) {
      return invalidUrlError();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  Result map<Result extends Object>({
    @required Result serverError(_ServerError value),
    @required Result invalidEmailError(_InvalidEmailError value),
    @required Result invalidUrlError(_InvalidUrlError value),
    @required Result allFieldsNotFilledError(_AllFieldsNotFilledError value),
  }) {
    assert(serverError != null);
    assert(invalidEmailError != null);
    assert(invalidUrlError != null);
    assert(allFieldsNotFilledError != null);
    return invalidUrlError(this);
  }

  @override
  @optionalTypeArgs
  Result maybeMap<Result extends Object>({
    Result serverError(_ServerError value),
    Result invalidEmailError(_InvalidEmailError value),
    Result invalidUrlError(_InvalidUrlError value),
    Result allFieldsNotFilledError(_AllFieldsNotFilledError value),
    @required Result orElse(),
  }) {
    assert(orElse != null);
    if (invalidUrlError != null) {
      return invalidUrlError(this);
    }
    return orElse();
  }
}

abstract class _InvalidUrlError implements ProfileFailure {
  const factory _InvalidUrlError() = _$_InvalidUrlError;
}

/// @nodoc
abstract class _$AllFieldsNotFilledErrorCopyWith<$Res> {
  factory _$AllFieldsNotFilledErrorCopyWith(_AllFieldsNotFilledError value,
          $Res Function(_AllFieldsNotFilledError) then) =
      __$AllFieldsNotFilledErrorCopyWithImpl<$Res>;
  $Res call({String message});
}

/// @nodoc
class __$AllFieldsNotFilledErrorCopyWithImpl<$Res>
    extends _$ProfileFailureCopyWithImpl<$Res>
    implements _$AllFieldsNotFilledErrorCopyWith<$Res> {
  __$AllFieldsNotFilledErrorCopyWithImpl(_AllFieldsNotFilledError _value,
      $Res Function(_AllFieldsNotFilledError) _then)
      : super(_value, (v) => _then(v as _AllFieldsNotFilledError));

  @override
  _AllFieldsNotFilledError get _value =>
      super._value as _AllFieldsNotFilledError;

  @override
  $Res call({
    Object message = freezed,
  }) {
    return _then(_AllFieldsNotFilledError(
      message: message == freezed ? _value.message : message as String,
    ));
  }
}

/// @nodoc
class _$_AllFieldsNotFilledError implements _AllFieldsNotFilledError {
  const _$_AllFieldsNotFilledError({this.message});

  @override
  final String message;

  @override
  String toString() {
    return 'ProfileFailure.allFieldsNotFilledError(message: $message)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other is _AllFieldsNotFilledError &&
            (identical(other.message, message) ||
                const DeepCollectionEquality().equals(other.message, message)));
  }

  @override
  int get hashCode =>
      runtimeType.hashCode ^ const DeepCollectionEquality().hash(message);

  @override
  _$AllFieldsNotFilledErrorCopyWith<_AllFieldsNotFilledError> get copyWith =>
      __$AllFieldsNotFilledErrorCopyWithImpl<_AllFieldsNotFilledError>(
          this, _$identity);

  @override
  @optionalTypeArgs
  Result when<Result extends Object>({
    @required Result serverError(),
    @required Result invalidEmailError(),
    @required Result invalidUrlError(),
    @required Result allFieldsNotFilledError(String message),
  }) {
    assert(serverError != null);
    assert(invalidEmailError != null);
    assert(invalidUrlError != null);
    assert(allFieldsNotFilledError != null);
    return allFieldsNotFilledError(message);
  }

  @override
  @optionalTypeArgs
  Result maybeWhen<Result extends Object>({
    Result serverError(),
    Result invalidEmailError(),
    Result invalidUrlError(),
    Result allFieldsNotFilledError(String message),
    @required Result orElse(),
  }) {
    assert(orElse != null);
    if (allFieldsNotFilledError != null) {
      return allFieldsNotFilledError(message);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  Result map<Result extends Object>({
    @required Result serverError(_ServerError value),
    @required Result invalidEmailError(_InvalidEmailError value),
    @required Result invalidUrlError(_InvalidUrlError value),
    @required Result allFieldsNotFilledError(_AllFieldsNotFilledError value),
  }) {
    assert(serverError != null);
    assert(invalidEmailError != null);
    assert(invalidUrlError != null);
    assert(allFieldsNotFilledError != null);
    return allFieldsNotFilledError(this);
  }

  @override
  @optionalTypeArgs
  Result maybeMap<Result extends Object>({
    Result serverError(_ServerError value),
    Result invalidEmailError(_InvalidEmailError value),
    Result invalidUrlError(_InvalidUrlError value),
    Result allFieldsNotFilledError(_AllFieldsNotFilledError value),
    @required Result orElse(),
  }) {
    assert(orElse != null);
    if (allFieldsNotFilledError != null) {
      return allFieldsNotFilledError(this);
    }
    return orElse();
  }
}

abstract class _AllFieldsNotFilledError implements ProfileFailure {
  const factory _AllFieldsNotFilledError({String message}) =
      _$_AllFieldsNotFilledError;

  String get message;
  _$AllFieldsNotFilledErrorCopyWith<_AllFieldsNotFilledError> get copyWith;
}
