import 'dart:convert';

import 'package:flutter_app/core/utils/month_map.dart';

Profile profileFromJson(String str) =>
    Profile.fromJson(json.decode(str) as Map<String, dynamic>);

String profileToJson(Profile data) => json.encode(data.toJson());

class Profile {
  Profile(
      {this.id,
      this.name,
      this.uniqueId,
      this.avatar,
      this.email,
      this.stateId,
      this.age,
      this.phone,
      this.slug,
      this.dob,
      this.shortBio,
      this.facebookLink = '',
      this.instagramLink = '',
      this.githubLink = '',
      this.twitterUrl = '',
      this.linkedinUrl = '',
      this.profileLink = '',
      this.flag,
      this.roleId,
      this.languageId,
      this.countryId,
      this.createdAt,
      this.updatedAt,
      this.certificates,
      this.domains = const [],
      this.educationStandard});

  int id;
  String name;
  String uniqueId;
  String avatar;
  String email;
  int age;
  String phone;
  String stateId;
  String slug;
  String shortBio;
  String facebookLink;
  String instagramLink;
  String githubLink;
  String twitterUrl;
  String linkedinUrl;
  String profileLink;
  String flag;
  String dob;
  int roleId;
  int languageId;
  int countryId;
  DateTime createdAt;
  DateTime updatedAt;
  List<EducationStandard> educationStandard;
  List<Certificate> certificates;
  List<Domain> domains;

  Profile copyWith(
          {int id,
          String name,
          String uniqueId,
          String avatar,
          String email,
          String college,
          int age,
          String phone,
          String slug,
          String shortBio,
          String facebookLink,
          String instagramLink,
          String githubLink,
          String twitterUrl,
          String linkedinUrl,
          String profileLink,
          String flag,
          int roleId,
          int languageId,
          int countryId,
          DateTime createdAt,
          DateTime updatedAt,
          String dob,
          List<Certificate> certificates,
          List<Domain> domains,
          // List<Education> education,
          EducationStandard educationStandard}) =>
      Profile(
        id: id ?? this.id,
        name: name ?? this.name,
        uniqueId: uniqueId ?? this.uniqueId,
        avatar: avatar ?? this.avatar,
        email: email ?? this.email,
        dob: this.dob,
        stateId: this.stateId,
        // education: education ?? this.education,
        educationStandard: this.educationStandard,
        age: age ?? this.age,
        phone: phone ?? this.phone,
        slug: slug ?? this.slug,
        shortBio: shortBio ?? this.shortBio,
        facebookLink: facebookLink ?? this.facebookLink,
        instagramLink: instagramLink ?? this.instagramLink,
        githubLink: githubLink ?? this.githubLink,
        twitterUrl: twitterUrl ?? this.twitterUrl,
        linkedinUrl: linkedinUrl ?? this.linkedinUrl,
        profileLink: profileLink ?? this.profileLink,
        flag: flag ?? this.flag,
        roleId: roleId ?? this.roleId,
        languageId: languageId ?? this.languageId,
        countryId: countryId ?? this.countryId,
        createdAt: createdAt ?? this.createdAt,
        updatedAt: updatedAt ?? this.updatedAt,
        certificates: certificates ?? this.certificates,
        domains: domains ?? this.domains,
      );

  factory Profile.fromJson(Map<String, dynamic> json) => Profile(
        id: json["id"] as int,
        name: json["name"] as String,
        uniqueId: json["unique_id"] as String,
        avatar: json["avatar"] as String,
        email: json["email"] as String,
        stateId: (json["state_id"] as int).toString(),
        dob: json["dob"] as String,
        age: json["age"] as int,
        phone: json["phone"] as String,
        slug: json["slug"] as String,
        shortBio: json["short_bio"] as String,
        facebookLink: json["facebook_link"] as String,
        instagramLink: json["instagram_link"] as String,
        githubLink: json["github_link"] as String,
        twitterUrl: json["twitter_url"] as String,
        linkedinUrl: json["linkedin_url"] as String,
        profileLink: json["profile_link"] as String,
        flag: json["flag"] as String,
        roleId: json["role_id"] as int,
        languageId: json["language_id"] as int,
        countryId: json["country_id"] as int,
        createdAt: DateTime.parse(json["created_at"] as String),
        updatedAt: DateTime.parse(json["updated_at"] as String),
        certificates: List<Certificate>.from(json["certificates"]
                .map((x) => Certificate.fromJson(x as Map<String, dynamic>))
            as Iterable<dynamic>),
        domains: List<Domain>.from(json["domains"]
                .map((x) => Domain.fromJson(x as Map<String, dynamic>))
            as Iterable<dynamic>),
        educationStandard: json["education_standard"] == null
            ? []
            : List<EducationStandard>.from(json["education_standard"].map((x) =>
                    EducationStandard.fromJson(x as Map<String, dynamic>))
                as Iterable<dynamic>),
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "name": name,
        "unique_id": uniqueId,
        "avatar": avatar,
        "email": email,
        "dob": dob,
        "age": age,
        "phone": phone,
        "slug": slug,
        "short_bio": shortBio,
        "facebook_link": facebookLink,
        "instagram_link": instagramLink,
        "github_link": githubLink,
        "twitter_url": twitterUrl,
        "linkedin_url": linkedinUrl,
        "profile_link": profileLink,
        "flag": flag,
        "role_id": roleId,
        "language_id": languageId,
        "country_id": countryId,
        "created_at": createdAt.toIso8601String(),
        "updated_at": updatedAt.toIso8601String(),
        "certificates": List<dynamic>.from(certificates.map((x) => x)),
        "domains": List<dynamic>.from(domains.map((x) => x)),
      };
}

class Certificate {
  Certificate({
    this.id,
    this.issuingDate,
    this.userId,
    this.image,
    this.description,
    this.organization,
    this.createdAt,
    this.updatedAt,
    this.day,
    this.month,
    this.year,
  });

  int id;
  int userId;
  String description;
  String image;
  String organization;
  String issuingDate;
  String month;
  String year;
  String day;
  DateTime createdAt;
  DateTime updatedAt;

  Certificate copyWith({
    int id,
    int userId,
    String image,
    String organization,
    String issuingDate,
    String month,
    String day,
    String year,
    DateTime createdAt,
    DateTime updatedAt,
  }) =>
      Certificate(
        id: id ?? this.id,
        userId: userId ?? this.userId,
        image: image ?? this.image,
        organization: organization ?? this.organization,
        description: description ?? this.description,
        issuingDate: issuingDate ?? this.issuingDate,
        createdAt: createdAt ?? this.createdAt,
        updatedAt: updatedAt ?? this.updatedAt,
        year: year ?? this.year,
        month: month ?? this.month,
        day: day ?? this.day,
      );

  factory Certificate.fromJson(Map<String, dynamic> json) => Certificate(
        id: json["id"] as int,
        userId: json["user_id"] as int,
        image: json["image"] as String,
        organization: json["organization"] as String,
        description: json["description"] as String,
        issuingDate: json["issuing_date"] as String,
        month: mapIntToMonth((json["issuing_date"] as String).split('-')[1]),
        day: (json["issuing_date"] as String).split('-').first,
        year: (json["issuing_date"] as String).split('-').last,
        createdAt: DateTime.parse(json["created_at"] as String),
        updatedAt: DateTime.parse(json["updated_at"] as String),
      );

  Map<String, dynamic> toJson() => {
        "certificate_description": description,
        "certificate_organization": organization,
        "certificate_issuing_date":
            '${day.padLeft(2, '0')}-${mapMonthToInt(month).toString().padLeft(2, '0')}-$year' //dd-mm-yyyy
      };
}

class EducationStandard {
  EducationStandard(
      {this.id,
      this.institutesId,
      this.educationStandardId,
      this.userId,
      this.createdAt,
      this.updatedAt,
      this.instituteName,
      this.standardName,
      this.isFirst = false});

  final int id;
  final int institutesId;
  final int educationStandardId;
  final int userId;
  final DateTime createdAt;
  final DateTime updatedAt;
  final Domain instituteName;
  final Domain standardName;
  final bool isFirst;

  EducationStandard copyWith(
          {int id,
          int institutesId,
          int educationStandardId,
          int userId,
          DateTime createdAt,
          DateTime updatedAt,
          Domain instituteName,
          Domain standardName,
          bool isFirst}) =>
      EducationStandard(
          id: id ?? this.id,
          institutesId: institutesId ?? this.institutesId,
          educationStandardId: educationStandardId ?? this.educationStandardId,
          userId: userId ?? this.userId,
          createdAt: createdAt ?? this.createdAt,
          updatedAt: updatedAt ?? this.updatedAt,
          instituteName: instituteName ?? this.instituteName,
          standardName: standardName ?? this.standardName,
          isFirst: isFirst ?? this.isFirst);

  factory EducationStandard.fromJson(Map<String, dynamic> json) =>
      EducationStandard(
        id: json["id"] as int,
        institutesId: json["institutes_id"] as int,
        educationStandardId: json["education_standard_id"] as int,
        userId: json["user_id"] as int,
        createdAt: DateTime.parse(json["created_at"] as String),
        updatedAt: DateTime.parse(json["updated_at"] as String),
        instituteName:
            Domain.fromJson(json["institute_name"] as Map<String, dynamic>),
        standardName:
            Domain.fromJson(json["standard_name"] as Map<String, dynamic>),
      );

  Map<String, dynamic> toJson() => {
        "institute_name": instituteName ?? "InsName",
        "standard_name": standardName ?? "StandardName"
      };
}

class Domain {
  Domain(
      {this.id,
      this.name,
      this.createdAt,
      this.updatedAt,
      this.pivot,
      this.value = 1.0});

  int id;
  String name;
  double value;
  DateTime createdAt;
  DateTime updatedAt;
  Pivot pivot;

  Domain copyWith(
          {int id,
          String name,
          DateTime createdAt,
          DateTime updatedAt,
          Pivot pivot,
          double value}) =>
      Domain(
          id: id ?? this.id,
          name: name ?? this.name,
          createdAt: createdAt ?? this.createdAt,
          updatedAt: updatedAt ?? this.updatedAt,
          pivot: pivot ?? this.pivot,
          value: value ?? this.value);

  factory Domain.fromJson(Map<String, dynamic> json) => Domain(
        id: json["id"] as int,
        name: json["name"] as String,
        value: json["pivot"] == null
            ? null
            : double.parse(json["pivot"]["experience"] as String),
        createdAt: DateTime.parse(json["created_at"] as String),
        updatedAt: DateTime.parse(json["updated_at"] as String),
        pivot: json["pivot"] == null
            ? null
            : Pivot.fromJson(json["pivot"] as Map<String, dynamic>),
      );

  Map<String, dynamic> toJson() => {
        "name": name ?? "NoName",
        "value": pivot?.experience ?? "NAN",
      };
}

class Pivot {
  Pivot({
    this.userId,
    this.experience = "1.0",
    this.domainId,
    this.createdAt,
    this.updatedAt,
  });

  final int userId;
  final int domainId;
  String experience;
  final DateTime createdAt;
  final DateTime updatedAt;

  Pivot copyWith({
    int userId,
    int domainId,
    DateTime createdAt,
    DateTime updatedAt,
  }) =>
      Pivot(
        userId: userId ?? this.userId,
        domainId: domainId ?? this.domainId,
        createdAt: createdAt ?? this.createdAt,
        updatedAt: updatedAt ?? this.updatedAt,
      );

  factory Pivot.fromJson(Map<String, dynamic> json) => Pivot(
        userId: json["user_id"] as int,
        domainId: json["domain_id"] as int,
        experience: json["experience"] as String,
        createdAt: DateTime.parse(json["created_at"] as String),
        updatedAt: DateTime.parse(json["updated_at"] as String),
      );

  Map<String, dynamic> toJson() => {
        "user_id": userId,
        "domain_id": domainId,
        "created_at": createdAt.toIso8601String(),
        "updated_at": updatedAt.toIso8601String(),
      };
}
