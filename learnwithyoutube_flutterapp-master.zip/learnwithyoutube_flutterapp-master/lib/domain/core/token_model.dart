import 'dart:convert';

import 'package:hive/hive.dart';

part 'token_model.g.dart';

ResponseTokenModel responseTokenModelFromJson(String str) =>
    ResponseTokenModel.fromJson(json.decode(str) as Map<String, dynamic>);

String responseTokenModelToJson(ResponseTokenModel data) =>
    json.encode(data.toJson());

@HiveType(typeId: 0)
class ResponseTokenModel {
  ResponseTokenModel({
    this.uniqueId,
    this.responseTokenModelNew,
    this.accessToken,
    this.expiresIn,
    this.refreshToken,
    this.flag,
    this.phoenixUserId,
    this.email,
    this.name,
    this.roleId,
  });

  @HiveField(0)
  final String uniqueId;
  @HiveField(1)
  final int responseTokenModelNew;
  @HiveField(2)
  final String accessToken;
  @HiveField(3)
  final int expiresIn;
  @HiveField(4)
  final String refreshToken;
  @HiveField(5)
  final dynamic flag;
  @HiveField(6)
  final int phoenixUserId;
  @HiveField(7)
  final String email;
  @HiveField(8)
  final dynamic name;
  @HiveField(9)
  final int roleId;

  ResponseTokenModel copyWith({
    String uniqueId,
    int responseTokenModelNew,
    String accessToken,
    int expiresIn,
    String refreshToken,
    dynamic flag,
    int phoenixUserId,
    String email,
    dynamic name,
    int roleId,
  }) =>
      ResponseTokenModel(
        uniqueId: uniqueId ?? this.uniqueId,
        responseTokenModelNew:
            responseTokenModelNew ?? this.responseTokenModelNew,
        accessToken: accessToken ?? this.accessToken,
        expiresIn: expiresIn ?? this.expiresIn,
        refreshToken: refreshToken ?? this.refreshToken,
        flag: flag ?? this.flag,
        phoenixUserId: phoenixUserId ?? this.phoenixUserId,
        email: email ?? this.email,
        name: name ?? this.name,
        roleId: roleId ?? this.roleId,
      );

  factory ResponseTokenModel.fromJson(Map<String, dynamic> json) =>
      ResponseTokenModel(
        uniqueId: json["unique_id"] as String,
        responseTokenModelNew: json["new"] as int,
        accessToken: json["access_token"] as String,
        expiresIn: json["expires_in"] as int,
        refreshToken: json["refresh_token"] as String,
        flag: json["flag"],
        phoenixUserId: json["phoenix_user_id"] as int,
        email: json["email"] as String,
        name: json["name"],
        roleId: json["role_id"]as int,
      );

  Map<String, dynamic> toJson() => {
        "unique_id": uniqueId,
        "new": responseTokenModelNew,
        "access_token": accessToken,
        "expires_in": expiresIn,
        "refresh_token": refreshToken,
        "flag": flag,
        "phoenix_user_id": phoenixUserId,
        "email": email,
        "name": name,
        "role_id": roleId,
      };
}
