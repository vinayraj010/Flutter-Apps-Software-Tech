import 'package:form_validators/form_validators.dart';

class LinkedinUsernameValidator implements IValidator {
  final String message;

  const LinkedinUsernameValidator(this.message);

  @override
  bool call(String value) {
    const _regex = r"""^[a-zA-Z0-9-]{5,30}$""";
    if (value == null || value.isEmpty) {
      return false;
    } else if (RegExp(_regex).hasMatch(value)) {
      return false;
    } else {
      return true;
    }
  }
}
