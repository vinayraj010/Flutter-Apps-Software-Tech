import 'package:flutter_app/core/utils/clean_string.dart';
import 'package:form_validators/form_validators.dart';

class PhoneValidator implements IValidator {
  final String message;

  const PhoneValidator(this.message);

  @override
  bool call(String value) {
    // r"""^(?!.*\.\.)(?!.*\.$)[^\W][\w.]{0,29}$""";
    if (cleanString(value).length == 10) {
      return false;
    } else {
      return true;
    }
  }
}
