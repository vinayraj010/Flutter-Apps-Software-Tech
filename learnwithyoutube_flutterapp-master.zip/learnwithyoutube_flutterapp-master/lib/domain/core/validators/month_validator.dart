import 'package:flutter_app/core/utils/clean_string.dart';
import 'package:form_validators/form_validators.dart';

class MonthValidator implements IValidator {
  final String message;
  @override
  bool call(String value) => value == null || cleanString(value).isEmpty;
  const MonthValidator([this.message = '']);
}
