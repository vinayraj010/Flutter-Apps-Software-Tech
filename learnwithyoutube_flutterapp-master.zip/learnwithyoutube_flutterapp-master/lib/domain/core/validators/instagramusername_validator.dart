import 'package:form_validators/form_validators.dart';

class InstagramUsernameValidator implements IValidator {
  final String message;

  const InstagramUsernameValidator(this.message);

  @override
  bool call(String value) {
    const _regex = r"""^(?!.*\.\.)(?!.*\.$)[^\W][\w.]{0,29}$""";
    if (value == null || value.isEmpty) {
      return false;
    } else if (RegExp(_regex).hasMatch(value)) {
      return false;
    } else {
      return true;
    }
  }
}
