import 'package:flutter_app/core/utils/clean_string.dart';
import 'package:form_validators/form_validators.dart';

class NonEmptyValidator implements IValidator {
  final String message;

  const NonEmptyValidator(this.message);

  @override
  bool call(String value) {
    if (cleanString(value).isNotEmpty) {
      return false;
    } else {
      return true;
    }
  }
}
