abstract class IValidatable {
  bool isValid();
}
