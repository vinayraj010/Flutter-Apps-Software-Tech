import 'package:dartz/dartz.dart';
import 'package:flutter_app/domain/chat/attendance.dart';
import 'package:flutter_app/domain/chat/chat_failure.dart';
import 'package:flutter_app/domain/chat/message.dart';
import 'package:flutter_app/domain/core/value_objects.dart';

abstract class IChatRepo {
  Future<Either<ChatFailure, Unit>> createChat(
      {int userId, StringSingleLine title});
  Future<Either<ChatFailure, Attendance>> addTeacherAttendance({int chatId});
  Future<Either<ChatFailure, Unit>> addStudentAttendance(
      {int chatId, int teacherAttendanceId});
  Future<Either<ChatFailure, Message>> getAllChats();
}
