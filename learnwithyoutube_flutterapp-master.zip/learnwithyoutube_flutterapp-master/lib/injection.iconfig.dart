// GENERATED CODE - DO NOT MODIFY BY HAND

// **************************************************************************
// InjectableConfigGenerator
// **************************************************************************

import 'package:flutter_app/application/providers/auth_provider.dart';
import 'package:flutter_app/application/providers/calendar_provider.dart';
import 'package:flutter_app/application/providers/certificate_provider.dart';
import 'package:flutter_app/application/providers/education_provider.dart';
import 'package:flutter_app/application/providers/profile_provider.dart';
import 'package:flutter_app/application/providers/skill_provider.dart';
import 'package:flutter_app/application/providers/youtube_player_provider.dart';
import 'package:flutter_app/core/services/file_picker.dart';
import 'package:flutter_app/infrastructure/auth/firebase_user_mapper.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:flutter_app/infrastructure/core/firebase_injectable_module.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:dio/dio.dart';
import 'package:flutter_app/domain/core/token_model.dart';
import 'package:hive/hive.dart';
import 'package:flutter_app/infrastructure/calendar/google_events_repo.dart';
import 'package:flutter_app/domain/calendar/i_google_event_repo.dart';
import 'package:flutter_app/infrastructure/core/backend_request.dart';
import 'package:flutter_app/domain/core/i_backend_request.dart';
import 'package:flutter_app/infrastructure/message/message_repo.dart';
import 'package:flutter_app/domain/message/i_message_repo.dart';
import 'package:flutter_app/infrastructure/profile/profile_repo.dart';
import 'package:flutter_app/domain/profile/i_profile_repo.dart';
import 'package:flutter_app/application/calendar/calendar_bloc.dart';
import 'package:flutter_app/application/calendar/event_form/event_form_bloc.dart';
import 'package:flutter_app/application/message/message_bloc.dart';
import 'package:flutter_app/application/profile/profile_bloc.dart';
import 'package:flutter_app/infrastructure/auth/firebase_auth_facade.dart';
import 'package:flutter_app/domain/auth/i_auth_facade.dart';
import 'package:flutter_app/infrastructure/chat/chat_repo.dart';
import 'package:flutter_app/domain/chat/i_chat_repo.dart';
import 'package:flutter_app/application/auth/auth_bloc.dart';
import 'package:flutter_app/application/auth/sign_in_form/sign_in_form_bloc.dart';
import 'package:flutter_app/application/chat/chat_bloc.dart';
import 'package:get_it/get_it.dart';

void $initGetIt(GetIt g, {String environment}) {
  final firebaseInjectableModule = _$FirebaseInjectableModule();
  g.registerLazySingleton<AuthProvider>(() => AuthProvider());
  g.registerLazySingleton<CalendarProvider>(() => CalendarProvider());
  g.registerLazySingleton<CertificateProvider>(() => CertificateProvider());
  g.registerLazySingleton<EducationProvider>(() => EducationProvider());
  g.registerFactory<ProfileProvider>(() => ProfileProvider());
  g.registerLazySingleton<SkillProvider>(() => SkillProvider());
  g.registerLazySingleton<PlayerProvider>(() => PlayerProvider());
  g.registerFactory<FilePickerService>(() => FilePickerService());
  g.registerLazySingleton<FirebaseUserMapper>(() => FirebaseUserMapper());
  g.registerLazySingleton<GoogleSignIn>(
      () => firebaseInjectableModule.googleSignIn);
  g.registerLazySingleton<FirebaseAuth>(
      () => firebaseInjectableModule.firebaseAuth);
  g.registerLazySingleton<FirebaseFirestore>(
      () => firebaseInjectableModule.firestore);
  g.registerLazySingleton<Dio>(() => firebaseInjectableModule.dio);
  g.registerLazySingleton<Box<ResponseTokenModel>>(
      () => firebaseInjectableModule.box);
  g.registerFactory<CalendarBloc>(() => CalendarBloc(
        g<IGoogleEventRepo>(),
        g<CalendarProvider>(),
      ));
  g.registerFactory<EventFormBloc>(() => EventFormBloc(
        g<IGoogleEventRepo>(),
      ));
  g.registerFactory<MessageBloc>(() => MessageBloc(
        g<IMessageRepo>(),
        g<FilePickerService>(),
      ));
  g.registerFactory<ProfileBloc>(() => ProfileBloc(
        g<IProfileRepo>(),
      ));
  g.registerFactory<AuthBloc>(() => AuthBloc(
        g<IAuthFacade>(),
      ));
  g.registerFactory<SignInFormBloc>(() => SignInFormBloc(
        g<IAuthFacade>(),
      ));
  g.registerFactory<ChatBloc>(() => ChatBloc(
        g<IChatRepo>(),
      ));

  //Register prod Dependencies --------
  if (environment == 'prod') {
    g.registerLazySingleton<IGoogleEventRepo>(() => GoogleEventsRepo(
          g<GoogleSignIn>(),
          g<CalendarProvider>(),
        ));
    g.registerLazySingleton<IBackendRequest>(() => BackendRequest(
          g<Dio>(),
          g<Box<ResponseTokenModel>>(),
        ));
    g.registerLazySingleton<IMessageRepo>(() => MessageRepo(
          g<IBackendRequest>(),
          g<Box<ResponseTokenModel>>(),
        ));
    g.registerLazySingleton<IProfileRepo>(() => ProfileRepo(
          g<IBackendRequest>(),
          g<Dio>(),
        ));
    g.registerLazySingleton<IAuthFacade>(() => FirebaseAuthFacade(
          g<FirebaseAuth>(),
          g<GoogleSignIn>(),
          g<FirebaseUserMapper>(),
          g<Dio>(),
          g<IBackendRequest>(),
          g<Box<ResponseTokenModel>>(),
          g<AuthProvider>(),
        ));
    g.registerLazySingleton<IChatRepo>(() => ChatRepo(
          g<IBackendRequest>(),
          g<Box<ResponseTokenModel>>(),
        ));
  }
}

class _$FirebaseInjectableModule extends FirebaseInjectableModule {}
