import 'dart:io';

import 'package:device_preview/device_preview.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_app/core/strings.dart';
import 'package:flutter_app/domain/core/token_model.dart';
import 'package:flutter_app/presentation/app_widget.dart';
// import 'package:flutter_downloader/flutter_downloader.dart';
import 'package:hive/hive.dart';
import 'package:injectable/injectable.dart';
import 'package:path_provider/path_provider.dart' as path_provider;

import 'injection.dart';

void main() async {
  try {
    WidgetsFlutterBinding.ensureInitialized();
    // await FlutterDownloader.initialize(
    //     debug: true // optional: set false to disable printing logs to console
    //     );
    await Firebase.initializeApp();

    final Directory directory =
        await path_provider.getApplicationDocumentsDirectory();
    Hive.init(directory.path);
    Hive.registerAdapter(ResponseTokenModelAdapter());
    await Hive.openBox<ResponseTokenModel>(HiveBoxNames.token);
    configureInjection(Environment.prod);

    runApp(DevicePreview(
        enabled: !kReleaseMode,
        builder: (context) => AppWidget() // Wrap your app
        ));
  } catch (e) {
    runApp(MaterialApp(
      home: Center(
        child: Text(e.toString()),
      ),
    ));
  }
}
