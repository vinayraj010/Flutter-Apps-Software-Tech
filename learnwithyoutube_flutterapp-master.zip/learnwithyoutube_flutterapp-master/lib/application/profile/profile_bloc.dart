import 'dart:async';

import 'package:bloc/bloc.dart';
import 'package:dartz/dartz.dart';
import 'package:date_format/date_format.dart';
import 'package:flutter/material.dart';
import 'package:flutter_app/application/providers/profile_provider.dart';
import 'package:flutter_app/core/routes/route.gr.dart' as route;
import 'package:flutter_app/core/services/file_picker.dart';
import 'package:flutter_app/core/utils/month_map.dart';
import 'package:flutter_app/domain/auth/value_objects.dart';
import 'package:flutter_app/domain/core/country.dart';
import 'package:flutter_app/domain/core/errors.dart';
import 'package:flutter_app/domain/core/value_objects.dart';
import 'package:flutter_app/domain/profile/i_profile_repo.dart';
import 'package:flutter_app/domain/profile/profile.dart';
import 'package:flutter_app/domain/profile/profile_failure.dart';
import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:injectable/injectable.dart';
import 'package:provider/provider.dart';

part 'profile_bloc.freezed.dart';
part 'profile_event.dart';
part 'profile_state.dart';

@injectable
class ProfileBloc extends Bloc<ProfileEvent, ProfileState> {
  ProfileBloc(this._repo) : super();
  final IProfileRepo _repo;

  @override
  Stream<ProfileState> mapEventToState(
    ProfileEvent event,
  ) async* {
    // TODO: implement mapEventToState
    yield* event.map(
      submitUserProfile: (e) async* {
        yield state.copyWith(submitOption: none());

        Either<ProfileFailure, Profile> failureOrSuccess;
        try {
          failureOrSuccess = await _repo.submitUserProfile(
            name: NonNullString(state.name).getOrCrash(),
            email: EmailAddress(state.email).getOrCrash(),
            country: int.parse('1'),
            age: int.parse('21'),
            college: 'NITK',
          );
        } catch (e) {
          yield (e as UnexpectedValueError).valueFailure.maybeMap(
              orElse: () => state,
              empty: (value) => state.copyWith(
                  submitOption: some(left(
                      ProfileFailure.allFieldsNotFilledError(
                          message: value.failedValue.toString())))),
              invalidEmail: (value) => state.copyWith(
                  submitOption:
                      some(left(const ProfileFailure.invalidUrlError()))));
        }

        yield failureOrSuccess.fold(
          (l) => state.copyWith(submitOption: some(left(l))), //option none
          (r) {
            return state.copyWith(submitOption: some(right(unit)), profile: r);
          },
        );
      },
      getUserProfile: (e) async* {
        // yield state.copyWith(getProfileOption: none());

        final Either<ProfileFailure, Profile> failureOrSuccess =
            await _repo.getUserProfile();

        yield failureOrSuccess.fold(
          (l) => state, //getOption,
          (r) {
            Provider.of<ProfileProvider>(
                    route.Router.navigator.key.currentContext,
                    listen: false)
                .stopLoading();
            return state.copyWith(
                profile: r, getProfileOption: some(right(unit)));
          },
        );
      },
      getCountries: (e) async* {
        yield state.copyWith(countryOption: none());

        final failureOrSuccess = await _repo.getCountries();
        yield failureOrSuccess.fold((l) => state, (r) {
          return state.copyWith(countries: r);
        });
      },
      updateAvatar: (e) async* {
        yield state.copyWith(avatarOption: none());

        Either<ProfileFailure, Profile> failureOrSuccess;

        try {
          failureOrSuccess =
              await _repo.updateAvatar(NonNullString(e.avatar).getOrCrash());
        } catch (e) {
          yield (e as UnexpectedValueError).valueFailure.maybeMap(
              orElse: () => state,
              empty: (value) => state.copyWith(
                  avatarOption: some(
                      left(const ProfileFailure.allFieldsNotFilledError()))));
        }

        yield failureOrSuccess.fold(
          (l) => state.copyWith(avatarOption: some(left(l))),
          (r) => state.copyWith(
            avatarOption: some(right(unit)),
            profile: r,
          ),
        );
      },
      saveAbout: (e) async* {
        //Reset all options

        //Assign
        final String _month = e.month;
        final String _day = e.day.padLeft(2, '0');
        final String _year = e.year;
        final String _counrty = e.country;
        final String _state = e.state;
        final String _phoneNumber = e.phoneNumber;

        final Map<String, dynamic> _data = {
          "date_of_birth": formatDate(
              DateTime(
                  int.parse(_year), mapMonthToInt(_month), int.parse(_day)),
              ['dd', '-', 'mm', '-', 'yyyy']),
          "state": _state,
          "country": _counrty,
          "phone": _phoneNumber
        };

        Either<ProfileFailure, Profile> failureOrSuccess;

        failureOrSuccess = await _repo.updateUserProfile(_data);

        yield failureOrSuccess.fold(
          (l) {
            return state.copyWith(
              linkedinOption: some(left(l)),
            );
          },
          (r) {
            return state.copyWith(
              profile: r,
              linkedinOption: some(right(unit)),
            );
          },
        );

        _pop();
      },
      saveSocialMedia: (e) async* {
        //Reset all options
        yield state.copyWith(
            instagramOption: none(),
            facebookOption: none(),
            twitterOption: none(),
            linkedinOption: none(),
            showSocialMediaErrorMessages: false);

        //Assign
        final String _instagramUserName = e.instagramUserName;
        final String _facebookUserName = e.facebookUserName;
        final String _twitterUserName = e.twitterUserName;
        final String _linkedinUserName = e.linkedinUserName;

        //Check for https

        final fullInstagramUrl = _instagramUserName.isEmpty
            ? 'null'
            : 'https://www.instagram.com/$_instagramUserName';

        final fullFacebookUrl = _facebookUserName.isEmpty
            ? 'null'
            : 'https://www.facebook.com/$_facebookUserName';

        final fullTwitterUrl = _twitterUserName.isEmpty
            ? 'null'
            : 'https://www.twitter.com/$_twitterUserName';

        final fullLinkedinUrl = _linkedinUserName.isEmpty
            ? 'null'
            : 'https://www.linkedin.com/in/$_linkedinUserName';

        Either<ProfileFailure, Profile> failureOrSuccess;

        failureOrSuccess = await _repo.addSocialMedia(
            fullFacebookUrl, fullInstagramUrl, fullTwitterUrl, fullLinkedinUrl);

        yield failureOrSuccess.fold((l) {
          return state.copyWith(
            instagramOption: some(left(l)),
          );
        }, (r) {
          return state.copyWith(
              instagramOption: some(right(unit)),
              profile: r,
              showSocialMediaErrorMessages: false);
        });

        _pop();
      },
      saveSkills: (e) async* {
        yield state.copyWith(skillOption: none());

        final List<Domain> _properDomains =
            e.domains.where((element) => element.name != null).toList();

        Either<ProfileFailure, Unit> failureOrSuccess;

        failureOrSuccess = await _repo.addDomains(_properDomains);

        yield failureOrSuccess.fold(
          (l) => state.copyWith(skillOption: some(left(l))),
          (r) {
            // _pop();
            return state.copyWith(
              skillOption: some(right(unit)),
            );
          },
        );
      },
      saveEducation: (e) async* {
        yield state.copyWith(collegeOption: none());

        Either<ProfileFailure, Unit> failureOrSuccess;
        failureOrSuccess = await _repo.addEducation(e.educations);

        yield failureOrSuccess.fold(
          (l) => state.copyWith(collegeOption: some(left(l))),
          (r) {
            return state.copyWith(
              collegeOption: some(right(unit)),
            );
          },
        );
      },
      saveCertificates: (e) async* {
        yield state.copyWith(certificateOption: none());

        Either<ProfileFailure, Unit> failureOrSuccess;

        failureOrSuccess = await _repo.addUserCertificate(e.certificates);

        yield failureOrSuccess.fold(
          (l) => state.copyWith(certificateOption: some(left(l))),
          (r) {
            return state.copyWith(
              certificateOption: some(right(unit)),
            );
          },
        );
      },
      updateEducation: (e) async* {
        yield state.copyWith(collegeOption: none());

        Either<ProfileFailure, Unit> failureOrSuccess;
        final List<Either<ProfileFailure, Unit>> _resultList =
            await Future.wait([
          _repo.updateEducationInstitute(e.educations),
          _repo.updateEducationStandard(e.educations),
        ]);

        final List<Either<ProfileFailure, Unit>> _failureList =
            _resultList.where((element) => element.isLeft()).toList();

        failureOrSuccess =
            _failureList.isEmpty ? _resultList.first : _failureList.first;

        yield failureOrSuccess.fold(
          (l) => state.copyWith(collegeOption: some(left(l))),
          (r) {
            // _pop();
            return state.copyWith(
              collegeOption: some(right(unit)),
            );
          },
        );
      },
      updateSkills: (e) async* {
        yield state.copyWith(skillOption: none());

        Either<ProfileFailure, Unit> failureOrSuccess;

        failureOrSuccess = await _repo.updateDomains(e.domain);

        yield failureOrSuccess.fold(
          (l) => state.copyWith(skillOption: some(left(l))),
          (r) {
            // _pop();
            return state.copyWith(
              skillOption: some(right(unit)),
            );
          },
        );
      },
      updateCertificates: (e) async* {
        yield state.copyWith(certificateOption: none());

        Either<ProfileFailure, Unit> failureOrSuccess;

        failureOrSuccess = await _repo.updateUserCertificate(e.certificates);

        yield failureOrSuccess.fold(
          (l) => state.copyWith(certificateOption: some(left(l))),
          (r) {
            return state.copyWith(
              certificateOption: some(right(unit)),
            );
          },
        );
      },
      deleteCertificate: (e) async* {
        yield state.copyWith(certificateOption: none());

        Either<ProfileFailure, Unit> failureOrSuccess;

        failureOrSuccess = await _repo.deleteUserCertificate(e.certificate);

        yield failureOrSuccess.fold(
          (l) => state.copyWith(certificateOption: some(left(l))),
          (r) {
            return state.copyWith(
              certificateOption: some(right(unit)),
            );
          },
        );
      },
      deleteEducation: (e) async* {
        yield state.copyWith(certificateOption: none());

        Either<ProfileFailure, Unit> failureOrSuccess;

        failureOrSuccess = await _repo.deleteEducation(e.education);

        yield failureOrSuccess.fold(
          (l) => state.copyWith(certificateOption: some(left(l))),
          (r) {
            return state.copyWith(
              certificateOption: some(right(unit)),
            );
          },
        );
      },
      deleteSkill: (e) async* {
        yield state.copyWith(certificateOption: none());

        Either<ProfileFailure, Unit> failureOrSuccess;

        failureOrSuccess = await _repo.deleteDomain(e.domain);

        yield failureOrSuccess.fold(
          (l) => state.copyWith(certificateOption: some(left(l))),
          (r) {
            return state.copyWith(
              certificateOption: some(right(unit)),
            );
          },
        );
      },
    );
  }

  void _pop() => Navigator.pop(route.Router.navigator.key.currentContext);

  @override
  // TODO: implement initialState
  ProfileState get initialState => ProfileState.initial();
}
