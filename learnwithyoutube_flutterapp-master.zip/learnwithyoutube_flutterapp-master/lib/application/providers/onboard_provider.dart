import 'package:flutter/foundation.dart';
import 'package:flutter_app/core/enums/auth_current_enum.dart';

class OnBoardProvider extends ChangeNotifier {
  ON_PAGE _currentPage = ON_PAGE.one;

  ON_PAGE get currentPage => _currentPage;

  void updateCurrentPage(ON_PAGE page) {
    _currentPage = page;
    notifyListeners();
  }
}
