import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_app/application/profile/profile_bloc.dart';
import 'package:flutter_app/application/providers/profile_provider.dart';
import 'package:flutter_app/core/routes/route.gr.dart' as route;
import 'package:flutter_app/core/utils/clean_string.dart';
import 'package:flutter_app/domain/profile/profile.dart';
import 'package:flutter_app/presentation/core/palette.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:injectable/injectable.dart';
import 'package:provider/provider.dart';

final BuildContext context = route.Router.navigator.key.currentContext;

@lazySingleton
class SkillProvider extends ChangeNotifier {
  Domain _skill;

  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  bool _showErrors = false;
  bool _isSkillNameNotFilled = false;
  InputBorder _skillNameTextFieldBorder;

  static List<Domain> _recentlyAdededSkills = <Domain>[
    Domain(pivot: Pivot()),
    Domain(pivot: Pivot()),
  ];
  static final List<Domain> _deletedSkills = <Domain>[];

  Domain get skill => _skill;
  GlobalKey<FormState> get formKey => _formKey;
  bool get showErrors => _showErrors;
  bool get isSkillNameNotFilled => _isSkillNameNotFilled;
  InputBorder get skillNameTextFieldBorder => _skillNameTextFieldBorder;
  List<Domain> get recentlyAdededSkills => _recentlyAdededSkills;
  List<Domain> get deletedSkills => _deletedSkills;

  bool checkWhetherSkillNameisFilled() {
    return _recentlyAdededSkills
        .where((element) => cleanString(element.name).isEmpty)
        .toList()
        .isNotEmpty;
  }

  MaterialStateProperty<BorderSide> addFieldBorder() {
    return MaterialStateProperty.all(BorderSide(
        color: checkWhetherSkillNameisFilled()
            ? Palette.cc4c4c4
            : Palette.onBlue));
  }

  void addAllPreviousSkillsToList() {
    final List<Domain> _allList = BlocProvider.of<ProfileBloc>(context)
        .state
        .profile
        .domains
        .reversed
        .toList();
    _recentlyAdededSkills.addAll(_allList);
    // notifyListeners();
  }

  //Call this Before Field
  void checkWhetherFieldsFilled({@required int index}) {
    _isSkillNameNotFilled =
        cleanString(_recentlyAdededSkills[index].name).isEmpty;

    _skillNameTextFieldBorder = OutlineInputBorder(
        borderSide: BorderSide(
            color: _isSkillNameNotFilled ? Palette.c686868 : Palette.onBlue),
        borderRadius: BorderRadius.circular(3));

    // notifyListeners();
  }

  void onSkillNameChanged({
    @required String value,
    @required int index,
  }) {
    try {
      final Domain _educationWithSchoolName =
          _recentlyAdededSkills.elementAt(index);
      _educationWithSchoolName.name = cleanString(value);

      _recentlyAdededSkills.removeAt(index);

      _recentlyAdededSkills.insert(index, _educationWithSchoolName);
    } catch (e) {
      _skill.name = cleanString(value);
      _recentlyAdededSkills.add(_skill);
    }

    notifyListeners();
  }

  void onSliderChanged({
    @required double newSliderValue,
    @required int index,
  }) {
    try {
      final Domain _skillWithName = _recentlyAdededSkills.elementAt(index);
      _skillWithName.value = newSliderValue.ceil().toDouble();

      _recentlyAdededSkills.removeAt(index);

      _recentlyAdededSkills.insert(index, _skillWithName);
    } catch (e) {
      _skill.value = newSliderValue.ceil().toDouble();
      _recentlyAdededSkills.insert(index, _skill);
    }

    _recentlyAdededSkills[index].pivot.experience =
        newSliderValue.toInt().toDouble().toString();

    notifyListeners();
  }

  String validatorForSkillName({
    @required String value,
    @required int index,
  }) {
    if (cleanString(_recentlyAdededSkills[index].name).isNotEmpty &&
        cleanString(value).isEmpty) {
      return '*Required';
    } else {
      return null;
    }
  }

  //TODO: Add new fields to top of the list
  void onAddFieldPressed() {
    if (!checkWhetherSkillNameisFilled()) {
      // _education = EducationStandard();
      _recentlyAdededSkills.add(Domain(pivot: Pivot()));

      notifyListeners();
    }
  }

  void showErrorsToTrue() {
    _showErrors = true;
    notifyListeners();
  }

  void _saveSkills() {
    _recentlyAdededSkills
        .removeWhere((element) => cleanString(element.name).isEmpty);
    if (_recentlyAdededSkills.isNotEmpty) {
      final List<Domain> _toBeAddedSkills = _recentlyAdededSkills
          .where((e) => e.id == null)
          .toList()
          .reversed
          .toList();

      BlocProvider.of<ProfileBloc>(context)
          .add(ProfileEvent.saveSkills(_toBeAddedSkills));

      final List<Domain> _toBeUpdatedSkills =
          _recentlyAdededSkills.where((e) => e?.id != null).toList();

      for (final Domain _domain in _toBeUpdatedSkills) {
        BlocProvider.of<ProfileBloc>(context)
            .add(ProfileEvent.updateSkills(_domain));
      }

      //Get Fresh Profile
      BlocProvider.of<ProfileBloc>(context)
          .add(const ProfileEvent.getUserProfile());
    } else {}
  }

  void _deleteSkill() {
    for (final Domain domain in _deletedSkills) {
      BlocProvider.of<ProfileBloc>(context)
          .add(ProfileEvent.deleteSkill(domain));
    }
  }

  void removeAndAddToDelete(int index) {
    _deletedSkills.add(_recentlyAdededSkills.elementAt(index));
    _recentlyAdededSkills.removeAt(index);
    notifyListeners();
  }

  void removeSkillFromList(int index) {
    _recentlyAdededSkills.removeAt(index);
    notifyListeners();
  }

  bool isOnline(int index) {
    return _recentlyAdededSkills[index].id != null;
  }

  void onSavePressed() {
    if (_formKey.currentState.validate()) {
      Provider.of<ProfileProvider>(context, listen: false).startLoading();
      Navigator.pop(context);
      _deleteSkill();
      _saveSkills();
      resetAll();
    } else {
      _showErrors = true;
    }
    notifyListeners();
  }

  void resetAll() {
    BlocProvider.of<ProfileBloc>(context)
        .add(const ProfileEvent.getUserProfile());
    _recentlyAdededSkills = <Domain>[
      Domain(pivot: Pivot()),
      Domain(pivot: Pivot()),
    ];
    _deletedSkills.clear();
    _skill = Domain();
    _showErrors = false;
    _isSkillNameNotFilled = false;
    notifyListeners();
  }
}
