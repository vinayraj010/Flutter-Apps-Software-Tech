import 'package:dartz/dartz.dart';
import 'package:flutter/cupertino.dart';
import 'package:injectable/injectable.dart';

@injectable
class ProfileProvider extends ChangeNotifier {
  Option<Unit> _loadingOption = none();

  Option<Unit> get loadingOption => _loadingOption;

  void startLoading() {
    _loadingOption = some(unit);
    notifyListeners();
  }

  void stopLoading() {
    _loadingOption = none();
    notifyListeners();
  }
}
