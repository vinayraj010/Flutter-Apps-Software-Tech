part of 'message_bloc.dart';

@freezed
abstract class MessageEvent with _$MessageEvent {
  const factory MessageEvent.messageChanged(String message) = _MessageChanged;
  const factory MessageEvent.getChatMessages({int chatId}) = _GetChatMessages;
  const factory MessageEvent.sendMessage({int chaId}) = _SendMessage;
  const factory MessageEvent.pickFile(
      {String path, FileType fileType, int chatId}) = _PickFile;

  const factory MessageEvent.removeFromSelectedMessages({MessageBody element}) =
      _RemoveFromSelectedMessages;
  const factory MessageEvent.addToSelectedMessages({MessageBody element}) =
      _AddToSelectedMessages;
  const factory MessageEvent.switchToStandardAppBar() = _StandardAppbar;
  const factory MessageEvent.switchToInfoAppBar() = _SwitchToInfoAppBar;
  const factory MessageEvent.showFilters() = _ShowFilters;
  const factory MessageEvent.hideFilters() = _HideFilters;
}
