// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies

part of 'message_bloc.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

/// @nodoc
class _$MessageEventTearOff {
  const _$MessageEventTearOff();

// ignore: unused_element
  _MessageChanged messageChanged(String message) {
    return _MessageChanged(
      message,
    );
  }

// ignore: unused_element
  _GetChatMessages getChatMessages({int chatId}) {
    return _GetChatMessages(
      chatId: chatId,
    );
  }

// ignore: unused_element
  _SendMessage sendMessage({int chaId}) {
    return _SendMessage(
      chaId: chaId,
    );
  }

// ignore: unused_element
  _PickFile pickFile({String path, FileType fileType, int chatId}) {
    return _PickFile(
      path: path,
      fileType: fileType,
      chatId: chatId,
    );
  }

// ignore: unused_element
  _RemoveFromSelectedMessages removeFromSelectedMessages(
      {MessageBody element}) {
    return _RemoveFromSelectedMessages(
      element: element,
    );
  }

// ignore: unused_element
  _AddToSelectedMessages addToSelectedMessages({MessageBody element}) {
    return _AddToSelectedMessages(
      element: element,
    );
  }

// ignore: unused_element
  _StandardAppbar switchToStandardAppBar() {
    return const _StandardAppbar();
  }

// ignore: unused_element
  _SwitchToInfoAppBar switchToInfoAppBar() {
    return const _SwitchToInfoAppBar();
  }

// ignore: unused_element
  _ShowFilters showFilters() {
    return const _ShowFilters();
  }

// ignore: unused_element
  _HideFilters hideFilters() {
    return const _HideFilters();
  }
}

/// @nodoc
// ignore: unused_element
const $MessageEvent = _$MessageEventTearOff();

/// @nodoc
mixin _$MessageEvent {
  @optionalTypeArgs
  Result when<Result extends Object>({
    @required Result messageChanged(String message),
    @required Result getChatMessages(int chatId),
    @required Result sendMessage(int chaId),
    @required Result pickFile(String path, FileType fileType, int chatId),
    @required Result removeFromSelectedMessages(MessageBody element),
    @required Result addToSelectedMessages(MessageBody element),
    @required Result switchToStandardAppBar(),
    @required Result switchToInfoAppBar(),
    @required Result showFilters(),
    @required Result hideFilters(),
  });
  @optionalTypeArgs
  Result maybeWhen<Result extends Object>({
    Result messageChanged(String message),
    Result getChatMessages(int chatId),
    Result sendMessage(int chaId),
    Result pickFile(String path, FileType fileType, int chatId),
    Result removeFromSelectedMessages(MessageBody element),
    Result addToSelectedMessages(MessageBody element),
    Result switchToStandardAppBar(),
    Result switchToInfoAppBar(),
    Result showFilters(),
    Result hideFilters(),
    @required Result orElse(),
  });
  @optionalTypeArgs
  Result map<Result extends Object>({
    @required Result messageChanged(_MessageChanged value),
    @required Result getChatMessages(_GetChatMessages value),
    @required Result sendMessage(_SendMessage value),
    @required Result pickFile(_PickFile value),
    @required
        Result removeFromSelectedMessages(_RemoveFromSelectedMessages value),
    @required Result addToSelectedMessages(_AddToSelectedMessages value),
    @required Result switchToStandardAppBar(_StandardAppbar value),
    @required Result switchToInfoAppBar(_SwitchToInfoAppBar value),
    @required Result showFilters(_ShowFilters value),
    @required Result hideFilters(_HideFilters value),
  });
  @optionalTypeArgs
  Result maybeMap<Result extends Object>({
    Result messageChanged(_MessageChanged value),
    Result getChatMessages(_GetChatMessages value),
    Result sendMessage(_SendMessage value),
    Result pickFile(_PickFile value),
    Result removeFromSelectedMessages(_RemoveFromSelectedMessages value),
    Result addToSelectedMessages(_AddToSelectedMessages value),
    Result switchToStandardAppBar(_StandardAppbar value),
    Result switchToInfoAppBar(_SwitchToInfoAppBar value),
    Result showFilters(_ShowFilters value),
    Result hideFilters(_HideFilters value),
    @required Result orElse(),
  });
}

/// @nodoc
abstract class $MessageEventCopyWith<$Res> {
  factory $MessageEventCopyWith(
          MessageEvent value, $Res Function(MessageEvent) then) =
      _$MessageEventCopyWithImpl<$Res>;
}

/// @nodoc
class _$MessageEventCopyWithImpl<$Res> implements $MessageEventCopyWith<$Res> {
  _$MessageEventCopyWithImpl(this._value, this._then);

  final MessageEvent _value;
  // ignore: unused_field
  final $Res Function(MessageEvent) _then;
}

/// @nodoc
abstract class _$MessageChangedCopyWith<$Res> {
  factory _$MessageChangedCopyWith(
          _MessageChanged value, $Res Function(_MessageChanged) then) =
      __$MessageChangedCopyWithImpl<$Res>;
  $Res call({String message});
}

/// @nodoc
class __$MessageChangedCopyWithImpl<$Res>
    extends _$MessageEventCopyWithImpl<$Res>
    implements _$MessageChangedCopyWith<$Res> {
  __$MessageChangedCopyWithImpl(
      _MessageChanged _value, $Res Function(_MessageChanged) _then)
      : super(_value, (v) => _then(v as _MessageChanged));

  @override
  _MessageChanged get _value => super._value as _MessageChanged;

  @override
  $Res call({
    Object message = freezed,
  }) {
    return _then(_MessageChanged(
      message == freezed ? _value.message : message as String,
    ));
  }
}

/// @nodoc
class _$_MessageChanged implements _MessageChanged {
  const _$_MessageChanged(this.message) : assert(message != null);

  @override
  final String message;

  @override
  String toString() {
    return 'MessageEvent.messageChanged(message: $message)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other is _MessageChanged &&
            (identical(other.message, message) ||
                const DeepCollectionEquality().equals(other.message, message)));
  }

  @override
  int get hashCode =>
      runtimeType.hashCode ^ const DeepCollectionEquality().hash(message);

  @override
  _$MessageChangedCopyWith<_MessageChanged> get copyWith =>
      __$MessageChangedCopyWithImpl<_MessageChanged>(this, _$identity);

  @override
  @optionalTypeArgs
  Result when<Result extends Object>({
    @required Result messageChanged(String message),
    @required Result getChatMessages(int chatId),
    @required Result sendMessage(int chaId),
    @required Result pickFile(String path, FileType fileType, int chatId),
    @required Result removeFromSelectedMessages(MessageBody element),
    @required Result addToSelectedMessages(MessageBody element),
    @required Result switchToStandardAppBar(),
    @required Result switchToInfoAppBar(),
    @required Result showFilters(),
    @required Result hideFilters(),
  }) {
    assert(messageChanged != null);
    assert(getChatMessages != null);
    assert(sendMessage != null);
    assert(pickFile != null);
    assert(removeFromSelectedMessages != null);
    assert(addToSelectedMessages != null);
    assert(switchToStandardAppBar != null);
    assert(switchToInfoAppBar != null);
    assert(showFilters != null);
    assert(hideFilters != null);
    return messageChanged(message);
  }

  @override
  @optionalTypeArgs
  Result maybeWhen<Result extends Object>({
    Result messageChanged(String message),
    Result getChatMessages(int chatId),
    Result sendMessage(int chaId),
    Result pickFile(String path, FileType fileType, int chatId),
    Result removeFromSelectedMessages(MessageBody element),
    Result addToSelectedMessages(MessageBody element),
    Result switchToStandardAppBar(),
    Result switchToInfoAppBar(),
    Result showFilters(),
    Result hideFilters(),
    @required Result orElse(),
  }) {
    assert(orElse != null);
    if (messageChanged != null) {
      return messageChanged(message);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  Result map<Result extends Object>({
    @required Result messageChanged(_MessageChanged value),
    @required Result getChatMessages(_GetChatMessages value),
    @required Result sendMessage(_SendMessage value),
    @required Result pickFile(_PickFile value),
    @required
        Result removeFromSelectedMessages(_RemoveFromSelectedMessages value),
    @required Result addToSelectedMessages(_AddToSelectedMessages value),
    @required Result switchToStandardAppBar(_StandardAppbar value),
    @required Result switchToInfoAppBar(_SwitchToInfoAppBar value),
    @required Result showFilters(_ShowFilters value),
    @required Result hideFilters(_HideFilters value),
  }) {
    assert(messageChanged != null);
    assert(getChatMessages != null);
    assert(sendMessage != null);
    assert(pickFile != null);
    assert(removeFromSelectedMessages != null);
    assert(addToSelectedMessages != null);
    assert(switchToStandardAppBar != null);
    assert(switchToInfoAppBar != null);
    assert(showFilters != null);
    assert(hideFilters != null);
    return messageChanged(this);
  }

  @override
  @optionalTypeArgs
  Result maybeMap<Result extends Object>({
    Result messageChanged(_MessageChanged value),
    Result getChatMessages(_GetChatMessages value),
    Result sendMessage(_SendMessage value),
    Result pickFile(_PickFile value),
    Result removeFromSelectedMessages(_RemoveFromSelectedMessages value),
    Result addToSelectedMessages(_AddToSelectedMessages value),
    Result switchToStandardAppBar(_StandardAppbar value),
    Result switchToInfoAppBar(_SwitchToInfoAppBar value),
    Result showFilters(_ShowFilters value),
    Result hideFilters(_HideFilters value),
    @required Result orElse(),
  }) {
    assert(orElse != null);
    if (messageChanged != null) {
      return messageChanged(this);
    }
    return orElse();
  }
}

abstract class _MessageChanged implements MessageEvent {
  const factory _MessageChanged(String message) = _$_MessageChanged;

  String get message;
  _$MessageChangedCopyWith<_MessageChanged> get copyWith;
}

/// @nodoc
abstract class _$GetChatMessagesCopyWith<$Res> {
  factory _$GetChatMessagesCopyWith(
          _GetChatMessages value, $Res Function(_GetChatMessages) then) =
      __$GetChatMessagesCopyWithImpl<$Res>;
  $Res call({int chatId});
}

/// @nodoc
class __$GetChatMessagesCopyWithImpl<$Res>
    extends _$MessageEventCopyWithImpl<$Res>
    implements _$GetChatMessagesCopyWith<$Res> {
  __$GetChatMessagesCopyWithImpl(
      _GetChatMessages _value, $Res Function(_GetChatMessages) _then)
      : super(_value, (v) => _then(v as _GetChatMessages));

  @override
  _GetChatMessages get _value => super._value as _GetChatMessages;

  @override
  $Res call({
    Object chatId = freezed,
  }) {
    return _then(_GetChatMessages(
      chatId: chatId == freezed ? _value.chatId : chatId as int,
    ));
  }
}

/// @nodoc
class _$_GetChatMessages implements _GetChatMessages {
  const _$_GetChatMessages({this.chatId});

  @override
  final int chatId;

  @override
  String toString() {
    return 'MessageEvent.getChatMessages(chatId: $chatId)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other is _GetChatMessages &&
            (identical(other.chatId, chatId) ||
                const DeepCollectionEquality().equals(other.chatId, chatId)));
  }

  @override
  int get hashCode =>
      runtimeType.hashCode ^ const DeepCollectionEquality().hash(chatId);

  @override
  _$GetChatMessagesCopyWith<_GetChatMessages> get copyWith =>
      __$GetChatMessagesCopyWithImpl<_GetChatMessages>(this, _$identity);

  @override
  @optionalTypeArgs
  Result when<Result extends Object>({
    @required Result messageChanged(String message),
    @required Result getChatMessages(int chatId),
    @required Result sendMessage(int chaId),
    @required Result pickFile(String path, FileType fileType, int chatId),
    @required Result removeFromSelectedMessages(MessageBody element),
    @required Result addToSelectedMessages(MessageBody element),
    @required Result switchToStandardAppBar(),
    @required Result switchToInfoAppBar(),
    @required Result showFilters(),
    @required Result hideFilters(),
  }) {
    assert(messageChanged != null);
    assert(getChatMessages != null);
    assert(sendMessage != null);
    assert(pickFile != null);
    assert(removeFromSelectedMessages != null);
    assert(addToSelectedMessages != null);
    assert(switchToStandardAppBar != null);
    assert(switchToInfoAppBar != null);
    assert(showFilters != null);
    assert(hideFilters != null);
    return getChatMessages(chatId);
  }

  @override
  @optionalTypeArgs
  Result maybeWhen<Result extends Object>({
    Result messageChanged(String message),
    Result getChatMessages(int chatId),
    Result sendMessage(int chaId),
    Result pickFile(String path, FileType fileType, int chatId),
    Result removeFromSelectedMessages(MessageBody element),
    Result addToSelectedMessages(MessageBody element),
    Result switchToStandardAppBar(),
    Result switchToInfoAppBar(),
    Result showFilters(),
    Result hideFilters(),
    @required Result orElse(),
  }) {
    assert(orElse != null);
    if (getChatMessages != null) {
      return getChatMessages(chatId);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  Result map<Result extends Object>({
    @required Result messageChanged(_MessageChanged value),
    @required Result getChatMessages(_GetChatMessages value),
    @required Result sendMessage(_SendMessage value),
    @required Result pickFile(_PickFile value),
    @required
        Result removeFromSelectedMessages(_RemoveFromSelectedMessages value),
    @required Result addToSelectedMessages(_AddToSelectedMessages value),
    @required Result switchToStandardAppBar(_StandardAppbar value),
    @required Result switchToInfoAppBar(_SwitchToInfoAppBar value),
    @required Result showFilters(_ShowFilters value),
    @required Result hideFilters(_HideFilters value),
  }) {
    assert(messageChanged != null);
    assert(getChatMessages != null);
    assert(sendMessage != null);
    assert(pickFile != null);
    assert(removeFromSelectedMessages != null);
    assert(addToSelectedMessages != null);
    assert(switchToStandardAppBar != null);
    assert(switchToInfoAppBar != null);
    assert(showFilters != null);
    assert(hideFilters != null);
    return getChatMessages(this);
  }

  @override
  @optionalTypeArgs
  Result maybeMap<Result extends Object>({
    Result messageChanged(_MessageChanged value),
    Result getChatMessages(_GetChatMessages value),
    Result sendMessage(_SendMessage value),
    Result pickFile(_PickFile value),
    Result removeFromSelectedMessages(_RemoveFromSelectedMessages value),
    Result addToSelectedMessages(_AddToSelectedMessages value),
    Result switchToStandardAppBar(_StandardAppbar value),
    Result switchToInfoAppBar(_SwitchToInfoAppBar value),
    Result showFilters(_ShowFilters value),
    Result hideFilters(_HideFilters value),
    @required Result orElse(),
  }) {
    assert(orElse != null);
    if (getChatMessages != null) {
      return getChatMessages(this);
    }
    return orElse();
  }
}

abstract class _GetChatMessages implements MessageEvent {
  const factory _GetChatMessages({int chatId}) = _$_GetChatMessages;

  int get chatId;
  _$GetChatMessagesCopyWith<_GetChatMessages> get copyWith;
}

/// @nodoc
abstract class _$SendMessageCopyWith<$Res> {
  factory _$SendMessageCopyWith(
          _SendMessage value, $Res Function(_SendMessage) then) =
      __$SendMessageCopyWithImpl<$Res>;
  $Res call({int chaId});
}

/// @nodoc
class __$SendMessageCopyWithImpl<$Res> extends _$MessageEventCopyWithImpl<$Res>
    implements _$SendMessageCopyWith<$Res> {
  __$SendMessageCopyWithImpl(
      _SendMessage _value, $Res Function(_SendMessage) _then)
      : super(_value, (v) => _then(v as _SendMessage));

  @override
  _SendMessage get _value => super._value as _SendMessage;

  @override
  $Res call({
    Object chaId = freezed,
  }) {
    return _then(_SendMessage(
      chaId: chaId == freezed ? _value.chaId : chaId as int,
    ));
  }
}

/// @nodoc
class _$_SendMessage implements _SendMessage {
  const _$_SendMessage({this.chaId});

  @override
  final int chaId;

  @override
  String toString() {
    return 'MessageEvent.sendMessage(chaId: $chaId)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other is _SendMessage &&
            (identical(other.chaId, chaId) ||
                const DeepCollectionEquality().equals(other.chaId, chaId)));
  }

  @override
  int get hashCode =>
      runtimeType.hashCode ^ const DeepCollectionEquality().hash(chaId);

  @override
  _$SendMessageCopyWith<_SendMessage> get copyWith =>
      __$SendMessageCopyWithImpl<_SendMessage>(this, _$identity);

  @override
  @optionalTypeArgs
  Result when<Result extends Object>({
    @required Result messageChanged(String message),
    @required Result getChatMessages(int chatId),
    @required Result sendMessage(int chaId),
    @required Result pickFile(String path, FileType fileType, int chatId),
    @required Result removeFromSelectedMessages(MessageBody element),
    @required Result addToSelectedMessages(MessageBody element),
    @required Result switchToStandardAppBar(),
    @required Result switchToInfoAppBar(),
    @required Result showFilters(),
    @required Result hideFilters(),
  }) {
    assert(messageChanged != null);
    assert(getChatMessages != null);
    assert(sendMessage != null);
    assert(pickFile != null);
    assert(removeFromSelectedMessages != null);
    assert(addToSelectedMessages != null);
    assert(switchToStandardAppBar != null);
    assert(switchToInfoAppBar != null);
    assert(showFilters != null);
    assert(hideFilters != null);
    return sendMessage(chaId);
  }

  @override
  @optionalTypeArgs
  Result maybeWhen<Result extends Object>({
    Result messageChanged(String message),
    Result getChatMessages(int chatId),
    Result sendMessage(int chaId),
    Result pickFile(String path, FileType fileType, int chatId),
    Result removeFromSelectedMessages(MessageBody element),
    Result addToSelectedMessages(MessageBody element),
    Result switchToStandardAppBar(),
    Result switchToInfoAppBar(),
    Result showFilters(),
    Result hideFilters(),
    @required Result orElse(),
  }) {
    assert(orElse != null);
    if (sendMessage != null) {
      return sendMessage(chaId);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  Result map<Result extends Object>({
    @required Result messageChanged(_MessageChanged value),
    @required Result getChatMessages(_GetChatMessages value),
    @required Result sendMessage(_SendMessage value),
    @required Result pickFile(_PickFile value),
    @required
        Result removeFromSelectedMessages(_RemoveFromSelectedMessages value),
    @required Result addToSelectedMessages(_AddToSelectedMessages value),
    @required Result switchToStandardAppBar(_StandardAppbar value),
    @required Result switchToInfoAppBar(_SwitchToInfoAppBar value),
    @required Result showFilters(_ShowFilters value),
    @required Result hideFilters(_HideFilters value),
  }) {
    assert(messageChanged != null);
    assert(getChatMessages != null);
    assert(sendMessage != null);
    assert(pickFile != null);
    assert(removeFromSelectedMessages != null);
    assert(addToSelectedMessages != null);
    assert(switchToStandardAppBar != null);
    assert(switchToInfoAppBar != null);
    assert(showFilters != null);
    assert(hideFilters != null);
    return sendMessage(this);
  }

  @override
  @optionalTypeArgs
  Result maybeMap<Result extends Object>({
    Result messageChanged(_MessageChanged value),
    Result getChatMessages(_GetChatMessages value),
    Result sendMessage(_SendMessage value),
    Result pickFile(_PickFile value),
    Result removeFromSelectedMessages(_RemoveFromSelectedMessages value),
    Result addToSelectedMessages(_AddToSelectedMessages value),
    Result switchToStandardAppBar(_StandardAppbar value),
    Result switchToInfoAppBar(_SwitchToInfoAppBar value),
    Result showFilters(_ShowFilters value),
    Result hideFilters(_HideFilters value),
    @required Result orElse(),
  }) {
    assert(orElse != null);
    if (sendMessage != null) {
      return sendMessage(this);
    }
    return orElse();
  }
}

abstract class _SendMessage implements MessageEvent {
  const factory _SendMessage({int chaId}) = _$_SendMessage;

  int get chaId;
  _$SendMessageCopyWith<_SendMessage> get copyWith;
}

/// @nodoc
abstract class _$PickFileCopyWith<$Res> {
  factory _$PickFileCopyWith(_PickFile value, $Res Function(_PickFile) then) =
      __$PickFileCopyWithImpl<$Res>;
  $Res call({String path, FileType fileType, int chatId});
}

/// @nodoc
class __$PickFileCopyWithImpl<$Res> extends _$MessageEventCopyWithImpl<$Res>
    implements _$PickFileCopyWith<$Res> {
  __$PickFileCopyWithImpl(_PickFile _value, $Res Function(_PickFile) _then)
      : super(_value, (v) => _then(v as _PickFile));

  @override
  _PickFile get _value => super._value as _PickFile;

  @override
  $Res call({
    Object path = freezed,
    Object fileType = freezed,
    Object chatId = freezed,
  }) {
    return _then(_PickFile(
      path: path == freezed ? _value.path : path as String,
      fileType: fileType == freezed ? _value.fileType : fileType as FileType,
      chatId: chatId == freezed ? _value.chatId : chatId as int,
    ));
  }
}

/// @nodoc
class _$_PickFile implements _PickFile {
  const _$_PickFile({this.path, this.fileType, this.chatId});

  @override
  final String path;
  @override
  final FileType fileType;
  @override
  final int chatId;

  @override
  String toString() {
    return 'MessageEvent.pickFile(path: $path, fileType: $fileType, chatId: $chatId)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other is _PickFile &&
            (identical(other.path, path) ||
                const DeepCollectionEquality().equals(other.path, path)) &&
            (identical(other.fileType, fileType) ||
                const DeepCollectionEquality()
                    .equals(other.fileType, fileType)) &&
            (identical(other.chatId, chatId) ||
                const DeepCollectionEquality().equals(other.chatId, chatId)));
  }

  @override
  int get hashCode =>
      runtimeType.hashCode ^
      const DeepCollectionEquality().hash(path) ^
      const DeepCollectionEquality().hash(fileType) ^
      const DeepCollectionEquality().hash(chatId);

  @override
  _$PickFileCopyWith<_PickFile> get copyWith =>
      __$PickFileCopyWithImpl<_PickFile>(this, _$identity);

  @override
  @optionalTypeArgs
  Result when<Result extends Object>({
    @required Result messageChanged(String message),
    @required Result getChatMessages(int chatId),
    @required Result sendMessage(int chaId),
    @required Result pickFile(String path, FileType fileType, int chatId),
    @required Result removeFromSelectedMessages(MessageBody element),
    @required Result addToSelectedMessages(MessageBody element),
    @required Result switchToStandardAppBar(),
    @required Result switchToInfoAppBar(),
    @required Result showFilters(),
    @required Result hideFilters(),
  }) {
    assert(messageChanged != null);
    assert(getChatMessages != null);
    assert(sendMessage != null);
    assert(pickFile != null);
    assert(removeFromSelectedMessages != null);
    assert(addToSelectedMessages != null);
    assert(switchToStandardAppBar != null);
    assert(switchToInfoAppBar != null);
    assert(showFilters != null);
    assert(hideFilters != null);
    return pickFile(path, fileType, chatId);
  }

  @override
  @optionalTypeArgs
  Result maybeWhen<Result extends Object>({
    Result messageChanged(String message),
    Result getChatMessages(int chatId),
    Result sendMessage(int chaId),
    Result pickFile(String path, FileType fileType, int chatId),
    Result removeFromSelectedMessages(MessageBody element),
    Result addToSelectedMessages(MessageBody element),
    Result switchToStandardAppBar(),
    Result switchToInfoAppBar(),
    Result showFilters(),
    Result hideFilters(),
    @required Result orElse(),
  }) {
    assert(orElse != null);
    if (pickFile != null) {
      return pickFile(path, fileType, chatId);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  Result map<Result extends Object>({
    @required Result messageChanged(_MessageChanged value),
    @required Result getChatMessages(_GetChatMessages value),
    @required Result sendMessage(_SendMessage value),
    @required Result pickFile(_PickFile value),
    @required
        Result removeFromSelectedMessages(_RemoveFromSelectedMessages value),
    @required Result addToSelectedMessages(_AddToSelectedMessages value),
    @required Result switchToStandardAppBar(_StandardAppbar value),
    @required Result switchToInfoAppBar(_SwitchToInfoAppBar value),
    @required Result showFilters(_ShowFilters value),
    @required Result hideFilters(_HideFilters value),
  }) {
    assert(messageChanged != null);
    assert(getChatMessages != null);
    assert(sendMessage != null);
    assert(pickFile != null);
    assert(removeFromSelectedMessages != null);
    assert(addToSelectedMessages != null);
    assert(switchToStandardAppBar != null);
    assert(switchToInfoAppBar != null);
    assert(showFilters != null);
    assert(hideFilters != null);
    return pickFile(this);
  }

  @override
  @optionalTypeArgs
  Result maybeMap<Result extends Object>({
    Result messageChanged(_MessageChanged value),
    Result getChatMessages(_GetChatMessages value),
    Result sendMessage(_SendMessage value),
    Result pickFile(_PickFile value),
    Result removeFromSelectedMessages(_RemoveFromSelectedMessages value),
    Result addToSelectedMessages(_AddToSelectedMessages value),
    Result switchToStandardAppBar(_StandardAppbar value),
    Result switchToInfoAppBar(_SwitchToInfoAppBar value),
    Result showFilters(_ShowFilters value),
    Result hideFilters(_HideFilters value),
    @required Result orElse(),
  }) {
    assert(orElse != null);
    if (pickFile != null) {
      return pickFile(this);
    }
    return orElse();
  }
}

abstract class _PickFile implements MessageEvent {
  const factory _PickFile({String path, FileType fileType, int chatId}) =
      _$_PickFile;

  String get path;
  FileType get fileType;
  int get chatId;
  _$PickFileCopyWith<_PickFile> get copyWith;
}

/// @nodoc
abstract class _$RemoveFromSelectedMessagesCopyWith<$Res> {
  factory _$RemoveFromSelectedMessagesCopyWith(
          _RemoveFromSelectedMessages value,
          $Res Function(_RemoveFromSelectedMessages) then) =
      __$RemoveFromSelectedMessagesCopyWithImpl<$Res>;
  $Res call({MessageBody element});
}

/// @nodoc
class __$RemoveFromSelectedMessagesCopyWithImpl<$Res>
    extends _$MessageEventCopyWithImpl<$Res>
    implements _$RemoveFromSelectedMessagesCopyWith<$Res> {
  __$RemoveFromSelectedMessagesCopyWithImpl(_RemoveFromSelectedMessages _value,
      $Res Function(_RemoveFromSelectedMessages) _then)
      : super(_value, (v) => _then(v as _RemoveFromSelectedMessages));

  @override
  _RemoveFromSelectedMessages get _value =>
      super._value as _RemoveFromSelectedMessages;

  @override
  $Res call({
    Object element = freezed,
  }) {
    return _then(_RemoveFromSelectedMessages(
      element: element == freezed ? _value.element : element as MessageBody,
    ));
  }
}

/// @nodoc
class _$_RemoveFromSelectedMessages implements _RemoveFromSelectedMessages {
  const _$_RemoveFromSelectedMessages({this.element});

  @override
  final MessageBody element;

  @override
  String toString() {
    return 'MessageEvent.removeFromSelectedMessages(element: $element)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other is _RemoveFromSelectedMessages &&
            (identical(other.element, element) ||
                const DeepCollectionEquality().equals(other.element, element)));
  }

  @override
  int get hashCode =>
      runtimeType.hashCode ^ const DeepCollectionEquality().hash(element);

  @override
  _$RemoveFromSelectedMessagesCopyWith<_RemoveFromSelectedMessages>
      get copyWith => __$RemoveFromSelectedMessagesCopyWithImpl<
          _RemoveFromSelectedMessages>(this, _$identity);

  @override
  @optionalTypeArgs
  Result when<Result extends Object>({
    @required Result messageChanged(String message),
    @required Result getChatMessages(int chatId),
    @required Result sendMessage(int chaId),
    @required Result pickFile(String path, FileType fileType, int chatId),
    @required Result removeFromSelectedMessages(MessageBody element),
    @required Result addToSelectedMessages(MessageBody element),
    @required Result switchToStandardAppBar(),
    @required Result switchToInfoAppBar(),
    @required Result showFilters(),
    @required Result hideFilters(),
  }) {
    assert(messageChanged != null);
    assert(getChatMessages != null);
    assert(sendMessage != null);
    assert(pickFile != null);
    assert(removeFromSelectedMessages != null);
    assert(addToSelectedMessages != null);
    assert(switchToStandardAppBar != null);
    assert(switchToInfoAppBar != null);
    assert(showFilters != null);
    assert(hideFilters != null);
    return removeFromSelectedMessages(element);
  }

  @override
  @optionalTypeArgs
  Result maybeWhen<Result extends Object>({
    Result messageChanged(String message),
    Result getChatMessages(int chatId),
    Result sendMessage(int chaId),
    Result pickFile(String path, FileType fileType, int chatId),
    Result removeFromSelectedMessages(MessageBody element),
    Result addToSelectedMessages(MessageBody element),
    Result switchToStandardAppBar(),
    Result switchToInfoAppBar(),
    Result showFilters(),
    Result hideFilters(),
    @required Result orElse(),
  }) {
    assert(orElse != null);
    if (removeFromSelectedMessages != null) {
      return removeFromSelectedMessages(element);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  Result map<Result extends Object>({
    @required Result messageChanged(_MessageChanged value),
    @required Result getChatMessages(_GetChatMessages value),
    @required Result sendMessage(_SendMessage value),
    @required Result pickFile(_PickFile value),
    @required
        Result removeFromSelectedMessages(_RemoveFromSelectedMessages value),
    @required Result addToSelectedMessages(_AddToSelectedMessages value),
    @required Result switchToStandardAppBar(_StandardAppbar value),
    @required Result switchToInfoAppBar(_SwitchToInfoAppBar value),
    @required Result showFilters(_ShowFilters value),
    @required Result hideFilters(_HideFilters value),
  }) {
    assert(messageChanged != null);
    assert(getChatMessages != null);
    assert(sendMessage != null);
    assert(pickFile != null);
    assert(removeFromSelectedMessages != null);
    assert(addToSelectedMessages != null);
    assert(switchToStandardAppBar != null);
    assert(switchToInfoAppBar != null);
    assert(showFilters != null);
    assert(hideFilters != null);
    return removeFromSelectedMessages(this);
  }

  @override
  @optionalTypeArgs
  Result maybeMap<Result extends Object>({
    Result messageChanged(_MessageChanged value),
    Result getChatMessages(_GetChatMessages value),
    Result sendMessage(_SendMessage value),
    Result pickFile(_PickFile value),
    Result removeFromSelectedMessages(_RemoveFromSelectedMessages value),
    Result addToSelectedMessages(_AddToSelectedMessages value),
    Result switchToStandardAppBar(_StandardAppbar value),
    Result switchToInfoAppBar(_SwitchToInfoAppBar value),
    Result showFilters(_ShowFilters value),
    Result hideFilters(_HideFilters value),
    @required Result orElse(),
  }) {
    assert(orElse != null);
    if (removeFromSelectedMessages != null) {
      return removeFromSelectedMessages(this);
    }
    return orElse();
  }
}

abstract class _RemoveFromSelectedMessages implements MessageEvent {
  const factory _RemoveFromSelectedMessages({MessageBody element}) =
      _$_RemoveFromSelectedMessages;

  MessageBody get element;
  _$RemoveFromSelectedMessagesCopyWith<_RemoveFromSelectedMessages>
      get copyWith;
}

/// @nodoc
abstract class _$AddToSelectedMessagesCopyWith<$Res> {
  factory _$AddToSelectedMessagesCopyWith(_AddToSelectedMessages value,
          $Res Function(_AddToSelectedMessages) then) =
      __$AddToSelectedMessagesCopyWithImpl<$Res>;
  $Res call({MessageBody element});
}

/// @nodoc
class __$AddToSelectedMessagesCopyWithImpl<$Res>
    extends _$MessageEventCopyWithImpl<$Res>
    implements _$AddToSelectedMessagesCopyWith<$Res> {
  __$AddToSelectedMessagesCopyWithImpl(_AddToSelectedMessages _value,
      $Res Function(_AddToSelectedMessages) _then)
      : super(_value, (v) => _then(v as _AddToSelectedMessages));

  @override
  _AddToSelectedMessages get _value => super._value as _AddToSelectedMessages;

  @override
  $Res call({
    Object element = freezed,
  }) {
    return _then(_AddToSelectedMessages(
      element: element == freezed ? _value.element : element as MessageBody,
    ));
  }
}

/// @nodoc
class _$_AddToSelectedMessages implements _AddToSelectedMessages {
  const _$_AddToSelectedMessages({this.element});

  @override
  final MessageBody element;

  @override
  String toString() {
    return 'MessageEvent.addToSelectedMessages(element: $element)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other is _AddToSelectedMessages &&
            (identical(other.element, element) ||
                const DeepCollectionEquality().equals(other.element, element)));
  }

  @override
  int get hashCode =>
      runtimeType.hashCode ^ const DeepCollectionEquality().hash(element);

  @override
  _$AddToSelectedMessagesCopyWith<_AddToSelectedMessages> get copyWith =>
      __$AddToSelectedMessagesCopyWithImpl<_AddToSelectedMessages>(
          this, _$identity);

  @override
  @optionalTypeArgs
  Result when<Result extends Object>({
    @required Result messageChanged(String message),
    @required Result getChatMessages(int chatId),
    @required Result sendMessage(int chaId),
    @required Result pickFile(String path, FileType fileType, int chatId),
    @required Result removeFromSelectedMessages(MessageBody element),
    @required Result addToSelectedMessages(MessageBody element),
    @required Result switchToStandardAppBar(),
    @required Result switchToInfoAppBar(),
    @required Result showFilters(),
    @required Result hideFilters(),
  }) {
    assert(messageChanged != null);
    assert(getChatMessages != null);
    assert(sendMessage != null);
    assert(pickFile != null);
    assert(removeFromSelectedMessages != null);
    assert(addToSelectedMessages != null);
    assert(switchToStandardAppBar != null);
    assert(switchToInfoAppBar != null);
    assert(showFilters != null);
    assert(hideFilters != null);
    return addToSelectedMessages(element);
  }

  @override
  @optionalTypeArgs
  Result maybeWhen<Result extends Object>({
    Result messageChanged(String message),
    Result getChatMessages(int chatId),
    Result sendMessage(int chaId),
    Result pickFile(String path, FileType fileType, int chatId),
    Result removeFromSelectedMessages(MessageBody element),
    Result addToSelectedMessages(MessageBody element),
    Result switchToStandardAppBar(),
    Result switchToInfoAppBar(),
    Result showFilters(),
    Result hideFilters(),
    @required Result orElse(),
  }) {
    assert(orElse != null);
    if (addToSelectedMessages != null) {
      return addToSelectedMessages(element);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  Result map<Result extends Object>({
    @required Result messageChanged(_MessageChanged value),
    @required Result getChatMessages(_GetChatMessages value),
    @required Result sendMessage(_SendMessage value),
    @required Result pickFile(_PickFile value),
    @required
        Result removeFromSelectedMessages(_RemoveFromSelectedMessages value),
    @required Result addToSelectedMessages(_AddToSelectedMessages value),
    @required Result switchToStandardAppBar(_StandardAppbar value),
    @required Result switchToInfoAppBar(_SwitchToInfoAppBar value),
    @required Result showFilters(_ShowFilters value),
    @required Result hideFilters(_HideFilters value),
  }) {
    assert(messageChanged != null);
    assert(getChatMessages != null);
    assert(sendMessage != null);
    assert(pickFile != null);
    assert(removeFromSelectedMessages != null);
    assert(addToSelectedMessages != null);
    assert(switchToStandardAppBar != null);
    assert(switchToInfoAppBar != null);
    assert(showFilters != null);
    assert(hideFilters != null);
    return addToSelectedMessages(this);
  }

  @override
  @optionalTypeArgs
  Result maybeMap<Result extends Object>({
    Result messageChanged(_MessageChanged value),
    Result getChatMessages(_GetChatMessages value),
    Result sendMessage(_SendMessage value),
    Result pickFile(_PickFile value),
    Result removeFromSelectedMessages(_RemoveFromSelectedMessages value),
    Result addToSelectedMessages(_AddToSelectedMessages value),
    Result switchToStandardAppBar(_StandardAppbar value),
    Result switchToInfoAppBar(_SwitchToInfoAppBar value),
    Result showFilters(_ShowFilters value),
    Result hideFilters(_HideFilters value),
    @required Result orElse(),
  }) {
    assert(orElse != null);
    if (addToSelectedMessages != null) {
      return addToSelectedMessages(this);
    }
    return orElse();
  }
}

abstract class _AddToSelectedMessages implements MessageEvent {
  const factory _AddToSelectedMessages({MessageBody element}) =
      _$_AddToSelectedMessages;

  MessageBody get element;
  _$AddToSelectedMessagesCopyWith<_AddToSelectedMessages> get copyWith;
}

/// @nodoc
abstract class _$StandardAppbarCopyWith<$Res> {
  factory _$StandardAppbarCopyWith(
          _StandardAppbar value, $Res Function(_StandardAppbar) then) =
      __$StandardAppbarCopyWithImpl<$Res>;
}

/// @nodoc
class __$StandardAppbarCopyWithImpl<$Res>
    extends _$MessageEventCopyWithImpl<$Res>
    implements _$StandardAppbarCopyWith<$Res> {
  __$StandardAppbarCopyWithImpl(
      _StandardAppbar _value, $Res Function(_StandardAppbar) _then)
      : super(_value, (v) => _then(v as _StandardAppbar));

  @override
  _StandardAppbar get _value => super._value as _StandardAppbar;
}

/// @nodoc
class _$_StandardAppbar implements _StandardAppbar {
  const _$_StandardAppbar();

  @override
  String toString() {
    return 'MessageEvent.switchToStandardAppBar()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) || (other is _StandardAppbar);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  Result when<Result extends Object>({
    @required Result messageChanged(String message),
    @required Result getChatMessages(int chatId),
    @required Result sendMessage(int chaId),
    @required Result pickFile(String path, FileType fileType, int chatId),
    @required Result removeFromSelectedMessages(MessageBody element),
    @required Result addToSelectedMessages(MessageBody element),
    @required Result switchToStandardAppBar(),
    @required Result switchToInfoAppBar(),
    @required Result showFilters(),
    @required Result hideFilters(),
  }) {
    assert(messageChanged != null);
    assert(getChatMessages != null);
    assert(sendMessage != null);
    assert(pickFile != null);
    assert(removeFromSelectedMessages != null);
    assert(addToSelectedMessages != null);
    assert(switchToStandardAppBar != null);
    assert(switchToInfoAppBar != null);
    assert(showFilters != null);
    assert(hideFilters != null);
    return switchToStandardAppBar();
  }

  @override
  @optionalTypeArgs
  Result maybeWhen<Result extends Object>({
    Result messageChanged(String message),
    Result getChatMessages(int chatId),
    Result sendMessage(int chaId),
    Result pickFile(String path, FileType fileType, int chatId),
    Result removeFromSelectedMessages(MessageBody element),
    Result addToSelectedMessages(MessageBody element),
    Result switchToStandardAppBar(),
    Result switchToInfoAppBar(),
    Result showFilters(),
    Result hideFilters(),
    @required Result orElse(),
  }) {
    assert(orElse != null);
    if (switchToStandardAppBar != null) {
      return switchToStandardAppBar();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  Result map<Result extends Object>({
    @required Result messageChanged(_MessageChanged value),
    @required Result getChatMessages(_GetChatMessages value),
    @required Result sendMessage(_SendMessage value),
    @required Result pickFile(_PickFile value),
    @required
        Result removeFromSelectedMessages(_RemoveFromSelectedMessages value),
    @required Result addToSelectedMessages(_AddToSelectedMessages value),
    @required Result switchToStandardAppBar(_StandardAppbar value),
    @required Result switchToInfoAppBar(_SwitchToInfoAppBar value),
    @required Result showFilters(_ShowFilters value),
    @required Result hideFilters(_HideFilters value),
  }) {
    assert(messageChanged != null);
    assert(getChatMessages != null);
    assert(sendMessage != null);
    assert(pickFile != null);
    assert(removeFromSelectedMessages != null);
    assert(addToSelectedMessages != null);
    assert(switchToStandardAppBar != null);
    assert(switchToInfoAppBar != null);
    assert(showFilters != null);
    assert(hideFilters != null);
    return switchToStandardAppBar(this);
  }

  @override
  @optionalTypeArgs
  Result maybeMap<Result extends Object>({
    Result messageChanged(_MessageChanged value),
    Result getChatMessages(_GetChatMessages value),
    Result sendMessage(_SendMessage value),
    Result pickFile(_PickFile value),
    Result removeFromSelectedMessages(_RemoveFromSelectedMessages value),
    Result addToSelectedMessages(_AddToSelectedMessages value),
    Result switchToStandardAppBar(_StandardAppbar value),
    Result switchToInfoAppBar(_SwitchToInfoAppBar value),
    Result showFilters(_ShowFilters value),
    Result hideFilters(_HideFilters value),
    @required Result orElse(),
  }) {
    assert(orElse != null);
    if (switchToStandardAppBar != null) {
      return switchToStandardAppBar(this);
    }
    return orElse();
  }
}

abstract class _StandardAppbar implements MessageEvent {
  const factory _StandardAppbar() = _$_StandardAppbar;
}

/// @nodoc
abstract class _$SwitchToInfoAppBarCopyWith<$Res> {
  factory _$SwitchToInfoAppBarCopyWith(
          _SwitchToInfoAppBar value, $Res Function(_SwitchToInfoAppBar) then) =
      __$SwitchToInfoAppBarCopyWithImpl<$Res>;
}

/// @nodoc
class __$SwitchToInfoAppBarCopyWithImpl<$Res>
    extends _$MessageEventCopyWithImpl<$Res>
    implements _$SwitchToInfoAppBarCopyWith<$Res> {
  __$SwitchToInfoAppBarCopyWithImpl(
      _SwitchToInfoAppBar _value, $Res Function(_SwitchToInfoAppBar) _then)
      : super(_value, (v) => _then(v as _SwitchToInfoAppBar));

  @override
  _SwitchToInfoAppBar get _value => super._value as _SwitchToInfoAppBar;
}

/// @nodoc
class _$_SwitchToInfoAppBar implements _SwitchToInfoAppBar {
  const _$_SwitchToInfoAppBar();

  @override
  String toString() {
    return 'MessageEvent.switchToInfoAppBar()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) || (other is _SwitchToInfoAppBar);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  Result when<Result extends Object>({
    @required Result messageChanged(String message),
    @required Result getChatMessages(int chatId),
    @required Result sendMessage(int chaId),
    @required Result pickFile(String path, FileType fileType, int chatId),
    @required Result removeFromSelectedMessages(MessageBody element),
    @required Result addToSelectedMessages(MessageBody element),
    @required Result switchToStandardAppBar(),
    @required Result switchToInfoAppBar(),
    @required Result showFilters(),
    @required Result hideFilters(),
  }) {
    assert(messageChanged != null);
    assert(getChatMessages != null);
    assert(sendMessage != null);
    assert(pickFile != null);
    assert(removeFromSelectedMessages != null);
    assert(addToSelectedMessages != null);
    assert(switchToStandardAppBar != null);
    assert(switchToInfoAppBar != null);
    assert(showFilters != null);
    assert(hideFilters != null);
    return switchToInfoAppBar();
  }

  @override
  @optionalTypeArgs
  Result maybeWhen<Result extends Object>({
    Result messageChanged(String message),
    Result getChatMessages(int chatId),
    Result sendMessage(int chaId),
    Result pickFile(String path, FileType fileType, int chatId),
    Result removeFromSelectedMessages(MessageBody element),
    Result addToSelectedMessages(MessageBody element),
    Result switchToStandardAppBar(),
    Result switchToInfoAppBar(),
    Result showFilters(),
    Result hideFilters(),
    @required Result orElse(),
  }) {
    assert(orElse != null);
    if (switchToInfoAppBar != null) {
      return switchToInfoAppBar();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  Result map<Result extends Object>({
    @required Result messageChanged(_MessageChanged value),
    @required Result getChatMessages(_GetChatMessages value),
    @required Result sendMessage(_SendMessage value),
    @required Result pickFile(_PickFile value),
    @required
        Result removeFromSelectedMessages(_RemoveFromSelectedMessages value),
    @required Result addToSelectedMessages(_AddToSelectedMessages value),
    @required Result switchToStandardAppBar(_StandardAppbar value),
    @required Result switchToInfoAppBar(_SwitchToInfoAppBar value),
    @required Result showFilters(_ShowFilters value),
    @required Result hideFilters(_HideFilters value),
  }) {
    assert(messageChanged != null);
    assert(getChatMessages != null);
    assert(sendMessage != null);
    assert(pickFile != null);
    assert(removeFromSelectedMessages != null);
    assert(addToSelectedMessages != null);
    assert(switchToStandardAppBar != null);
    assert(switchToInfoAppBar != null);
    assert(showFilters != null);
    assert(hideFilters != null);
    return switchToInfoAppBar(this);
  }

  @override
  @optionalTypeArgs
  Result maybeMap<Result extends Object>({
    Result messageChanged(_MessageChanged value),
    Result getChatMessages(_GetChatMessages value),
    Result sendMessage(_SendMessage value),
    Result pickFile(_PickFile value),
    Result removeFromSelectedMessages(_RemoveFromSelectedMessages value),
    Result addToSelectedMessages(_AddToSelectedMessages value),
    Result switchToStandardAppBar(_StandardAppbar value),
    Result switchToInfoAppBar(_SwitchToInfoAppBar value),
    Result showFilters(_ShowFilters value),
    Result hideFilters(_HideFilters value),
    @required Result orElse(),
  }) {
    assert(orElse != null);
    if (switchToInfoAppBar != null) {
      return switchToInfoAppBar(this);
    }
    return orElse();
  }
}

abstract class _SwitchToInfoAppBar implements MessageEvent {
  const factory _SwitchToInfoAppBar() = _$_SwitchToInfoAppBar;
}

/// @nodoc
abstract class _$ShowFiltersCopyWith<$Res> {
  factory _$ShowFiltersCopyWith(
          _ShowFilters value, $Res Function(_ShowFilters) then) =
      __$ShowFiltersCopyWithImpl<$Res>;
}

/// @nodoc
class __$ShowFiltersCopyWithImpl<$Res> extends _$MessageEventCopyWithImpl<$Res>
    implements _$ShowFiltersCopyWith<$Res> {
  __$ShowFiltersCopyWithImpl(
      _ShowFilters _value, $Res Function(_ShowFilters) _then)
      : super(_value, (v) => _then(v as _ShowFilters));

  @override
  _ShowFilters get _value => super._value as _ShowFilters;
}

/// @nodoc
class _$_ShowFilters implements _ShowFilters {
  const _$_ShowFilters();

  @override
  String toString() {
    return 'MessageEvent.showFilters()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) || (other is _ShowFilters);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  Result when<Result extends Object>({
    @required Result messageChanged(String message),
    @required Result getChatMessages(int chatId),
    @required Result sendMessage(int chaId),
    @required Result pickFile(String path, FileType fileType, int chatId),
    @required Result removeFromSelectedMessages(MessageBody element),
    @required Result addToSelectedMessages(MessageBody element),
    @required Result switchToStandardAppBar(),
    @required Result switchToInfoAppBar(),
    @required Result showFilters(),
    @required Result hideFilters(),
  }) {
    assert(messageChanged != null);
    assert(getChatMessages != null);
    assert(sendMessage != null);
    assert(pickFile != null);
    assert(removeFromSelectedMessages != null);
    assert(addToSelectedMessages != null);
    assert(switchToStandardAppBar != null);
    assert(switchToInfoAppBar != null);
    assert(showFilters != null);
    assert(hideFilters != null);
    return showFilters();
  }

  @override
  @optionalTypeArgs
  Result maybeWhen<Result extends Object>({
    Result messageChanged(String message),
    Result getChatMessages(int chatId),
    Result sendMessage(int chaId),
    Result pickFile(String path, FileType fileType, int chatId),
    Result removeFromSelectedMessages(MessageBody element),
    Result addToSelectedMessages(MessageBody element),
    Result switchToStandardAppBar(),
    Result switchToInfoAppBar(),
    Result showFilters(),
    Result hideFilters(),
    @required Result orElse(),
  }) {
    assert(orElse != null);
    if (showFilters != null) {
      return showFilters();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  Result map<Result extends Object>({
    @required Result messageChanged(_MessageChanged value),
    @required Result getChatMessages(_GetChatMessages value),
    @required Result sendMessage(_SendMessage value),
    @required Result pickFile(_PickFile value),
    @required
        Result removeFromSelectedMessages(_RemoveFromSelectedMessages value),
    @required Result addToSelectedMessages(_AddToSelectedMessages value),
    @required Result switchToStandardAppBar(_StandardAppbar value),
    @required Result switchToInfoAppBar(_SwitchToInfoAppBar value),
    @required Result showFilters(_ShowFilters value),
    @required Result hideFilters(_HideFilters value),
  }) {
    assert(messageChanged != null);
    assert(getChatMessages != null);
    assert(sendMessage != null);
    assert(pickFile != null);
    assert(removeFromSelectedMessages != null);
    assert(addToSelectedMessages != null);
    assert(switchToStandardAppBar != null);
    assert(switchToInfoAppBar != null);
    assert(showFilters != null);
    assert(hideFilters != null);
    return showFilters(this);
  }

  @override
  @optionalTypeArgs
  Result maybeMap<Result extends Object>({
    Result messageChanged(_MessageChanged value),
    Result getChatMessages(_GetChatMessages value),
    Result sendMessage(_SendMessage value),
    Result pickFile(_PickFile value),
    Result removeFromSelectedMessages(_RemoveFromSelectedMessages value),
    Result addToSelectedMessages(_AddToSelectedMessages value),
    Result switchToStandardAppBar(_StandardAppbar value),
    Result switchToInfoAppBar(_SwitchToInfoAppBar value),
    Result showFilters(_ShowFilters value),
    Result hideFilters(_HideFilters value),
    @required Result orElse(),
  }) {
    assert(orElse != null);
    if (showFilters != null) {
      return showFilters(this);
    }
    return orElse();
  }
}

abstract class _ShowFilters implements MessageEvent {
  const factory _ShowFilters() = _$_ShowFilters;
}

/// @nodoc
abstract class _$HideFiltersCopyWith<$Res> {
  factory _$HideFiltersCopyWith(
          _HideFilters value, $Res Function(_HideFilters) then) =
      __$HideFiltersCopyWithImpl<$Res>;
}

/// @nodoc
class __$HideFiltersCopyWithImpl<$Res> extends _$MessageEventCopyWithImpl<$Res>
    implements _$HideFiltersCopyWith<$Res> {
  __$HideFiltersCopyWithImpl(
      _HideFilters _value, $Res Function(_HideFilters) _then)
      : super(_value, (v) => _then(v as _HideFilters));

  @override
  _HideFilters get _value => super._value as _HideFilters;
}

/// @nodoc
class _$_HideFilters implements _HideFilters {
  const _$_HideFilters();

  @override
  String toString() {
    return 'MessageEvent.hideFilters()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) || (other is _HideFilters);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  Result when<Result extends Object>({
    @required Result messageChanged(String message),
    @required Result getChatMessages(int chatId),
    @required Result sendMessage(int chaId),
    @required Result pickFile(String path, FileType fileType, int chatId),
    @required Result removeFromSelectedMessages(MessageBody element),
    @required Result addToSelectedMessages(MessageBody element),
    @required Result switchToStandardAppBar(),
    @required Result switchToInfoAppBar(),
    @required Result showFilters(),
    @required Result hideFilters(),
  }) {
    assert(messageChanged != null);
    assert(getChatMessages != null);
    assert(sendMessage != null);
    assert(pickFile != null);
    assert(removeFromSelectedMessages != null);
    assert(addToSelectedMessages != null);
    assert(switchToStandardAppBar != null);
    assert(switchToInfoAppBar != null);
    assert(showFilters != null);
    assert(hideFilters != null);
    return hideFilters();
  }

  @override
  @optionalTypeArgs
  Result maybeWhen<Result extends Object>({
    Result messageChanged(String message),
    Result getChatMessages(int chatId),
    Result sendMessage(int chaId),
    Result pickFile(String path, FileType fileType, int chatId),
    Result removeFromSelectedMessages(MessageBody element),
    Result addToSelectedMessages(MessageBody element),
    Result switchToStandardAppBar(),
    Result switchToInfoAppBar(),
    Result showFilters(),
    Result hideFilters(),
    @required Result orElse(),
  }) {
    assert(orElse != null);
    if (hideFilters != null) {
      return hideFilters();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  Result map<Result extends Object>({
    @required Result messageChanged(_MessageChanged value),
    @required Result getChatMessages(_GetChatMessages value),
    @required Result sendMessage(_SendMessage value),
    @required Result pickFile(_PickFile value),
    @required
        Result removeFromSelectedMessages(_RemoveFromSelectedMessages value),
    @required Result addToSelectedMessages(_AddToSelectedMessages value),
    @required Result switchToStandardAppBar(_StandardAppbar value),
    @required Result switchToInfoAppBar(_SwitchToInfoAppBar value),
    @required Result showFilters(_ShowFilters value),
    @required Result hideFilters(_HideFilters value),
  }) {
    assert(messageChanged != null);
    assert(getChatMessages != null);
    assert(sendMessage != null);
    assert(pickFile != null);
    assert(removeFromSelectedMessages != null);
    assert(addToSelectedMessages != null);
    assert(switchToStandardAppBar != null);
    assert(switchToInfoAppBar != null);
    assert(showFilters != null);
    assert(hideFilters != null);
    return hideFilters(this);
  }

  @override
  @optionalTypeArgs
  Result maybeMap<Result extends Object>({
    Result messageChanged(_MessageChanged value),
    Result getChatMessages(_GetChatMessages value),
    Result sendMessage(_SendMessage value),
    Result pickFile(_PickFile value),
    Result removeFromSelectedMessages(_RemoveFromSelectedMessages value),
    Result addToSelectedMessages(_AddToSelectedMessages value),
    Result switchToStandardAppBar(_StandardAppbar value),
    Result switchToInfoAppBar(_SwitchToInfoAppBar value),
    Result showFilters(_ShowFilters value),
    Result hideFilters(_HideFilters value),
    @required Result orElse(),
  }) {
    assert(orElse != null);
    if (hideFilters != null) {
      return hideFilters(this);
    }
    return orElse();
  }
}

abstract class _HideFilters implements MessageEvent {
  const factory _HideFilters() = _$_HideFilters;
}

/// @nodoc
class _$MessageStateTearOff {
  const _$MessageStateTearOff();

// ignore: unused_element
  _MessageState call(
      {Message messages,
      List<MessageBody> listOfMessages,
      bool isLoading,
      bool showErrorMessage,
      NonNullString message,
      String currentUrl,
      bool showFilters,
      Option<List<MessageBody>> someOrNOSelectedElements,
      Option<ChatAppBarState> failureOrSuccessChatAppBarState,
      Option<String> nextUrl,
      Option<Either<MessageFailure, Unit>> failureOrSuccessGetMessage,
      Option<Either<MessageFailure, Unit>> failureOrSuccessSendMessage}) {
    return _MessageState(
      messages: messages,
      listOfMessages: listOfMessages,
      isLoading: isLoading,
      showErrorMessage: showErrorMessage,
      message: message,
      currentUrl: currentUrl,
      showFilters: showFilters,
      someOrNOSelectedElements: someOrNOSelectedElements,
      failureOrSuccessChatAppBarState: failureOrSuccessChatAppBarState,
      nextUrl: nextUrl,
      failureOrSuccessGetMessage: failureOrSuccessGetMessage,
      failureOrSuccessSendMessage: failureOrSuccessSendMessage,
    );
  }
}

/// @nodoc
// ignore: unused_element
const $MessageState = _$MessageStateTearOff();

/// @nodoc
mixin _$MessageState {
  Message get messages;
  List<MessageBody> get listOfMessages;
  bool get isLoading;
  bool get showErrorMessage;
  NonNullString get message;
  String get currentUrl;
  bool get showFilters;
  Option<List<MessageBody>> get someOrNOSelectedElements;
  Option<ChatAppBarState> get failureOrSuccessChatAppBarState;
  Option<String> get nextUrl;
  Option<Either<MessageFailure, Unit>> get failureOrSuccessGetMessage;
  Option<Either<MessageFailure, Unit>> get failureOrSuccessSendMessage;

  $MessageStateCopyWith<MessageState> get copyWith;
}

/// @nodoc
abstract class $MessageStateCopyWith<$Res> {
  factory $MessageStateCopyWith(
          MessageState value, $Res Function(MessageState) then) =
      _$MessageStateCopyWithImpl<$Res>;
  $Res call(
      {Message messages,
      List<MessageBody> listOfMessages,
      bool isLoading,
      bool showErrorMessage,
      NonNullString message,
      String currentUrl,
      bool showFilters,
      Option<List<MessageBody>> someOrNOSelectedElements,
      Option<ChatAppBarState> failureOrSuccessChatAppBarState,
      Option<String> nextUrl,
      Option<Either<MessageFailure, Unit>> failureOrSuccessGetMessage,
      Option<Either<MessageFailure, Unit>> failureOrSuccessSendMessage});
}

/// @nodoc
class _$MessageStateCopyWithImpl<$Res> implements $MessageStateCopyWith<$Res> {
  _$MessageStateCopyWithImpl(this._value, this._then);

  final MessageState _value;
  // ignore: unused_field
  final $Res Function(MessageState) _then;

  @override
  $Res call({
    Object messages = freezed,
    Object listOfMessages = freezed,
    Object isLoading = freezed,
    Object showErrorMessage = freezed,
    Object message = freezed,
    Object currentUrl = freezed,
    Object showFilters = freezed,
    Object someOrNOSelectedElements = freezed,
    Object failureOrSuccessChatAppBarState = freezed,
    Object nextUrl = freezed,
    Object failureOrSuccessGetMessage = freezed,
    Object failureOrSuccessSendMessage = freezed,
  }) {
    return _then(_value.copyWith(
      messages: messages == freezed ? _value.messages : messages as Message,
      listOfMessages: listOfMessages == freezed
          ? _value.listOfMessages
          : listOfMessages as List<MessageBody>,
      isLoading: isLoading == freezed ? _value.isLoading : isLoading as bool,
      showErrorMessage: showErrorMessage == freezed
          ? _value.showErrorMessage
          : showErrorMessage as bool,
      message: message == freezed ? _value.message : message as NonNullString,
      currentUrl:
          currentUrl == freezed ? _value.currentUrl : currentUrl as String,
      showFilters:
          showFilters == freezed ? _value.showFilters : showFilters as bool,
      someOrNOSelectedElements: someOrNOSelectedElements == freezed
          ? _value.someOrNOSelectedElements
          : someOrNOSelectedElements as Option<List<MessageBody>>,
      failureOrSuccessChatAppBarState:
          failureOrSuccessChatAppBarState == freezed
              ? _value.failureOrSuccessChatAppBarState
              : failureOrSuccessChatAppBarState as Option<ChatAppBarState>,
      nextUrl: nextUrl == freezed ? _value.nextUrl : nextUrl as Option<String>,
      failureOrSuccessGetMessage: failureOrSuccessGetMessage == freezed
          ? _value.failureOrSuccessGetMessage
          : failureOrSuccessGetMessage as Option<Either<MessageFailure, Unit>>,
      failureOrSuccessSendMessage: failureOrSuccessSendMessage == freezed
          ? _value.failureOrSuccessSendMessage
          : failureOrSuccessSendMessage as Option<Either<MessageFailure, Unit>>,
    ));
  }
}

/// @nodoc
abstract class _$MessageStateCopyWith<$Res>
    implements $MessageStateCopyWith<$Res> {
  factory _$MessageStateCopyWith(
          _MessageState value, $Res Function(_MessageState) then) =
      __$MessageStateCopyWithImpl<$Res>;
  @override
  $Res call(
      {Message messages,
      List<MessageBody> listOfMessages,
      bool isLoading,
      bool showErrorMessage,
      NonNullString message,
      String currentUrl,
      bool showFilters,
      Option<List<MessageBody>> someOrNOSelectedElements,
      Option<ChatAppBarState> failureOrSuccessChatAppBarState,
      Option<String> nextUrl,
      Option<Either<MessageFailure, Unit>> failureOrSuccessGetMessage,
      Option<Either<MessageFailure, Unit>> failureOrSuccessSendMessage});
}

/// @nodoc
class __$MessageStateCopyWithImpl<$Res> extends _$MessageStateCopyWithImpl<$Res>
    implements _$MessageStateCopyWith<$Res> {
  __$MessageStateCopyWithImpl(
      _MessageState _value, $Res Function(_MessageState) _then)
      : super(_value, (v) => _then(v as _MessageState));

  @override
  _MessageState get _value => super._value as _MessageState;

  @override
  $Res call({
    Object messages = freezed,
    Object listOfMessages = freezed,
    Object isLoading = freezed,
    Object showErrorMessage = freezed,
    Object message = freezed,
    Object currentUrl = freezed,
    Object showFilters = freezed,
    Object someOrNOSelectedElements = freezed,
    Object failureOrSuccessChatAppBarState = freezed,
    Object nextUrl = freezed,
    Object failureOrSuccessGetMessage = freezed,
    Object failureOrSuccessSendMessage = freezed,
  }) {
    return _then(_MessageState(
      messages: messages == freezed ? _value.messages : messages as Message,
      listOfMessages: listOfMessages == freezed
          ? _value.listOfMessages
          : listOfMessages as List<MessageBody>,
      isLoading: isLoading == freezed ? _value.isLoading : isLoading as bool,
      showErrorMessage: showErrorMessage == freezed
          ? _value.showErrorMessage
          : showErrorMessage as bool,
      message: message == freezed ? _value.message : message as NonNullString,
      currentUrl:
          currentUrl == freezed ? _value.currentUrl : currentUrl as String,
      showFilters:
          showFilters == freezed ? _value.showFilters : showFilters as bool,
      someOrNOSelectedElements: someOrNOSelectedElements == freezed
          ? _value.someOrNOSelectedElements
          : someOrNOSelectedElements as Option<List<MessageBody>>,
      failureOrSuccessChatAppBarState:
          failureOrSuccessChatAppBarState == freezed
              ? _value.failureOrSuccessChatAppBarState
              : failureOrSuccessChatAppBarState as Option<ChatAppBarState>,
      nextUrl: nextUrl == freezed ? _value.nextUrl : nextUrl as Option<String>,
      failureOrSuccessGetMessage: failureOrSuccessGetMessage == freezed
          ? _value.failureOrSuccessGetMessage
          : failureOrSuccessGetMessage as Option<Either<MessageFailure, Unit>>,
      failureOrSuccessSendMessage: failureOrSuccessSendMessage == freezed
          ? _value.failureOrSuccessSendMessage
          : failureOrSuccessSendMessage as Option<Either<MessageFailure, Unit>>,
    ));
  }
}

/// @nodoc
class _$_MessageState implements _MessageState {
  const _$_MessageState(
      {this.messages,
      this.listOfMessages,
      this.isLoading,
      this.showErrorMessage,
      this.message,
      this.currentUrl,
      this.showFilters,
      this.someOrNOSelectedElements,
      this.failureOrSuccessChatAppBarState,
      this.nextUrl,
      this.failureOrSuccessGetMessage,
      this.failureOrSuccessSendMessage});

  @override
  final Message messages;
  @override
  final List<MessageBody> listOfMessages;
  @override
  final bool isLoading;
  @override
  final bool showErrorMessage;
  @override
  final NonNullString message;
  @override
  final String currentUrl;
  @override
  final bool showFilters;
  @override
  final Option<List<MessageBody>> someOrNOSelectedElements;
  @override
  final Option<ChatAppBarState> failureOrSuccessChatAppBarState;
  @override
  final Option<String> nextUrl;
  @override
  final Option<Either<MessageFailure, Unit>> failureOrSuccessGetMessage;
  @override
  final Option<Either<MessageFailure, Unit>> failureOrSuccessSendMessage;

  @override
  String toString() {
    return 'MessageState(messages: $messages, listOfMessages: $listOfMessages, isLoading: $isLoading, showErrorMessage: $showErrorMessage, message: $message, currentUrl: $currentUrl, showFilters: $showFilters, someOrNOSelectedElements: $someOrNOSelectedElements, failureOrSuccessChatAppBarState: $failureOrSuccessChatAppBarState, nextUrl: $nextUrl, failureOrSuccessGetMessage: $failureOrSuccessGetMessage, failureOrSuccessSendMessage: $failureOrSuccessSendMessage)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other is _MessageState &&
            (identical(other.messages, messages) ||
                const DeepCollectionEquality()
                    .equals(other.messages, messages)) &&
            (identical(other.listOfMessages, listOfMessages) ||
                const DeepCollectionEquality()
                    .equals(other.listOfMessages, listOfMessages)) &&
            (identical(other.isLoading, isLoading) ||
                const DeepCollectionEquality()
                    .equals(other.isLoading, isLoading)) &&
            (identical(other.showErrorMessage, showErrorMessage) ||
                const DeepCollectionEquality()
                    .equals(other.showErrorMessage, showErrorMessage)) &&
            (identical(other.message, message) ||
                const DeepCollectionEquality()
                    .equals(other.message, message)) &&
            (identical(other.currentUrl, currentUrl) ||
                const DeepCollectionEquality()
                    .equals(other.currentUrl, currentUrl)) &&
            (identical(other.showFilters, showFilters) ||
                const DeepCollectionEquality()
                    .equals(other.showFilters, showFilters)) &&
            (identical(other.someOrNOSelectedElements, someOrNOSelectedElements) ||
                const DeepCollectionEquality().equals(
                    other.someOrNOSelectedElements,
                    someOrNOSelectedElements)) &&
            (identical(other.failureOrSuccessChatAppBarState,
                    failureOrSuccessChatAppBarState) ||
                const DeepCollectionEquality().equals(
                    other.failureOrSuccessChatAppBarState,
                    failureOrSuccessChatAppBarState)) &&
            (identical(other.nextUrl, nextUrl) ||
                const DeepCollectionEquality()
                    .equals(other.nextUrl, nextUrl)) &&
            (identical(other.failureOrSuccessGetMessage, failureOrSuccessGetMessage) ||
                const DeepCollectionEquality().equals(
                    other.failureOrSuccessGetMessage,
                    failureOrSuccessGetMessage)) &&
            (identical(other.failureOrSuccessSendMessage,
                    failureOrSuccessSendMessage) ||
                const DeepCollectionEquality().equals(
                    other.failureOrSuccessSendMessage,
                    failureOrSuccessSendMessage)));
  }

  @override
  int get hashCode =>
      runtimeType.hashCode ^
      const DeepCollectionEquality().hash(messages) ^
      const DeepCollectionEquality().hash(listOfMessages) ^
      const DeepCollectionEquality().hash(isLoading) ^
      const DeepCollectionEquality().hash(showErrorMessage) ^
      const DeepCollectionEquality().hash(message) ^
      const DeepCollectionEquality().hash(currentUrl) ^
      const DeepCollectionEquality().hash(showFilters) ^
      const DeepCollectionEquality().hash(someOrNOSelectedElements) ^
      const DeepCollectionEquality().hash(failureOrSuccessChatAppBarState) ^
      const DeepCollectionEquality().hash(nextUrl) ^
      const DeepCollectionEquality().hash(failureOrSuccessGetMessage) ^
      const DeepCollectionEquality().hash(failureOrSuccessSendMessage);

  @override
  _$MessageStateCopyWith<_MessageState> get copyWith =>
      __$MessageStateCopyWithImpl<_MessageState>(this, _$identity);
}

abstract class _MessageState implements MessageState {
  const factory _MessageState(
          {Message messages,
          List<MessageBody> listOfMessages,
          bool isLoading,
          bool showErrorMessage,
          NonNullString message,
          String currentUrl,
          bool showFilters,
          Option<List<MessageBody>> someOrNOSelectedElements,
          Option<ChatAppBarState> failureOrSuccessChatAppBarState,
          Option<String> nextUrl,
          Option<Either<MessageFailure, Unit>> failureOrSuccessGetMessage,
          Option<Either<MessageFailure, Unit>> failureOrSuccessSendMessage}) =
      _$_MessageState;

  @override
  Message get messages;
  @override
  List<MessageBody> get listOfMessages;
  @override
  bool get isLoading;
  @override
  bool get showErrorMessage;
  @override
  NonNullString get message;
  @override
  String get currentUrl;
  @override
  bool get showFilters;
  @override
  Option<List<MessageBody>> get someOrNOSelectedElements;
  @override
  Option<ChatAppBarState> get failureOrSuccessChatAppBarState;
  @override
  Option<String> get nextUrl;
  @override
  Option<Either<MessageFailure, Unit>> get failureOrSuccessGetMessage;
  @override
  Option<Either<MessageFailure, Unit>> get failureOrSuccessSendMessage;
  @override
  _$MessageStateCopyWith<_MessageState> get copyWith;
}
