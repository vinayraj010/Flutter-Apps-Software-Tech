// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies

part of 'chat_bloc.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

/// @nodoc
class _$ChatEventTearOff {
  const _$ChatEventTearOff();

// ignore: unused_element
  _GetAllChats getAllChats() {
    return const _GetAllChats();
  }

// ignore: unused_element
  _TitleChanged titleChanged(String title) {
    return _TitleChanged(
      title,
    );
  }

// ignore: unused_element
  _CreateChat createChat({int userId}) {
    return _CreateChat(
      userId: userId,
    );
  }

// ignore: unused_element
  _AddTeacherAttendance addTeacherAttendance({int chatId}) {
    return _AddTeacherAttendance(
      chatId: chatId,
    );
  }

// ignore: unused_element
  _AddStudentAttendance addStudentAttendance(
      {int chatId, int teacherAttendanceId}) {
    return _AddStudentAttendance(
      chatId: chatId,
      teacherAttendanceId: teacherAttendanceId,
    );
  }
}

/// @nodoc
// ignore: unused_element
const $ChatEvent = _$ChatEventTearOff();

/// @nodoc
mixin _$ChatEvent {
  @optionalTypeArgs
  Result when<Result extends Object>({
    @required Result getAllChats(),
    @required Result titleChanged(String title),
    @required Result createChat(int userId),
    @required Result addTeacherAttendance(int chatId),
    @required Result addStudentAttendance(int chatId, int teacherAttendanceId),
  });
  @optionalTypeArgs
  Result maybeWhen<Result extends Object>({
    Result getAllChats(),
    Result titleChanged(String title),
    Result createChat(int userId),
    Result addTeacherAttendance(int chatId),
    Result addStudentAttendance(int chatId, int teacherAttendanceId),
    @required Result orElse(),
  });
  @optionalTypeArgs
  Result map<Result extends Object>({
    @required Result getAllChats(_GetAllChats value),
    @required Result titleChanged(_TitleChanged value),
    @required Result createChat(_CreateChat value),
    @required Result addTeacherAttendance(_AddTeacherAttendance value),
    @required Result addStudentAttendance(_AddStudentAttendance value),
  });
  @optionalTypeArgs
  Result maybeMap<Result extends Object>({
    Result getAllChats(_GetAllChats value),
    Result titleChanged(_TitleChanged value),
    Result createChat(_CreateChat value),
    Result addTeacherAttendance(_AddTeacherAttendance value),
    Result addStudentAttendance(_AddStudentAttendance value),
    @required Result orElse(),
  });
}

/// @nodoc
abstract class $ChatEventCopyWith<$Res> {
  factory $ChatEventCopyWith(ChatEvent value, $Res Function(ChatEvent) then) =
      _$ChatEventCopyWithImpl<$Res>;
}

/// @nodoc
class _$ChatEventCopyWithImpl<$Res> implements $ChatEventCopyWith<$Res> {
  _$ChatEventCopyWithImpl(this._value, this._then);

  final ChatEvent _value;
  // ignore: unused_field
  final $Res Function(ChatEvent) _then;
}

/// @nodoc
abstract class _$GetAllChatsCopyWith<$Res> {
  factory _$GetAllChatsCopyWith(
          _GetAllChats value, $Res Function(_GetAllChats) then) =
      __$GetAllChatsCopyWithImpl<$Res>;
}

/// @nodoc
class __$GetAllChatsCopyWithImpl<$Res> extends _$ChatEventCopyWithImpl<$Res>
    implements _$GetAllChatsCopyWith<$Res> {
  __$GetAllChatsCopyWithImpl(
      _GetAllChats _value, $Res Function(_GetAllChats) _then)
      : super(_value, (v) => _then(v as _GetAllChats));

  @override
  _GetAllChats get _value => super._value as _GetAllChats;
}

/// @nodoc
class _$_GetAllChats implements _GetAllChats {
  const _$_GetAllChats();

  @override
  String toString() {
    return 'ChatEvent.getAllChats()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) || (other is _GetAllChats);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  Result when<Result extends Object>({
    @required Result getAllChats(),
    @required Result titleChanged(String title),
    @required Result createChat(int userId),
    @required Result addTeacherAttendance(int chatId),
    @required Result addStudentAttendance(int chatId, int teacherAttendanceId),
  }) {
    assert(getAllChats != null);
    assert(titleChanged != null);
    assert(createChat != null);
    assert(addTeacherAttendance != null);
    assert(addStudentAttendance != null);
    return getAllChats();
  }

  @override
  @optionalTypeArgs
  Result maybeWhen<Result extends Object>({
    Result getAllChats(),
    Result titleChanged(String title),
    Result createChat(int userId),
    Result addTeacherAttendance(int chatId),
    Result addStudentAttendance(int chatId, int teacherAttendanceId),
    @required Result orElse(),
  }) {
    assert(orElse != null);
    if (getAllChats != null) {
      return getAllChats();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  Result map<Result extends Object>({
    @required Result getAllChats(_GetAllChats value),
    @required Result titleChanged(_TitleChanged value),
    @required Result createChat(_CreateChat value),
    @required Result addTeacherAttendance(_AddTeacherAttendance value),
    @required Result addStudentAttendance(_AddStudentAttendance value),
  }) {
    assert(getAllChats != null);
    assert(titleChanged != null);
    assert(createChat != null);
    assert(addTeacherAttendance != null);
    assert(addStudentAttendance != null);
    return getAllChats(this);
  }

  @override
  @optionalTypeArgs
  Result maybeMap<Result extends Object>({
    Result getAllChats(_GetAllChats value),
    Result titleChanged(_TitleChanged value),
    Result createChat(_CreateChat value),
    Result addTeacherAttendance(_AddTeacherAttendance value),
    Result addStudentAttendance(_AddStudentAttendance value),
    @required Result orElse(),
  }) {
    assert(orElse != null);
    if (getAllChats != null) {
      return getAllChats(this);
    }
    return orElse();
  }
}

abstract class _GetAllChats implements ChatEvent {
  const factory _GetAllChats() = _$_GetAllChats;
}

/// @nodoc
abstract class _$TitleChangedCopyWith<$Res> {
  factory _$TitleChangedCopyWith(
          _TitleChanged value, $Res Function(_TitleChanged) then) =
      __$TitleChangedCopyWithImpl<$Res>;
  $Res call({String title});
}

/// @nodoc
class __$TitleChangedCopyWithImpl<$Res> extends _$ChatEventCopyWithImpl<$Res>
    implements _$TitleChangedCopyWith<$Res> {
  __$TitleChangedCopyWithImpl(
      _TitleChanged _value, $Res Function(_TitleChanged) _then)
      : super(_value, (v) => _then(v as _TitleChanged));

  @override
  _TitleChanged get _value => super._value as _TitleChanged;

  @override
  $Res call({
    Object title = freezed,
  }) {
    return _then(_TitleChanged(
      title == freezed ? _value.title : title as String,
    ));
  }
}

/// @nodoc
class _$_TitleChanged implements _TitleChanged {
  const _$_TitleChanged(this.title) : assert(title != null);

  @override
  final String title;

  @override
  String toString() {
    return 'ChatEvent.titleChanged(title: $title)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other is _TitleChanged &&
            (identical(other.title, title) ||
                const DeepCollectionEquality().equals(other.title, title)));
  }

  @override
  int get hashCode =>
      runtimeType.hashCode ^ const DeepCollectionEquality().hash(title);

  @override
  _$TitleChangedCopyWith<_TitleChanged> get copyWith =>
      __$TitleChangedCopyWithImpl<_TitleChanged>(this, _$identity);

  @override
  @optionalTypeArgs
  Result when<Result extends Object>({
    @required Result getAllChats(),
    @required Result titleChanged(String title),
    @required Result createChat(int userId),
    @required Result addTeacherAttendance(int chatId),
    @required Result addStudentAttendance(int chatId, int teacherAttendanceId),
  }) {
    assert(getAllChats != null);
    assert(titleChanged != null);
    assert(createChat != null);
    assert(addTeacherAttendance != null);
    assert(addStudentAttendance != null);
    return titleChanged(title);
  }

  @override
  @optionalTypeArgs
  Result maybeWhen<Result extends Object>({
    Result getAllChats(),
    Result titleChanged(String title),
    Result createChat(int userId),
    Result addTeacherAttendance(int chatId),
    Result addStudentAttendance(int chatId, int teacherAttendanceId),
    @required Result orElse(),
  }) {
    assert(orElse != null);
    if (titleChanged != null) {
      return titleChanged(title);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  Result map<Result extends Object>({
    @required Result getAllChats(_GetAllChats value),
    @required Result titleChanged(_TitleChanged value),
    @required Result createChat(_CreateChat value),
    @required Result addTeacherAttendance(_AddTeacherAttendance value),
    @required Result addStudentAttendance(_AddStudentAttendance value),
  }) {
    assert(getAllChats != null);
    assert(titleChanged != null);
    assert(createChat != null);
    assert(addTeacherAttendance != null);
    assert(addStudentAttendance != null);
    return titleChanged(this);
  }

  @override
  @optionalTypeArgs
  Result maybeMap<Result extends Object>({
    Result getAllChats(_GetAllChats value),
    Result titleChanged(_TitleChanged value),
    Result createChat(_CreateChat value),
    Result addTeacherAttendance(_AddTeacherAttendance value),
    Result addStudentAttendance(_AddStudentAttendance value),
    @required Result orElse(),
  }) {
    assert(orElse != null);
    if (titleChanged != null) {
      return titleChanged(this);
    }
    return orElse();
  }
}

abstract class _TitleChanged implements ChatEvent {
  const factory _TitleChanged(String title) = _$_TitleChanged;

  String get title;
  _$TitleChangedCopyWith<_TitleChanged> get copyWith;
}

/// @nodoc
abstract class _$CreateChatCopyWith<$Res> {
  factory _$CreateChatCopyWith(
          _CreateChat value, $Res Function(_CreateChat) then) =
      __$CreateChatCopyWithImpl<$Res>;
  $Res call({int userId});
}

/// @nodoc
class __$CreateChatCopyWithImpl<$Res> extends _$ChatEventCopyWithImpl<$Res>
    implements _$CreateChatCopyWith<$Res> {
  __$CreateChatCopyWithImpl(
      _CreateChat _value, $Res Function(_CreateChat) _then)
      : super(_value, (v) => _then(v as _CreateChat));

  @override
  _CreateChat get _value => super._value as _CreateChat;

  @override
  $Res call({
    Object userId = freezed,
  }) {
    return _then(_CreateChat(
      userId: userId == freezed ? _value.userId : userId as int,
    ));
  }
}

/// @nodoc
class _$_CreateChat implements _CreateChat {
  const _$_CreateChat({this.userId});

  @override
  final int userId;

  @override
  String toString() {
    return 'ChatEvent.createChat(userId: $userId)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other is _CreateChat &&
            (identical(other.userId, userId) ||
                const DeepCollectionEquality().equals(other.userId, userId)));
  }

  @override
  int get hashCode =>
      runtimeType.hashCode ^ const DeepCollectionEquality().hash(userId);

  @override
  _$CreateChatCopyWith<_CreateChat> get copyWith =>
      __$CreateChatCopyWithImpl<_CreateChat>(this, _$identity);

  @override
  @optionalTypeArgs
  Result when<Result extends Object>({
    @required Result getAllChats(),
    @required Result titleChanged(String title),
    @required Result createChat(int userId),
    @required Result addTeacherAttendance(int chatId),
    @required Result addStudentAttendance(int chatId, int teacherAttendanceId),
  }) {
    assert(getAllChats != null);
    assert(titleChanged != null);
    assert(createChat != null);
    assert(addTeacherAttendance != null);
    assert(addStudentAttendance != null);
    return createChat(userId);
  }

  @override
  @optionalTypeArgs
  Result maybeWhen<Result extends Object>({
    Result getAllChats(),
    Result titleChanged(String title),
    Result createChat(int userId),
    Result addTeacherAttendance(int chatId),
    Result addStudentAttendance(int chatId, int teacherAttendanceId),
    @required Result orElse(),
  }) {
    assert(orElse != null);
    if (createChat != null) {
      return createChat(userId);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  Result map<Result extends Object>({
    @required Result getAllChats(_GetAllChats value),
    @required Result titleChanged(_TitleChanged value),
    @required Result createChat(_CreateChat value),
    @required Result addTeacherAttendance(_AddTeacherAttendance value),
    @required Result addStudentAttendance(_AddStudentAttendance value),
  }) {
    assert(getAllChats != null);
    assert(titleChanged != null);
    assert(createChat != null);
    assert(addTeacherAttendance != null);
    assert(addStudentAttendance != null);
    return createChat(this);
  }

  @override
  @optionalTypeArgs
  Result maybeMap<Result extends Object>({
    Result getAllChats(_GetAllChats value),
    Result titleChanged(_TitleChanged value),
    Result createChat(_CreateChat value),
    Result addTeacherAttendance(_AddTeacherAttendance value),
    Result addStudentAttendance(_AddStudentAttendance value),
    @required Result orElse(),
  }) {
    assert(orElse != null);
    if (createChat != null) {
      return createChat(this);
    }
    return orElse();
  }
}

abstract class _CreateChat implements ChatEvent {
  const factory _CreateChat({int userId}) = _$_CreateChat;

  int get userId;
  _$CreateChatCopyWith<_CreateChat> get copyWith;
}

/// @nodoc
abstract class _$AddTeacherAttendanceCopyWith<$Res> {
  factory _$AddTeacherAttendanceCopyWith(_AddTeacherAttendance value,
          $Res Function(_AddTeacherAttendance) then) =
      __$AddTeacherAttendanceCopyWithImpl<$Res>;
  $Res call({int chatId});
}

/// @nodoc
class __$AddTeacherAttendanceCopyWithImpl<$Res>
    extends _$ChatEventCopyWithImpl<$Res>
    implements _$AddTeacherAttendanceCopyWith<$Res> {
  __$AddTeacherAttendanceCopyWithImpl(
      _AddTeacherAttendance _value, $Res Function(_AddTeacherAttendance) _then)
      : super(_value, (v) => _then(v as _AddTeacherAttendance));

  @override
  _AddTeacherAttendance get _value => super._value as _AddTeacherAttendance;

  @override
  $Res call({
    Object chatId = freezed,
  }) {
    return _then(_AddTeacherAttendance(
      chatId: chatId == freezed ? _value.chatId : chatId as int,
    ));
  }
}

/// @nodoc
class _$_AddTeacherAttendance implements _AddTeacherAttendance {
  const _$_AddTeacherAttendance({this.chatId});

  @override
  final int chatId;

  @override
  String toString() {
    return 'ChatEvent.addTeacherAttendance(chatId: $chatId)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other is _AddTeacherAttendance &&
            (identical(other.chatId, chatId) ||
                const DeepCollectionEquality().equals(other.chatId, chatId)));
  }

  @override
  int get hashCode =>
      runtimeType.hashCode ^ const DeepCollectionEquality().hash(chatId);

  @override
  _$AddTeacherAttendanceCopyWith<_AddTeacherAttendance> get copyWith =>
      __$AddTeacherAttendanceCopyWithImpl<_AddTeacherAttendance>(
          this, _$identity);

  @override
  @optionalTypeArgs
  Result when<Result extends Object>({
    @required Result getAllChats(),
    @required Result titleChanged(String title),
    @required Result createChat(int userId),
    @required Result addTeacherAttendance(int chatId),
    @required Result addStudentAttendance(int chatId, int teacherAttendanceId),
  }) {
    assert(getAllChats != null);
    assert(titleChanged != null);
    assert(createChat != null);
    assert(addTeacherAttendance != null);
    assert(addStudentAttendance != null);
    return addTeacherAttendance(chatId);
  }

  @override
  @optionalTypeArgs
  Result maybeWhen<Result extends Object>({
    Result getAllChats(),
    Result titleChanged(String title),
    Result createChat(int userId),
    Result addTeacherAttendance(int chatId),
    Result addStudentAttendance(int chatId, int teacherAttendanceId),
    @required Result orElse(),
  }) {
    assert(orElse != null);
    if (addTeacherAttendance != null) {
      return addTeacherAttendance(chatId);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  Result map<Result extends Object>({
    @required Result getAllChats(_GetAllChats value),
    @required Result titleChanged(_TitleChanged value),
    @required Result createChat(_CreateChat value),
    @required Result addTeacherAttendance(_AddTeacherAttendance value),
    @required Result addStudentAttendance(_AddStudentAttendance value),
  }) {
    assert(getAllChats != null);
    assert(titleChanged != null);
    assert(createChat != null);
    assert(addTeacherAttendance != null);
    assert(addStudentAttendance != null);
    return addTeacherAttendance(this);
  }

  @override
  @optionalTypeArgs
  Result maybeMap<Result extends Object>({
    Result getAllChats(_GetAllChats value),
    Result titleChanged(_TitleChanged value),
    Result createChat(_CreateChat value),
    Result addTeacherAttendance(_AddTeacherAttendance value),
    Result addStudentAttendance(_AddStudentAttendance value),
    @required Result orElse(),
  }) {
    assert(orElse != null);
    if (addTeacherAttendance != null) {
      return addTeacherAttendance(this);
    }
    return orElse();
  }
}

abstract class _AddTeacherAttendance implements ChatEvent {
  const factory _AddTeacherAttendance({int chatId}) = _$_AddTeacherAttendance;

  int get chatId;
  _$AddTeacherAttendanceCopyWith<_AddTeacherAttendance> get copyWith;
}

/// @nodoc
abstract class _$AddStudentAttendanceCopyWith<$Res> {
  factory _$AddStudentAttendanceCopyWith(_AddStudentAttendance value,
          $Res Function(_AddStudentAttendance) then) =
      __$AddStudentAttendanceCopyWithImpl<$Res>;
  $Res call({int chatId, int teacherAttendanceId});
}

/// @nodoc
class __$AddStudentAttendanceCopyWithImpl<$Res>
    extends _$ChatEventCopyWithImpl<$Res>
    implements _$AddStudentAttendanceCopyWith<$Res> {
  __$AddStudentAttendanceCopyWithImpl(
      _AddStudentAttendance _value, $Res Function(_AddStudentAttendance) _then)
      : super(_value, (v) => _then(v as _AddStudentAttendance));

  @override
  _AddStudentAttendance get _value => super._value as _AddStudentAttendance;

  @override
  $Res call({
    Object chatId = freezed,
    Object teacherAttendanceId = freezed,
  }) {
    return _then(_AddStudentAttendance(
      chatId: chatId == freezed ? _value.chatId : chatId as int,
      teacherAttendanceId: teacherAttendanceId == freezed
          ? _value.teacherAttendanceId
          : teacherAttendanceId as int,
    ));
  }
}

/// @nodoc
class _$_AddStudentAttendance implements _AddStudentAttendance {
  const _$_AddStudentAttendance({this.chatId, this.teacherAttendanceId});

  @override
  final int chatId;
  @override
  final int teacherAttendanceId;

  @override
  String toString() {
    return 'ChatEvent.addStudentAttendance(chatId: $chatId, teacherAttendanceId: $teacherAttendanceId)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other is _AddStudentAttendance &&
            (identical(other.chatId, chatId) ||
                const DeepCollectionEquality().equals(other.chatId, chatId)) &&
            (identical(other.teacherAttendanceId, teacherAttendanceId) ||
                const DeepCollectionEquality()
                    .equals(other.teacherAttendanceId, teacherAttendanceId)));
  }

  @override
  int get hashCode =>
      runtimeType.hashCode ^
      const DeepCollectionEquality().hash(chatId) ^
      const DeepCollectionEquality().hash(teacherAttendanceId);

  @override
  _$AddStudentAttendanceCopyWith<_AddStudentAttendance> get copyWith =>
      __$AddStudentAttendanceCopyWithImpl<_AddStudentAttendance>(
          this, _$identity);

  @override
  @optionalTypeArgs
  Result when<Result extends Object>({
    @required Result getAllChats(),
    @required Result titleChanged(String title),
    @required Result createChat(int userId),
    @required Result addTeacherAttendance(int chatId),
    @required Result addStudentAttendance(int chatId, int teacherAttendanceId),
  }) {
    assert(getAllChats != null);
    assert(titleChanged != null);
    assert(createChat != null);
    assert(addTeacherAttendance != null);
    assert(addStudentAttendance != null);
    return addStudentAttendance(chatId, teacherAttendanceId);
  }

  @override
  @optionalTypeArgs
  Result maybeWhen<Result extends Object>({
    Result getAllChats(),
    Result titleChanged(String title),
    Result createChat(int userId),
    Result addTeacherAttendance(int chatId),
    Result addStudentAttendance(int chatId, int teacherAttendanceId),
    @required Result orElse(),
  }) {
    assert(orElse != null);
    if (addStudentAttendance != null) {
      return addStudentAttendance(chatId, teacherAttendanceId);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  Result map<Result extends Object>({
    @required Result getAllChats(_GetAllChats value),
    @required Result titleChanged(_TitleChanged value),
    @required Result createChat(_CreateChat value),
    @required Result addTeacherAttendance(_AddTeacherAttendance value),
    @required Result addStudentAttendance(_AddStudentAttendance value),
  }) {
    assert(getAllChats != null);
    assert(titleChanged != null);
    assert(createChat != null);
    assert(addTeacherAttendance != null);
    assert(addStudentAttendance != null);
    return addStudentAttendance(this);
  }

  @override
  @optionalTypeArgs
  Result maybeMap<Result extends Object>({
    Result getAllChats(_GetAllChats value),
    Result titleChanged(_TitleChanged value),
    Result createChat(_CreateChat value),
    Result addTeacherAttendance(_AddTeacherAttendance value),
    Result addStudentAttendance(_AddStudentAttendance value),
    @required Result orElse(),
  }) {
    assert(orElse != null);
    if (addStudentAttendance != null) {
      return addStudentAttendance(this);
    }
    return orElse();
  }
}

abstract class _AddStudentAttendance implements ChatEvent {
  const factory _AddStudentAttendance({int chatId, int teacherAttendanceId}) =
      _$_AddStudentAttendance;

  int get chatId;
  int get teacherAttendanceId;
  _$AddStudentAttendanceCopyWith<_AddStudentAttendance> get copyWith;
}

/// @nodoc
class _$ChatStateTearOff {
  const _$ChatStateTearOff();

// ignore: unused_element
  _ChatState call(
      {Option<Either<ChatFailure, Unit>> failureOrSuccessForAttendance,
      Option<Either<ChatFailure, Unit>> failureOrSuccessForCRUDChat,
      Message allChats,
      Attendance attendance,
      StringSingleLine title,
      bool showErrorMessage}) {
    return _ChatState(
      failureOrSuccessForAttendance: failureOrSuccessForAttendance,
      failureOrSuccessForCRUDChat: failureOrSuccessForCRUDChat,
      allChats: allChats,
      attendance: attendance,
      title: title,
      showErrorMessage: showErrorMessage,
    );
  }
}

/// @nodoc
// ignore: unused_element
const $ChatState = _$ChatStateTearOff();

/// @nodoc
mixin _$ChatState {
  Option<Either<ChatFailure, Unit>> get failureOrSuccessForAttendance;
  Option<Either<ChatFailure, Unit>> get failureOrSuccessForCRUDChat;
  Message get allChats;
  Attendance get attendance;
  StringSingleLine get title;
  bool get showErrorMessage;

  $ChatStateCopyWith<ChatState> get copyWith;
}

/// @nodoc
abstract class $ChatStateCopyWith<$Res> {
  factory $ChatStateCopyWith(ChatState value, $Res Function(ChatState) then) =
      _$ChatStateCopyWithImpl<$Res>;
  $Res call(
      {Option<Either<ChatFailure, Unit>> failureOrSuccessForAttendance,
      Option<Either<ChatFailure, Unit>> failureOrSuccessForCRUDChat,
      Message allChats,
      Attendance attendance,
      StringSingleLine title,
      bool showErrorMessage});
}

/// @nodoc
class _$ChatStateCopyWithImpl<$Res> implements $ChatStateCopyWith<$Res> {
  _$ChatStateCopyWithImpl(this._value, this._then);

  final ChatState _value;
  // ignore: unused_field
  final $Res Function(ChatState) _then;

  @override
  $Res call({
    Object failureOrSuccessForAttendance = freezed,
    Object failureOrSuccessForCRUDChat = freezed,
    Object allChats = freezed,
    Object attendance = freezed,
    Object title = freezed,
    Object showErrorMessage = freezed,
  }) {
    return _then(_value.copyWith(
      failureOrSuccessForAttendance: failureOrSuccessForAttendance == freezed
          ? _value.failureOrSuccessForAttendance
          : failureOrSuccessForAttendance as Option<Either<ChatFailure, Unit>>,
      failureOrSuccessForCRUDChat: failureOrSuccessForCRUDChat == freezed
          ? _value.failureOrSuccessForCRUDChat
          : failureOrSuccessForCRUDChat as Option<Either<ChatFailure, Unit>>,
      allChats: allChats == freezed ? _value.allChats : allChats as Message,
      attendance:
          attendance == freezed ? _value.attendance : attendance as Attendance,
      title: title == freezed ? _value.title : title as StringSingleLine,
      showErrorMessage: showErrorMessage == freezed
          ? _value.showErrorMessage
          : showErrorMessage as bool,
    ));
  }
}

/// @nodoc
abstract class _$ChatStateCopyWith<$Res> implements $ChatStateCopyWith<$Res> {
  factory _$ChatStateCopyWith(
          _ChatState value, $Res Function(_ChatState) then) =
      __$ChatStateCopyWithImpl<$Res>;
  @override
  $Res call(
      {Option<Either<ChatFailure, Unit>> failureOrSuccessForAttendance,
      Option<Either<ChatFailure, Unit>> failureOrSuccessForCRUDChat,
      Message allChats,
      Attendance attendance,
      StringSingleLine title,
      bool showErrorMessage});
}

/// @nodoc
class __$ChatStateCopyWithImpl<$Res> extends _$ChatStateCopyWithImpl<$Res>
    implements _$ChatStateCopyWith<$Res> {
  __$ChatStateCopyWithImpl(_ChatState _value, $Res Function(_ChatState) _then)
      : super(_value, (v) => _then(v as _ChatState));

  @override
  _ChatState get _value => super._value as _ChatState;

  @override
  $Res call({
    Object failureOrSuccessForAttendance = freezed,
    Object failureOrSuccessForCRUDChat = freezed,
    Object allChats = freezed,
    Object attendance = freezed,
    Object title = freezed,
    Object showErrorMessage = freezed,
  }) {
    return _then(_ChatState(
      failureOrSuccessForAttendance: failureOrSuccessForAttendance == freezed
          ? _value.failureOrSuccessForAttendance
          : failureOrSuccessForAttendance as Option<Either<ChatFailure, Unit>>,
      failureOrSuccessForCRUDChat: failureOrSuccessForCRUDChat == freezed
          ? _value.failureOrSuccessForCRUDChat
          : failureOrSuccessForCRUDChat as Option<Either<ChatFailure, Unit>>,
      allChats: allChats == freezed ? _value.allChats : allChats as Message,
      attendance:
          attendance == freezed ? _value.attendance : attendance as Attendance,
      title: title == freezed ? _value.title : title as StringSingleLine,
      showErrorMessage: showErrorMessage == freezed
          ? _value.showErrorMessage
          : showErrorMessage as bool,
    ));
  }
}

/// @nodoc
class _$_ChatState implements _ChatState {
  _$_ChatState(
      {this.failureOrSuccessForAttendance,
      this.failureOrSuccessForCRUDChat,
      this.allChats,
      this.attendance,
      this.title,
      this.showErrorMessage});

  @override
  final Option<Either<ChatFailure, Unit>> failureOrSuccessForAttendance;
  @override
  final Option<Either<ChatFailure, Unit>> failureOrSuccessForCRUDChat;
  @override
  final Message allChats;
  @override
  final Attendance attendance;
  @override
  final StringSingleLine title;
  @override
  final bool showErrorMessage;

  @override
  String toString() {
    return 'ChatState(failureOrSuccessForAttendance: $failureOrSuccessForAttendance, failureOrSuccessForCRUDChat: $failureOrSuccessForCRUDChat, allChats: $allChats, attendance: $attendance, title: $title, showErrorMessage: $showErrorMessage)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other is _ChatState &&
            (identical(other.failureOrSuccessForAttendance,
                    failureOrSuccessForAttendance) ||
                const DeepCollectionEquality().equals(
                    other.failureOrSuccessForAttendance,
                    failureOrSuccessForAttendance)) &&
            (identical(other.failureOrSuccessForCRUDChat,
                    failureOrSuccessForCRUDChat) ||
                const DeepCollectionEquality().equals(
                    other.failureOrSuccessForCRUDChat,
                    failureOrSuccessForCRUDChat)) &&
            (identical(other.allChats, allChats) ||
                const DeepCollectionEquality()
                    .equals(other.allChats, allChats)) &&
            (identical(other.attendance, attendance) ||
                const DeepCollectionEquality()
                    .equals(other.attendance, attendance)) &&
            (identical(other.title, title) ||
                const DeepCollectionEquality().equals(other.title, title)) &&
            (identical(other.showErrorMessage, showErrorMessage) ||
                const DeepCollectionEquality()
                    .equals(other.showErrorMessage, showErrorMessage)));
  }

  @override
  int get hashCode =>
      runtimeType.hashCode ^
      const DeepCollectionEquality().hash(failureOrSuccessForAttendance) ^
      const DeepCollectionEquality().hash(failureOrSuccessForCRUDChat) ^
      const DeepCollectionEquality().hash(allChats) ^
      const DeepCollectionEquality().hash(attendance) ^
      const DeepCollectionEquality().hash(title) ^
      const DeepCollectionEquality().hash(showErrorMessage);

  @override
  _$ChatStateCopyWith<_ChatState> get copyWith =>
      __$ChatStateCopyWithImpl<_ChatState>(this, _$identity);
}

abstract class _ChatState implements ChatState {
  factory _ChatState(
      {Option<Either<ChatFailure, Unit>> failureOrSuccessForAttendance,
      Option<Either<ChatFailure, Unit>> failureOrSuccessForCRUDChat,
      Message allChats,
      Attendance attendance,
      StringSingleLine title,
      bool showErrorMessage}) = _$_ChatState;

  @override
  Option<Either<ChatFailure, Unit>> get failureOrSuccessForAttendance;
  @override
  Option<Either<ChatFailure, Unit>> get failureOrSuccessForCRUDChat;
  @override
  Message get allChats;
  @override
  Attendance get attendance;
  @override
  StringSingleLine get title;
  @override
  bool get showErrorMessage;
  @override
  _$ChatStateCopyWith<_ChatState> get copyWith;
}
