import 'package:date_format/date_format.dart';

String rawStringToDate(String raw) {
  final int _year =
      int.parse(raw.split('-').firstWhere((element) => element.length == 4));
  final int _month = int.parse(raw.split('-')[1]);
  final int _day = int.parse(raw.split('-').indexOf(_year.toString()) == 0
      ? raw.split('-').lastWhere((element) => element.length == 2)
      : raw.split('-').firstWhere((element) => element.length == 2));

  final String _date =
      formatDate(DateTime(_year, _month, _day), ['dd', ' ', 'MM', ', ', yyyy]);

  return _date;
}
