int mapMonthToInt(String month) {
  final Map<String, int> _calendarMonth = {
    'January': 1,
    'February': 2,
    'March': 3,
    'April': 4,
    'May': 5,
    'June': 6,
    'July': 7,
    'August': 8,
    'September': 9,
    'October': 10,
    'November': 11,
    'December': 12,
  };

  return _calendarMonth[month];
}

String mapIntToMonth(String id) {
  final Map<String, String> _calendarMonth = {
    "01": 'January',
    "02": 'February',
    "03": 'March',
    "04": 'April',
    "05": 'May',
    "06": 'June',
    "07": 'July',
    "08": 'August',
    "09": 'September',
    "10": 'October',
    "11": 'November',
    "12": 'December',
  };

  return _calendarMonth[id];
}
