// import 'package:flutter/material.dart';
// import 'package:flutter/rendering.dart';

// class Home extends StatefulWidget {
//   const Home({Key? key}) : super(key: key);

//   @override
//   State<Home> createState() => _HomeState();
// }

// class _HomeState extends State<Home> {
//   var controller;
//   List<Widget> _list = <Widget>[
//     Container(
//         alignment: Alignment.center,
//         height: 200,
//         //width: double.maxFinite,
//         color: Colors.green,
//         child: new Center(
//             child: Text(
//           "Page 1",
//           style: TextStyle(color: Colors.white),
//         ))),
//     Container(
//         alignment: Alignment.center,
//         height: 200,
//         // width: double.maxFinite,
//         color: Colors.red,
//         child: new Center(
//             child: Text(
//           "Page 2",
//           style: TextStyle(color: Colors.white),
//         ))),
//     Container(
//         alignment: Alignment.center,
//         height: 200,
//         //  width: double.maxFinite,
//         color: Colors.blue,
//         child: new Center(
//             child: Text(
//           "Page 3",
//           style: TextStyle(color: Colors.white),
//         ))),
//     Container(
//         alignment: Alignment.center,
//         height: 200,
//         //  width: double.maxFinite,
//         color: Colors.orange,
//         child: new Center(
//             child: Text(
//           "Page 4",
//           style: TextStyle(color: Colors.white),
//         ))),
//   ];

//   int pageIndex = 0;

//   @override
//   void initState() {
//     // TODO: implement initState
//     controller = PageController(initialPage: pageIndex);
//     super.initState();
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: Text("Home"),
//       ),
//       body: homeBody(),
//     );
//   }

//   Widget homeBody() {
//     return Padding(
//       padding: const EdgeInsets.all(8.0),
//       child: Column(
//         children: [
//           Row(
//             mainAxisAlignment: MainAxisAlignment.center,
//             children: [
//               IconButton(
//                   onPressed: () {
//                     setState(() {
//                       if (pageIndex > 0) {
//                         pageIndex = pageIndex - 1;
//                         controller.animateToPage(
//                           pageIndex,
//                           duration: Duration(milliseconds: 300),
//                           curve: Curves.linear,
//                         );
//                       }
//                     });
//                   },
//                   icon: Icon(
//                     Icons.arrow_back_ios_outlined,
//                     size: 40,
//                     color: pageIndex != 0 ? Colors.black : Colors.grey,
//                   )),
//               SizedBox(width: 10),
//               SizedBox(
//                 height: 100,
//                 width: 200,
//                 child: PageView(
//                   controller: controller,
//                   scrollDirection: Axis.horizontal,
//                   children: _list,
//                   physics: new NeverScrollableScrollPhysics(),
//                   onPageChanged: (currentIndex) {
//                     pageIndex = currentIndex;
//                   },
//                 ),
//               ),
//               SizedBox(width: 10),
//               IconButton(
//                   onPressed: () {
//                     setState(() {
//                       if (pageIndex < _list.length) {
//                         pageIndex = pageIndex + 1;
//                         controller.animateToPage(
//                           pageIndex,
//                           duration: Duration(milliseconds: 300),
//                           curve: Curves.linear,
//                         );
//                       }
//                     });
//                   },
//                   icon: Icon(
//                     Icons.arrow_forward_ios_outlined,
//                     size: 40,
//                     color:
//                         pageIndex != _list.length ? Colors.black : Colors.grey,
//                   )),
//             ],
//           )
//         ],
//       ),
//     );
//   }

//   @override
//   void dispose() {
//     controller.dispose();
//     super.dispose();
//   }
// }
