// ignore: file_names
import 'package:uuid/uuid.dart';

void main() {
  var uuid = Uuid();

  print(uuid.v1()); //59976040-a675-11ec-8ee4-1f922f66b681
  print(uuid.v4()); //38541b4a-26ee-4a4a-b0d6-e524254ff3b0
  print(uuid.v5(Uuid.NAMESPACE_NIL,
      "cloudhadoop.com")); //499cd2aa-9aab-5c3d-aff5-7f12306f02fb
}
