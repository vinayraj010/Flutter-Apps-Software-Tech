import 'package:coloredcontainer/Model/embeddedSubscribtion.dart';
import 'package:http/http.dart' as http;

class ApiService {
  getUsers() async {
    var url = Uri.parse(
        'https://stage.tsbdev.co/api/v1/subscription/embedded-subscription?clientId=5f92a62013332e0f667794dc');
    var response = await http.get(url);
    if (response.statusCode == 200) {
      var json = response.body;
      return embeddedSubscribtionFromJson(json);
    }
  }
}
