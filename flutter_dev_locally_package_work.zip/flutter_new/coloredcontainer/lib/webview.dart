// import 'package:flutter/material.dart';
// import 'package:webview_flutter/webview_flutter.dart';

// void main() => runApp(MyAppgg());

// class MyAppgg extends StatelessWidget {

// const MyAppgg({super.key});

//   @override
//   Widget build(BuildContext context) {
//     return MaterialApp(home: Scaffold(body: WebViewLoad()));
//   }
// }

// class WebViewLoad extends StatefulWidget {
//   WebViewLoadUI createState() => WebViewLoadUI();
// }

// class WebViewLoadUI extends State<WebViewLoad> {

//  @override
//   void initState() {
//     if (Platform.isAndroid) {
//       WebView.platform = SurfaceAndroidWebView();
//     }
//     super.initState();
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//         appBar: AppBar(title: Text('Flutter WebView')),
//         body: WebView(
//           //  initialUrl: 'https://google.com',
//           initialUrl: 'https://conscent.netlify.app/',
//           javascriptMode: JavascriptMode.disabled,
//         ));
//   }
// }

import 'dart:io'; // Add this import.

import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';

void main() {
  runApp(
    const MaterialApp(
      home: WebViewApp(),
    ),
  );
}

class WebViewApp extends StatefulWidget {
  const WebViewApp({super.key});

  @override
  State<WebViewApp> createState() => _WebViewAppState();
}

class _WebViewAppState extends State<WebViewApp> {
  // Add from here ...
  @override
  void initState() {
    if (Platform.isAndroid) {
      //   WebView.platform = SurfaceAndroidWebView();
    }
    super.initState();
  }
  // ... to here.

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Conscent'),
      ),
      //https://conscentsss.com/?csc-tierId=\(tierId!)
      body: WebView(
        initialUrl:
            'https://conscent.netlify.app/overlay?clientId=5f92a62013332e0f667794dc&loginChallenge=EDD1E6C6-B2A5-4AFC-8DED-2231BB0F7C2B&clientContentId=Client-Story-Id-1',
        javascriptMode: JavascriptMode.unrestricted,
        onPageFinished: (url) {
          if (url.contains('https://conscentsss.com/?csc-tierId')) {
            print("test");
            print('Page finished loading: $url');
            print("test");
            setState(() {});
            Navigator.pop(context);
          }
        },
      ),
    );
  }
}
