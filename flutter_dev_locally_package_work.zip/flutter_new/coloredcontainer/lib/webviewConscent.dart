import 'dart:io'; // Add this import.

import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';

void main() {
  runApp(
    const MaterialApp(
      home: WebViewAppss(),
    ),
  );
}

class WebViewAppss extends StatefulWidget {
  const WebViewAppss({super.key});

  @override
  State<WebViewAppss> createState() => _WebViewAppStates();
}

class _WebViewAppStates extends State<WebViewAppss> {
  // Add from here ...
  @override
  void initState() {
    if (Platform.isAndroid) {
      //  WebView.platform = SurfaceAndroidWebView();
    }
    super.initState();
  }
  // ... to here.

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Conscent'),
      ),
      body: WebView(
        initialUrl:
            'https://csc-subs-stage.netlify.app/design?clientContentId=Client-Story-Id-1&clientId=5f92a62013332e0f667794dc&loginChallenge=F6C488B3-6A69-4030-9DAE-5E91F5505990',
        javascriptMode: JavascriptMode.unrestricted,
      ),
    );
  }
}
