// To parse this JSON data, do
//
//     final getUserDetail = getUserDetailFromJson(jsonString);

import 'dart:convert';

GetUserDetail getUserDetailFromJson(String str) =>
    GetUserDetail.fromJson(json.decode(str));

String getUserDetailToJson(GetUserDetail data) => json.encode(data.toJson());

class GetUserDetail {
  GetUserDetail({
    required this.address,
    required this.wallet,
    required this.name,
    required this.id,
    required this.phoneNumber,
    required this.country,
    required this.promotionalOptIn,
    required this.lastPurchasedOn,
    required this.secondaryEmail,
    required this.hashedPhoneNumber,
    required this.previousSubscriber,
    required this.existingSubscriber,
  });

  Address address;
  Wallet wallet;
  String name;
  String id;
  String phoneNumber;
  String country;
  bool promotionalOptIn;
  DateTime lastPurchasedOn;
  String secondaryEmail;
  String hashedPhoneNumber;
  bool previousSubscriber;
  bool existingSubscriber;

  factory GetUserDetail.fromJson(Map<String, dynamic> json) => GetUserDetail(
        address: Address.fromJson(json["address"]),
        wallet: Wallet.fromJson(json["wallet"]),
        name: json["name"],
        id: json["_id"],
        phoneNumber: json["phoneNumber"],
        country: json["country"],
        promotionalOptIn: json["promotionalOptIn"],
        lastPurchasedOn: DateTime.parse(json["lastPurchasedOn"]),
        secondaryEmail: json["secondaryEmail"],
        hashedPhoneNumber: json["hashedPhoneNumber"],
        previousSubscriber: json["previousSubscriber"],
        existingSubscriber: json["existingSubscriber"],
      );

  Map<String, dynamic> toJson() => {
        "address": address.toJson(),
        "wallet": wallet.toJson(),
        "name": name,
        "_id": id,
        "phoneNumber": phoneNumber,
        "country": country,
        "promotionalOptIn": promotionalOptIn,
        "lastPurchasedOn": lastPurchasedOn.toIso8601String(),
        "secondaryEmail": secondaryEmail,
        "hashedPhoneNumber": hashedPhoneNumber,
        "previousSubscriber": previousSubscriber,
        "existingSubscriber": existingSubscriber,
      };
}

class Address {
  Address({
    required this.apartment,
    required this.area,
    required this.pincode,
    required this.landmark,
    required this.city,
    required this.state,
    required this.country,
  });

  String apartment;
  String area;
  String pincode;
  String landmark;
  String city;
  String state;
  String country;

  factory Address.fromJson(Map<String, dynamic> json) => Address(
        apartment: json["apartment"],
        area: json["area"],
        pincode: json["pincode"],
        landmark: json["landmark"],
        city: json["city"],
        state: json["state"],
        country: json["country"],
      );

  Map<String, dynamic> toJson() => {
        "apartment": apartment,
        "area": area,
        "pincode": pincode,
        "landmark": landmark,
        "city": city,
        "state": state,
        "country": country,
      };
}

class Wallet {
  Wallet({
    required this.balance,
    required this.currency,
  });

  Balance balance;
  String currency;

  factory Wallet.fromJson(Map<String, dynamic> json) => Wallet(
        balance: Balance.fromJson(json["balance"]),
        currency: json["currency"],
      );

  Map<String, dynamic> toJson() => {
        "balance": balance.toJson(),
        "currency": currency,
      };
}

class Balance {
  Balance({
    required this.numberDecimal,
  });

  String numberDecimal;

  factory Balance.fromJson(Map<String, dynamic> json) => Balance(
        numberDecimal: json["\u0024numberDecimal"],
      );

  Map<String, dynamic> toJson() => {
        "\u0024numberDecimal": numberDecimal,
      };
}
