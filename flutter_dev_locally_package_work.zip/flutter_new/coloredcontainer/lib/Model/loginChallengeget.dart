// ignore: file_names
import 'dart:convert';

LoginChallengeget loginChallengegetFromJson(String str) =>
    LoginChallengeget.fromJson(json.decode(str));

String loginChallengegetToJson(LoginChallengeget data) =>
    json.encode(data.toJson());

class LoginChallengeget {
  LoginChallengeget({
    required this.loginChallengeId,
    required this.sessionId,
    required this.redirectTo,
  });

  String loginChallengeId;
  String sessionId;
  String redirectTo;

  factory LoginChallengeget.fromJson(Map<String, dynamic> json) =>
      LoginChallengeget(
        loginChallengeId:
            json["loginChallengeId"] == null ? null : json["loginChallengeId"],
        sessionId: json["sessionId"] == null ? null : json["sessionId"],
        redirectTo: json["redirectTo"] == null ? null : json["redirectTo"],
      );

  Map<String, dynamic> toJson() => {
        "loginChallengeId": loginChallengeId == null ? null : loginChallengeId,
        "sessionId": sessionId == null ? null : sessionId,
        "redirectTo": redirectTo == null ? null : redirectTo,
      };
}
