// To parse this JSON data, do
//
//     final subscriptionAccess = subscriptionAccessFromJson(jsonString);

import 'dart:convert';

SubscriptionAccess subscriptionAccessFromJson(String str) =>
    SubscriptionAccess.fromJson(json.decode(str));

String subscriptionAccessToJson(SubscriptionAccess data) =>
    json.encode(data.toJson());

class SubscriptionAccess {
  SubscriptionAccess({
    required this.subscriptionAlreadyPurchased,
    required this.purchasedSubscriptions,
    required this.freeTrialConsumed,
    required this.allowRenewal,
    required this.internalUser,
    required this.payload,
    required this.consumptionId,
    required this.signature,
    required this.downloadExists,
  });

  bool subscriptionAlreadyPurchased;
  List<PurchasedSubscription> purchasedSubscriptions;
  bool freeTrialConsumed;
  bool allowRenewal;
  bool internalUser;
  Payload payload;
  String consumptionId;
  String signature;
  bool downloadExists;

  factory SubscriptionAccess.fromJson(Map<String, dynamic> json) =>
      SubscriptionAccess(
        subscriptionAlreadyPurchased: json["subscriptionAlreadyPurchased"],
        purchasedSubscriptions: List<PurchasedSubscription>.from(
            json["purchasedSubscriptions"]
                .map((x) => PurchasedSubscription.fromJson(x))),
        freeTrialConsumed: json["freeTrialConsumed"] == null
            ? null
            : json["freeTrialConsumed"],
        allowRenewal:
            json["allowRenewal"] == null ? null : json["allowRenewal"],
        internalUser:
            json["internalUser"] == null ? null : json["internalUser"],
        payload: Payload.fromJson(json["payload"]),
        consumptionId:
            json["consumptionId"] == null ? null : json["consumptionId"],
        signature: json["signature"] == null ? null : json["signature"],
        downloadExists:
            json["downloadExists"] == null ? null : json["downloadExists"],
      );

  Map<String, dynamic> toJson() => {
        "subscriptionAlreadyPurchased": subscriptionAlreadyPurchased == null
            ? null
            : subscriptionAlreadyPurchased,
        "purchasedSubscriptions": purchasedSubscriptions == null
            ? null
            : List<dynamic>.from(purchasedSubscriptions.map((x) => x.toJson())),
        "freeTrialConsumed":
            freeTrialConsumed == null ? null : freeTrialConsumed,
        "allowRenewal": allowRenewal == null ? null : allowRenewal,
        "internalUser": internalUser == null ? null : internalUser,
        "payload": payload == null ? null : payload.toJson(),
        "consumptionId": consumptionId == null ? null : consumptionId,
        "signature": signature == null ? null : signature,
        "downloadExists": downloadExists == null ? null : downloadExists,
      };
}

class Payload {
  Payload({
    required this.clientId,
    required this.contentId,
    required this.subscriptionId,
    required this.createdAt,
  });

  String clientId;
  String contentId;
  String subscriptionId;
  DateTime createdAt;

  factory Payload.fromJson(Map<String, dynamic> json) => Payload(
        clientId: json["clientId"] == null ? null : json["clientId"],
        contentId: json["contentId"] == null ? null : json["contentId"],
        subscriptionId:
            json["subscriptionId"] == null ? null : json["subscriptionId"],
        createdAt: DateTime.parse(json["createdAt"]),
      );

  Map<String, dynamic> toJson() => {
        "clientId": clientId == null ? null : clientId,
        "contentId": contentId == null ? null : contentId,
        "subscriptionId": subscriptionId == null ? null : subscriptionId,
        "createdAt": createdAt == null ? null : createdAt.toIso8601String(),
      };
}

class PurchasedSubscription {
  PurchasedSubscription({
    required this.purchasedDate,
    required this.validity,
    required this.priceDetails,
    required this.offerDetails,
    required this.subscription,
    required this.subscriptionDetails,
  });

  String purchasedDate;
  String validity;
  PriceDetails priceDetails;
  List<dynamic> offerDetails;
  Subscription subscription;
  SubscriptionDetails subscriptionDetails;

  factory PurchasedSubscription.fromJson(Map<String, dynamic> json) =>
      PurchasedSubscription(
        purchasedDate:
            json["purchasedDate"] == null ? null : json["purchasedDate"],
        validity: json["validity"] == null ? null : json["validity"],
        priceDetails: PriceDetails.fromJson(json["priceDetails"]),
        offerDetails: List<dynamic>.from(json["offerDetails"].map((x) => x)),
        subscription: Subscription.fromJson(json["subscription"]),
        subscriptionDetails:
            SubscriptionDetails.fromJson(json["subscriptionDetails"]),
      );

  Map<String, dynamic> toJson() => {
        "purchasedDate": purchasedDate == null ? null : purchasedDate,
        "validity": validity == null ? null : validity,
        "priceDetails": priceDetails == null ? null : priceDetails.toJson(),
        "offerDetails": offerDetails == null
            ? null
            : List<dynamic>.from(offerDetails.map((x) => x)),
        "subscription": subscription == null ? null : subscription.toJson(),
        "subscriptionDetails":
            subscriptionDetails == null ? null : subscriptionDetails.toJson(),
      };
}

class PriceDetails {
  PriceDetails({
    required this.amount,
    required this.currency,
  });

  int amount;
  String currency;

  factory PriceDetails.fromJson(Map<String, dynamic> json) => PriceDetails(
        amount: json["amount"] == null ? null : json["amount"],
        currency: json["currency"] == null ? null : json["currency"],
      );

  Map<String, dynamic> toJson() => {
        "amount": amount == null ? null : amount,
        "currency": currency == null ? null : currency,
      };
}

class Subscription {
  Subscription({
    required this.tierId,
    required this.digital,
    required this.physical,
    required this.adFree,
    required this.title,
    required this.renew,
    required this.duration,
    required this.durationText,
  });

  String tierId;
  bool digital;
  bool physical;
  bool adFree;
  String title;
  bool renew;
  int duration;
  String durationText;

  factory Subscription.fromJson(Map<String, dynamic> json) => Subscription(
        tierId: json["tierId"] == null ? null : json["tierId"],
        digital: json["digital"] == null ? null : json["digital"],
        physical: json["physical"] == null ? null : json["physical"],
        adFree: json["adFree"] == null ? null : json["adFree"],
        title: json["title"] == null ? null : json["title"],
        renew: json["renew"] == null ? null : json["renew"],
        duration: json["duration"] == null ? null : json["duration"],
        durationText:
            json["durationText"] == null ? null : json["durationText"],
      );

  Map<String, dynamic> toJson() => {
        "tierId": tierId == null ? null : tierId,
        "digital": digital == null ? null : digital,
        "physical": physical == null ? null : physical,
        "adFree": adFree == null ? null : adFree,
        "title": title == null ? null : title,
        "renew": renew == null ? null : renew,
        "duration": duration == null ? null : duration,
        "durationText": durationText == null ? null : durationText,
      };
}

class SubscriptionDetails {
  SubscriptionDetails({
    required this.freeTrial,
    required this.benefits,
    required this.physical,
    required this.digital,
    required this.adFree,
    required this.migrated,
    required this.couponsEnabled,
    required this.adminCoupon,
    required this.usedCouponNumbers,
    required this.id,
    required this.recommended,
    required this.enabled,
    required this.clientId,
    required this.title,
    required this.tiers,
    required this.iconUrl,
    required this.createdAt,
    required this.updatedAt,
    required this.v,
    required this.currencySymbol,
  });

  FreeTrial freeTrial;
  String benefits;
  bool physical;
  bool digital;
  bool adFree;
  bool migrated;
  bool couponsEnabled;
  String adminCoupon;
  List<dynamic> usedCouponNumbers;
  String id;
  bool recommended;
  bool enabled;
  String clientId;
  String title;
  List<Tier> tiers;
  String iconUrl;
  DateTime createdAt;
  DateTime updatedAt;
  int v;
  String currencySymbol;

  factory SubscriptionDetails.fromJson(Map<String, dynamic> json) =>
      SubscriptionDetails(
        freeTrial: FreeTrial.fromJson(json["freeTrial"]),
        benefits: json["benefits"] == null ? null : json["benefits"],
        physical: json["physical"] == null ? null : json["physical"],
        digital: json["digital"] == null ? null : json["digital"],
        adFree: json["adFree"] == null ? null : json["adFree"],
        migrated: json["migrated"] == null ? null : json["migrated"],
        couponsEnabled:
            json["couponsEnabled"] == null ? null : json["couponsEnabled"],
        adminCoupon: json["adminCoupon"] == null ? null : json["adminCoupon"],
        usedCouponNumbers:
            List<dynamic>.from(json["usedCouponNumbers"].map((x) => x)),
        id: json["_id"] == null ? null : json["_id"],
        recommended: json["recommended"] == null ? null : json["recommended"],
        enabled: json["enabled"] == null ? null : json["enabled"],
        clientId: json["clientId"] == null ? null : json["clientId"],
        title: json["title"] == null ? null : json["title"],
        tiers: List<Tier>.from(json["tiers"].map((x) => Tier.fromJson(x))),
        iconUrl: json["iconUrl"] == null ? null : json["iconUrl"],
        createdAt: DateTime.parse(json["createdAt"]),
        updatedAt: DateTime.parse(json["updatedAt"]),
        v: json["__v"] == null ? null : json["__v"],
        currencySymbol:
            json["currencySymbol"] == null ? null : json["currencySymbol"],
      );

  Map<String, dynamic> toJson() => {
        "freeTrial": freeTrial == null ? null : freeTrial.toJson(),
        "benefits": benefits == null ? null : benefits,
        "physical": physical == null ? null : physical,
        "digital": digital == null ? null : digital,
        "adFree": adFree == null ? null : adFree,
        "migrated": migrated == null ? null : migrated,
        "couponsEnabled": couponsEnabled == null ? null : couponsEnabled,
        "adminCoupon": adminCoupon == null ? null : adminCoupon,
        "usedCouponNumbers": usedCouponNumbers == null
            ? null
            : List<dynamic>.from(usedCouponNumbers.map((x) => x)),
        "_id": id == null ? null : id,
        "recommended": recommended == null ? null : recommended,
        "enabled": enabled == null ? null : enabled,
        "clientId": clientId == null ? null : clientId,
        "title": title == null ? null : title,
        "tiers": tiers == null
            ? null
            : List<dynamic>.from(tiers.map((x) => x.toJson())),
        "iconUrl": iconUrl == null ? null : iconUrl,
        "createdAt": createdAt == null ? null : createdAt.toIso8601String(),
        "updatedAt": updatedAt == null ? null : updatedAt.toIso8601String(),
        "__v": v == null ? null : v,
        "currencySymbol": currencySymbol == null ? null : currencySymbol,
      };
}

class FreeTrial {
  FreeTrial({
    required this.enabled,
    required this.duration,
  });

  bool enabled;
  dynamic duration;

  factory FreeTrial.fromJson(Map<String, dynamic> json) => FreeTrial(
        enabled: json["enabled"] == null ? null : json["enabled"],
        duration: json["duration"],
      );

  Map<String, dynamic> toJson() => {
        "enabled": enabled == null ? null : enabled,
        "duration": duration,
      };
}

class Tier {
  Tier({
    required this.priceOverrides,
    required this.currency,
    required this.basePrice,
    required this.offers,
    required this.id,
    required this.price,
    required this.duration,
  });

  PriceOverrides priceOverrides;
  String currency;
  int basePrice;
  List<Offer> offers;
  String id;
  int price;
  int duration;

  factory Tier.fromJson(Map<String, dynamic> json) => Tier(
        priceOverrides: PriceOverrides.fromJson(json["priceOverrides"]),
        currency: json["currency"] == null ? null : json["currency"],
        basePrice: json["basePrice"] == null ? null : json["basePrice"],
        offers: List<Offer>.from(json["offers"].map((x) => Offer.fromJson(x))),
        id: json["_id"] == null ? null : json["_id"],
        price: json["price"] == null ? null : json["price"],
        duration: json["duration"] == null ? null : json["duration"],
      );

  Map<String, dynamic> toJson() => {
        "priceOverrides":
            priceOverrides == null ? null : priceOverrides.toJson(),
        "currency": currency == null ? null : currency,
        "basePrice": basePrice == null ? null : basePrice,
        "offers": offers == null
            ? null
            : List<dynamic>.from(offers.map((x) => x.toJson())),
        "_id": id == null ? null : id,
        "price": price == null ? null : price,
        "duration": duration == null ? null : duration,
      };
}

class Offer {
  Offer({
    required this.id,
    required this.title,
    required this.benefits,
    required this.iconUrl,
  });

  String id;
  String title;
  String benefits;
  String iconUrl;

  factory Offer.fromJson(Map<String, dynamic> json) => Offer(
        id: json["_id"] == null ? null : json["_id"],
        title: json["title"] == null ? null : json["title"],
        benefits: json["benefits"] == null ? null : json["benefits"],
        iconUrl: json["iconUrl"] == null ? null : json["iconUrl"],
      );

  Map<String, dynamic> toJson() => {
        "_id": id == null ? null : id,
        "title": title == null ? null : title,
        "benefits": benefits == null ? null : benefits,
        "iconUrl": iconUrl == null ? null : iconUrl,
      };
}

class PriceOverrides {
  PriceOverrides({
    required this.country,
  });

  List<dynamic> country;

  factory PriceOverrides.fromJson(Map<String, dynamic> json) => PriceOverrides(
        country: List<dynamic>.from(json["country"].map((x) => x)),
      );

  Map<String, dynamic> toJson() => {
        "country":
            country == null ? null : List<dynamic>.from(country.map((x) => x)),
      };
}
