import 'dart:io'; // Add this import.

import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';

void main() {
  runApp(
    const MaterialApp(
      home: WebViewApps(),
    ),
  );
}

class WebViewApps extends StatefulWidget {
  const WebViewApps({super.key});

  @override
  State<WebViewApps> createState() => _WebViewAppStates();
}

class _WebViewAppStates extends State<WebViewApps> {
  // Add from here ...
  @override
  void initState() {
    if (Platform.isAndroid) {
      //  WebView.platform = SurfaceAndroidWebView();
    }
    super.initState();
  }
  // ... to here.

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Conscent'),
      ),
      body: WebView(
        initialUrl:
            'https://conscent.netlify.app/subscription?clientId=5f92a62013332e0f667794dc&clientContentId=Client-Story-Id-1&tierId=619b7f6cfbacc96bd8fb232a&viewId=62d5535821757f0f25a37bf4&siteUrl=https://csc-mock.netlify.app/5f92a62013332e0f667794dc/Client-Story-Id-1&availFreeTrial=true',
        javascriptMode: JavascriptMode.unrestricted,
        onPageFinished: (url) {
          if (url.contains('conscent://home?id=Client-Story-Id-1')) {
            print("test");
            print('Page finished loading: $url');
            print("test");
            setState(() {});
            Navigator.pop(context);
          }
        },
      ),
    );
  }
}
