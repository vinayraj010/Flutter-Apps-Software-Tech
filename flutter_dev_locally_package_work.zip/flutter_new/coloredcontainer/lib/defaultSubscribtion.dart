// ignore_for_file: unused_import, duplicate_import

import 'dart:async';
import 'dart:convert';

import 'package:coloredcontainer/Api/Api.dart';
import 'package:coloredcontainer/EmbeddedSubscribe.dart';
import 'package:coloredcontainer/Model/DataFile.dart';
import 'package:coloredcontainer/Model/contentAccesspost.dart';
import 'package:coloredcontainer/Model/contentDetails.dart';
import 'package:coloredcontainer/Model/getUserDetail.dart';
import 'package:coloredcontainer/Model/loginChallengeget.dart';
import 'package:coloredcontainer/Model/loginChallengepost.dart';
import 'package:coloredcontainer/Model/logout.dart';
import 'package:coloredcontainer/Model/subscriptionAccess.dart';
import 'package:coloredcontainer/main.dart';
import 'package:coloredcontainer/webview.dart';
import 'package:coloredcontainer/webviewConscent.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:uuid/uuid.dart';

import 'Model/embeddedSubscribtion.dart';

// //API Content Access post

// Future<ContentAccess> submitData(
//     String clientId, String clientContentId) async {
//   var response = await http.post(
//       Uri.parse('https://stage.tsbdev.co/api/v1/content/access'),
//       body: {"clientId": clientId, "clientContentId": clientContentId});
//   if (response.statusCode == 201) {
//     String responseString = response.body;
//     contentAccessFromJson(responseString);
//   } else {
//     throw Exception('Failed to create album.');
//   }
// }

// API login Challenge post

String loginChallengeIds = "loginChallengeId";

class MyApppp extends StatefulWidget {
  MyApppp({super.key});

  @override
  State<MyApppp> createState() => _MyAppppState();
}

class _MyAppppState extends State<MyApppp> {
  var uuid = const Uuid();

  final loginChallengeId = TextEditingController();

  final redirectTo = TextEditingController();
  @override
  void initState() {
    print("_dataMain");

    getPsts();
    print("_dataMain");

    super.initState();
  }

  Object? get filteredProducts => null;

  Future<LoginChallengepost> submitDatas(
      String loginChallengeId, String redirectTo) async {
    var response = await http.post(
        Uri.parse('https://stage.tsbdev.co/api/v1/login-challenge'),
        body: {"loginChallengeId": uuid.v1(), "redirectTo": redirectTo});
    print(response.body);

    if (response.statusCode == 201) {
      var responseString = response.body;
      String id = loginChallengepostFromJson(responseString).loginChallengeId;
      final prefs = await SharedPreferences.getInstance();
      prefs.setString('loginChallengeId', id);

      // ignore: avoid_print
      print(prefs.getString('loginChallengeId'));
      Get.off(const MyApps());

      // await newUserDefault.setString('loginChallengeId', 'loginChallengeId');

      return loginChallengepostFromJson(responseString);
    } else {
      throw Exception('Failed to create album.');
    }
  }

  tryAutoLogin() async {
    var any = await SharedPreferences.getInstance();
    if (!any.containsKey("loginChallengeId")) {
      return false;
    } else {
      return true;
    }
  }

// API login Challenge get
  Future<LoginChallengeget> getPost() async {
    var client = http.Client();
    // final prefs = await SharedPreferences.getInstance();
    // final counter = prefs.getString('loginChallengeId') ?? 'sdfs';
    // print(counter);
    print('object hgfdghfghasdfhasfhdqsddjqjdsjh');
    // final prefs = await SharedPreferences.getInstance();
    //final loginChallengeId = prefs.getInt('loginChallengeId') ?? 0;

    final prefs = await SharedPreferences.getInstance();
    // setState(() {
    loginChallengeIds =
        prefs.getString('loginChallengeId') ?? "loginChallengeId";
    // });

    print('--------');
    print(prefs.getString('loginChallengeId'));
    var loginId = prefs.getString('loginChallengeId');
    var uri =
        Uri.parse('https://stage.tsbdev.co/api/v1/login-challenge/$loginId');
    print(uri);
    print('urlllllllllllllllll');
    var response = await client.get(uri);
    if (response.statusCode == 200) {
      String responseString = response.body;
      return loginChallengegetFromJson(responseString);
    } else {
      throw Exception('Failed to create album.');
    }
  }

// Webview
  Future<SubscriptionAccess> getPostss() async {
    var client = http.Client();
    var uri = Uri.parse('https://stage.tsbdev.co/api/v1/subscription/access?');
    var response = await client.get(uri);
    if (response.statusCode == 200) {
      var json = response.body;
      return subscriptionAccessFromJson(json);
    } else {
      throw Exception('Failed to create album.');
    }
  }

  dynamic dataMain;
// API contentDetails get
  getPsts() async {
    var url = Uri.parse(
        'https://stage.tsbdev.co/api/v1/content?clientContentId=Client-Story-Id-1&clientId=5f92a62013332e0f667794dc');
    var response = await http.get(url);
    if (response.statusCode == 200) {
      dataMain = jsonDecode(response.body);
      print("dataMain");
      print(dataMain);
      print("dataMain");
      setState(() {});
    } else {
      throw Exception('Failed to load album');
    }
  }

// API get User Detail get
  Future<GetUserDetail> getPst() async {
    var client = http.Client();
    var uri = Uri.parse(
        'https://stage.tsbdev.co/api/v1/user/62c561a6f8f5315114da9f33?clientId=5f92a62013332e0f667794dc');
    var response = await client.get(uri);
    if (response.statusCode == 200) {
      var json = response.body;
      return getUserDetailFromJson(json);
    } else {
      throw Exception('Failed to create album.');
    }
  }

//API logout post
  @override
  Widget build(BuildContext context) {
    loginChallengeId.text = 'uuid';
    redirectTo.text = 'https://google.co.in';

    return SafeArea(
      child: Scaffold(
        body: Center(
          child: Card(
            child: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: <Widget>[
                  ListTile(
                    title: const Text(
                      'Continue Reading ...',
                      textAlign: TextAlign.center,
                    ),
                    subtitle: Text(
                      dataMain == null
                          ? ""
                          : dataMain["paywallCustomization"]
                                  ["micropaymentDisplaytext"]
                              .toString(),
                      //  _dataMain.paywallCustomization.micropaymentDisplaytext,
                      textAlign: TextAlign.center,
                    ),
                  ),

                  ListTile(
                    title: Text(
                      dataMain == null
                          ? ""
                          : "Pay " +
                              dataMain["currencySymbol"] +
                              dataMain["price"].toString() +
                              " to read now",
                      textAlign: TextAlign.center,
                    ),
                  ),

                  ElevatedButton(
                    onPressed: () {
                      print(uuid.v1());
                      print('object ggggggggggggg');

                      submitDatas(loginChallengeId.text, redirectTo.text);

                      Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => const WebViewApp()),
                      );
                    },
                    child: const Text('Read Now'),
                    style: ElevatedButton.styleFrom(
                      shape: const StadiumBorder(),
                    ),
                  ),
                  const Text("Pay with"),
                  Image.asset('assets/conscentLogoMono.png',
                      height: 50,
                      width: 80,
                      opacity: const AlwaysStoppedAnimation<double>(0.5)),
                  //Image.asset

                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      const Text('Already Purchased?'),
                      TextButton(
                        child: const Text(
                          'Log into Conscent',
                          style: TextStyle(fontSize: 15, color: Colors.grey),
                        ),
                        onPressed: () {
                          //signup screen
                          getPost();
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => const WebViewApp(),
                              settings: const RouteSettings(
                                arguments: EmbeddedSubscribtion,
                              ),
                            ),
                          );
                        },
                      ),
                    ],
                  ),

                  const ListTile(
                    title: Text(
                      'Onces paid this story is free for 30 Days',
                      textAlign: TextAlign.center,
                    ),
                  ),

                  const ListTile(
                    title: Text(
                      '------------------  OR  ------------------',
                      textAlign: TextAlign.center,
                    ),
                  ),
                  ListTile(
                    title: Text(
                      dataMain == null
                          ? ""
                          : "${dataMain["validPass.duration"].toString()} - hrs unlimited access to premium content",
                      textAlign: TextAlign.center,
                    ),
                  ),
                  // ElevatedButton(
                  //   onPressed: () {
                  //     getPost();
                  //     Navigator.push(
                  //       context,
                  //       MaterialPageRoute(
                  //         builder: (context) => const WebViewApp(),
                  //         settings: const RouteSettings(
                  //           arguments: EmbeddedSubscribtion,
                  //         ),
                  //       ),
                  //     );
                  //     // Navigator.of(context).pushNamed(Subscribe.routeName,
                  //     //     arguments: jsonEncode(filteredProducts));
                  //   },
                  //   child: Text('Buy a pass for ₹ ' +
                  //       dataMain["validPass"]["price"].toString()),
                  //   style: ElevatedButton.styleFrom(
                  //     shape: const StadiumBorder(),
                  //   ),
                  // ),
                  const Text("Pay with"),
                  Image.asset('assets/conscentLogoMono.png',
                      height: 50,
                      width: 80,
                      opacity: const AlwaysStoppedAnimation<double>(0.5)),

                  const ListTile(
                    title: const Text(
                      '------------------  OR  ------------------',
                      textAlign: TextAlign.center,
                    ),
                  ),
                  ListTile(
                    title: Text(
                      dataMain == null
                          ? ""
                          : dataMain["paywallCustomization"]
                              ["subscriptionText"],
                      textAlign: TextAlign.center,
                    ),
                  ),
                  ListTile(
                    title: Text(
                      dataMain == null
                          ? ""
                          : dataMain["paywallCustomization"]
                              ["subscriptionTitle"],
                      textAlign: TextAlign.center,
                    ),
                  ),
                  ElevatedButton(
                    // onPressed: () {
                    //   Navigator.push(
                    //     context,
                    //     MaterialPageRoute(builder: (context) => Subscribe()),
                    //   );
                    // },

                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => const WebViewAppss()),
                      );
                    },
                    child: const Text('Subscribtion Now'),
                    style: ElevatedButton.styleFrom(
                      shape: const StadiumBorder(),
                    ),
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      const Text('Already a Subscriber?'),
                      TextButton(
                        child: const Text(
                          'Sign In',
                          style: TextStyle(fontSize: 15, color: Colors.grey),
                        ),
                        onPressed: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(builder: (context) => MyApppp()),
                          );
                        },
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
