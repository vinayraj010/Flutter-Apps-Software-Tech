// // ignore_for_file: file_names

import 'dart:convert';

import 'package:coloredcontainer/Model/embeddedSubscribtion.dart';
import 'package:coloredcontainer/webviews.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class Subscribe extends StatefulWidget {
  const Subscribe({Key? key}) : super(key: key);

  @override
  State<Subscribe> createState() => SubscribeState();
}

class SubscribeState extends State<Subscribe> {
  int i = 0;
  int selected = -1;
  List result = [];
  doOnLaunch() async {
    var response = await http.get(Uri.parse(
        "https://stage.tsbdev.co/api/v1/subscription/embedded-subscription?clientId=5f92a62013332e0f667794dc"));
    result = jsonDecode(response.body)["subscriptions"];
    print("vv");
    // print(result);
    print(result[i].toString());
    print("vv");
    setState(() {});
  }

  var controller;
  EmbeddedSubscribtion? _embeddedSubscribtion;

  List<Widget> _list = <Widget>[];

  List<Widget> _list2 = <Widget>[];

  var data;
  bool isPressed = false;
  int pageIndex = 0;

  //Widget HomeBody .......................................................

  Widget homeBody() {
    return result == null
        ? const CircularProgressIndicator()
        : Padding(
            padding: const EdgeInsets.all(8.0),
            child: Column(
              children: [
                Row(
                  children: [
                    IconButton(
                        onPressed: () {
                          if (i > 0) {
                            selected = -1;
                            setState(() {
                              i--;
                            });
                          }
                        },
                        icon: const Icon(Icons.arrow_back_ios)),
                    SizedBox(
                      width: 260,
                      height: 250,
                      child: Center(
                        child: GridView.builder(
                            itemCount: result[i]["tiers"].length == null
                                ? 0
                                : result[i]["tiers"].length,
                            gridDelegate:
                                const SliverGridDelegateWithFixedCrossAxisCount(
                                    crossAxisCount: 2,
                                    mainAxisSpacing: 8,
                                    crossAxisSpacing: 8,
                                    childAspectRatio: 1.6),
                            itemBuilder: (context, index) {
                              return InkWell(
                                onTap: () {
                                  setState(() {
                                    selected = index;
                                    isPressed = !isPressed;
                                  });
                                },
                                child: Container(
                                  decoration: BoxDecoration(
                                    color: selected == index && isPressed
                                        ? Colors.red
                                        : Colors.white,
                                    border: Border.all(),
                                    borderRadius: BorderRadius.circular(10),
                                  ),
                                  child: Padding(
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 10, vertical: 5),
                                    child: Column(
                                      children: [
                                        Text(
                                          result[i]["tiers"][index]["basePrice"]
                                                      .toString() ==
                                                  "0"
                                              ? ""
                                              : result[i]["tiers"][index]
                                                      ["basePrice"]
                                                  .toString(),
                                          style: TextStyle(
                                              decoration:
                                                  TextDecoration.lineThrough,
                                              fontSize: 20,
                                              color:
                                                  selected == index && isPressed
                                                      ? Colors.white
                                                      : Colors.black),
                                        ),
                                        Text(
                                          result[i]["tiers"][index]["price"]
                                                  .toString() +
                                              " Rs",
                                          style: TextStyle(
                                              fontSize: 20,
                                              color:
                                                  selected == index && isPressed
                                                      ? Colors.white
                                                      : Colors.black),
                                        ),
                                        Text(
                                          result[i]["tiers"][index]["duration"]
                                                  .toString() +
                                              " month",
                                          style: TextStyle(
                                              fontSize: 17,
                                              color:
                                                  selected == index && isPressed
                                                      ? Colors.white
                                                      : Colors.black),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              );
                            }),
                      ),
                    ),
                    IconButton(
                        onPressed: () {
                          setState(() {
                            selected = -1;
                            if (i < result.length - 1) {
                              i++;
                            }
                          });
                        },
                        icon: const Icon(Icons.arrow_forward_ios)),
                  ],
                ),
                const Text(
                  "Benifits You will Get",
                  style: TextStyle(fontSize: 22),
                ),
                const SizedBox(
                  height: 10,
                ),
                Text(result[i]["benefits"] ?? "",
                    style: const TextStyle(fontSize: 16),
                    textAlign: TextAlign.center),
                const SizedBox(
                  height: 10,
                ),
                Text(
                    "Start your ${result[i]["freeTrial"]["duration"].toString()}-days Free Trail",
                    style: const TextStyle(fontSize: 16),
                    textAlign: TextAlign.center)
              ],
            ),
          );
  }

// first call..................................

// end

  @override
  Widget build(BuildContext context) {
    var children2 = <Widget>[
      const ListTile(
        title: Text(
          'Welcome to the embedded subs testing phase one',
          textAlign: TextAlign.center,
        ),
      ),
      const ListTile(
        title: Text(
          'Choose Plan',
          textAlign: TextAlign.center,
          style: TextStyle(fontSize: 20),
        ),
      ),
      Container(
        child: Column(
          children: <Widget>[
            Container(
              child: SizedBox(child: homeBody()),
            ),
          ],
        ),
      ),
      ElevatedButton(
        // onPressed: () {},

        onPressed: () {
          print('Dev');
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => const WebViewApps()),
          );
        },
        // child:
        //   Colors.black,
        style: ElevatedButton.styleFrom(
          shape: const StadiumBorder(),
        ),

        child: const Text('Subscribe'),
      ),
      const Text("Pay with"),
      Image.asset('assets/conscentLogoMono.png',
          height: 50,
          width: 80,
          opacity: const AlwaysStoppedAnimation<double>(0.5))
    ];

    return Center(
      child: Card(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: children2,
        ),
      ),
    );
  }

  @override
  void initState() {
    // TODO: implement initState
    controller = PageController(initialPage: pageIndex);
    doOnLaunch();
    super.initState();
  }

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }
}
