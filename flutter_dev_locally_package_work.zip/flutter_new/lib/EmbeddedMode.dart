// ignore_for_file: unused_import, duplicate_import

import 'dart:async';
import 'dart:convert';

import 'package:coloredcontainer/EmbeddedSubscribe.dart';
import 'package:flutter/material.dart';
import 'package:flutter_new/Model/DataFile.dart';
import 'package:flutter_new/Model/contentAccesspost.dart';
import 'package:flutter_new/Model/contentDetails.dart';
import 'package:flutter_new/Model/getUserDetail.dart';
import 'package:flutter_new/Model/loginChallengeget.dart';
import 'package:flutter_new/Model/loginChallengepost.dart';
import 'package:flutter_new/Model/logout.dart';
import 'package:flutter_new/Model/subscriptionAccess.dart';
import 'package:flutter_new/main.dart';
import 'package:get/get.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:uuid/uuid.dart';

import 'Model/embeddedSubscribtion.dart';

String loginChallengeIds = "loginChallengeId";

class MyAp extends StatelessWidget {
  const MyAp({super.key});

  _MyApState createState() => _MyApState();

  @override
  Widget build(BuildContext context) {
    const appTitle = 'Embeded Mode';

    return MaterialApp(
      title: appTitle,
      home: Scaffold(
        appBar: AppBar(
          title: const Text(appTitle),
          backgroundColor: Colors.blue,
        ),
        body: _MyApState(),
      ),
    );
  }
}

class _MyApState extends StatelessWidget {
  var uuid = const Uuid();
  final loginChallengeId = TextEditingController();
  final redirectTo = TextEditingController();

//API logout post
  @override
  Widget build(BuildContext context) {
    loginChallengeId.text = 'uuid';
    redirectTo.text = 'https://google.co.in';

    return SafeArea(
      child: Scaffold(
        body: Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: const <Widget>[
              Padding(
                padding: EdgeInsets.all(20.0),
                child: Text(
                  'Early use Scientists are still debating when people started wearing clothes. Estimates by various experts have ranged from 40,000 to 3 million years ago. Some more recent studies involving the evolution of body lice have implied a more recent development with some indicating a development of around 170,000 years ago and others indicating as little as 40,000. No single estimate is widely accepted.[1][2][3][4] Ralf Kittler, Manfred Kayser and Mark Stoneking, anthropologists at the Max Planck Institute for Evolutionary Anthropology, conducted a genetic analysis of human body lice that suggests clothing originated around 170,000 years ago. Body lice are an indicator of clothes-wearing, since most humans have sparse body hair, and lice thus require human clothing to survive. Their research suggests that the invention of clothing may have coincided with the northward migration of modern Homo sapiens away from the warm climate of Africa, thought to have begun between 50,000 and 100,000 years ago. However, a second group of researchers using similar genetic methods estimate that clothing originated around 540,000 years ago.[5]...',
                  maxLines: 4,
                ),
              ),
              Expanded(flex: 2, child: Subscribe()),
            ],
          ),
        ),
      ),
    );
  }
}
