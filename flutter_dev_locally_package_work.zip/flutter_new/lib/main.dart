import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter_new/EmbeddedMode.dart';
import 'package:flutter_new/Model/contentAccesspost.dart';
import 'package:flutter_new/Model/contentDetails.dart';
import 'package:flutter_new/Model/embeddedSubscribtion.dart';
import 'package:flutter_new/defaultSubscribtion.dart';
import 'package:get/get.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

void main() => runApp(const MyApps());

bool isSwitched = false;

class MyApps extends StatelessWidget {
  const MyApps({super.key});

  MyCustomForm createState() => MyCustomForm();

  @override
  Widget build(BuildContext context) {
    const appTitle = 'Setting';

    return MaterialApp(
      title: appTitle,
      home: Scaffold(
        appBar: AppBar(
          title: const Text(appTitle),
          backgroundColor: Colors.blue,
        ),
        body: MyCustomForm(),
      ),
    );
  }
}

// ignore: must_be_immutable
class MyCustomForm extends StatelessWidget {
  MyCustomForm({super.key});

  final clientIdController = TextEditingController();
  final contentIdController = TextEditingController();

  //API Content Access post

  Future<ContentAccess> submitData(
      String clientId, String clientContentId) async {
    print(clientContentId);
    print(clientId);
    var response = await http.post(
        Uri.parse('https://stage.tsbdev.co/api/v1/content/access'),
        body: {"clientId": clientId, "clientContentId": clientContentId});
    print(response.body);
    if (response.statusCode == 201) {
      String responseString = response.body;
      print(response.body);
      // set state in here
      return contentAccessFromJson(responseString);
    } else {
      throw Exception('Failed to create album.');
    }
  }

  // API contentDetails get

  Future<ContentDetails> getPsts() async {
    var client = http.Client();

    String clientId = clientIdController.text;
    String contentId = contentIdController.text;

    var uri = Uri.parse(
        'https://stage.tsbdev.co/api/v1/content?clientContentId=$contentId&clientId=$clientId');
    print(uri);
    print('data');
    var response = await http.get(uri);
    if (response.statusCode == 200) {
      String responseString = response.body;
      print(response.body);

      return contentDetailsFromJson(responseString);
    } else {
      throw Exception('Failed to create album.');
    }
  }

  Future<EmbeddedSubscribtion> getPstss() async {
    var client = http.Client();
    String clientId = clientIdController.text;
    String contentId = contentIdController.text;
    var uri = Uri.parse(
        'https://stage.tsbdev.co/api/v1/subscription/embedded-subscription?clientId=$clientId');
    // 'https://stage.tsbdev.co/api/v1/subscription/embedded-subscription?clientId=5f92a62013332e0f667794dc');
    print(uri);
    print('data');
    var response = await http.get(uri);
    if (response.statusCode == 200) {
      String responseString = response.body;
      print(response.body);
      var embeddedSubscription = jsonDecode(responseString);
      return embeddedSubscribtionFromJson(responseString);
    } else {
      throw Exception('Failed to create album.');
    }
  }

  //   Future<List<EmbeddedSubscribtion>> loadData() async {
  //     String clientId = clientIdController.text;
  //    String contentId = contentIdController.text;
  //   try {
  //     var response = await http.get(Uri.parse(
  //         'https://stage.tsbdev.co/api/v1/subscription/embedded-subscription?clientId=$clientId'));
  //     if (response.statusCode == 200) {
  //       final jsonBody = json.decode(response.body);
  //       Demandes data = Demandes.fromJson(jsonBody);
  //       final srAttributes = data.srMboSet.sr;
  //       return srAttributes;
  //     }
  //   } catch (e) {
  //     throw Exception(e.toString());
  //   }
  //   throw Exception("");
  // }

  @override
  Widget build(BuildContext context) {
    clientIdController.text = '5f92a62013332e0f667794dc';
    contentIdController.text = 'Client-Story-Id-1';
    return Column(
      children: <Widget>[
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 16),
          child: TextFormField(
            controller: clientIdController,
            decoration: const InputDecoration(
              border: UnderlineInputBorder(),
              labelText: 'Enter your Client Id',
            ),
          ),
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 16),
          child: TextFormField(
            controller: contentIdController,
            decoration: const InputDecoration(
              border: UnderlineInputBorder(),
              labelText: 'Enter your Content Id',
            ),
          ),
        ),
        Column(
          children: [
            const SizedBox(
              height: 50,
            ),
            TextButton.icon(
              // <-- TextButton
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => MyApp()),
                );
              },
              icon: const Icon(
                Icons.skip_next,
                size: 24.0,
              ),
              label: Text('Next'),
            ),
            TextButton.icon(
              // <-- TextButton
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => MyAp(),
                  ),
                );
              },

              icon: const Icon(
                Icons.mode,
                size: 24.0,
              ),
              label: const Text('Embedded Mode'),
            ),
            TextButton.icon(
              // <-- TextButton
              onPressed: () {
                logOut();
              },
              icon: const Icon(
                Icons.logout,
                size: 24.0,
              ),
              label: Text('Logout'),
            ),
          ],
        )
      ],
    );
  }

  static logOut() async {
    final prefs = await SharedPreferences.getInstance();
    prefs.clear();
    Get.off(() => MyCustomForm());
  }
}
