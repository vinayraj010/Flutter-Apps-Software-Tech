import 'dart:convert';

import 'package:flutter_app/core/strings.dart';
import 'package:flutter_app/domain/core/token_model.dart';
import 'package:flutter_app/injection.dart';
import 'package:hive/hive.dart';

Message messageFromJson(String str) =>
    Message.fromJson(json.decode(str) as Map<String, dynamic>);

String messageToJson(Message data) => json.encode(data.toJson());

class Message {
  Message({
    this.currentPage,
    this.data,
    this.firstPageUrl,
    this.from,
    this.lastPage,
    this.lastPageUrl,
    this.nextPageUrl,
    this.path,
    this.perPage,
    this.prevPageUrl,
    this.to,
    this.total,
  });

  final int currentPage;
  final List<MessageBody> data;
  final String firstPageUrl;
  final int from;
  final int lastPage;
  final String lastPageUrl;
  final dynamic nextPageUrl;
  final String path;
  final int perPage;
  final dynamic prevPageUrl;
  final int to;
  final int total;

  Message copyWith({
    int currentPage,
    List<MessageBody> data,
    String firstPageUrl,
    int from,
    int lastPage,
    String lastPageUrl,
    dynamic nextPageUrl,
    String path,
    int perPage,
    dynamic prevPageUrl,
    int to,
    int total,
  }) =>
      Message(
        currentPage: currentPage ?? this.currentPage,
        data: data ?? this.data,
        firstPageUrl: firstPageUrl ?? this.firstPageUrl,
        from: from ?? this.from,
        lastPage: lastPage ?? this.lastPage,
        lastPageUrl: lastPageUrl ?? this.lastPageUrl,
        nextPageUrl: nextPageUrl ?? this.nextPageUrl,
        path: path ?? this.path,
        perPage: perPage ?? this.perPage,
        prevPageUrl: prevPageUrl ?? this.prevPageUrl,
        to: to ?? this.to,
        total: total ?? this.total,
      );

  factory Message.fromJson(Map<String, dynamic> json) => Message(
        currentPage: json["current_page"] as int,
        data: List<MessageBody>.from(json['data']
                .map((x) => MessageBody.fromJson(x as Map<String, dynamic>))
            as Iterable<dynamic>),
        firstPageUrl: json["first_page_url"] as String,
        from: json["from"] as int,
        lastPage: json["last_page"] as int,
        lastPageUrl: json["last_page_url"] as String,
        nextPageUrl: json["next_page_url"] as String,
        path: json["path"] as String,
        perPage: json["per_page"] as int,
        prevPageUrl: json["prev_page_url"] as String,
        to: json["to"] as int,
        total: json["total"] as int,
      );

  Map<String, dynamic> toJson() => {
        "current_page": currentPage,
        "data": List<dynamic>.from(data.map((x) => x.toJson())),
        "first_page_url": firstPageUrl,
        "from": from,
        "last_page": lastPage,
        "last_page_url": lastPageUrl,
        "next_page_url": nextPageUrl,
        "path": path,
        "per_page": perPage,
        "prev_page_url": prevPageUrl,
        "to": to,
        "total": total,
      };
}

class MessageBody {
  MessageBody(
      {this.id,
      this.chatId,
      this.message,
      this.typeId,
      this.senderId,
      this.createdAt,
      this.updatedAt,
      this.isChild,
      this.sender,
      this.isSent});

  final int id;
  final int chatId;
  final String message;
  final int typeId;
  final int senderId;
  final DateTime createdAt;
  final DateTime updatedAt;
  final dynamic isChild;
  final Sender sender;
  final bool isSent;

  MessageBody copyWith({
    int id,
    int chatId,
    String message,
    int typeId,
    int senderId,
    DateTime createdAt,
    DateTime updatedAt,
    dynamic isChild,
    Sender sender,
  }) =>
      MessageBody(
        id: id ?? this.id,
        chatId: chatId ?? this.chatId,
        message: message ?? this.message,
        typeId: typeId ?? this.typeId,
        senderId: senderId ?? this.senderId,
        createdAt: createdAt ?? this.createdAt,
        updatedAt: updatedAt ?? this.updatedAt,
        isChild: isChild ?? this.isChild,
        sender: sender ?? this.sender,
        isSent: isSent ?? isSent,
      );

  factory MessageBody.fromJson(Map<String, dynamic> json) => MessageBody(
      id: json["id"] as int,
      chatId: json["chat_id"] as int,
      message: json["message"] as String,
      typeId: json["type_id"] as int,
      senderId: json["sender_id"] as int,
      createdAt: DateTime.parse(json["created_at"] as String),
      updatedAt: DateTime.parse(json["updated_at"] as String),
      isChild: json["is_child"] as int,
      sender: Sender.fromJson(json["sender"] as Map<String, dynamic>),
      //TODO: Make this dynamic
      isSent: getIt<Box<ResponseTokenModel>>().get(HiveBoxNames.token).name == json['sender']['name']);

  Map<String, dynamic> toJson() => {
        "id": id,
        "chat_id": chatId,
        "message": message,
        "type_id": typeId,
        "sender_id": senderId,
        "created_at": createdAt.toIso8601String(),
        "updated_at": updatedAt.toIso8601String(),
        "is_child": isChild,
        "sender": sender.toJson(),
      };
}

class Sender {
  Sender({
    this.id,
    this.name,
    this.avatar,
  });

  final int id;
  final String name;
  final String avatar;

  Sender copyWith({
    int id,
    String name,
    String avatar,
  }) =>
      Sender(
        id: id ?? this.id,
        name: name ?? this.name,
        avatar: avatar ?? this.avatar,
      );

  factory Sender.fromJson(Map<String, dynamic> json) => Sender(
        id: json["id"] as int,
        name: json["name"] as String,
        avatar: json["avatar"] as String,
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "name": name,
        "avatar": avatar,
      };
}
