import 'package:dartz/dartz.dart';
import 'package:flutter_app/domain/chat/message.dart';
import 'package:flutter_app/domain/core/value_objects.dart';
import 'package:flutter_app/domain/message/message_failure.dart';

abstract class IMessageRepo {
  Future<Either<MessageFailure, Unit>> sendMessage(
      {int chatId, NonNullString message});
  Future<Either<MessageFailure, Unit>> sendMultiMediaMessage(
      {int chatId, String path, int typeId});
  Future<Either<MessageFailure, Message>> getChatMessage(
      {int chatId, String url});
}
