// To parse this JSON data, do
//
//     final country = countryFromJson(jsonString);

import 'package:freezed_annotation/freezed_annotation.dart';
import 'dart:convert';

part 'country.freezed.dart';
part 'country.g.dart';

List<Country> countryFromJson(List str) => List<Country>.from(
    str.map((x) => Country.fromJson(x as Map<String, dynamic>)));
String countryToJson(List<Country> data) =>
    json.encode(List<dynamic>.from(data.map((x) => x.toJson())));

@freezed
abstract class Country with _$Country {
  const factory Country({
    int id,
    String code,
    String name,
    dynamic createdAt,
    dynamic updatedAt,
  }) = _Country;

  factory Country.fromJson(Map<String, dynamic> json) =>
      _$CountryFromJson(json);
}
