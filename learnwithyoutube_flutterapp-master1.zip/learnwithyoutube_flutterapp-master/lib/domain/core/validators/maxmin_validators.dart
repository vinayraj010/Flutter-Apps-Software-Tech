import 'package:flutter_app/core/utils/clean_string.dart';
import 'package:form_validators/form_validators.dart';

class MinMaxValidator implements IValidator {
  final int min;
  final int max;
  final String message;

  const MinMaxValidator({this.min, this.max, this.message});

  @override
  bool call(String value) {
    if (int.parse(cleanString(value)) >= min && int.parse(cleanString(value)) <= max) {
      return false;
    } else {
      return true;
    }
  }
}
