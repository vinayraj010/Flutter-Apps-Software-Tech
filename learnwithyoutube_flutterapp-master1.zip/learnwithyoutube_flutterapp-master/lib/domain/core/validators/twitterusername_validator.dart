import 'package:form_validators/form_validators.dart';

class TwitterUsernameValidator implements IValidator {
  final String message;

  const TwitterUsernameValidator(this.message);

  @override
  bool call(String value) {
    const _regex = r"""^[a-zA-Z0-9_]{1,15}$""";
    if (value == null || value.isEmpty) {
      return false;
    } else if (RegExp(_regex).hasMatch(value)) {
      return false;
    } else {
      return true;
    }
  }
}
