// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'token_model.dart';

// **************************************************************************
// TypeAdapterGenerator
// **************************************************************************

class ResponseTokenModelAdapter extends TypeAdapter<ResponseTokenModel> {
  @override
  ResponseTokenModel read(BinaryReader reader) {
    var numOfFields = reader.readByte();
    var fields = <int, dynamic>{
      for (var i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return ResponseTokenModel(
      uniqueId: fields[0] as String,
      responseTokenModelNew: fields[1] as int,
      accessToken: fields[2] as String,
      expiresIn: fields[3] as int,
      refreshToken: fields[4] as String,
      flag: fields[5] as dynamic,
      phoenixUserId: fields[6] as int,
      email: fields[7] as String,
      name: fields[8] as dynamic,
      roleId: fields[9] as int,
    );
  }

  @override
  void write(BinaryWriter writer, ResponseTokenModel obj) {
    writer
      ..writeByte(10)
      ..writeByte(0)
      ..write(obj.uniqueId)
      ..writeByte(1)
      ..write(obj.responseTokenModelNew)
      ..writeByte(2)
      ..write(obj.accessToken)
      ..writeByte(3)
      ..write(obj.expiresIn)
      ..writeByte(4)
      ..write(obj.refreshToken)
      ..writeByte(5)
      ..write(obj.flag)
      ..writeByte(6)
      ..write(obj.phoenixUserId)
      ..writeByte(7)
      ..write(obj.email)
      ..writeByte(8)
      ..write(obj.name)
      ..writeByte(9)
      ..write(obj.roleId);
  }

  @override
  // TODO: implement typeId
  int get typeId => 0;
}
