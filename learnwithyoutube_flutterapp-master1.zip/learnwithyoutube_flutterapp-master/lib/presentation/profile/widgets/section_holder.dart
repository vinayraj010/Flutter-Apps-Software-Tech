import 'package:flutter/material.dart';
import 'package:flutter_neumorphic/flutter_neumorphic.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:google_fonts/google_fonts.dart';

class SectionHolder extends StatelessWidget {
  final Widget child;
  final String icon;
  final String title;
  final VoidCallback onEditPressed;
  final bool isShowPen;

  const SectionHolder(
      {Key key,
      this.child,
      this.icon,
      this.title,
      this.onEditPressed,
      this.isShowPen = true})
      : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Stack(
      alignment: Alignment.bottomRight,
      children: [
        Container(
          margin: const EdgeInsets.only(left: 10, right: 10, top: 15),
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(15),
            color: Colors.white,
            border: Border.all(color: Colors.white, width: 2),
            // gradient: LinearGradient(
            //     begin: Alignment.topLeft,
            //     end: Alignment.bottomRight,
            //     stops: const [
            //       0.01,
            //       0.1,
            //       0.9
            //     ],
            //     colors: [
            //       const Color(0xff6646E7).withOpacity(0.4),
            //       Colors.white,
            //       const Color(0xff6646E7).withOpacity(0.4),
            //     ]),
            // boxShadow: [
            //   const BoxShadow(
            //       color: Color.fromRGBO(0, 0, 0, 0.25),
            //       blurRadius: 3,
            //       spreadRadius: 1,
            //       offset: Offset(0, 4))
            // ]),
          ),
          child: Column(
            children: [
              Row(
                children: [
                  SvgPicture.asset('assets/profile/$icon.svg'),
                  SizedBox(
                    width: 10,
                  ),
                  Text(
                    title,
                    style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                        fontFamily: GoogleFonts.poppins().fontFamily),
                  )
                ],
              ),
              const SizedBox(
                height: 20,
              ),
              child
            ],
          ),
        ),
        Positioned(
          right: 10,
          child: Visibility(
            visible: isShowPen,
            child: GestureDetector(
                onTap: onEditPressed,
                child: SvgPicture.asset('assets/profile/edit_pen.svg')),
          ),
        )
      ],
    );
  }
}
