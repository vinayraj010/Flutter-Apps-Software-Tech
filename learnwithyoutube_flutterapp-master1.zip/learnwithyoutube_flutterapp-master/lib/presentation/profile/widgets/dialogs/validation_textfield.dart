import 'package:flutter/material.dart';
import 'package:flutter_app/presentation/core/palette.dart';

final EdgeInsets fromPadding = const EdgeInsets.all(0).copyWith(left: 8);

typedef Validator = String Function(String input);
typedef OnChanged = void Function(String value);

class ValidationTextField extends StatelessWidget {
  final GlobalKey<FormState> formKey;
  final String initialValue;
  final Validator validator;
  final OnChanged onChanged;
  final String hintText;
  final bool isNotFilled;
  final InputBorder border;
  final TextInputType keyboardType;
  const ValidationTextField({
    Key key,
    @required this.formKey,
    @required this.initialValue,
    @required this.validator,
    @required this.onChanged,
    @required this.hintText,
    @required this.isNotFilled,
    @required this.border,
    @required this.keyboardType,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(left: 10),
      child: TextFormField(
        style: const TextStyle(fontSize: 14),
        initialValue: initialValue,
        validator: validator,
        onSaved: (newValue) {
          formKey.currentState.validate();
        },
        onChanged: onChanged,
        keyboardType: keyboardType,
        decoration: InputDecoration(
          contentPadding: fromPadding,
          hintText: hintText,
          filled: true,
          hintStyle: TextStyle(color: Palette.cafadad, fontSize: 14),
          fillColor: isNotFilled ? Palette.cafafafa : Palette.onBackground,
          focusedBorder: border,
          enabledBorder: border,
          border: border,
        ),
      ),
    );
  }
}
