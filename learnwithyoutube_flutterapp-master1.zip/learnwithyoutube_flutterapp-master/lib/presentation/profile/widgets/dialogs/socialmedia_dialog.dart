import 'package:flutter/material.dart';
import 'package:flutter_app/application/profile/profile_bloc.dart';
import 'package:flutter_app/core/routes/route.gr.dart' as route;
import 'package:flutter_app/core/utils/clean_string.dart';
import 'package:flutter_app/domain/core/validators/facebookusername_validator.dart';
import 'package:flutter_app/domain/core/validators/instagramusername_validator.dart';
import 'package:flutter_app/domain/core/validators/linkedinusername_validators.dart';
import 'package:flutter_app/domain/core/validators/twitterusername_validator.dart';
import 'package:flutter_app/domain/profile/profile.dart';
import 'package:flutter_app/presentation/core/palette.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_svg/svg.dart';
import 'package:form_validators/form_validators.dart';
import 'package:google_fonts/google_fonts.dart';

import '../add_dialog.dart';

final BuildContext context = route.Router.navigator.key.currentContext;

class SocialMediaDialog {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  bool _showError = false;

  void call() async {
    final EdgeInsets fromPadding = const EdgeInsets.all(0).copyWith(left: 8);

    String instagramUserName;
    String facebookUserName;
    String twitterUserName;
    String linkedinUserName;

    String _splitUserName(String url) {
      if (url == null || url.isEmpty || url == 'null') {
        return '';
      }
      return url.split('/').last;
    }

    return await showDialog(
        context: context,
        barrierDismissible: false,
        builder: (_) => BlocConsumer<ProfileBloc, ProfileState>(
              listener: (context, state) {
                // TODO: implement listener
              },
              builder: (context, state) {
                final Profile _profile = state.profile;
                instagramUserName = _splitUserName(_profile.instagramLink);
                facebookUserName = _splitUserName(_profile.facebookLink);
                twitterUserName = _splitUserName(_profile.twitterUrl);
                linkedinUserName = _splitUserName(_profile.linkedinUrl);

                return StatefulBuilder(
                  builder: (context, setMState) {
                    //Instagram
                    final bool _isInstagramNotFilled =
                        instagramUserName == null ||
                            cleanString(instagramUserName).isEmpty;

                    final InputBorder _instagramTextFieldBorder =
                        OutlineInputBorder(
                            borderSide: BorderSide(
                                color: _isInstagramNotFilled
                                    ? Palette.c686868
                                    : Palette.onBlue),
                            borderRadius: BorderRadius.circular(3));

                    //Twitter
                    final bool _isTwitterNotFilled = twitterUserName == null ||
                        cleanString(twitterUserName).isEmpty;

                    final InputBorder _twitterTextFieldBorder =
                        OutlineInputBorder(
                            borderSide: BorderSide(
                                color: _isTwitterNotFilled
                                    ? Palette.c686868
                                    : Palette.onBlue),
                            borderRadius: BorderRadius.circular(3));

                    //Facebook
                    final bool _isFacebookNotFilled =
                        facebookUserName == null ||
                            cleanString(facebookUserName).isEmpty;

                    final InputBorder _facebookTextFieldBorder =
                        OutlineInputBorder(
                            borderSide: BorderSide(
                                color: _isFacebookNotFilled
                                    ? Palette.c686868
                                    : Palette.onBlue),
                            borderRadius: BorderRadius.circular(3));

                    //Linkedin
                    final bool _isLinkedinNotFilled =
                        linkedinUserName == null ||
                            cleanString(linkedinUserName).isEmpty;

                    final InputBorder _linkedinTextFieldBorder =
                        OutlineInputBorder(
                            borderSide: BorderSide(
                                color: _isLinkedinNotFilled
                                    ? Palette.c686868
                                    : Palette.onBlue),
                            borderRadius: BorderRadius.circular(3));

                    return AddDialog(
                      asset: 'social_media',
                      heading: 'Social media handles',
                      child: Form(
                        key: _formKey,
                        autovalidate: _showError,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                SvgPicture.asset(
                                    'assets/profile/instagram.svg'),
                                const SizedBox(
                                  width: 10,
                                ),
                                Text(
                                  'Instagram',
                                  style: TextStyle(
                                      fontSize: 14,
                                      fontWeight: FontWeight.w400,
                                      color: Palette.c686868,
                                      fontFamily:
                                          GoogleFonts.poppins().fontFamily),
                                ),
                              ],
                            ),
                            const SizedBox(
                              height: 10,
                            ),
                            Padding(
                              padding: const EdgeInsets.only(left: 10),
                              child: TextFormField(
                                validator: validate([
                                  const InstagramUsernameValidator(
                                      'Invalid Username')
                                ]) as String Function(String value),
                                initialValue: instagramUserName,
                                keyboardType: TextInputType.text,
                                onChanged: (value) {
                                  instagramUserName = cleanString(value);
                                  setMState(() {});
                                },
                                decoration: InputDecoration(
                                  contentPadding: fromPadding,
                                  hintText: 'Username',
                                  hintStyle: TextStyle(
                                      color: Palette.cafadad, fontSize: 14),
                                  filled: true,
                                  fillColor: _isInstagramNotFilled
                                      ? Palette.cafafafa
                                      : Palette.onBackground,
                                  focusedBorder: _instagramTextFieldBorder,
                                  enabledBorder: _instagramTextFieldBorder,
                                  border: _instagramTextFieldBorder,
                                ),
                              ),
                            ),
                            const SizedBox(
                              height: 20,
                            ),
                            Row(
                              children: [
                                SvgPicture.asset('assets/profile/twitter.svg'),
                                const SizedBox(
                                  width: 10,
                                ),
                                Text(
                                  'Twitter',
                                  style: TextStyle(
                                      fontSize: 14,
                                      fontWeight: FontWeight.w400,
                                      color: Palette.c686868,
                                      fontFamily:
                                          GoogleFonts.poppins().fontFamily),
                                ),
                              ],
                            ),
                            const SizedBox(
                              height: 10,
                            ),
                            Padding(
                              padding: const EdgeInsets.only(left: 10),
                              child: TextFormField(
                                  validator: validate([
                                    const TwitterUsernameValidator(
                                        'Invalid Username')
                                  ]) as String Function(String value),
                                  initialValue: twitterUserName,
                                  onChanged: (value) {
                                    twitterUserName = cleanString(value);
                                    setMState(() {});
                                  },
                                  keyboardType: TextInputType.text,
                                  decoration: InputDecoration(
                                    contentPadding: fromPadding,
                                    hintText: 'Username',
                                    hintStyle: TextStyle(
                                        color: Palette.cafadad, fontSize: 14),
                                    filled: true,
                                    fillColor: _isTwitterNotFilled
                                        ? Palette.cafafafa
                                        : Palette.onBackground,
                                    focusedBorder: _twitterTextFieldBorder,
                                    enabledBorder: _twitterTextFieldBorder,
                                    border: _twitterTextFieldBorder,
                                  )),
                            ),
                            const SizedBox(
                              height: 20,
                            ),
                            Row(
                              children: [
                                SvgPicture.asset('assets/profile/facebook.svg'),
                                const SizedBox(
                                  width: 10,
                                ),
                                Text(
                                  'Facebook',
                                  style: TextStyle(
                                      fontSize: 14,
                                      fontWeight: FontWeight.w400,
                                      color: Palette.c686868,
                                      fontFamily:
                                          GoogleFonts.poppins().fontFamily),
                                ),
                              ],
                            ),
                            const SizedBox(
                              height: 10,
                            ),
                            Padding(
                              padding: const EdgeInsets.only(left: 10),
                              child: TextFormField(
                                validator: validate([
                                  const FacebookUsernameValidator(
                                      'Invalid Username'),
                                ]) as String Function(String value),
                                initialValue: facebookUserName,
                                onChanged: (value) {
                                  facebookUserName = cleanString(value);
                                  setMState(() {});
                                },
                                keyboardType: TextInputType.text,
                                decoration: InputDecoration(
                                  contentPadding: fromPadding,
                                  hintText: 'Username',
                                  hintStyle: TextStyle(
                                      color: Palette.cafadad, fontSize: 14),
                                  filled: true,
                                  fillColor: _isFacebookNotFilled
                                      ? Palette.cafafafa
                                      : Palette.onBackground,
                                  focusedBorder: _facebookTextFieldBorder,
                                  enabledBorder: _facebookTextFieldBorder,
                                  border: _facebookTextFieldBorder,
                                ),
                              ),
                            ),
                            const SizedBox(
                              height: 20,
                            ),
                            Row(
                              children: [
                                SvgPicture.asset('assets/profile/linkedin.svg'),
                                const SizedBox(
                                  width: 10,
                                ),
                                Text(
                                  'Linkedin',
                                  style: TextStyle(
                                      fontSize: 14,
                                      fontWeight: FontWeight.w400,
                                      color: Palette.c686868,
                                      fontFamily:
                                          GoogleFonts.poppins().fontFamily),
                                ),
                              ],
                            ),
                            const SizedBox(
                              height: 10,
                            ),
                            Padding(
                              padding: const EdgeInsets.only(left: 10),
                              child: TextFormField(
                                validator: validate([
                                  const LinkedinUsernameValidator(
                                      'Invalid Username')
                                ]) as String Function(String value),
                                initialValue: linkedinUserName,
                                onChanged: (value) {
                                  linkedinUserName = cleanString(value);
                                  setMState(() {});
                                },
                                keyboardType: TextInputType.text,
                                decoration: InputDecoration(
                                  contentPadding: fromPadding,
                                  hintText: 'Username',
                                  hintStyle: TextStyle(
                                      color: Palette.cafadad, fontSize: 14),
                                  filled: true,
                                  fillColor: _isLinkedinNotFilled
                                      ? Palette.cafafafa
                                      : Palette.onBackground,
                                  focusedBorder: _linkedinTextFieldBorder,
                                  enabledBorder: _linkedinTextFieldBorder,
                                  border: _linkedinTextFieldBorder,
                                ),
                              ),
                            ),
                            const SizedBox(
                              height: 50,
                            ),
                            Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Padding(
                                  padding: const EdgeInsets.only(top: 6),
                                  child: SvgPicture.asset(
                                      'assets/profile/info.svg'),
                                ),
                                const SizedBox(
                                  width: 10,
                                ),
                                Text(
                                  'This information will get\nreflected in your public profile',
                                  style: TextStyle(
                                      fontSize: 12,
                                      fontWeight: FontWeight.w400,
                                      color: Palette.onBlue,
                                      fontFamily:
                                          GoogleFonts.poppins().fontFamily),
                                ),
                              ],
                            ),
                            const SizedBox(
                              height: 25,
                            ),
                            Padding(
                              padding: const EdgeInsets.only(left: 10),
                              child: RaisedButton(
                                elevation: 0,
                                color: Palette.onBlue,
                                onPressed: () {
                                  if (_formKey.currentState.validate()) {
                                    BlocProvider.of<ProfileBloc>(context).add(
                                        ProfileEvent.saveSocialMedia(
                                            facebookUserName: facebookUserName,
                                            instagramUserName:
                                                instagramUserName,
                                            twitterUserName: twitterUserName,
                                            linkedinUserName:
                                                linkedinUserName));
                                  } else {
                                    setMState(() {
                                      _showError = true;
                                    });
                                  }
                                },
                                shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(16)),
                                child: Container(
                                    alignment: Alignment.center,
                                    height: 50,
                                    width: 130,
                                    child: SvgPicture.asset(
                                        'assets/profile/about_save.svg')),
                              ),
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                );
              },
            ));
  } // ignore: avoid_void_async

}
