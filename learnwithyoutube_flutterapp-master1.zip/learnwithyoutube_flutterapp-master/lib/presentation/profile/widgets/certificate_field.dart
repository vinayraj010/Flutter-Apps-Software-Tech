import 'package:dotted_border/dotted_border.dart';
import 'package:flutter/material.dart'
    hide DropdownButton, DropdownMenuItem, DropdownButtonFormField;
import 'package:flutter_app/application/providers/certificate_provider.dart';
import 'package:flutter_app/core/utils/month_map.dart';
import 'package:flutter_app/presentation/core/palette.dart';
import 'package:flutter_app/presentation/profile/widgets/certificate_image.dart';
import 'package:flutter_app/presentation/profile/widgets/dialogs/validation_textfield.dart';
import 'package:flutter_app/presentation/profile/widgets/drop_down_form_field.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:google_fonts/google_fonts.dart';

import 'add_dialog.dart';

class CertificateField extends StatelessWidget {
  final CertificateProvider provider;
  final int index;

  const CertificateField({
    Key key,
    @required this.provider,
    @required this.index,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    provider.checkWhetherFieldsFilled(index: index);
    return Column(
      children: [
        Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          // mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            SvgPicture.asset('assets/profile/certificate_small.svg'),
            const SizedBox(
              width: 10,
            ),
            Flexible(
              child: DottedBorder(
                dashPattern: const [8, 8, 8, 8],
                color: provider.imageBorderColor(index),
                child: Container(
                  alignment: Alignment.center,
                  height: 221,
                  decoration: const BoxDecoration(color: Color(0xffF9F9F9)),
                  padding: const EdgeInsets.all(20),
                  child:
                      CertificateImageHolder(index: index, provider: provider),
                ),
              ),
            ),
            const SizedBox(
              width: 10,
            ),
            Visibility(
              visible: provider.isOnline(index),
              child: GestureDetector(
                onTap: () => provider.removeAndAddToDelete(index),
                child: SvgPicture.asset(
                  'assets/profile/bin.svg',
                ),
              ),
            ),
          ],
        ),
        const SizedBox(
          height: 38,
        ),
        Row(
          children: [
            const SizedBox(
              width: 20,
            ),
            Text(
              'Name of the certificate ',
              style: TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                  color: Palette.c686868,
                  fontFamily: GoogleFonts.poppins().fontFamily),
            ),
          ],
        ),
        const SizedBox(
          height: 10,
        ),
        ValidationTextField(
          // key: ValueKey(provider.recentlyAdededCertificates[index].id),
          validator: (input) =>
              provider.validatorForName(value: input, index: index),
          onChanged: (value) =>
              provider.onNameChanged(value: value, index: index),
          keyboardType: TextInputType.text,
          border: provider.nameTextFieldBorder,
          formKey: provider.formKey,
          hintText: 'eg. Basics of photoshop',
          initialValue: provider.recentlyAdededCertificates[index].description,
          isNotFilled: provider.isNameNotFilled,
        ),
        const SizedBox(
          height: 30,
        ),
        Row(
          children: [
            const SizedBox(
              width: 20,
            ),
            Text(
              'Issuing organization',
              style: TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                  color: Palette.c686868,
                  fontFamily: GoogleFonts.poppins().fontFamily),
            ),
          ],
        ),
        const SizedBox(
          height: 10,
        ),
        ValidationTextField(
          // key: ValueKey(provider.recentlyAdededCertificates[index].organization),
          validator: (input) =>
              provider.validatorForOrg(value: input, index: index),
          onChanged: (value) =>
              provider.onOrganisationChanged(value: value, index: index),
          keyboardType: TextInputType.text,
          border: provider.orgTextFieldBorder,
          formKey: provider.formKey,
          hintText: 'eg. Beyond Exams',
          initialValue: provider.recentlyAdededCertificates[index].organization,
          isNotFilled: provider.isOrgNotFilled,
        ),
        const SizedBox(
          height: 30,
        ),
        Row(
          children: [
            const SizedBox(
              width: 20,
            ),
            Text(
              'Issuing date',
              style: TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                  color: Palette.c686868,
                  fontFamily: GoogleFonts.poppins().fontFamily),
            ),
          ],
        ),
        const SizedBox(
          height: 10,
        ),
        Padding(
          padding: const EdgeInsets.only(left: 10),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Expanded(
                flex: 2,
                child: Container(
                  alignment: Alignment.centerLeft,
                  padding: const EdgeInsets.only(left: 10),
                  decoration: BoxDecoration(
                    color: provider.monthDropDownFillColor,
                    borderRadius: BorderRadius.circular(3),
                    border: Border.all(
                      color: provider.monthDropDownBorder,
                    ),
                  ),
                  child: DropdownButtonFormField<String>(
                      // key: ValueKey(
                      //     provider.recentlyAdededCertificates[index].id),
                      iconSize: 18,
                      decoration: InputDecoration(
                          contentPadding: fromPadding,
                          hintText: 'Month',
                          hintStyle:
                              TextStyle(color: Palette.cafadad, fontSize: 14),
                          filled: true,
                          fillColor: provider.monthDropDownFillColor,
                          border: OutlineInputBorder(
                              borderSide: BorderSide.none,
                              borderRadius: BorderRadius.circular(3))),
                      validator: (input) => provider.validatorForMonth(
                          value: input, index: index),
                      value: provider.recentlyAdededCertificates[index]
                                  ?.issuingDate
                                  ?.split('-') !=
                              null
                          ? mapIntToMonth(provider
                              .recentlyAdededCertificates[index]?.issuingDate
                              ?.split('-')[1])
                          : null,
                      isExpanded: true,
                      hint: Text(
                        'Month',
                        style: TextStyle(fontSize: 14, color: Palette.cafadad),
                      ),
                      items: months
                          .map((e) => DropdownMenuItem<String>(
                                value: e,
                                child: Text(
                                  e,
                                  overflow: TextOverflow.clip,
                                ),
                              ))
                          .toList(),
                      onChanged: (value) =>
                          provider.onMonthChanged(value: value, index: index)),
                ),
              ),
              const SizedBox(width: 10),
              Flexible(
                child: ValidationTextField(
                  // key: ValueKey(provider.recentlyAdededCertificates[index].day),
                  validator: (input) =>
                      provider.validatorForDay(value: input, index: index),
                  onChanged: (value) =>
                      provider.onDayChanged(value: value, index: index),
                  keyboardType: TextInputType.number,
                  border: provider.dayTextFieldBorder,
                  formKey: provider.formKey,
                  hintText: 'Day',
                  initialValue: provider
                      .recentlyAdededCertificates[index]?.issuingDate
                      ?.split('-')
                      ?.first,
                  isNotFilled: provider.isDayNotFilled,
                ),
              ),
              const SizedBox(width: 10),
              Flexible(
                child: ValidationTextField(
                  // key: ValueKey(provider.recentlyAdededCertificates[index].year),
                  validator: (input) =>
                      provider.validatorForYear(value: input, index: index),
                  onChanged: (value) =>
                      provider.onYearChanged(value: value, index: index),
                  keyboardType: TextInputType.number,
                  border: provider.yearTextFieldBorder,
                  formKey: provider.formKey,
                  hintText: 'Year',
                  initialValue: provider
                      .recentlyAdededCertificates[index]?.issuingDate
                      ?.split('-')
                      ?.last,
                  isNotFilled: provider.isYearNotFilled,
                ),
              ),
            ],
          ),
        ),
        const SizedBox(
          height: 34,
        ),
      ],
    );
  }
}
