import 'package:flutter/material.dart';
import 'package:flutter_app/application/profile/profile_bloc.dart';
import 'package:flutter_app/core/utils/convert_date.dart';
import 'package:flutter_app/presentation/core/palette.dart';
import 'package:flutter_app/presentation/profile/widgets/dialogs/about_dialog.dart';
import 'package:flutter_app/presentation/profile/widgets/section_holder.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_svg/flutter_svg.dart';

class About extends StatefulWidget {
  const About({
    Key key,
    this.state,
  }) : super(key: key);

  final ProfileState state;

  @override
  _AboutState createState() => _AboutState();
}

class _AboutState extends State<About> {
  void _addEvent(ProfileEvent event) {
    return BlocProvider.of<ProfileBloc>(context).add(event);
  }

  @override
  Widget build(BuildContext context) {
    return SectionHolder(
        title: 'About',
        icon: 'about',
        onEditPressed: AboutSectionDialog(),
        child: BlocBuilder<ProfileBloc, ProfileState>(
          builder: (context, state) {
            return Column(
              children: [
                _Child(
                  asset: 'dob',
                  title: 'Date Of Birth',
                  isEmpty: state.profile.dob == null,
                  value: state.profile.dob != null
                      ? rawStringToDate(state.profile.dob)
                      : 'dd/mm/yy',
                ),
                _Child(
                  asset: 'phone',
                  title: 'Contact no.',
                  isEmpty: state.profile.phone == null ||
                      state.profile.phone.isEmpty,
                  value: state.profile.phone ?? 'xxxxxxxxxx',
                ),
                _Child(
                  asset: 'location',
                  title: 'Location',
                  isEmpty: state.profile.countryId == null,
                  value: state.profile.countryId != null
                      ? state.countries
                              .firstWhere(
                                  (e) => e.id == state.profile.countryId)
                              .name ??
                          'xyz'
                      : 'xyz',
                ),
              ],
            );
          },
        ));
  }
}

class _Child extends StatelessWidget {
  final String title;
  final String value;
  final String asset;
  final bool isEmpty;

  const _Child({Key key, this.title, this.asset, this.value, this.isEmpty})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 9, left: 6, right: 6),
      child: Row(
        children: [
          Expanded(
            child: Row(
              children: [
                SvgPicture.asset('assets/profile/$asset.svg'),
                const SizedBox(
                  width: 11,
                ),
                Text(
                  title,
                  style: TextStyle(
                    color: Palette.c1d1d1d,
                    fontSize: 14,
                    fontWeight: FontWeight.w400,
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: Text(
              value,
              style: TextStyle(
                color: isEmpty ? Palette.cc4c4c4 : Palette.c1d1d1d,
                fontSize: 14,
                fontWeight: FontWeight.w400,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class AboutBackground extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return SectionHolder(
        title: 'About',
        icon: 'about',
        onEditPressed: AboutSectionDialog(),
        child: Column(
          children: const [
            _Child(
              asset: 'dob',
              title: 'Date Of Birth',
              isEmpty: true,
              value: 'dd/mm/yy',
            ),
            _Child(
              asset: 'phone',
              title: 'Contact no.',
              isEmpty: true,
              value: 'xxxxxxxxxx',
            ),
            _Child(
              asset: 'location',
              title: 'Location',
              isEmpty: true,
              value: 'xyz',
            ),
          ],
        ));
  }
}
