import 'dart:io';
import 'dart:math';
import 'dart:ui';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:dotted_border/dotted_border.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter_app/application/profile/profile_bloc.dart';
import 'package:flutter_app/presentation/core/palette.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_svg/svg.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:image_cropper/image_cropper.dart';

import 'image_viewer.dart';

// ignore: must_be_immutable
class Avatar extends StatefulWidget {
  final ProfileState state;

  const Avatar({Key key, this.state}) : super(key: key);

  @override
  _AvatarState createState() => _AvatarState();
}

class _AvatarState extends State<Avatar> {
  File selectedImage;

  @override
  Widget build(BuildContext context) {
    // ignore: avoid_void_async
    void _pickImage(Function setMState) async => await FilePicker.platform
            .pickFiles(
          type: FileType.image,
          allowCompression: true,
        )
            .then((result) async {
          if (result != null) {
            final path = result.files.single.path;
            await ImageCropper.cropImage(
                sourcePath: path,
                aspectRatioPresets: [
                  CropAspectRatioPreset.square,
                  CropAspectRatioPreset.ratio3x2,
                  CropAspectRatioPreset.original,
                  CropAspectRatioPreset.ratio4x3,
                  CropAspectRatioPreset.ratio16x9
                ],
                androidUiSettings: AndroidUiSettings(
                    initAspectRatio: CropAspectRatioPreset.original,
                    toolbarColor: Palette.white,
                    statusBarColor: Colors.black,
                    lockAspectRatio: false,
                    hideBottomControls: true,
                    toolbarTitle: 'Crop Image',
                    activeControlsWidgetColor: Palette.onBlue),
                iosUiSettings: const IOSUiSettings(
                  minimumAspectRatio: 1.0,
                )).then((value) {
              if (value != null) {
                selectedImage = value;
                setMState(() {});
              }
            });
          } else {}
        });

    Widget _actionButtons(Function setMState) {
      if (selectedImage == null) {
        return RaisedButton(
          elevation: 0,
          color: Palette.onBlue,
          onPressed: () => _pickImage(setMState),
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          child: SizedBox(
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                SvgPicture.asset(
                  'assets/profile/upload.svg',
                  color: Palette.white,
                  height: 17,
                  width: 17,
                ),
                const SizedBox(
                  width: 10,
                ),
                Text(
                  'Upload',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                      color: Palette.white,
                      fontSize: 18,
                      fontWeight: FontWeight.w600),
                ),
              ],
            ),
            height: 50,
            width: 130,
          ),
        );
      } else {
        return Row(
          children: [
            Expanded(
              child: RaisedButton(
                elevation: 0,
                color: Palette.white,
                onPressed: () => _pickImage(setMState),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16)),
                child: SizedBox(
                  height: 50,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      SvgPicture.asset(
                        'assets/repeat.svg',
                      ),
                      const SizedBox(
                        width: 10,
                      ),
                      Text(
                        'Change',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                            color: Palette.onBlue,
                            fontSize: 18,
                            fontWeight: FontWeight.w600),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            const SizedBox(
              width: 38,
            ),
            Expanded(
              child: RaisedButton(
                elevation: 0,
                color: Palette.onBlue,
                onPressed: () {
                  BlocProvider.of<ProfileBloc>(context)
                      .add(ProfileEvent.updateAvatar(selectedImage.path));
                  Navigator.pop(context);
                },
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16)),
                child: SizedBox(
                  height: 50,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      SvgPicture.asset(
                        'assets/download.svg',
                      ),
                      const SizedBox(
                        width: 10,
                      ),
                      Text(
                        'Save',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                            color: Palette.white,
                            fontSize: 18,
                            fontWeight: FontWeight.w600),
                      ),
                    ],
                  ),
                ),
              ),
            )
          ],
        );
      }
    }

    return GestureDetector(
      onTap: () => Navigator.push(
          context,
          MaterialPageRoute(
              builder: (_) => ImageViewer(
                    url: widget.state.profile.avatar,
                  ))),
      child: Stack(
        alignment: Alignment.center,
        children: [
          Container(
            // alignment: Alignment.center,
            height: 81,
            width: 81,

            decoration: const BoxDecoration(
              shape: BoxShape.circle,
              color: Color(0xffC0AEFF),
            ),
          ),
          Container(
              // alignment: Alignment.center,
              height: 70,
              width: 70,
              padding: const EdgeInsets.all(7),
              decoration:
                  BoxDecoration(shape: BoxShape.circle, color: Palette.onBlue),
              child: ClipOval(
                child: CachedNetworkImage(
                  imageUrl: widget.state.profile.avatar,
                  fit: BoxFit.cover,
                  errorWidget: (context, url, error) => const Text('Error'),
                ),
              )),
          SizedBox(
            height: 77,
            width: 77,
            child: Transform.rotate(
              angle: pi * 1,
              child: const CircularProgressIndicator(
                value: 0.25,
                valueColor: AlwaysStoppedAnimation<Color>(Color(0xffFEBE16)),
              ),
            ),
          ),
          Positioned(
            bottom: 5,
            right: 2,
            child: GestureDetector(
              onTap: () async {
                await showDialog(
                  barrierDismissible: false,
                  context: context,
                  builder: (_) {
                    return WillPopScope(
                      onWillPop: () async {
                        selectedImage = null;
                        return true;
                      },
                      child: BackdropFilter(
                        filter: ImageFilter.blur(sigmaX: 5, sigmaY: 5),
                        child: Dialog(
                            elevation: 100,
                            insetPadding:
                                const EdgeInsets.symmetric(horizontal: 20),
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(15)),
                            backgroundColor: Palette.onBackground,
                            child: StatefulBuilder(
                              builder: (context, setMState) {
                                return Container(
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 24),
                                    child: Column(
                                      mainAxisSize: MainAxisSize.min,
                                      children: [
                                        const SizedBox(
                                          height: 21,
                                        ),
                                        GestureDetector(
                                          onTap: () {
                                            selectedImage = null;
                                            Navigator.pop(context);
                                          },
                                          child: const Align(
                                            alignment: Alignment.centerRight,
                                            child: Icon(
                                              FontAwesomeIcons.times,
                                              size: 17,
                                              color: Color(0xff1d1d1d),
                                            ),
                                          ),
                                        ),
                                        const SizedBox(
                                          height: 16,
                                        ),
                                        GestureDetector(
                                          onTap: () {
                                            if (selectedImage == null) {
                                            } else {}
                                          },
                                          child: DottedBorder(
                                            dashPattern: [8, 8, 8, 8],
                                            color: Palette.onBlue,
                                            child: Container(
                                              alignment: Alignment.center,
                                              height: 250,
                                              width: 330,
                                              decoration: BoxDecoration(
                                                  color: Palette.white),
                                              padding: const EdgeInsets.all(20),
                                              child: _image(),
                                            ),
                                          ),
                                        ),
                                        const SizedBox(
                                          height: 24,
                                        ),
                                        _text(),
                                        const SizedBox(
                                          height: 40,
                                        ),
                                        _actionButtons(setMState),
                                        const SizedBox(
                                          height: 40,
                                        ),
                                      ],
                                    ));
                              },
                            )),
                      ),
                    );
                  },
                );
              },
              child: Container(
                height: 21,
                width: 21,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                    shape: BoxShape.circle, color: Palette.onBackground),
                child: SvgPicture.asset(
                  'assets/profile/camera.svg',
                  height: 10,
                  width: 10,
                ),
              ),
            ),
          )
        ],
      ),
    );
  }

  Widget _image() {
    if (selectedImage == null) {
      return SvgPicture.asset('assets/dummy_image.svg');
    } else {
      return Image.file(selectedImage);
    }
  }

  Text _text() {
    if (selectedImage == null) {
      return const Text(
        'Upload a nice photo of yourself!',
        textAlign: TextAlign.center,
        style: TextStyle(color: Color(0xff1D1D1D), fontSize: 18),
      );
    } else {
      return const Text(
        'Looks great !',
        textAlign: TextAlign.center,
        style: TextStyle(color: Color(0xff1D1D1D), fontSize: 18),
      );
    }
  }
}
