import 'package:dartz/dartz.dart';
import 'package:flutter/material.dart' hide PopupMenuButton, PopupMenuItem;
import 'package:flutter_app/presentation/core/palette.dart';
import 'package:flutter_app/presentation/core/widgets/custom_popup.dart';

class CustomPopUpButton extends StatelessWidget {
  final Widget child;
  final List<Tuple2<Widget, dynamic>> itemBuilder;
  final void Function(dynamic) onChanged;
  final dynamic value;
  final bool showSelectedItem;
  CustomPopUpButton(
      {Key key,
      @required this.value,
      @required this.child,
      @required this.itemBuilder,
      @required this.onChanged,
      this.showSelectedItem = true})
      : assert(itemBuilder
            .any((tuple) => tuple.value2.runtimeType == value.runtimeType)),
        super(key: key);

  @override
  Widget build(BuildContext context) {
    return Theme(
      data: Theme.of(context).copyWith(
          cardColor: Colors.white,
          highlightColor: Palette.white,
          splashColor: Palette.white),
      child: PopupMenuButton(
          color: Palette.white,
          initialValue: value,
          elevation: 25,
          captureInheritedThemes: true,
          onSelected: onChanged,
          padding: const EdgeInsets.all(0),
          itemBuilder: (_) => itemBuilder
              .map((tuple) => PopupMenuItem(
                    value: tuple.value2,
                    // enabled: false,
                    child: Container(
                      padding: const EdgeInsets.only(
                          left: 40, top: 12, bottom: 12, right: 40),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(12),
                        color: value == tuple.value2
                            ? Palette.onBackground
                            : Palette.white,
                      ),
                      child: tuple.value1,
                    ),
                  ))
              .toList(),
          offset: const Offset(20, 0),
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          child: child),
    );
  }
}

/*


PopupMenuItem(
          // enabled: true,
          // height: 40,
          child: Container(
            // width: 160,
            padding: const EdgeInsets.only(left: 20, top: 12, bottom: 12),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              // mainAxisAlignment: MainAxisAlignment.end,
              children: [
                SvgPicture.asset(
                  'assets/courses/report.svg',
                  color: Color(
                    0xff1c1c1c,
                  ),
                ),
                const SizedBox(
                  width: 10,
                ),
                Text(
                  "Report",
                  style: TextStyle(
                    color: Color(
                      0xff1c1c1c,
                    ),
                    fontSize: 16,
                    fontWeight: FontWeight.w400,
                    // fontFamily: "Poppins",
                  ),
                )
              ],
            ),
          ),
        ),



        */
