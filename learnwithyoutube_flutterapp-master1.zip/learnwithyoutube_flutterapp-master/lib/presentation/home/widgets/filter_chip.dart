import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class FilterLabelChip extends StatelessWidget {
  final VoidCallback onTap;
  final String title;
  final Color color;

  const FilterLabelChip(
      {Key key,
      @required this.onTap,
      @required this.title,
      @required this.color})
      : super(key: key);
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Chip(
        elevation: 0.0,
        padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 2),
        backgroundColor: color,
        label: Text(title,
            style: TextStyle(
                color: const Color(0xff1D1D1D),
                fontFamily: GoogleFonts.poppins().fontFamily)),
      ),
    );
  }
}
