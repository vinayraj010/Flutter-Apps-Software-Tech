import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_app/presentation/core/palette.dart';
import 'package:flutter_app/presentation/home/widgets/emoji_picker.dart';
import 'package:google_fonts/google_fonts.dart';

class ChatInfoColumn extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Column(
        children: [
          const SizedBox(height: 24),
          Stack(
            children: [
              Container(
                width: MediaQuery.of(context).size.width,
                margin: const EdgeInsets.only(top: 54, left: 18, right: 18),
                padding:
                    const EdgeInsets.symmetric(horizontal: 33, vertical: 25),
                decoration: BoxDecoration(
                    color: Palette.white,
                    borderRadius: const BorderRadius.only(
                      bottomLeft: Radius.circular(18),
                      bottomRight: Radius.circular(18),
                    )),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Mon - Fri  (14:00 -16:00)',
                        style: TextStyle(
                            fontSize: 16,
                            fontFamily: GoogleFonts.poppins().fontFamily))
                  ],
                ),
              ),
              Container(
                  height: 54,
                  margin: const EdgeInsets.symmetric(horizontal: 18),
                  padding: const EdgeInsets.only(left: 33),
                  width: MediaQuery.of(context).size.width,
                  alignment: Alignment.centerLeft,
                  decoration: BoxDecoration(
                      color: Palette.onBackground,
                      boxShadow: [
                        const BoxShadow(
                            color: Color.fromRGBO(102, 70, 231, 0.27),
                            offset: Offset(0, 9),
                            blurRadius: 40,
                            spreadRadius: 1)
                      ],
                      borderRadius: const BorderRadius.only(
                        topLeft: Radius.circular(18),
                        topRight: Radius.circular(18),
                      )),
                  child: Text('Class IV-VI',
                      style: TextStyle(
                          color: const Color(0xffFCB500),
                          fontSize: 18,
                          fontFamily: GoogleFonts.poppins().fontFamily,
                          fontWeight: FontWeight.w600))),
            ],
          ),
          const SizedBox(height: 24),
          Stack(
            children: [
              Container(
                width: MediaQuery.of(context).size.width,
                margin: const EdgeInsets.only(top: 54, left: 18, right: 18),
                padding:
                    const EdgeInsets.symmetric(horizontal: 33, vertical: 25),
                decoration: BoxDecoration(
                    color: Palette.white,
                    borderRadius: const BorderRadius.only(
                      bottomLeft: Radius.circular(18),
                      bottomRight: Radius.circular(18),
                    )),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                        'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum ',
                        style: TextStyle(
                            fontSize: 16,
                            fontFamily: GoogleFonts.poppins().fontFamily))
                  ],
                ),
              ),
              Container(
                  height: 54,
                  margin: const EdgeInsets.symmetric(horizontal: 18),
                  padding: const EdgeInsets.only(left: 33),
                  width: MediaQuery.of(context).size.width,
                  alignment: Alignment.centerLeft,
                  decoration: BoxDecoration(
                      color: Palette.onBackground,
                      boxShadow: [
                        const BoxShadow(
                            color: Color.fromRGBO(102, 70, 231, 0.27),
                            offset: Offset(0, 9),
                            blurRadius: 40,
                            spreadRadius: 1)
                      ],
                      borderRadius: const BorderRadius.only(
                        topLeft: Radius.circular(18),
                        topRight: Radius.circular(18),
                      )),
                  child: Text('Lorem Ipsum',
                      style: TextStyle(
                          color: const Color(0xff77AF44),
                          fontSize: 18,
                          fontFamily: GoogleFonts.poppins().fontFamily,
                          fontWeight: FontWeight.w600))),
            ],
          ),
          const SizedBox(height: 24),
          Stack(
            children: [
              Container(
                width: MediaQuery.of(context).size.width,
                margin: const EdgeInsets.only(top: 54, left: 18, right: 18),
                padding:
                    const EdgeInsets.symmetric(horizontal: 33, vertical: 25),
                decoration: BoxDecoration(
                    color: Palette.white,
                    borderRadius: const BorderRadius.only(
                      bottomLeft: Radius.circular(18),
                      bottomRight: Radius.circular(18),
                    )),
                child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: List.generate(
                        17,
                        (index) => ListTile(
                              leading: SizedBox(
                                height: 34,
                                width: 34,
                                child: ClipOval(
                                  child: CachedNetworkImage(
                                      imageUrl:
                                          'https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixid=MXwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHw%3D&ixlib=rb-1.2.1&auto=format&fit=crop&w=634&q=80',
                                      fit: BoxFit.cover),
                                ),
                              ),
                              title: Text('Miss. Shubadra Achariya',
                                  style: TextStyle(
                                      fontSize: 16,
                                      fontFamily:
                                          GoogleFonts.poppins().fontFamily)),
                            ))),
              ),
              Container(
                  height: 54,
                  margin: const EdgeInsets.symmetric(horizontal: 18),
                  padding: const EdgeInsets.only(left: 33),
                  width: MediaQuery.of(context).size.width,
                  alignment: Alignment.centerLeft,
                  decoration: BoxDecoration(
                      color: Palette.onBackground,
                      boxShadow: [
                        const BoxShadow(
                            color: Color.fromRGBO(102, 70, 231, 0.27),
                            offset: Offset(0, 9),
                            blurRadius: 40,
                            spreadRadius: 1)
                      ],
                      borderRadius: const BorderRadius.only(
                        topLeft: Radius.circular(18),
                        topRight: Radius.circular(18),
                      )),
                  child: Text('Chat participants (17)',
                      style: TextStyle(
                          color: const Color(0xff6646E7),
                          fontSize: 18,
                          fontFamily: GoogleFonts.poppins().fontFamily,
                          fontWeight: FontWeight.w600))),
            ],
          ),
          const SizedBox(height: 24),
        ],
      ),
    );
  }
}
