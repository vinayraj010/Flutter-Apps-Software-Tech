import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_app/application/profile/profile_bloc.dart';
import 'package:flutter_app/application/providers/profile_provider.dart';
import 'package:flutter_app/core/routes/route.gr.dart' as route;
import 'package:flutter_app/core/utils/clean_string.dart';
import 'package:flutter_app/domain/profile/profile.dart';
import 'package:flutter_app/presentation/core/palette.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:injectable/injectable.dart';
import 'package:provider/provider.dart';

final BuildContext context = route.Router.navigator.key.currentContext;

@lazySingleton
class EducationProvider extends ChangeNotifier {
  EducationStandard _education;

  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  bool _showErrors = false;
  bool _isClassNotFilled = false;
  bool _isSchoolNotFilled = false;
  InputBorder _classTextFieldBorder;
  InputBorder _schoolTextFieldBorder;

  static List<EducationStandard> _recentlyAdededEducations =
      <EducationStandard>[
    EducationStandard(
        instituteName: Domain(), standardName: Domain(), isFirst: true),
    EducationStandard(
      instituteName: Domain(),
      standardName: Domain(),
    ),
  ];
  static final List<EducationStandard> _deletedEducations =
      <EducationStandard>[];

  EducationStandard get education => _education;
  GlobalKey<FormState> get formKey => _formKey;
  bool get showErrors => _showErrors;
  bool get isClassNotFilled => _isClassNotFilled;
  bool get isSchoolNotFilled => _isSchoolNotFilled;
  InputBorder get schoolTextFieldBorder => _schoolTextFieldBorder;
  InputBorder get classTextFieldBorder => _classTextFieldBorder;
  List<EducationStandard> get recentlyAdededEducations =>
      _recentlyAdededEducations;

  bool checkWhetherAllFieldsAllFilled() {
    return _recentlyAdededEducations
        .where((element) =>
            cleanString(element.instituteName.name).isEmpty ||
            cleanString(element.standardName.name).isEmpty)
        .toList()
        .isNotEmpty;
  }

  MaterialStateProperty<BorderSide> addFieldBorder() {
    return MaterialStateProperty.all(BorderSide(
        color: checkWhetherAllFieldsAllFilled()
            ? Palette.cc4c4c4
            : Palette.onBlue));
  }

  void addAllPreviousEducationsToList() {
    final List<EducationStandard> _allList =
        BlocProvider.of<ProfileBloc>(context).state.profile.educationStandard;
    _recentlyAdededEducations.addAll(_allList);
    // notifyListeners();
  }

  //Call this Before Field
  void checkWhetherFieldsFilled({@required int index}) {
    _isClassNotFilled =
        _recentlyAdededEducations[index]?.instituteName?.name == null ||
            cleanString(_recentlyAdededEducations[index].instituteName.name)
                .isEmpty;

    _classTextFieldBorder = OutlineInputBorder(
        borderSide: BorderSide(
            color: _isClassNotFilled ? Palette.c686868 : Palette.onBlue),
        borderRadius: BorderRadius.circular(3));

    _isSchoolNotFilled = _recentlyAdededEducations[index]?.standardName?.name ==
            null ||
        cleanString(_recentlyAdededEducations[index].standardName.name).isEmpty;

    _schoolTextFieldBorder = OutlineInputBorder(
        borderSide: BorderSide(
            color: _isSchoolNotFilled ? Palette.c686868 : Palette.onBlue),
        borderRadius: BorderRadius.circular(3));

    // notifyListeners();
  }

  void onClassChanged({
    @required String value,
    @required int index,
  }) {
    try {
      final EducationStandard _educationWithSchoolName =
          _recentlyAdededEducations.elementAt(index);
      _educationWithSchoolName.instituteName.name = cleanString(value);

      _recentlyAdededEducations.removeAt(index);

      _recentlyAdededEducations.insert(index, _educationWithSchoolName);
    } catch (e) {
      _education.instituteName.name = cleanString(value);
      _recentlyAdededEducations.add(_education);
    }

    notifyListeners();
  }

  void onSchoolChanged({
    @required String value,
    @required int index,
  }) {
    try {
      final EducationStandard _educationWithClassName =
          _recentlyAdededEducations.elementAt(index);
      _educationWithClassName.standardName.name = cleanString(value);

      _recentlyAdededEducations.removeAt(index);

      _recentlyAdededEducations.insert(index, _educationWithClassName);
    } catch (e) {
      _education.standardName.name = cleanString(value);
      _recentlyAdededEducations.add(_education);
    }

    notifyListeners();
  }

  String validatorForClass({
    @required String value,
    @required int index,
  }) {
    if (cleanString(_recentlyAdededEducations[index].standardName?.name)
            .isNotEmpty &&
        cleanString(value).isEmpty) {
      return '*Required';
    } else {
      return null;
    }
  }

  String validatorForSchool({
    @required String value,
    @required int index,
  }) {
    if (cleanString(_recentlyAdededEducations[index].instituteName?.name)
            .isNotEmpty &&
        cleanString(value).isEmpty) {
      return '*Required';
    } else {
      return null;
    }
  }

  //TODO: Add new fields to top of the list
  void onAddFieldPressed() {
    if (!checkWhetherAllFieldsAllFilled()) {
      // _education = EducationStandard();
      _recentlyAdededEducations.add(EducationStandard(
        instituteName: Domain(),
        standardName: Domain(),
      ));

      notifyListeners();
    }
  }

  void showErrorsToTrue() {
    _showErrors = true;
    notifyListeners();
  }

  void _saveEducations() {
    _recentlyAdededEducations.removeWhere((element) =>
        cleanString(element.instituteName.name).isEmpty ||
        cleanString(element.standardName.name).isEmpty);
    final List<EducationStandard> _toBeAddedEducations =
        _recentlyAdededEducations.where((e) => e.id == null).toList();

    BlocProvider.of<ProfileBloc>(context)
        .add(ProfileEvent.saveEducation(_toBeAddedEducations));

    final List<EducationStandard> _toBeUpdatedEducations =
        _recentlyAdededEducations.where((e) => e?.id != null).toList();

    BlocProvider.of<ProfileBloc>(context)
        .add(ProfileEvent.updateEducation(_toBeUpdatedEducations));

    //Get Fresh Profile
    BlocProvider.of<ProfileBloc>(context)
        .add(const ProfileEvent.getUserProfile());
  }

  void onSavePressed() {
    if (_formKey.currentState.validate()) {
      Provider.of<ProfileProvider>(context, listen: false).startLoading();

      Navigator.pop(context);
      _deleteEducation();
      _saveEducations();
      resetAll();
    } else {
      _showErrors = true;
    }
    notifyListeners();
  }

  void _deleteEducation() {
    for (final EducationStandard education in _deletedEducations) {
      BlocProvider.of<ProfileBloc>(context)
          .add(ProfileEvent.deleteEducation(education));
    }
  }

  void removeAndAddToDelete(int index) {
    _deletedEducations.add(_recentlyAdededEducations.elementAt(index));
    _recentlyAdededEducations.removeAt(index);
    notifyListeners();
  }

  void resetAll() {
    BlocProvider.of<ProfileBloc>(context)
        .add(const ProfileEvent.getUserProfile());
    _recentlyAdededEducations = <EducationStandard>[
      EducationStandard(
          instituteName: Domain(), standardName: Domain(), isFirst: true),
      EducationStandard(
        instituteName: Domain(),
        standardName: Domain(),
      ),
    ];
    _deletedEducations.clear();
    _education = EducationStandard();
    _showErrors = false;
    _isClassNotFilled = false;
    _isSchoolNotFilled = false;
    notifyListeners();
  }

  bool isOnline(int index) {
    return _recentlyAdededEducations[index].id != null;
  }
}
