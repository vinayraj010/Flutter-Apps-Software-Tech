part of 'chat_bloc.dart';

@freezed
abstract class ChatState with _$ChatState {
  factory ChatState({
    Option<Either<ChatFailure, Unit>> failureOrSuccessForAttendance,
    Option<Either<ChatFailure, Unit>> failureOrSuccessForCRUDChat,
    Message allChats,
    Attendance attendance,
    StringSingleLine title,
    bool showErrorMessage,
  }) = _ChatState;

  factory ChatState.initial() => ChatState(
        failureOrSuccessForAttendance: none(),
        failureOrSuccessForCRUDChat: none(),
        showErrorMessage: false,
      );
}
