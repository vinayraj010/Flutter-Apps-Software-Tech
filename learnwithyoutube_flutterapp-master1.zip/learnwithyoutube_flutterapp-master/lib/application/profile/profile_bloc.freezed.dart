// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies

part of 'profile_bloc.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

/// @nodoc
class _$ProfileEventTearOff {
  const _$ProfileEventTearOff();

// ignore: unused_element
  _SubmitUserProfile submitUserProfile() {
    return const _SubmitUserProfile();
  }

// ignore: unused_element
  _GetUserProfile getUserProfile() {
    return const _GetUserProfile();
  }

// ignore: unused_element
  _GetCountries getCountries() {
    return const _GetCountries();
  }

// ignore: unused_element
  _AvatarUpdate updateAvatar(String avatar) {
    return _AvatarUpdate(
      avatar,
    );
  }

// ignore: unused_element
  _SaveSocialMediaHandles saveSocialMedia(
      {@required String facebookUserName,
      @required String instagramUserName,
      @required String twitterUserName,
      @required String linkedinUserName}) {
    return _SaveSocialMediaHandles(
      facebookUserName: facebookUserName,
      instagramUserName: instagramUserName,
      twitterUserName: twitterUserName,
      linkedinUserName: linkedinUserName,
    );
  }

// ignore: unused_element
  _SaveAbout saveAbout(
      {@required String month,
      @required String day,
      @required String year,
      @required String country,
      @required String state,
      @required String phoneNumber}) {
    return _SaveAbout(
      month: month,
      day: day,
      year: year,
      country: country,
      state: state,
      phoneNumber: phoneNumber,
    );
  }

// ignore: unused_element
  _SaveSkills saveSkills(List<Domain> domains) {
    return _SaveSkills(
      domains,
    );
  }

// ignore: unused_element
  _UpdateSkill updateSkills(Domain domain) {
    return _UpdateSkill(
      domain,
    );
  }

// ignore: unused_element
  _SaveEducations saveEducation(List<EducationStandard> educations) {
    return _SaveEducations(
      educations,
    );
  }

// ignore: unused_element
  _UpdateEducations updateEducation(List<EducationStandard> educations) {
    return _UpdateEducations(
      educations,
    );
  }

// ignore: unused_element
  _SaveCertificates saveCertificates(Certificate certificates) {
    return _SaveCertificates(
      certificates,
    );
  }

// ignore: unused_element
  _UpdateCertificates updateCertificates(Certificate certificates) {
    return _UpdateCertificates(
      certificates,
    );
  }

// ignore: unused_element
  _DeleteCertificate deleteCertificate(Certificate certificate) {
    return _DeleteCertificate(
      certificate,
    );
  }

// ignore: unused_element
  _DeleteEducation deleteEducation(EducationStandard education) {
    return _DeleteEducation(
      education,
    );
  }

// ignore: unused_element
  _DeleteDomain deleteSkill(Domain domain) {
    return _DeleteDomain(
      domain,
    );
  }
}

/// @nodoc
// ignore: unused_element
const $ProfileEvent = _$ProfileEventTearOff();

/// @nodoc
mixin _$ProfileEvent {
  @optionalTypeArgs
  Result when<Result extends Object>({
    @required Result submitUserProfile(),
    @required Result getUserProfile(),
    @required Result getCountries(),
    @required Result updateAvatar(String avatar),
    @required
        Result saveSocialMedia(
            String facebookUserName,
            String instagramUserName,
            String twitterUserName,
            String linkedinUserName),
    @required
        Result saveAbout(String month, String day, String year, String country,
            String state, String phoneNumber),
    @required Result saveSkills(List<Domain> domains),
    @required Result updateSkills(Domain domain),
    @required Result saveEducation(List<EducationStandard> educations),
    @required Result updateEducation(List<EducationStandard> educations),
    @required Result saveCertificates(Certificate certificates),
    @required Result updateCertificates(Certificate certificates),
    @required Result deleteCertificate(Certificate certificate),
    @required Result deleteEducation(EducationStandard education),
    @required Result deleteSkill(Domain domain),
  });
  @optionalTypeArgs
  Result maybeWhen<Result extends Object>({
    Result submitUserProfile(),
    Result getUserProfile(),
    Result getCountries(),
    Result updateAvatar(String avatar),
    Result saveSocialMedia(String facebookUserName, String instagramUserName,
        String twitterUserName, String linkedinUserName),
    Result saveAbout(String month, String day, String year, String country,
        String state, String phoneNumber),
    Result saveSkills(List<Domain> domains),
    Result updateSkills(Domain domain),
    Result saveEducation(List<EducationStandard> educations),
    Result updateEducation(List<EducationStandard> educations),
    Result saveCertificates(Certificate certificates),
    Result updateCertificates(Certificate certificates),
    Result deleteCertificate(Certificate certificate),
    Result deleteEducation(EducationStandard education),
    Result deleteSkill(Domain domain),
    @required Result orElse(),
  });
  @optionalTypeArgs
  Result map<Result extends Object>({
    @required Result submitUserProfile(_SubmitUserProfile value),
    @required Result getUserProfile(_GetUserProfile value),
    @required Result getCountries(_GetCountries value),
    @required Result updateAvatar(_AvatarUpdate value),
    @required Result saveSocialMedia(_SaveSocialMediaHandles value),
    @required Result saveAbout(_SaveAbout value),
    @required Result saveSkills(_SaveSkills value),
    @required Result updateSkills(_UpdateSkill value),
    @required Result saveEducation(_SaveEducations value),
    @required Result updateEducation(_UpdateEducations value),
    @required Result saveCertificates(_SaveCertificates value),
    @required Result updateCertificates(_UpdateCertificates value),
    @required Result deleteCertificate(_DeleteCertificate value),
    @required Result deleteEducation(_DeleteEducation value),
    @required Result deleteSkill(_DeleteDomain value),
  });
  @optionalTypeArgs
  Result maybeMap<Result extends Object>({
    Result submitUserProfile(_SubmitUserProfile value),
    Result getUserProfile(_GetUserProfile value),
    Result getCountries(_GetCountries value),
    Result updateAvatar(_AvatarUpdate value),
    Result saveSocialMedia(_SaveSocialMediaHandles value),
    Result saveAbout(_SaveAbout value),
    Result saveSkills(_SaveSkills value),
    Result updateSkills(_UpdateSkill value),
    Result saveEducation(_SaveEducations value),
    Result updateEducation(_UpdateEducations value),
    Result saveCertificates(_SaveCertificates value),
    Result updateCertificates(_UpdateCertificates value),
    Result deleteCertificate(_DeleteCertificate value),
    Result deleteEducation(_DeleteEducation value),
    Result deleteSkill(_DeleteDomain value),
    @required Result orElse(),
  });
}

/// @nodoc
abstract class $ProfileEventCopyWith<$Res> {
  factory $ProfileEventCopyWith(
          ProfileEvent value, $Res Function(ProfileEvent) then) =
      _$ProfileEventCopyWithImpl<$Res>;
}

/// @nodoc
class _$ProfileEventCopyWithImpl<$Res> implements $ProfileEventCopyWith<$Res> {
  _$ProfileEventCopyWithImpl(this._value, this._then);

  final ProfileEvent _value;
  // ignore: unused_field
  final $Res Function(ProfileEvent) _then;
}

/// @nodoc
abstract class _$SubmitUserProfileCopyWith<$Res> {
  factory _$SubmitUserProfileCopyWith(
          _SubmitUserProfile value, $Res Function(_SubmitUserProfile) then) =
      __$SubmitUserProfileCopyWithImpl<$Res>;
}

/// @nodoc
class __$SubmitUserProfileCopyWithImpl<$Res>
    extends _$ProfileEventCopyWithImpl<$Res>
    implements _$SubmitUserProfileCopyWith<$Res> {
  __$SubmitUserProfileCopyWithImpl(
      _SubmitUserProfile _value, $Res Function(_SubmitUserProfile) _then)
      : super(_value, (v) => _then(v as _SubmitUserProfile));

  @override
  _SubmitUserProfile get _value => super._value as _SubmitUserProfile;
}

/// @nodoc
class _$_SubmitUserProfile implements _SubmitUserProfile {
  const _$_SubmitUserProfile();

  @override
  String toString() {
    return 'ProfileEvent.submitUserProfile()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) || (other is _SubmitUserProfile);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  Result when<Result extends Object>({
    @required Result submitUserProfile(),
    @required Result getUserProfile(),
    @required Result getCountries(),
    @required Result updateAvatar(String avatar),
    @required
        Result saveSocialMedia(
            String facebookUserName,
            String instagramUserName,
            String twitterUserName,
            String linkedinUserName),
    @required
        Result saveAbout(String month, String day, String year, String country,
            String state, String phoneNumber),
    @required Result saveSkills(List<Domain> domains),
    @required Result updateSkills(Domain domain),
    @required Result saveEducation(List<EducationStandard> educations),
    @required Result updateEducation(List<EducationStandard> educations),
    @required Result saveCertificates(Certificate certificates),
    @required Result updateCertificates(Certificate certificates),
    @required Result deleteCertificate(Certificate certificate),
    @required Result deleteEducation(EducationStandard education),
    @required Result deleteSkill(Domain domain),
  }) {
    assert(submitUserProfile != null);
    assert(getUserProfile != null);
    assert(getCountries != null);
    assert(updateAvatar != null);
    assert(saveSocialMedia != null);
    assert(saveAbout != null);
    assert(saveSkills != null);
    assert(updateSkills != null);
    assert(saveEducation != null);
    assert(updateEducation != null);
    assert(saveCertificates != null);
    assert(updateCertificates != null);
    assert(deleteCertificate != null);
    assert(deleteEducation != null);
    assert(deleteSkill != null);
    return submitUserProfile();
  }

  @override
  @optionalTypeArgs
  Result maybeWhen<Result extends Object>({
    Result submitUserProfile(),
    Result getUserProfile(),
    Result getCountries(),
    Result updateAvatar(String avatar),
    Result saveSocialMedia(String facebookUserName, String instagramUserName,
        String twitterUserName, String linkedinUserName),
    Result saveAbout(String month, String day, String year, String country,
        String state, String phoneNumber),
    Result saveSkills(List<Domain> domains),
    Result updateSkills(Domain domain),
    Result saveEducation(List<EducationStandard> educations),
    Result updateEducation(List<EducationStandard> educations),
    Result saveCertificates(Certificate certificates),
    Result updateCertificates(Certificate certificates),
    Result deleteCertificate(Certificate certificate),
    Result deleteEducation(EducationStandard education),
    Result deleteSkill(Domain domain),
    @required Result orElse(),
  }) {
    assert(orElse != null);
    if (submitUserProfile != null) {
      return submitUserProfile();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  Result map<Result extends Object>({
    @required Result submitUserProfile(_SubmitUserProfile value),
    @required Result getUserProfile(_GetUserProfile value),
    @required Result getCountries(_GetCountries value),
    @required Result updateAvatar(_AvatarUpdate value),
    @required Result saveSocialMedia(_SaveSocialMediaHandles value),
    @required Result saveAbout(_SaveAbout value),
    @required Result saveSkills(_SaveSkills value),
    @required Result updateSkills(_UpdateSkill value),
    @required Result saveEducation(_SaveEducations value),
    @required Result updateEducation(_UpdateEducations value),
    @required Result saveCertificates(_SaveCertificates value),
    @required Result updateCertificates(_UpdateCertificates value),
    @required Result deleteCertificate(_DeleteCertificate value),
    @required Result deleteEducation(_DeleteEducation value),
    @required Result deleteSkill(_DeleteDomain value),
  }) {
    assert(submitUserProfile != null);
    assert(getUserProfile != null);
    assert(getCountries != null);
    assert(updateAvatar != null);
    assert(saveSocialMedia != null);
    assert(saveAbout != null);
    assert(saveSkills != null);
    assert(updateSkills != null);
    assert(saveEducation != null);
    assert(updateEducation != null);
    assert(saveCertificates != null);
    assert(updateCertificates != null);
    assert(deleteCertificate != null);
    assert(deleteEducation != null);
    assert(deleteSkill != null);
    return submitUserProfile(this);
  }

  @override
  @optionalTypeArgs
  Result maybeMap<Result extends Object>({
    Result submitUserProfile(_SubmitUserProfile value),
    Result getUserProfile(_GetUserProfile value),
    Result getCountries(_GetCountries value),
    Result updateAvatar(_AvatarUpdate value),
    Result saveSocialMedia(_SaveSocialMediaHandles value),
    Result saveAbout(_SaveAbout value),
    Result saveSkills(_SaveSkills value),
    Result updateSkills(_UpdateSkill value),
    Result saveEducation(_SaveEducations value),
    Result updateEducation(_UpdateEducations value),
    Result saveCertificates(_SaveCertificates value),
    Result updateCertificates(_UpdateCertificates value),
    Result deleteCertificate(_DeleteCertificate value),
    Result deleteEducation(_DeleteEducation value),
    Result deleteSkill(_DeleteDomain value),
    @required Result orElse(),
  }) {
    assert(orElse != null);
    if (submitUserProfile != null) {
      return submitUserProfile(this);
    }
    return orElse();
  }
}

abstract class _SubmitUserProfile implements ProfileEvent {
  const factory _SubmitUserProfile() = _$_SubmitUserProfile;
}

/// @nodoc
abstract class _$GetUserProfileCopyWith<$Res> {
  factory _$GetUserProfileCopyWith(
          _GetUserProfile value, $Res Function(_GetUserProfile) then) =
      __$GetUserProfileCopyWithImpl<$Res>;
}

/// @nodoc
class __$GetUserProfileCopyWithImpl<$Res>
    extends _$ProfileEventCopyWithImpl<$Res>
    implements _$GetUserProfileCopyWith<$Res> {
  __$GetUserProfileCopyWithImpl(
      _GetUserProfile _value, $Res Function(_GetUserProfile) _then)
      : super(_value, (v) => _then(v as _GetUserProfile));

  @override
  _GetUserProfile get _value => super._value as _GetUserProfile;
}

/// @nodoc
class _$_GetUserProfile implements _GetUserProfile {
  const _$_GetUserProfile();

  @override
  String toString() {
    return 'ProfileEvent.getUserProfile()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) || (other is _GetUserProfile);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  Result when<Result extends Object>({
    @required Result submitUserProfile(),
    @required Result getUserProfile(),
    @required Result getCountries(),
    @required Result updateAvatar(String avatar),
    @required
        Result saveSocialMedia(
            String facebookUserName,
            String instagramUserName,
            String twitterUserName,
            String linkedinUserName),
    @required
        Result saveAbout(String month, String day, String year, String country,
            String state, String phoneNumber),
    @required Result saveSkills(List<Domain> domains),
    @required Result updateSkills(Domain domain),
    @required Result saveEducation(List<EducationStandard> educations),
    @required Result updateEducation(List<EducationStandard> educations),
    @required Result saveCertificates(Certificate certificates),
    @required Result updateCertificates(Certificate certificates),
    @required Result deleteCertificate(Certificate certificate),
    @required Result deleteEducation(EducationStandard education),
    @required Result deleteSkill(Domain domain),
  }) {
    assert(submitUserProfile != null);
    assert(getUserProfile != null);
    assert(getCountries != null);
    assert(updateAvatar != null);
    assert(saveSocialMedia != null);
    assert(saveAbout != null);
    assert(saveSkills != null);
    assert(updateSkills != null);
    assert(saveEducation != null);
    assert(updateEducation != null);
    assert(saveCertificates != null);
    assert(updateCertificates != null);
    assert(deleteCertificate != null);
    assert(deleteEducation != null);
    assert(deleteSkill != null);
    return getUserProfile();
  }

  @override
  @optionalTypeArgs
  Result maybeWhen<Result extends Object>({
    Result submitUserProfile(),
    Result getUserProfile(),
    Result getCountries(),
    Result updateAvatar(String avatar),
    Result saveSocialMedia(String facebookUserName, String instagramUserName,
        String twitterUserName, String linkedinUserName),
    Result saveAbout(String month, String day, String year, String country,
        String state, String phoneNumber),
    Result saveSkills(List<Domain> domains),
    Result updateSkills(Domain domain),
    Result saveEducation(List<EducationStandard> educations),
    Result updateEducation(List<EducationStandard> educations),
    Result saveCertificates(Certificate certificates),
    Result updateCertificates(Certificate certificates),
    Result deleteCertificate(Certificate certificate),
    Result deleteEducation(EducationStandard education),
    Result deleteSkill(Domain domain),
    @required Result orElse(),
  }) {
    assert(orElse != null);
    if (getUserProfile != null) {
      return getUserProfile();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  Result map<Result extends Object>({
    @required Result submitUserProfile(_SubmitUserProfile value),
    @required Result getUserProfile(_GetUserProfile value),
    @required Result getCountries(_GetCountries value),
    @required Result updateAvatar(_AvatarUpdate value),
    @required Result saveSocialMedia(_SaveSocialMediaHandles value),
    @required Result saveAbout(_SaveAbout value),
    @required Result saveSkills(_SaveSkills value),
    @required Result updateSkills(_UpdateSkill value),
    @required Result saveEducation(_SaveEducations value),
    @required Result updateEducation(_UpdateEducations value),
    @required Result saveCertificates(_SaveCertificates value),
    @required Result updateCertificates(_UpdateCertificates value),
    @required Result deleteCertificate(_DeleteCertificate value),
    @required Result deleteEducation(_DeleteEducation value),
    @required Result deleteSkill(_DeleteDomain value),
  }) {
    assert(submitUserProfile != null);
    assert(getUserProfile != null);
    assert(getCountries != null);
    assert(updateAvatar != null);
    assert(saveSocialMedia != null);
    assert(saveAbout != null);
    assert(saveSkills != null);
    assert(updateSkills != null);
    assert(saveEducation != null);
    assert(updateEducation != null);
    assert(saveCertificates != null);
    assert(updateCertificates != null);
    assert(deleteCertificate != null);
    assert(deleteEducation != null);
    assert(deleteSkill != null);
    return getUserProfile(this);
  }

  @override
  @optionalTypeArgs
  Result maybeMap<Result extends Object>({
    Result submitUserProfile(_SubmitUserProfile value),
    Result getUserProfile(_GetUserProfile value),
    Result getCountries(_GetCountries value),
    Result updateAvatar(_AvatarUpdate value),
    Result saveSocialMedia(_SaveSocialMediaHandles value),
    Result saveAbout(_SaveAbout value),
    Result saveSkills(_SaveSkills value),
    Result updateSkills(_UpdateSkill value),
    Result saveEducation(_SaveEducations value),
    Result updateEducation(_UpdateEducations value),
    Result saveCertificates(_SaveCertificates value),
    Result updateCertificates(_UpdateCertificates value),
    Result deleteCertificate(_DeleteCertificate value),
    Result deleteEducation(_DeleteEducation value),
    Result deleteSkill(_DeleteDomain value),
    @required Result orElse(),
  }) {
    assert(orElse != null);
    if (getUserProfile != null) {
      return getUserProfile(this);
    }
    return orElse();
  }
}

abstract class _GetUserProfile implements ProfileEvent {
  const factory _GetUserProfile() = _$_GetUserProfile;
}

/// @nodoc
abstract class _$GetCountriesCopyWith<$Res> {
  factory _$GetCountriesCopyWith(
          _GetCountries value, $Res Function(_GetCountries) then) =
      __$GetCountriesCopyWithImpl<$Res>;
}

/// @nodoc
class __$GetCountriesCopyWithImpl<$Res> extends _$ProfileEventCopyWithImpl<$Res>
    implements _$GetCountriesCopyWith<$Res> {
  __$GetCountriesCopyWithImpl(
      _GetCountries _value, $Res Function(_GetCountries) _then)
      : super(_value, (v) => _then(v as _GetCountries));

  @override
  _GetCountries get _value => super._value as _GetCountries;
}

/// @nodoc
class _$_GetCountries implements _GetCountries {
  const _$_GetCountries();

  @override
  String toString() {
    return 'ProfileEvent.getCountries()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) || (other is _GetCountries);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  Result when<Result extends Object>({
    @required Result submitUserProfile(),
    @required Result getUserProfile(),
    @required Result getCountries(),
    @required Result updateAvatar(String avatar),
    @required
        Result saveSocialMedia(
            String facebookUserName,
            String instagramUserName,
            String twitterUserName,
            String linkedinUserName),
    @required
        Result saveAbout(String month, String day, String year, String country,
            String state, String phoneNumber),
    @required Result saveSkills(List<Domain> domains),
    @required Result updateSkills(Domain domain),
    @required Result saveEducation(List<EducationStandard> educations),
    @required Result updateEducation(List<EducationStandard> educations),
    @required Result saveCertificates(Certificate certificates),
    @required Result updateCertificates(Certificate certificates),
    @required Result deleteCertificate(Certificate certificate),
    @required Result deleteEducation(EducationStandard education),
    @required Result deleteSkill(Domain domain),
  }) {
    assert(submitUserProfile != null);
    assert(getUserProfile != null);
    assert(getCountries != null);
    assert(updateAvatar != null);
    assert(saveSocialMedia != null);
    assert(saveAbout != null);
    assert(saveSkills != null);
    assert(updateSkills != null);
    assert(saveEducation != null);
    assert(updateEducation != null);
    assert(saveCertificates != null);
    assert(updateCertificates != null);
    assert(deleteCertificate != null);
    assert(deleteEducation != null);
    assert(deleteSkill != null);
    return getCountries();
  }

  @override
  @optionalTypeArgs
  Result maybeWhen<Result extends Object>({
    Result submitUserProfile(),
    Result getUserProfile(),
    Result getCountries(),
    Result updateAvatar(String avatar),
    Result saveSocialMedia(String facebookUserName, String instagramUserName,
        String twitterUserName, String linkedinUserName),
    Result saveAbout(String month, String day, String year, String country,
        String state, String phoneNumber),
    Result saveSkills(List<Domain> domains),
    Result updateSkills(Domain domain),
    Result saveEducation(List<EducationStandard> educations),
    Result updateEducation(List<EducationStandard> educations),
    Result saveCertificates(Certificate certificates),
    Result updateCertificates(Certificate certificates),
    Result deleteCertificate(Certificate certificate),
    Result deleteEducation(EducationStandard education),
    Result deleteSkill(Domain domain),
    @required Result orElse(),
  }) {
    assert(orElse != null);
    if (getCountries != null) {
      return getCountries();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  Result map<Result extends Object>({
    @required Result submitUserProfile(_SubmitUserProfile value),
    @required Result getUserProfile(_GetUserProfile value),
    @required Result getCountries(_GetCountries value),
    @required Result updateAvatar(_AvatarUpdate value),
    @required Result saveSocialMedia(_SaveSocialMediaHandles value),
    @required Result saveAbout(_SaveAbout value),
    @required Result saveSkills(_SaveSkills value),
    @required Result updateSkills(_UpdateSkill value),
    @required Result saveEducation(_SaveEducations value),
    @required Result updateEducation(_UpdateEducations value),
    @required Result saveCertificates(_SaveCertificates value),
    @required Result updateCertificates(_UpdateCertificates value),
    @required Result deleteCertificate(_DeleteCertificate value),
    @required Result deleteEducation(_DeleteEducation value),
    @required Result deleteSkill(_DeleteDomain value),
  }) {
    assert(submitUserProfile != null);
    assert(getUserProfile != null);
    assert(getCountries != null);
    assert(updateAvatar != null);
    assert(saveSocialMedia != null);
    assert(saveAbout != null);
    assert(saveSkills != null);
    assert(updateSkills != null);
    assert(saveEducation != null);
    assert(updateEducation != null);
    assert(saveCertificates != null);
    assert(updateCertificates != null);
    assert(deleteCertificate != null);
    assert(deleteEducation != null);
    assert(deleteSkill != null);
    return getCountries(this);
  }

  @override
  @optionalTypeArgs
  Result maybeMap<Result extends Object>({
    Result submitUserProfile(_SubmitUserProfile value),
    Result getUserProfile(_GetUserProfile value),
    Result getCountries(_GetCountries value),
    Result updateAvatar(_AvatarUpdate value),
    Result saveSocialMedia(_SaveSocialMediaHandles value),
    Result saveAbout(_SaveAbout value),
    Result saveSkills(_SaveSkills value),
    Result updateSkills(_UpdateSkill value),
    Result saveEducation(_SaveEducations value),
    Result updateEducation(_UpdateEducations value),
    Result saveCertificates(_SaveCertificates value),
    Result updateCertificates(_UpdateCertificates value),
    Result deleteCertificate(_DeleteCertificate value),
    Result deleteEducation(_DeleteEducation value),
    Result deleteSkill(_DeleteDomain value),
    @required Result orElse(),
  }) {
    assert(orElse != null);
    if (getCountries != null) {
      return getCountries(this);
    }
    return orElse();
  }
}

abstract class _GetCountries implements ProfileEvent {
  const factory _GetCountries() = _$_GetCountries;
}

/// @nodoc
abstract class _$AvatarUpdateCopyWith<$Res> {
  factory _$AvatarUpdateCopyWith(
          _AvatarUpdate value, $Res Function(_AvatarUpdate) then) =
      __$AvatarUpdateCopyWithImpl<$Res>;
  $Res call({String avatar});
}

/// @nodoc
class __$AvatarUpdateCopyWithImpl<$Res> extends _$ProfileEventCopyWithImpl<$Res>
    implements _$AvatarUpdateCopyWith<$Res> {
  __$AvatarUpdateCopyWithImpl(
      _AvatarUpdate _value, $Res Function(_AvatarUpdate) _then)
      : super(_value, (v) => _then(v as _AvatarUpdate));

  @override
  _AvatarUpdate get _value => super._value as _AvatarUpdate;

  @override
  $Res call({
    Object avatar = freezed,
  }) {
    return _then(_AvatarUpdate(
      avatar == freezed ? _value.avatar : avatar as String,
    ));
  }
}

/// @nodoc
class _$_AvatarUpdate implements _AvatarUpdate {
  const _$_AvatarUpdate(this.avatar) : assert(avatar != null);

  @override
  final String avatar;

  @override
  String toString() {
    return 'ProfileEvent.updateAvatar(avatar: $avatar)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other is _AvatarUpdate &&
            (identical(other.avatar, avatar) ||
                const DeepCollectionEquality().equals(other.avatar, avatar)));
  }

  @override
  int get hashCode =>
      runtimeType.hashCode ^ const DeepCollectionEquality().hash(avatar);

  @override
  _$AvatarUpdateCopyWith<_AvatarUpdate> get copyWith =>
      __$AvatarUpdateCopyWithImpl<_AvatarUpdate>(this, _$identity);

  @override
  @optionalTypeArgs
  Result when<Result extends Object>({
    @required Result submitUserProfile(),
    @required Result getUserProfile(),
    @required Result getCountries(),
    @required Result updateAvatar(String avatar),
    @required
        Result saveSocialMedia(
            String facebookUserName,
            String instagramUserName,
            String twitterUserName,
            String linkedinUserName),
    @required
        Result saveAbout(String month, String day, String year, String country,
            String state, String phoneNumber),
    @required Result saveSkills(List<Domain> domains),
    @required Result updateSkills(Domain domain),
    @required Result saveEducation(List<EducationStandard> educations),
    @required Result updateEducation(List<EducationStandard> educations),
    @required Result saveCertificates(Certificate certificates),
    @required Result updateCertificates(Certificate certificates),
    @required Result deleteCertificate(Certificate certificate),
    @required Result deleteEducation(EducationStandard education),
    @required Result deleteSkill(Domain domain),
  }) {
    assert(submitUserProfile != null);
    assert(getUserProfile != null);
    assert(getCountries != null);
    assert(updateAvatar != null);
    assert(saveSocialMedia != null);
    assert(saveAbout != null);
    assert(saveSkills != null);
    assert(updateSkills != null);
    assert(saveEducation != null);
    assert(updateEducation != null);
    assert(saveCertificates != null);
    assert(updateCertificates != null);
    assert(deleteCertificate != null);
    assert(deleteEducation != null);
    assert(deleteSkill != null);
    return updateAvatar(avatar);
  }

  @override
  @optionalTypeArgs
  Result maybeWhen<Result extends Object>({
    Result submitUserProfile(),
    Result getUserProfile(),
    Result getCountries(),
    Result updateAvatar(String avatar),
    Result saveSocialMedia(String facebookUserName, String instagramUserName,
        String twitterUserName, String linkedinUserName),
    Result saveAbout(String month, String day, String year, String country,
        String state, String phoneNumber),
    Result saveSkills(List<Domain> domains),
    Result updateSkills(Domain domain),
    Result saveEducation(List<EducationStandard> educations),
    Result updateEducation(List<EducationStandard> educations),
    Result saveCertificates(Certificate certificates),
    Result updateCertificates(Certificate certificates),
    Result deleteCertificate(Certificate certificate),
    Result deleteEducation(EducationStandard education),
    Result deleteSkill(Domain domain),
    @required Result orElse(),
  }) {
    assert(orElse != null);
    if (updateAvatar != null) {
      return updateAvatar(avatar);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  Result map<Result extends Object>({
    @required Result submitUserProfile(_SubmitUserProfile value),
    @required Result getUserProfile(_GetUserProfile value),
    @required Result getCountries(_GetCountries value),
    @required Result updateAvatar(_AvatarUpdate value),
    @required Result saveSocialMedia(_SaveSocialMediaHandles value),
    @required Result saveAbout(_SaveAbout value),
    @required Result saveSkills(_SaveSkills value),
    @required Result updateSkills(_UpdateSkill value),
    @required Result saveEducation(_SaveEducations value),
    @required Result updateEducation(_UpdateEducations value),
    @required Result saveCertificates(_SaveCertificates value),
    @required Result updateCertificates(_UpdateCertificates value),
    @required Result deleteCertificate(_DeleteCertificate value),
    @required Result deleteEducation(_DeleteEducation value),
    @required Result deleteSkill(_DeleteDomain value),
  }) {
    assert(submitUserProfile != null);
    assert(getUserProfile != null);
    assert(getCountries != null);
    assert(updateAvatar != null);
    assert(saveSocialMedia != null);
    assert(saveAbout != null);
    assert(saveSkills != null);
    assert(updateSkills != null);
    assert(saveEducation != null);
    assert(updateEducation != null);
    assert(saveCertificates != null);
    assert(updateCertificates != null);
    assert(deleteCertificate != null);
    assert(deleteEducation != null);
    assert(deleteSkill != null);
    return updateAvatar(this);
  }

  @override
  @optionalTypeArgs
  Result maybeMap<Result extends Object>({
    Result submitUserProfile(_SubmitUserProfile value),
    Result getUserProfile(_GetUserProfile value),
    Result getCountries(_GetCountries value),
    Result updateAvatar(_AvatarUpdate value),
    Result saveSocialMedia(_SaveSocialMediaHandles value),
    Result saveAbout(_SaveAbout value),
    Result saveSkills(_SaveSkills value),
    Result updateSkills(_UpdateSkill value),
    Result saveEducation(_SaveEducations value),
    Result updateEducation(_UpdateEducations value),
    Result saveCertificates(_SaveCertificates value),
    Result updateCertificates(_UpdateCertificates value),
    Result deleteCertificate(_DeleteCertificate value),
    Result deleteEducation(_DeleteEducation value),
    Result deleteSkill(_DeleteDomain value),
    @required Result orElse(),
  }) {
    assert(orElse != null);
    if (updateAvatar != null) {
      return updateAvatar(this);
    }
    return orElse();
  }
}

abstract class _AvatarUpdate implements ProfileEvent {
  const factory _AvatarUpdate(String avatar) = _$_AvatarUpdate;

  String get avatar;
  _$AvatarUpdateCopyWith<_AvatarUpdate> get copyWith;
}

/// @nodoc
abstract class _$SaveSocialMediaHandlesCopyWith<$Res> {
  factory _$SaveSocialMediaHandlesCopyWith(_SaveSocialMediaHandles value,
          $Res Function(_SaveSocialMediaHandles) then) =
      __$SaveSocialMediaHandlesCopyWithImpl<$Res>;
  $Res call(
      {String facebookUserName,
      String instagramUserName,
      String twitterUserName,
      String linkedinUserName});
}

/// @nodoc
class __$SaveSocialMediaHandlesCopyWithImpl<$Res>
    extends _$ProfileEventCopyWithImpl<$Res>
    implements _$SaveSocialMediaHandlesCopyWith<$Res> {
  __$SaveSocialMediaHandlesCopyWithImpl(_SaveSocialMediaHandles _value,
      $Res Function(_SaveSocialMediaHandles) _then)
      : super(_value, (v) => _then(v as _SaveSocialMediaHandles));

  @override
  _SaveSocialMediaHandles get _value => super._value as _SaveSocialMediaHandles;

  @override
  $Res call({
    Object facebookUserName = freezed,
    Object instagramUserName = freezed,
    Object twitterUserName = freezed,
    Object linkedinUserName = freezed,
  }) {
    return _then(_SaveSocialMediaHandles(
      facebookUserName: facebookUserName == freezed
          ? _value.facebookUserName
          : facebookUserName as String,
      instagramUserName: instagramUserName == freezed
          ? _value.instagramUserName
          : instagramUserName as String,
      twitterUserName: twitterUserName == freezed
          ? _value.twitterUserName
          : twitterUserName as String,
      linkedinUserName: linkedinUserName == freezed
          ? _value.linkedinUserName
          : linkedinUserName as String,
    ));
  }
}

/// @nodoc
class _$_SaveSocialMediaHandles implements _SaveSocialMediaHandles {
  const _$_SaveSocialMediaHandles(
      {@required this.facebookUserName,
      @required this.instagramUserName,
      @required this.twitterUserName,
      @required this.linkedinUserName})
      : assert(facebookUserName != null),
        assert(instagramUserName != null),
        assert(twitterUserName != null),
        assert(linkedinUserName != null);

  @override
  final String facebookUserName;
  @override
  final String instagramUserName;
  @override
  final String twitterUserName;
  @override
  final String linkedinUserName;

  @override
  String toString() {
    return 'ProfileEvent.saveSocialMedia(facebookUserName: $facebookUserName, instagramUserName: $instagramUserName, twitterUserName: $twitterUserName, linkedinUserName: $linkedinUserName)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other is _SaveSocialMediaHandles &&
            (identical(other.facebookUserName, facebookUserName) ||
                const DeepCollectionEquality()
                    .equals(other.facebookUserName, facebookUserName)) &&
            (identical(other.instagramUserName, instagramUserName) ||
                const DeepCollectionEquality()
                    .equals(other.instagramUserName, instagramUserName)) &&
            (identical(other.twitterUserName, twitterUserName) ||
                const DeepCollectionEquality()
                    .equals(other.twitterUserName, twitterUserName)) &&
            (identical(other.linkedinUserName, linkedinUserName) ||
                const DeepCollectionEquality()
                    .equals(other.linkedinUserName, linkedinUserName)));
  }

  @override
  int get hashCode =>
      runtimeType.hashCode ^
      const DeepCollectionEquality().hash(facebookUserName) ^
      const DeepCollectionEquality().hash(instagramUserName) ^
      const DeepCollectionEquality().hash(twitterUserName) ^
      const DeepCollectionEquality().hash(linkedinUserName);

  @override
  _$SaveSocialMediaHandlesCopyWith<_SaveSocialMediaHandles> get copyWith =>
      __$SaveSocialMediaHandlesCopyWithImpl<_SaveSocialMediaHandles>(
          this, _$identity);

  @override
  @optionalTypeArgs
  Result when<Result extends Object>({
    @required Result submitUserProfile(),
    @required Result getUserProfile(),
    @required Result getCountries(),
    @required Result updateAvatar(String avatar),
    @required
        Result saveSocialMedia(
            String facebookUserName,
            String instagramUserName,
            String twitterUserName,
            String linkedinUserName),
    @required
        Result saveAbout(String month, String day, String year, String country,
            String state, String phoneNumber),
    @required Result saveSkills(List<Domain> domains),
    @required Result updateSkills(Domain domain),
    @required Result saveEducation(List<EducationStandard> educations),
    @required Result updateEducation(List<EducationStandard> educations),
    @required Result saveCertificates(Certificate certificates),
    @required Result updateCertificates(Certificate certificates),
    @required Result deleteCertificate(Certificate certificate),
    @required Result deleteEducation(EducationStandard education),
    @required Result deleteSkill(Domain domain),
  }) {
    assert(submitUserProfile != null);
    assert(getUserProfile != null);
    assert(getCountries != null);
    assert(updateAvatar != null);
    assert(saveSocialMedia != null);
    assert(saveAbout != null);
    assert(saveSkills != null);
    assert(updateSkills != null);
    assert(saveEducation != null);
    assert(updateEducation != null);
    assert(saveCertificates != null);
    assert(updateCertificates != null);
    assert(deleteCertificate != null);
    assert(deleteEducation != null);
    assert(deleteSkill != null);
    return saveSocialMedia(
        facebookUserName, instagramUserName, twitterUserName, linkedinUserName);
  }

  @override
  @optionalTypeArgs
  Result maybeWhen<Result extends Object>({
    Result submitUserProfile(),
    Result getUserProfile(),
    Result getCountries(),
    Result updateAvatar(String avatar),
    Result saveSocialMedia(String facebookUserName, String instagramUserName,
        String twitterUserName, String linkedinUserName),
    Result saveAbout(String month, String day, String year, String country,
        String state, String phoneNumber),
    Result saveSkills(List<Domain> domains),
    Result updateSkills(Domain domain),
    Result saveEducation(List<EducationStandard> educations),
    Result updateEducation(List<EducationStandard> educations),
    Result saveCertificates(Certificate certificates),
    Result updateCertificates(Certificate certificates),
    Result deleteCertificate(Certificate certificate),
    Result deleteEducation(EducationStandard education),
    Result deleteSkill(Domain domain),
    @required Result orElse(),
  }) {
    assert(orElse != null);
    if (saveSocialMedia != null) {
      return saveSocialMedia(facebookUserName, instagramUserName,
          twitterUserName, linkedinUserName);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  Result map<Result extends Object>({
    @required Result submitUserProfile(_SubmitUserProfile value),
    @required Result getUserProfile(_GetUserProfile value),
    @required Result getCountries(_GetCountries value),
    @required Result updateAvatar(_AvatarUpdate value),
    @required Result saveSocialMedia(_SaveSocialMediaHandles value),
    @required Result saveAbout(_SaveAbout value),
    @required Result saveSkills(_SaveSkills value),
    @required Result updateSkills(_UpdateSkill value),
    @required Result saveEducation(_SaveEducations value),
    @required Result updateEducation(_UpdateEducations value),
    @required Result saveCertificates(_SaveCertificates value),
    @required Result updateCertificates(_UpdateCertificates value),
    @required Result deleteCertificate(_DeleteCertificate value),
    @required Result deleteEducation(_DeleteEducation value),
    @required Result deleteSkill(_DeleteDomain value),
  }) {
    assert(submitUserProfile != null);
    assert(getUserProfile != null);
    assert(getCountries != null);
    assert(updateAvatar != null);
    assert(saveSocialMedia != null);
    assert(saveAbout != null);
    assert(saveSkills != null);
    assert(updateSkills != null);
    assert(saveEducation != null);
    assert(updateEducation != null);
    assert(saveCertificates != null);
    assert(updateCertificates != null);
    assert(deleteCertificate != null);
    assert(deleteEducation != null);
    assert(deleteSkill != null);
    return saveSocialMedia(this);
  }

  @override
  @optionalTypeArgs
  Result maybeMap<Result extends Object>({
    Result submitUserProfile(_SubmitUserProfile value),
    Result getUserProfile(_GetUserProfile value),
    Result getCountries(_GetCountries value),
    Result updateAvatar(_AvatarUpdate value),
    Result saveSocialMedia(_SaveSocialMediaHandles value),
    Result saveAbout(_SaveAbout value),
    Result saveSkills(_SaveSkills value),
    Result updateSkills(_UpdateSkill value),
    Result saveEducation(_SaveEducations value),
    Result updateEducation(_UpdateEducations value),
    Result saveCertificates(_SaveCertificates value),
    Result updateCertificates(_UpdateCertificates value),
    Result deleteCertificate(_DeleteCertificate value),
    Result deleteEducation(_DeleteEducation value),
    Result deleteSkill(_DeleteDomain value),
    @required Result orElse(),
  }) {
    assert(orElse != null);
    if (saveSocialMedia != null) {
      return saveSocialMedia(this);
    }
    return orElse();
  }
}

abstract class _SaveSocialMediaHandles implements ProfileEvent {
  const factory _SaveSocialMediaHandles(
      {@required String facebookUserName,
      @required String instagramUserName,
      @required String twitterUserName,
      @required String linkedinUserName}) = _$_SaveSocialMediaHandles;

  String get facebookUserName;
  String get instagramUserName;
  String get twitterUserName;
  String get linkedinUserName;
  _$SaveSocialMediaHandlesCopyWith<_SaveSocialMediaHandles> get copyWith;
}

/// @nodoc
abstract class _$SaveAboutCopyWith<$Res> {
  factory _$SaveAboutCopyWith(
          _SaveAbout value, $Res Function(_SaveAbout) then) =
      __$SaveAboutCopyWithImpl<$Res>;
  $Res call(
      {String month,
      String day,
      String year,
      String country,
      String state,
      String phoneNumber});
}

/// @nodoc
class __$SaveAboutCopyWithImpl<$Res> extends _$ProfileEventCopyWithImpl<$Res>
    implements _$SaveAboutCopyWith<$Res> {
  __$SaveAboutCopyWithImpl(_SaveAbout _value, $Res Function(_SaveAbout) _then)
      : super(_value, (v) => _then(v as _SaveAbout));

  @override
  _SaveAbout get _value => super._value as _SaveAbout;

  @override
  $Res call({
    Object month = freezed,
    Object day = freezed,
    Object year = freezed,
    Object country = freezed,
    Object state = freezed,
    Object phoneNumber = freezed,
  }) {
    return _then(_SaveAbout(
      month: month == freezed ? _value.month : month as String,
      day: day == freezed ? _value.day : day as String,
      year: year == freezed ? _value.year : year as String,
      country: country == freezed ? _value.country : country as String,
      state: state == freezed ? _value.state : state as String,
      phoneNumber:
          phoneNumber == freezed ? _value.phoneNumber : phoneNumber as String,
    ));
  }
}

/// @nodoc
class _$_SaveAbout implements _SaveAbout {
  const _$_SaveAbout(
      {@required this.month,
      @required this.day,
      @required this.year,
      @required this.country,
      @required this.state,
      @required this.phoneNumber})
      : assert(month != null),
        assert(day != null),
        assert(year != null),
        assert(country != null),
        assert(state != null),
        assert(phoneNumber != null);

  @override
  final String month;
  @override
  final String day;
  @override
  final String year;
  @override
  final String country;
  @override
  final String state;
  @override
  final String phoneNumber;

  @override
  String toString() {
    return 'ProfileEvent.saveAbout(month: $month, day: $day, year: $year, country: $country, state: $state, phoneNumber: $phoneNumber)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other is _SaveAbout &&
            (identical(other.month, month) ||
                const DeepCollectionEquality().equals(other.month, month)) &&
            (identical(other.day, day) ||
                const DeepCollectionEquality().equals(other.day, day)) &&
            (identical(other.year, year) ||
                const DeepCollectionEquality().equals(other.year, year)) &&
            (identical(other.country, country) ||
                const DeepCollectionEquality()
                    .equals(other.country, country)) &&
            (identical(other.state, state) ||
                const DeepCollectionEquality().equals(other.state, state)) &&
            (identical(other.phoneNumber, phoneNumber) ||
                const DeepCollectionEquality()
                    .equals(other.phoneNumber, phoneNumber)));
  }

  @override
  int get hashCode =>
      runtimeType.hashCode ^
      const DeepCollectionEquality().hash(month) ^
      const DeepCollectionEquality().hash(day) ^
      const DeepCollectionEquality().hash(year) ^
      const DeepCollectionEquality().hash(country) ^
      const DeepCollectionEquality().hash(state) ^
      const DeepCollectionEquality().hash(phoneNumber);

  @override
  _$SaveAboutCopyWith<_SaveAbout> get copyWith =>
      __$SaveAboutCopyWithImpl<_SaveAbout>(this, _$identity);

  @override
  @optionalTypeArgs
  Result when<Result extends Object>({
    @required Result submitUserProfile(),
    @required Result getUserProfile(),
    @required Result getCountries(),
    @required Result updateAvatar(String avatar),
    @required
        Result saveSocialMedia(
            String facebookUserName,
            String instagramUserName,
            String twitterUserName,
            String linkedinUserName),
    @required
        Result saveAbout(String month, String day, String year, String country,
            String state, String phoneNumber),
    @required Result saveSkills(List<Domain> domains),
    @required Result updateSkills(Domain domain),
    @required Result saveEducation(List<EducationStandard> educations),
    @required Result updateEducation(List<EducationStandard> educations),
    @required Result saveCertificates(Certificate certificates),
    @required Result updateCertificates(Certificate certificates),
    @required Result deleteCertificate(Certificate certificate),
    @required Result deleteEducation(EducationStandard education),
    @required Result deleteSkill(Domain domain),
  }) {
    assert(submitUserProfile != null);
    assert(getUserProfile != null);
    assert(getCountries != null);
    assert(updateAvatar != null);
    assert(saveSocialMedia != null);
    assert(saveAbout != null);
    assert(saveSkills != null);
    assert(updateSkills != null);
    assert(saveEducation != null);
    assert(updateEducation != null);
    assert(saveCertificates != null);
    assert(updateCertificates != null);
    assert(deleteCertificate != null);
    assert(deleteEducation != null);
    assert(deleteSkill != null);
    return saveAbout(month, day, year, country, state, phoneNumber);
  }

  @override
  @optionalTypeArgs
  Result maybeWhen<Result extends Object>({
    Result submitUserProfile(),
    Result getUserProfile(),
    Result getCountries(),
    Result updateAvatar(String avatar),
    Result saveSocialMedia(String facebookUserName, String instagramUserName,
        String twitterUserName, String linkedinUserName),
    Result saveAbout(String month, String day, String year, String country,
        String state, String phoneNumber),
    Result saveSkills(List<Domain> domains),
    Result updateSkills(Domain domain),
    Result saveEducation(List<EducationStandard> educations),
    Result updateEducation(List<EducationStandard> educations),
    Result saveCertificates(Certificate certificates),
    Result updateCertificates(Certificate certificates),
    Result deleteCertificate(Certificate certificate),
    Result deleteEducation(EducationStandard education),
    Result deleteSkill(Domain domain),
    @required Result orElse(),
  }) {
    assert(orElse != null);
    if (saveAbout != null) {
      return saveAbout(month, day, year, country, state, phoneNumber);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  Result map<Result extends Object>({
    @required Result submitUserProfile(_SubmitUserProfile value),
    @required Result getUserProfile(_GetUserProfile value),
    @required Result getCountries(_GetCountries value),
    @required Result updateAvatar(_AvatarUpdate value),
    @required Result saveSocialMedia(_SaveSocialMediaHandles value),
    @required Result saveAbout(_SaveAbout value),
    @required Result saveSkills(_SaveSkills value),
    @required Result updateSkills(_UpdateSkill value),
    @required Result saveEducation(_SaveEducations value),
    @required Result updateEducation(_UpdateEducations value),
    @required Result saveCertificates(_SaveCertificates value),
    @required Result updateCertificates(_UpdateCertificates value),
    @required Result deleteCertificate(_DeleteCertificate value),
    @required Result deleteEducation(_DeleteEducation value),
    @required Result deleteSkill(_DeleteDomain value),
  }) {
    assert(submitUserProfile != null);
    assert(getUserProfile != null);
    assert(getCountries != null);
    assert(updateAvatar != null);
    assert(saveSocialMedia != null);
    assert(saveAbout != null);
    assert(saveSkills != null);
    assert(updateSkills != null);
    assert(saveEducation != null);
    assert(updateEducation != null);
    assert(saveCertificates != null);
    assert(updateCertificates != null);
    assert(deleteCertificate != null);
    assert(deleteEducation != null);
    assert(deleteSkill != null);
    return saveAbout(this);
  }

  @override
  @optionalTypeArgs
  Result maybeMap<Result extends Object>({
    Result submitUserProfile(_SubmitUserProfile value),
    Result getUserProfile(_GetUserProfile value),
    Result getCountries(_GetCountries value),
    Result updateAvatar(_AvatarUpdate value),
    Result saveSocialMedia(_SaveSocialMediaHandles value),
    Result saveAbout(_SaveAbout value),
    Result saveSkills(_SaveSkills value),
    Result updateSkills(_UpdateSkill value),
    Result saveEducation(_SaveEducations value),
    Result updateEducation(_UpdateEducations value),
    Result saveCertificates(_SaveCertificates value),
    Result updateCertificates(_UpdateCertificates value),
    Result deleteCertificate(_DeleteCertificate value),
    Result deleteEducation(_DeleteEducation value),
    Result deleteSkill(_DeleteDomain value),
    @required Result orElse(),
  }) {
    assert(orElse != null);
    if (saveAbout != null) {
      return saveAbout(this);
    }
    return orElse();
  }
}

abstract class _SaveAbout implements ProfileEvent {
  const factory _SaveAbout(
      {@required String month,
      @required String day,
      @required String year,
      @required String country,
      @required String state,
      @required String phoneNumber}) = _$_SaveAbout;

  String get month;
  String get day;
  String get year;
  String get country;
  String get state;
  String get phoneNumber;
  _$SaveAboutCopyWith<_SaveAbout> get copyWith;
}

/// @nodoc
abstract class _$SaveSkillsCopyWith<$Res> {
  factory _$SaveSkillsCopyWith(
          _SaveSkills value, $Res Function(_SaveSkills) then) =
      __$SaveSkillsCopyWithImpl<$Res>;
  $Res call({List<Domain> domains});
}

/// @nodoc
class __$SaveSkillsCopyWithImpl<$Res> extends _$ProfileEventCopyWithImpl<$Res>
    implements _$SaveSkillsCopyWith<$Res> {
  __$SaveSkillsCopyWithImpl(
      _SaveSkills _value, $Res Function(_SaveSkills) _then)
      : super(_value, (v) => _then(v as _SaveSkills));

  @override
  _SaveSkills get _value => super._value as _SaveSkills;

  @override
  $Res call({
    Object domains = freezed,
  }) {
    return _then(_SaveSkills(
      domains == freezed ? _value.domains : domains as List<Domain>,
    ));
  }
}

/// @nodoc
class _$_SaveSkills implements _SaveSkills {
  const _$_SaveSkills(this.domains) : assert(domains != null);

  @override
  final List<Domain> domains;

  @override
  String toString() {
    return 'ProfileEvent.saveSkills(domains: $domains)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other is _SaveSkills &&
            (identical(other.domains, domains) ||
                const DeepCollectionEquality().equals(other.domains, domains)));
  }

  @override
  int get hashCode =>
      runtimeType.hashCode ^ const DeepCollectionEquality().hash(domains);

  @override
  _$SaveSkillsCopyWith<_SaveSkills> get copyWith =>
      __$SaveSkillsCopyWithImpl<_SaveSkills>(this, _$identity);

  @override
  @optionalTypeArgs
  Result when<Result extends Object>({
    @required Result submitUserProfile(),
    @required Result getUserProfile(),
    @required Result getCountries(),
    @required Result updateAvatar(String avatar),
    @required
        Result saveSocialMedia(
            String facebookUserName,
            String instagramUserName,
            String twitterUserName,
            String linkedinUserName),
    @required
        Result saveAbout(String month, String day, String year, String country,
            String state, String phoneNumber),
    @required Result saveSkills(List<Domain> domains),
    @required Result updateSkills(Domain domain),
    @required Result saveEducation(List<EducationStandard> educations),
    @required Result updateEducation(List<EducationStandard> educations),
    @required Result saveCertificates(Certificate certificates),
    @required Result updateCertificates(Certificate certificates),
    @required Result deleteCertificate(Certificate certificate),
    @required Result deleteEducation(EducationStandard education),
    @required Result deleteSkill(Domain domain),
  }) {
    assert(submitUserProfile != null);
    assert(getUserProfile != null);
    assert(getCountries != null);
    assert(updateAvatar != null);
    assert(saveSocialMedia != null);
    assert(saveAbout != null);
    assert(saveSkills != null);
    assert(updateSkills != null);
    assert(saveEducation != null);
    assert(updateEducation != null);
    assert(saveCertificates != null);
    assert(updateCertificates != null);
    assert(deleteCertificate != null);
    assert(deleteEducation != null);
    assert(deleteSkill != null);
    return saveSkills(domains);
  }

  @override
  @optionalTypeArgs
  Result maybeWhen<Result extends Object>({
    Result submitUserProfile(),
    Result getUserProfile(),
    Result getCountries(),
    Result updateAvatar(String avatar),
    Result saveSocialMedia(String facebookUserName, String instagramUserName,
        String twitterUserName, String linkedinUserName),
    Result saveAbout(String month, String day, String year, String country,
        String state, String phoneNumber),
    Result saveSkills(List<Domain> domains),
    Result updateSkills(Domain domain),
    Result saveEducation(List<EducationStandard> educations),
    Result updateEducation(List<EducationStandard> educations),
    Result saveCertificates(Certificate certificates),
    Result updateCertificates(Certificate certificates),
    Result deleteCertificate(Certificate certificate),
    Result deleteEducation(EducationStandard education),
    Result deleteSkill(Domain domain),
    @required Result orElse(),
  }) {
    assert(orElse != null);
    if (saveSkills != null) {
      return saveSkills(domains);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  Result map<Result extends Object>({
    @required Result submitUserProfile(_SubmitUserProfile value),
    @required Result getUserProfile(_GetUserProfile value),
    @required Result getCountries(_GetCountries value),
    @required Result updateAvatar(_AvatarUpdate value),
    @required Result saveSocialMedia(_SaveSocialMediaHandles value),
    @required Result saveAbout(_SaveAbout value),
    @required Result saveSkills(_SaveSkills value),
    @required Result updateSkills(_UpdateSkill value),
    @required Result saveEducation(_SaveEducations value),
    @required Result updateEducation(_UpdateEducations value),
    @required Result saveCertificates(_SaveCertificates value),
    @required Result updateCertificates(_UpdateCertificates value),
    @required Result deleteCertificate(_DeleteCertificate value),
    @required Result deleteEducation(_DeleteEducation value),
    @required Result deleteSkill(_DeleteDomain value),
  }) {
    assert(submitUserProfile != null);
    assert(getUserProfile != null);
    assert(getCountries != null);
    assert(updateAvatar != null);
    assert(saveSocialMedia != null);
    assert(saveAbout != null);
    assert(saveSkills != null);
    assert(updateSkills != null);
    assert(saveEducation != null);
    assert(updateEducation != null);
    assert(saveCertificates != null);
    assert(updateCertificates != null);
    assert(deleteCertificate != null);
    assert(deleteEducation != null);
    assert(deleteSkill != null);
    return saveSkills(this);
  }

  @override
  @optionalTypeArgs
  Result maybeMap<Result extends Object>({
    Result submitUserProfile(_SubmitUserProfile value),
    Result getUserProfile(_GetUserProfile value),
    Result getCountries(_GetCountries value),
    Result updateAvatar(_AvatarUpdate value),
    Result saveSocialMedia(_SaveSocialMediaHandles value),
    Result saveAbout(_SaveAbout value),
    Result saveSkills(_SaveSkills value),
    Result updateSkills(_UpdateSkill value),
    Result saveEducation(_SaveEducations value),
    Result updateEducation(_UpdateEducations value),
    Result saveCertificates(_SaveCertificates value),
    Result updateCertificates(_UpdateCertificates value),
    Result deleteCertificate(_DeleteCertificate value),
    Result deleteEducation(_DeleteEducation value),
    Result deleteSkill(_DeleteDomain value),
    @required Result orElse(),
  }) {
    assert(orElse != null);
    if (saveSkills != null) {
      return saveSkills(this);
    }
    return orElse();
  }
}

abstract class _SaveSkills implements ProfileEvent {
  const factory _SaveSkills(List<Domain> domains) = _$_SaveSkills;

  List<Domain> get domains;
  _$SaveSkillsCopyWith<_SaveSkills> get copyWith;
}

/// @nodoc
abstract class _$UpdateSkillCopyWith<$Res> {
  factory _$UpdateSkillCopyWith(
          _UpdateSkill value, $Res Function(_UpdateSkill) then) =
      __$UpdateSkillCopyWithImpl<$Res>;
  $Res call({Domain domain});
}

/// @nodoc
class __$UpdateSkillCopyWithImpl<$Res> extends _$ProfileEventCopyWithImpl<$Res>
    implements _$UpdateSkillCopyWith<$Res> {
  __$UpdateSkillCopyWithImpl(
      _UpdateSkill _value, $Res Function(_UpdateSkill) _then)
      : super(_value, (v) => _then(v as _UpdateSkill));

  @override
  _UpdateSkill get _value => super._value as _UpdateSkill;

  @override
  $Res call({
    Object domain = freezed,
  }) {
    return _then(_UpdateSkill(
      domain == freezed ? _value.domain : domain as Domain,
    ));
  }
}

/// @nodoc
class _$_UpdateSkill implements _UpdateSkill {
  const _$_UpdateSkill(this.domain) : assert(domain != null);

  @override
  final Domain domain;

  @override
  String toString() {
    return 'ProfileEvent.updateSkills(domain: $domain)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other is _UpdateSkill &&
            (identical(other.domain, domain) ||
                const DeepCollectionEquality().equals(other.domain, domain)));
  }

  @override
  int get hashCode =>
      runtimeType.hashCode ^ const DeepCollectionEquality().hash(domain);

  @override
  _$UpdateSkillCopyWith<_UpdateSkill> get copyWith =>
      __$UpdateSkillCopyWithImpl<_UpdateSkill>(this, _$identity);

  @override
  @optionalTypeArgs
  Result when<Result extends Object>({
    @required Result submitUserProfile(),
    @required Result getUserProfile(),
    @required Result getCountries(),
    @required Result updateAvatar(String avatar),
    @required
        Result saveSocialMedia(
            String facebookUserName,
            String instagramUserName,
            String twitterUserName,
            String linkedinUserName),
    @required
        Result saveAbout(String month, String day, String year, String country,
            String state, String phoneNumber),
    @required Result saveSkills(List<Domain> domains),
    @required Result updateSkills(Domain domain),
    @required Result saveEducation(List<EducationStandard> educations),
    @required Result updateEducation(List<EducationStandard> educations),
    @required Result saveCertificates(Certificate certificates),
    @required Result updateCertificates(Certificate certificates),
    @required Result deleteCertificate(Certificate certificate),
    @required Result deleteEducation(EducationStandard education),
    @required Result deleteSkill(Domain domain),
  }) {
    assert(submitUserProfile != null);
    assert(getUserProfile != null);
    assert(getCountries != null);
    assert(updateAvatar != null);
    assert(saveSocialMedia != null);
    assert(saveAbout != null);
    assert(saveSkills != null);
    assert(updateSkills != null);
    assert(saveEducation != null);
    assert(updateEducation != null);
    assert(saveCertificates != null);
    assert(updateCertificates != null);
    assert(deleteCertificate != null);
    assert(deleteEducation != null);
    assert(deleteSkill != null);
    return updateSkills(domain);
  }

  @override
  @optionalTypeArgs
  Result maybeWhen<Result extends Object>({
    Result submitUserProfile(),
    Result getUserProfile(),
    Result getCountries(),
    Result updateAvatar(String avatar),
    Result saveSocialMedia(String facebookUserName, String instagramUserName,
        String twitterUserName, String linkedinUserName),
    Result saveAbout(String month, String day, String year, String country,
        String state, String phoneNumber),
    Result saveSkills(List<Domain> domains),
    Result updateSkills(Domain domain),
    Result saveEducation(List<EducationStandard> educations),
    Result updateEducation(List<EducationStandard> educations),
    Result saveCertificates(Certificate certificates),
    Result updateCertificates(Certificate certificates),
    Result deleteCertificate(Certificate certificate),
    Result deleteEducation(EducationStandard education),
    Result deleteSkill(Domain domain),
    @required Result orElse(),
  }) {
    assert(orElse != null);
    if (updateSkills != null) {
      return updateSkills(domain);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  Result map<Result extends Object>({
    @required Result submitUserProfile(_SubmitUserProfile value),
    @required Result getUserProfile(_GetUserProfile value),
    @required Result getCountries(_GetCountries value),
    @required Result updateAvatar(_AvatarUpdate value),
    @required Result saveSocialMedia(_SaveSocialMediaHandles value),
    @required Result saveAbout(_SaveAbout value),
    @required Result saveSkills(_SaveSkills value),
    @required Result updateSkills(_UpdateSkill value),
    @required Result saveEducation(_SaveEducations value),
    @required Result updateEducation(_UpdateEducations value),
    @required Result saveCertificates(_SaveCertificates value),
    @required Result updateCertificates(_UpdateCertificates value),
    @required Result deleteCertificate(_DeleteCertificate value),
    @required Result deleteEducation(_DeleteEducation value),
    @required Result deleteSkill(_DeleteDomain value),
  }) {
    assert(submitUserProfile != null);
    assert(getUserProfile != null);
    assert(getCountries != null);
    assert(updateAvatar != null);
    assert(saveSocialMedia != null);
    assert(saveAbout != null);
    assert(saveSkills != null);
    assert(updateSkills != null);
    assert(saveEducation != null);
    assert(updateEducation != null);
    assert(saveCertificates != null);
    assert(updateCertificates != null);
    assert(deleteCertificate != null);
    assert(deleteEducation != null);
    assert(deleteSkill != null);
    return updateSkills(this);
  }

  @override
  @optionalTypeArgs
  Result maybeMap<Result extends Object>({
    Result submitUserProfile(_SubmitUserProfile value),
    Result getUserProfile(_GetUserProfile value),
    Result getCountries(_GetCountries value),
    Result updateAvatar(_AvatarUpdate value),
    Result saveSocialMedia(_SaveSocialMediaHandles value),
    Result saveAbout(_SaveAbout value),
    Result saveSkills(_SaveSkills value),
    Result updateSkills(_UpdateSkill value),
    Result saveEducation(_SaveEducations value),
    Result updateEducation(_UpdateEducations value),
    Result saveCertificates(_SaveCertificates value),
    Result updateCertificates(_UpdateCertificates value),
    Result deleteCertificate(_DeleteCertificate value),
    Result deleteEducation(_DeleteEducation value),
    Result deleteSkill(_DeleteDomain value),
    @required Result orElse(),
  }) {
    assert(orElse != null);
    if (updateSkills != null) {
      return updateSkills(this);
    }
    return orElse();
  }
}

abstract class _UpdateSkill implements ProfileEvent {
  const factory _UpdateSkill(Domain domain) = _$_UpdateSkill;

  Domain get domain;
  _$UpdateSkillCopyWith<_UpdateSkill> get copyWith;
}

/// @nodoc
abstract class _$SaveEducationsCopyWith<$Res> {
  factory _$SaveEducationsCopyWith(
          _SaveEducations value, $Res Function(_SaveEducations) then) =
      __$SaveEducationsCopyWithImpl<$Res>;
  $Res call({List<EducationStandard> educations});
}

/// @nodoc
class __$SaveEducationsCopyWithImpl<$Res>
    extends _$ProfileEventCopyWithImpl<$Res>
    implements _$SaveEducationsCopyWith<$Res> {
  __$SaveEducationsCopyWithImpl(
      _SaveEducations _value, $Res Function(_SaveEducations) _then)
      : super(_value, (v) => _then(v as _SaveEducations));

  @override
  _SaveEducations get _value => super._value as _SaveEducations;

  @override
  $Res call({
    Object educations = freezed,
  }) {
    return _then(_SaveEducations(
      educations == freezed
          ? _value.educations
          : educations as List<EducationStandard>,
    ));
  }
}

/// @nodoc
class _$_SaveEducations implements _SaveEducations {
  const _$_SaveEducations(this.educations) : assert(educations != null);

  @override
  final List<EducationStandard> educations;

  @override
  String toString() {
    return 'ProfileEvent.saveEducation(educations: $educations)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other is _SaveEducations &&
            (identical(other.educations, educations) ||
                const DeepCollectionEquality()
                    .equals(other.educations, educations)));
  }

  @override
  int get hashCode =>
      runtimeType.hashCode ^ const DeepCollectionEquality().hash(educations);

  @override
  _$SaveEducationsCopyWith<_SaveEducations> get copyWith =>
      __$SaveEducationsCopyWithImpl<_SaveEducations>(this, _$identity);

  @override
  @optionalTypeArgs
  Result when<Result extends Object>({
    @required Result submitUserProfile(),
    @required Result getUserProfile(),
    @required Result getCountries(),
    @required Result updateAvatar(String avatar),
    @required
        Result saveSocialMedia(
            String facebookUserName,
            String instagramUserName,
            String twitterUserName,
            String linkedinUserName),
    @required
        Result saveAbout(String month, String day, String year, String country,
            String state, String phoneNumber),
    @required Result saveSkills(List<Domain> domains),
    @required Result updateSkills(Domain domain),
    @required Result saveEducation(List<EducationStandard> educations),
    @required Result updateEducation(List<EducationStandard> educations),
    @required Result saveCertificates(Certificate certificates),
    @required Result updateCertificates(Certificate certificates),
    @required Result deleteCertificate(Certificate certificate),
    @required Result deleteEducation(EducationStandard education),
    @required Result deleteSkill(Domain domain),
  }) {
    assert(submitUserProfile != null);
    assert(getUserProfile != null);
    assert(getCountries != null);
    assert(updateAvatar != null);
    assert(saveSocialMedia != null);
    assert(saveAbout != null);
    assert(saveSkills != null);
    assert(updateSkills != null);
    assert(saveEducation != null);
    assert(updateEducation != null);
    assert(saveCertificates != null);
    assert(updateCertificates != null);
    assert(deleteCertificate != null);
    assert(deleteEducation != null);
    assert(deleteSkill != null);
    return saveEducation(educations);
  }

  @override
  @optionalTypeArgs
  Result maybeWhen<Result extends Object>({
    Result submitUserProfile(),
    Result getUserProfile(),
    Result getCountries(),
    Result updateAvatar(String avatar),
    Result saveSocialMedia(String facebookUserName, String instagramUserName,
        String twitterUserName, String linkedinUserName),
    Result saveAbout(String month, String day, String year, String country,
        String state, String phoneNumber),
    Result saveSkills(List<Domain> domains),
    Result updateSkills(Domain domain),
    Result saveEducation(List<EducationStandard> educations),
    Result updateEducation(List<EducationStandard> educations),
    Result saveCertificates(Certificate certificates),
    Result updateCertificates(Certificate certificates),
    Result deleteCertificate(Certificate certificate),
    Result deleteEducation(EducationStandard education),
    Result deleteSkill(Domain domain),
    @required Result orElse(),
  }) {
    assert(orElse != null);
    if (saveEducation != null) {
      return saveEducation(educations);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  Result map<Result extends Object>({
    @required Result submitUserProfile(_SubmitUserProfile value),
    @required Result getUserProfile(_GetUserProfile value),
    @required Result getCountries(_GetCountries value),
    @required Result updateAvatar(_AvatarUpdate value),
    @required Result saveSocialMedia(_SaveSocialMediaHandles value),
    @required Result saveAbout(_SaveAbout value),
    @required Result saveSkills(_SaveSkills value),
    @required Result updateSkills(_UpdateSkill value),
    @required Result saveEducation(_SaveEducations value),
    @required Result updateEducation(_UpdateEducations value),
    @required Result saveCertificates(_SaveCertificates value),
    @required Result updateCertificates(_UpdateCertificates value),
    @required Result deleteCertificate(_DeleteCertificate value),
    @required Result deleteEducation(_DeleteEducation value),
    @required Result deleteSkill(_DeleteDomain value),
  }) {
    assert(submitUserProfile != null);
    assert(getUserProfile != null);
    assert(getCountries != null);
    assert(updateAvatar != null);
    assert(saveSocialMedia != null);
    assert(saveAbout != null);
    assert(saveSkills != null);
    assert(updateSkills != null);
    assert(saveEducation != null);
    assert(updateEducation != null);
    assert(saveCertificates != null);
    assert(updateCertificates != null);
    assert(deleteCertificate != null);
    assert(deleteEducation != null);
    assert(deleteSkill != null);
    return saveEducation(this);
  }

  @override
  @optionalTypeArgs
  Result maybeMap<Result extends Object>({
    Result submitUserProfile(_SubmitUserProfile value),
    Result getUserProfile(_GetUserProfile value),
    Result getCountries(_GetCountries value),
    Result updateAvatar(_AvatarUpdate value),
    Result saveSocialMedia(_SaveSocialMediaHandles value),
    Result saveAbout(_SaveAbout value),
    Result saveSkills(_SaveSkills value),
    Result updateSkills(_UpdateSkill value),
    Result saveEducation(_SaveEducations value),
    Result updateEducation(_UpdateEducations value),
    Result saveCertificates(_SaveCertificates value),
    Result updateCertificates(_UpdateCertificates value),
    Result deleteCertificate(_DeleteCertificate value),
    Result deleteEducation(_DeleteEducation value),
    Result deleteSkill(_DeleteDomain value),
    @required Result orElse(),
  }) {
    assert(orElse != null);
    if (saveEducation != null) {
      return saveEducation(this);
    }
    return orElse();
  }
}

abstract class _SaveEducations implements ProfileEvent {
  const factory _SaveEducations(List<EducationStandard> educations) =
      _$_SaveEducations;

  List<EducationStandard> get educations;
  _$SaveEducationsCopyWith<_SaveEducations> get copyWith;
}

/// @nodoc
abstract class _$UpdateEducationsCopyWith<$Res> {
  factory _$UpdateEducationsCopyWith(
          _UpdateEducations value, $Res Function(_UpdateEducations) then) =
      __$UpdateEducationsCopyWithImpl<$Res>;
  $Res call({List<EducationStandard> educations});
}

/// @nodoc
class __$UpdateEducationsCopyWithImpl<$Res>
    extends _$ProfileEventCopyWithImpl<$Res>
    implements _$UpdateEducationsCopyWith<$Res> {
  __$UpdateEducationsCopyWithImpl(
      _UpdateEducations _value, $Res Function(_UpdateEducations) _then)
      : super(_value, (v) => _then(v as _UpdateEducations));

  @override
  _UpdateEducations get _value => super._value as _UpdateEducations;

  @override
  $Res call({
    Object educations = freezed,
  }) {
    return _then(_UpdateEducations(
      educations == freezed
          ? _value.educations
          : educations as List<EducationStandard>,
    ));
  }
}

/// @nodoc
class _$_UpdateEducations implements _UpdateEducations {
  const _$_UpdateEducations(this.educations) : assert(educations != null);

  @override
  final List<EducationStandard> educations;

  @override
  String toString() {
    return 'ProfileEvent.updateEducation(educations: $educations)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other is _UpdateEducations &&
            (identical(other.educations, educations) ||
                const DeepCollectionEquality()
                    .equals(other.educations, educations)));
  }

  @override
  int get hashCode =>
      runtimeType.hashCode ^ const DeepCollectionEquality().hash(educations);

  @override
  _$UpdateEducationsCopyWith<_UpdateEducations> get copyWith =>
      __$UpdateEducationsCopyWithImpl<_UpdateEducations>(this, _$identity);

  @override
  @optionalTypeArgs
  Result when<Result extends Object>({
    @required Result submitUserProfile(),
    @required Result getUserProfile(),
    @required Result getCountries(),
    @required Result updateAvatar(String avatar),
    @required
        Result saveSocialMedia(
            String facebookUserName,
            String instagramUserName,
            String twitterUserName,
            String linkedinUserName),
    @required
        Result saveAbout(String month, String day, String year, String country,
            String state, String phoneNumber),
    @required Result saveSkills(List<Domain> domains),
    @required Result updateSkills(Domain domain),
    @required Result saveEducation(List<EducationStandard> educations),
    @required Result updateEducation(List<EducationStandard> educations),
    @required Result saveCertificates(Certificate certificates),
    @required Result updateCertificates(Certificate certificates),
    @required Result deleteCertificate(Certificate certificate),
    @required Result deleteEducation(EducationStandard education),
    @required Result deleteSkill(Domain domain),
  }) {
    assert(submitUserProfile != null);
    assert(getUserProfile != null);
    assert(getCountries != null);
    assert(updateAvatar != null);
    assert(saveSocialMedia != null);
    assert(saveAbout != null);
    assert(saveSkills != null);
    assert(updateSkills != null);
    assert(saveEducation != null);
    assert(updateEducation != null);
    assert(saveCertificates != null);
    assert(updateCertificates != null);
    assert(deleteCertificate != null);
    assert(deleteEducation != null);
    assert(deleteSkill != null);
    return updateEducation(educations);
  }

  @override
  @optionalTypeArgs
  Result maybeWhen<Result extends Object>({
    Result submitUserProfile(),
    Result getUserProfile(),
    Result getCountries(),
    Result updateAvatar(String avatar),
    Result saveSocialMedia(String facebookUserName, String instagramUserName,
        String twitterUserName, String linkedinUserName),
    Result saveAbout(String month, String day, String year, String country,
        String state, String phoneNumber),
    Result saveSkills(List<Domain> domains),
    Result updateSkills(Domain domain),
    Result saveEducation(List<EducationStandard> educations),
    Result updateEducation(List<EducationStandard> educations),
    Result saveCertificates(Certificate certificates),
    Result updateCertificates(Certificate certificates),
    Result deleteCertificate(Certificate certificate),
    Result deleteEducation(EducationStandard education),
    Result deleteSkill(Domain domain),
    @required Result orElse(),
  }) {
    assert(orElse != null);
    if (updateEducation != null) {
      return updateEducation(educations);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  Result map<Result extends Object>({
    @required Result submitUserProfile(_SubmitUserProfile value),
    @required Result getUserProfile(_GetUserProfile value),
    @required Result getCountries(_GetCountries value),
    @required Result updateAvatar(_AvatarUpdate value),
    @required Result saveSocialMedia(_SaveSocialMediaHandles value),
    @required Result saveAbout(_SaveAbout value),
    @required Result saveSkills(_SaveSkills value),
    @required Result updateSkills(_UpdateSkill value),
    @required Result saveEducation(_SaveEducations value),
    @required Result updateEducation(_UpdateEducations value),
    @required Result saveCertificates(_SaveCertificates value),
    @required Result updateCertificates(_UpdateCertificates value),
    @required Result deleteCertificate(_DeleteCertificate value),
    @required Result deleteEducation(_DeleteEducation value),
    @required Result deleteSkill(_DeleteDomain value),
  }) {
    assert(submitUserProfile != null);
    assert(getUserProfile != null);
    assert(getCountries != null);
    assert(updateAvatar != null);
    assert(saveSocialMedia != null);
    assert(saveAbout != null);
    assert(saveSkills != null);
    assert(updateSkills != null);
    assert(saveEducation != null);
    assert(updateEducation != null);
    assert(saveCertificates != null);
    assert(updateCertificates != null);
    assert(deleteCertificate != null);
    assert(deleteEducation != null);
    assert(deleteSkill != null);
    return updateEducation(this);
  }

  @override
  @optionalTypeArgs
  Result maybeMap<Result extends Object>({
    Result submitUserProfile(_SubmitUserProfile value),
    Result getUserProfile(_GetUserProfile value),
    Result getCountries(_GetCountries value),
    Result updateAvatar(_AvatarUpdate value),
    Result saveSocialMedia(_SaveSocialMediaHandles value),
    Result saveAbout(_SaveAbout value),
    Result saveSkills(_SaveSkills value),
    Result updateSkills(_UpdateSkill value),
    Result saveEducation(_SaveEducations value),
    Result updateEducation(_UpdateEducations value),
    Result saveCertificates(_SaveCertificates value),
    Result updateCertificates(_UpdateCertificates value),
    Result deleteCertificate(_DeleteCertificate value),
    Result deleteEducation(_DeleteEducation value),
    Result deleteSkill(_DeleteDomain value),
    @required Result orElse(),
  }) {
    assert(orElse != null);
    if (updateEducation != null) {
      return updateEducation(this);
    }
    return orElse();
  }
}

abstract class _UpdateEducations implements ProfileEvent {
  const factory _UpdateEducations(List<EducationStandard> educations) =
      _$_UpdateEducations;

  List<EducationStandard> get educations;
  _$UpdateEducationsCopyWith<_UpdateEducations> get copyWith;
}

/// @nodoc
abstract class _$SaveCertificatesCopyWith<$Res> {
  factory _$SaveCertificatesCopyWith(
          _SaveCertificates value, $Res Function(_SaveCertificates) then) =
      __$SaveCertificatesCopyWithImpl<$Res>;
  $Res call({Certificate certificates});
}

/// @nodoc
class __$SaveCertificatesCopyWithImpl<$Res>
    extends _$ProfileEventCopyWithImpl<$Res>
    implements _$SaveCertificatesCopyWith<$Res> {
  __$SaveCertificatesCopyWithImpl(
      _SaveCertificates _value, $Res Function(_SaveCertificates) _then)
      : super(_value, (v) => _then(v as _SaveCertificates));

  @override
  _SaveCertificates get _value => super._value as _SaveCertificates;

  @override
  $Res call({
    Object certificates = freezed,
  }) {
    return _then(_SaveCertificates(
      certificates == freezed
          ? _value.certificates
          : certificates as Certificate,
    ));
  }
}

/// @nodoc
class _$_SaveCertificates implements _SaveCertificates {
  const _$_SaveCertificates(this.certificates) : assert(certificates != null);

  @override
  final Certificate certificates;

  @override
  String toString() {
    return 'ProfileEvent.saveCertificates(certificates: $certificates)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other is _SaveCertificates &&
            (identical(other.certificates, certificates) ||
                const DeepCollectionEquality()
                    .equals(other.certificates, certificates)));
  }

  @override
  int get hashCode =>
      runtimeType.hashCode ^ const DeepCollectionEquality().hash(certificates);

  @override
  _$SaveCertificatesCopyWith<_SaveCertificates> get copyWith =>
      __$SaveCertificatesCopyWithImpl<_SaveCertificates>(this, _$identity);

  @override
  @optionalTypeArgs
  Result when<Result extends Object>({
    @required Result submitUserProfile(),
    @required Result getUserProfile(),
    @required Result getCountries(),
    @required Result updateAvatar(String avatar),
    @required
        Result saveSocialMedia(
            String facebookUserName,
            String instagramUserName,
            String twitterUserName,
            String linkedinUserName),
    @required
        Result saveAbout(String month, String day, String year, String country,
            String state, String phoneNumber),
    @required Result saveSkills(List<Domain> domains),
    @required Result updateSkills(Domain domain),
    @required Result saveEducation(List<EducationStandard> educations),
    @required Result updateEducation(List<EducationStandard> educations),
    @required Result saveCertificates(Certificate certificates),
    @required Result updateCertificates(Certificate certificates),
    @required Result deleteCertificate(Certificate certificate),
    @required Result deleteEducation(EducationStandard education),
    @required Result deleteSkill(Domain domain),
  }) {
    assert(submitUserProfile != null);
    assert(getUserProfile != null);
    assert(getCountries != null);
    assert(updateAvatar != null);
    assert(saveSocialMedia != null);
    assert(saveAbout != null);
    assert(saveSkills != null);
    assert(updateSkills != null);
    assert(saveEducation != null);
    assert(updateEducation != null);
    assert(saveCertificates != null);
    assert(updateCertificates != null);
    assert(deleteCertificate != null);
    assert(deleteEducation != null);
    assert(deleteSkill != null);
    return saveCertificates(certificates);
  }

  @override
  @optionalTypeArgs
  Result maybeWhen<Result extends Object>({
    Result submitUserProfile(),
    Result getUserProfile(),
    Result getCountries(),
    Result updateAvatar(String avatar),
    Result saveSocialMedia(String facebookUserName, String instagramUserName,
        String twitterUserName, String linkedinUserName),
    Result saveAbout(String month, String day, String year, String country,
        String state, String phoneNumber),
    Result saveSkills(List<Domain> domains),
    Result updateSkills(Domain domain),
    Result saveEducation(List<EducationStandard> educations),
    Result updateEducation(List<EducationStandard> educations),
    Result saveCertificates(Certificate certificates),
    Result updateCertificates(Certificate certificates),
    Result deleteCertificate(Certificate certificate),
    Result deleteEducation(EducationStandard education),
    Result deleteSkill(Domain domain),
    @required Result orElse(),
  }) {
    assert(orElse != null);
    if (saveCertificates != null) {
      return saveCertificates(certificates);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  Result map<Result extends Object>({
    @required Result submitUserProfile(_SubmitUserProfile value),
    @required Result getUserProfile(_GetUserProfile value),
    @required Result getCountries(_GetCountries value),
    @required Result updateAvatar(_AvatarUpdate value),
    @required Result saveSocialMedia(_SaveSocialMediaHandles value),
    @required Result saveAbout(_SaveAbout value),
    @required Result saveSkills(_SaveSkills value),
    @required Result updateSkills(_UpdateSkill value),
    @required Result saveEducation(_SaveEducations value),
    @required Result updateEducation(_UpdateEducations value),
    @required Result saveCertificates(_SaveCertificates value),
    @required Result updateCertificates(_UpdateCertificates value),
    @required Result deleteCertificate(_DeleteCertificate value),
    @required Result deleteEducation(_DeleteEducation value),
    @required Result deleteSkill(_DeleteDomain value),
  }) {
    assert(submitUserProfile != null);
    assert(getUserProfile != null);
    assert(getCountries != null);
    assert(updateAvatar != null);
    assert(saveSocialMedia != null);
    assert(saveAbout != null);
    assert(saveSkills != null);
    assert(updateSkills != null);
    assert(saveEducation != null);
    assert(updateEducation != null);
    assert(saveCertificates != null);
    assert(updateCertificates != null);
    assert(deleteCertificate != null);
    assert(deleteEducation != null);
    assert(deleteSkill != null);
    return saveCertificates(this);
  }

  @override
  @optionalTypeArgs
  Result maybeMap<Result extends Object>({
    Result submitUserProfile(_SubmitUserProfile value),
    Result getUserProfile(_GetUserProfile value),
    Result getCountries(_GetCountries value),
    Result updateAvatar(_AvatarUpdate value),
    Result saveSocialMedia(_SaveSocialMediaHandles value),
    Result saveAbout(_SaveAbout value),
    Result saveSkills(_SaveSkills value),
    Result updateSkills(_UpdateSkill value),
    Result saveEducation(_SaveEducations value),
    Result updateEducation(_UpdateEducations value),
    Result saveCertificates(_SaveCertificates value),
    Result updateCertificates(_UpdateCertificates value),
    Result deleteCertificate(_DeleteCertificate value),
    Result deleteEducation(_DeleteEducation value),
    Result deleteSkill(_DeleteDomain value),
    @required Result orElse(),
  }) {
    assert(orElse != null);
    if (saveCertificates != null) {
      return saveCertificates(this);
    }
    return orElse();
  }
}

abstract class _SaveCertificates implements ProfileEvent {
  const factory _SaveCertificates(Certificate certificates) =
      _$_SaveCertificates;

  Certificate get certificates;
  _$SaveCertificatesCopyWith<_SaveCertificates> get copyWith;
}

/// @nodoc
abstract class _$UpdateCertificatesCopyWith<$Res> {
  factory _$UpdateCertificatesCopyWith(
          _UpdateCertificates value, $Res Function(_UpdateCertificates) then) =
      __$UpdateCertificatesCopyWithImpl<$Res>;
  $Res call({Certificate certificates});
}

/// @nodoc
class __$UpdateCertificatesCopyWithImpl<$Res>
    extends _$ProfileEventCopyWithImpl<$Res>
    implements _$UpdateCertificatesCopyWith<$Res> {
  __$UpdateCertificatesCopyWithImpl(
      _UpdateCertificates _value, $Res Function(_UpdateCertificates) _then)
      : super(_value, (v) => _then(v as _UpdateCertificates));

  @override
  _UpdateCertificates get _value => super._value as _UpdateCertificates;

  @override
  $Res call({
    Object certificates = freezed,
  }) {
    return _then(_UpdateCertificates(
      certificates == freezed
          ? _value.certificates
          : certificates as Certificate,
    ));
  }
}

/// @nodoc
class _$_UpdateCertificates implements _UpdateCertificates {
  const _$_UpdateCertificates(this.certificates) : assert(certificates != null);

  @override
  final Certificate certificates;

  @override
  String toString() {
    return 'ProfileEvent.updateCertificates(certificates: $certificates)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other is _UpdateCertificates &&
            (identical(other.certificates, certificates) ||
                const DeepCollectionEquality()
                    .equals(other.certificates, certificates)));
  }

  @override
  int get hashCode =>
      runtimeType.hashCode ^ const DeepCollectionEquality().hash(certificates);

  @override
  _$UpdateCertificatesCopyWith<_UpdateCertificates> get copyWith =>
      __$UpdateCertificatesCopyWithImpl<_UpdateCertificates>(this, _$identity);

  @override
  @optionalTypeArgs
  Result when<Result extends Object>({
    @required Result submitUserProfile(),
    @required Result getUserProfile(),
    @required Result getCountries(),
    @required Result updateAvatar(String avatar),
    @required
        Result saveSocialMedia(
            String facebookUserName,
            String instagramUserName,
            String twitterUserName,
            String linkedinUserName),
    @required
        Result saveAbout(String month, String day, String year, String country,
            String state, String phoneNumber),
    @required Result saveSkills(List<Domain> domains),
    @required Result updateSkills(Domain domain),
    @required Result saveEducation(List<EducationStandard> educations),
    @required Result updateEducation(List<EducationStandard> educations),
    @required Result saveCertificates(Certificate certificates),
    @required Result updateCertificates(Certificate certificates),
    @required Result deleteCertificate(Certificate certificate),
    @required Result deleteEducation(EducationStandard education),
    @required Result deleteSkill(Domain domain),
  }) {
    assert(submitUserProfile != null);
    assert(getUserProfile != null);
    assert(getCountries != null);
    assert(updateAvatar != null);
    assert(saveSocialMedia != null);
    assert(saveAbout != null);
    assert(saveSkills != null);
    assert(updateSkills != null);
    assert(saveEducation != null);
    assert(updateEducation != null);
    assert(saveCertificates != null);
    assert(updateCertificates != null);
    assert(deleteCertificate != null);
    assert(deleteEducation != null);
    assert(deleteSkill != null);
    return updateCertificates(certificates);
  }

  @override
  @optionalTypeArgs
  Result maybeWhen<Result extends Object>({
    Result submitUserProfile(),
    Result getUserProfile(),
    Result getCountries(),
    Result updateAvatar(String avatar),
    Result saveSocialMedia(String facebookUserName, String instagramUserName,
        String twitterUserName, String linkedinUserName),
    Result saveAbout(String month, String day, String year, String country,
        String state, String phoneNumber),
    Result saveSkills(List<Domain> domains),
    Result updateSkills(Domain domain),
    Result saveEducation(List<EducationStandard> educations),
    Result updateEducation(List<EducationStandard> educations),
    Result saveCertificates(Certificate certificates),
    Result updateCertificates(Certificate certificates),
    Result deleteCertificate(Certificate certificate),
    Result deleteEducation(EducationStandard education),
    Result deleteSkill(Domain domain),
    @required Result orElse(),
  }) {
    assert(orElse != null);
    if (updateCertificates != null) {
      return updateCertificates(certificates);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  Result map<Result extends Object>({
    @required Result submitUserProfile(_SubmitUserProfile value),
    @required Result getUserProfile(_GetUserProfile value),
    @required Result getCountries(_GetCountries value),
    @required Result updateAvatar(_AvatarUpdate value),
    @required Result saveSocialMedia(_SaveSocialMediaHandles value),
    @required Result saveAbout(_SaveAbout value),
    @required Result saveSkills(_SaveSkills value),
    @required Result updateSkills(_UpdateSkill value),
    @required Result saveEducation(_SaveEducations value),
    @required Result updateEducation(_UpdateEducations value),
    @required Result saveCertificates(_SaveCertificates value),
    @required Result updateCertificates(_UpdateCertificates value),
    @required Result deleteCertificate(_DeleteCertificate value),
    @required Result deleteEducation(_DeleteEducation value),
    @required Result deleteSkill(_DeleteDomain value),
  }) {
    assert(submitUserProfile != null);
    assert(getUserProfile != null);
    assert(getCountries != null);
    assert(updateAvatar != null);
    assert(saveSocialMedia != null);
    assert(saveAbout != null);
    assert(saveSkills != null);
    assert(updateSkills != null);
    assert(saveEducation != null);
    assert(updateEducation != null);
    assert(saveCertificates != null);
    assert(updateCertificates != null);
    assert(deleteCertificate != null);
    assert(deleteEducation != null);
    assert(deleteSkill != null);
    return updateCertificates(this);
  }

  @override
  @optionalTypeArgs
  Result maybeMap<Result extends Object>({
    Result submitUserProfile(_SubmitUserProfile value),
    Result getUserProfile(_GetUserProfile value),
    Result getCountries(_GetCountries value),
    Result updateAvatar(_AvatarUpdate value),
    Result saveSocialMedia(_SaveSocialMediaHandles value),
    Result saveAbout(_SaveAbout value),
    Result saveSkills(_SaveSkills value),
    Result updateSkills(_UpdateSkill value),
    Result saveEducation(_SaveEducations value),
    Result updateEducation(_UpdateEducations value),
    Result saveCertificates(_SaveCertificates value),
    Result updateCertificates(_UpdateCertificates value),
    Result deleteCertificate(_DeleteCertificate value),
    Result deleteEducation(_DeleteEducation value),
    Result deleteSkill(_DeleteDomain value),
    @required Result orElse(),
  }) {
    assert(orElse != null);
    if (updateCertificates != null) {
      return updateCertificates(this);
    }
    return orElse();
  }
}

abstract class _UpdateCertificates implements ProfileEvent {
  const factory _UpdateCertificates(Certificate certificates) =
      _$_UpdateCertificates;

  Certificate get certificates;
  _$UpdateCertificatesCopyWith<_UpdateCertificates> get copyWith;
}

/// @nodoc
abstract class _$DeleteCertificateCopyWith<$Res> {
  factory _$DeleteCertificateCopyWith(
          _DeleteCertificate value, $Res Function(_DeleteCertificate) then) =
      __$DeleteCertificateCopyWithImpl<$Res>;
  $Res call({Certificate certificate});
}

/// @nodoc
class __$DeleteCertificateCopyWithImpl<$Res>
    extends _$ProfileEventCopyWithImpl<$Res>
    implements _$DeleteCertificateCopyWith<$Res> {
  __$DeleteCertificateCopyWithImpl(
      _DeleteCertificate _value, $Res Function(_DeleteCertificate) _then)
      : super(_value, (v) => _then(v as _DeleteCertificate));

  @override
  _DeleteCertificate get _value => super._value as _DeleteCertificate;

  @override
  $Res call({
    Object certificate = freezed,
  }) {
    return _then(_DeleteCertificate(
      certificate == freezed ? _value.certificate : certificate as Certificate,
    ));
  }
}

/// @nodoc
class _$_DeleteCertificate implements _DeleteCertificate {
  const _$_DeleteCertificate(this.certificate) : assert(certificate != null);

  @override
  final Certificate certificate;

  @override
  String toString() {
    return 'ProfileEvent.deleteCertificate(certificate: $certificate)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other is _DeleteCertificate &&
            (identical(other.certificate, certificate) ||
                const DeepCollectionEquality()
                    .equals(other.certificate, certificate)));
  }

  @override
  int get hashCode =>
      runtimeType.hashCode ^ const DeepCollectionEquality().hash(certificate);

  @override
  _$DeleteCertificateCopyWith<_DeleteCertificate> get copyWith =>
      __$DeleteCertificateCopyWithImpl<_DeleteCertificate>(this, _$identity);

  @override
  @optionalTypeArgs
  Result when<Result extends Object>({
    @required Result submitUserProfile(),
    @required Result getUserProfile(),
    @required Result getCountries(),
    @required Result updateAvatar(String avatar),
    @required
        Result saveSocialMedia(
            String facebookUserName,
            String instagramUserName,
            String twitterUserName,
            String linkedinUserName),
    @required
        Result saveAbout(String month, String day, String year, String country,
            String state, String phoneNumber),
    @required Result saveSkills(List<Domain> domains),
    @required Result updateSkills(Domain domain),
    @required Result saveEducation(List<EducationStandard> educations),
    @required Result updateEducation(List<EducationStandard> educations),
    @required Result saveCertificates(Certificate certificates),
    @required Result updateCertificates(Certificate certificates),
    @required Result deleteCertificate(Certificate certificate),
    @required Result deleteEducation(EducationStandard education),
    @required Result deleteSkill(Domain domain),
  }) {
    assert(submitUserProfile != null);
    assert(getUserProfile != null);
    assert(getCountries != null);
    assert(updateAvatar != null);
    assert(saveSocialMedia != null);
    assert(saveAbout != null);
    assert(saveSkills != null);
    assert(updateSkills != null);
    assert(saveEducation != null);
    assert(updateEducation != null);
    assert(saveCertificates != null);
    assert(updateCertificates != null);
    assert(deleteCertificate != null);
    assert(deleteEducation != null);
    assert(deleteSkill != null);
    return deleteCertificate(certificate);
  }

  @override
  @optionalTypeArgs
  Result maybeWhen<Result extends Object>({
    Result submitUserProfile(),
    Result getUserProfile(),
    Result getCountries(),
    Result updateAvatar(String avatar),
    Result saveSocialMedia(String facebookUserName, String instagramUserName,
        String twitterUserName, String linkedinUserName),
    Result saveAbout(String month, String day, String year, String country,
        String state, String phoneNumber),
    Result saveSkills(List<Domain> domains),
    Result updateSkills(Domain domain),
    Result saveEducation(List<EducationStandard> educations),
    Result updateEducation(List<EducationStandard> educations),
    Result saveCertificates(Certificate certificates),
    Result updateCertificates(Certificate certificates),
    Result deleteCertificate(Certificate certificate),
    Result deleteEducation(EducationStandard education),
    Result deleteSkill(Domain domain),
    @required Result orElse(),
  }) {
    assert(orElse != null);
    if (deleteCertificate != null) {
      return deleteCertificate(certificate);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  Result map<Result extends Object>({
    @required Result submitUserProfile(_SubmitUserProfile value),
    @required Result getUserProfile(_GetUserProfile value),
    @required Result getCountries(_GetCountries value),
    @required Result updateAvatar(_AvatarUpdate value),
    @required Result saveSocialMedia(_SaveSocialMediaHandles value),
    @required Result saveAbout(_SaveAbout value),
    @required Result saveSkills(_SaveSkills value),
    @required Result updateSkills(_UpdateSkill value),
    @required Result saveEducation(_SaveEducations value),
    @required Result updateEducation(_UpdateEducations value),
    @required Result saveCertificates(_SaveCertificates value),
    @required Result updateCertificates(_UpdateCertificates value),
    @required Result deleteCertificate(_DeleteCertificate value),
    @required Result deleteEducation(_DeleteEducation value),
    @required Result deleteSkill(_DeleteDomain value),
  }) {
    assert(submitUserProfile != null);
    assert(getUserProfile != null);
    assert(getCountries != null);
    assert(updateAvatar != null);
    assert(saveSocialMedia != null);
    assert(saveAbout != null);
    assert(saveSkills != null);
    assert(updateSkills != null);
    assert(saveEducation != null);
    assert(updateEducation != null);
    assert(saveCertificates != null);
    assert(updateCertificates != null);
    assert(deleteCertificate != null);
    assert(deleteEducation != null);
    assert(deleteSkill != null);
    return deleteCertificate(this);
  }

  @override
  @optionalTypeArgs
  Result maybeMap<Result extends Object>({
    Result submitUserProfile(_SubmitUserProfile value),
    Result getUserProfile(_GetUserProfile value),
    Result getCountries(_GetCountries value),
    Result updateAvatar(_AvatarUpdate value),
    Result saveSocialMedia(_SaveSocialMediaHandles value),
    Result saveAbout(_SaveAbout value),
    Result saveSkills(_SaveSkills value),
    Result updateSkills(_UpdateSkill value),
    Result saveEducation(_SaveEducations value),
    Result updateEducation(_UpdateEducations value),
    Result saveCertificates(_SaveCertificates value),
    Result updateCertificates(_UpdateCertificates value),
    Result deleteCertificate(_DeleteCertificate value),
    Result deleteEducation(_DeleteEducation value),
    Result deleteSkill(_DeleteDomain value),
    @required Result orElse(),
  }) {
    assert(orElse != null);
    if (deleteCertificate != null) {
      return deleteCertificate(this);
    }
    return orElse();
  }
}

abstract class _DeleteCertificate implements ProfileEvent {
  const factory _DeleteCertificate(Certificate certificate) =
      _$_DeleteCertificate;

  Certificate get certificate;
  _$DeleteCertificateCopyWith<_DeleteCertificate> get copyWith;
}

/// @nodoc
abstract class _$DeleteEducationCopyWith<$Res> {
  factory _$DeleteEducationCopyWith(
          _DeleteEducation value, $Res Function(_DeleteEducation) then) =
      __$DeleteEducationCopyWithImpl<$Res>;
  $Res call({EducationStandard education});
}

/// @nodoc
class __$DeleteEducationCopyWithImpl<$Res>
    extends _$ProfileEventCopyWithImpl<$Res>
    implements _$DeleteEducationCopyWith<$Res> {
  __$DeleteEducationCopyWithImpl(
      _DeleteEducation _value, $Res Function(_DeleteEducation) _then)
      : super(_value, (v) => _then(v as _DeleteEducation));

  @override
  _DeleteEducation get _value => super._value as _DeleteEducation;

  @override
  $Res call({
    Object education = freezed,
  }) {
    return _then(_DeleteEducation(
      education == freezed ? _value.education : education as EducationStandard,
    ));
  }
}

/// @nodoc
class _$_DeleteEducation implements _DeleteEducation {
  const _$_DeleteEducation(this.education) : assert(education != null);

  @override
  final EducationStandard education;

  @override
  String toString() {
    return 'ProfileEvent.deleteEducation(education: $education)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other is _DeleteEducation &&
            (identical(other.education, education) ||
                const DeepCollectionEquality()
                    .equals(other.education, education)));
  }

  @override
  int get hashCode =>
      runtimeType.hashCode ^ const DeepCollectionEquality().hash(education);

  @override
  _$DeleteEducationCopyWith<_DeleteEducation> get copyWith =>
      __$DeleteEducationCopyWithImpl<_DeleteEducation>(this, _$identity);

  @override
  @optionalTypeArgs
  Result when<Result extends Object>({
    @required Result submitUserProfile(),
    @required Result getUserProfile(),
    @required Result getCountries(),
    @required Result updateAvatar(String avatar),
    @required
        Result saveSocialMedia(
            String facebookUserName,
            String instagramUserName,
            String twitterUserName,
            String linkedinUserName),
    @required
        Result saveAbout(String month, String day, String year, String country,
            String state, String phoneNumber),
    @required Result saveSkills(List<Domain> domains),
    @required Result updateSkills(Domain domain),
    @required Result saveEducation(List<EducationStandard> educations),
    @required Result updateEducation(List<EducationStandard> educations),
    @required Result saveCertificates(Certificate certificates),
    @required Result updateCertificates(Certificate certificates),
    @required Result deleteCertificate(Certificate certificate),
    @required Result deleteEducation(EducationStandard education),
    @required Result deleteSkill(Domain domain),
  }) {
    assert(submitUserProfile != null);
    assert(getUserProfile != null);
    assert(getCountries != null);
    assert(updateAvatar != null);
    assert(saveSocialMedia != null);
    assert(saveAbout != null);
    assert(saveSkills != null);
    assert(updateSkills != null);
    assert(saveEducation != null);
    assert(updateEducation != null);
    assert(saveCertificates != null);
    assert(updateCertificates != null);
    assert(deleteCertificate != null);
    assert(deleteEducation != null);
    assert(deleteSkill != null);
    return deleteEducation(education);
  }

  @override
  @optionalTypeArgs
  Result maybeWhen<Result extends Object>({
    Result submitUserProfile(),
    Result getUserProfile(),
    Result getCountries(),
    Result updateAvatar(String avatar),
    Result saveSocialMedia(String facebookUserName, String instagramUserName,
        String twitterUserName, String linkedinUserName),
    Result saveAbout(String month, String day, String year, String country,
        String state, String phoneNumber),
    Result saveSkills(List<Domain> domains),
    Result updateSkills(Domain domain),
    Result saveEducation(List<EducationStandard> educations),
    Result updateEducation(List<EducationStandard> educations),
    Result saveCertificates(Certificate certificates),
    Result updateCertificates(Certificate certificates),
    Result deleteCertificate(Certificate certificate),
    Result deleteEducation(EducationStandard education),
    Result deleteSkill(Domain domain),
    @required Result orElse(),
  }) {
    assert(orElse != null);
    if (deleteEducation != null) {
      return deleteEducation(education);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  Result map<Result extends Object>({
    @required Result submitUserProfile(_SubmitUserProfile value),
    @required Result getUserProfile(_GetUserProfile value),
    @required Result getCountries(_GetCountries value),
    @required Result updateAvatar(_AvatarUpdate value),
    @required Result saveSocialMedia(_SaveSocialMediaHandles value),
    @required Result saveAbout(_SaveAbout value),
    @required Result saveSkills(_SaveSkills value),
    @required Result updateSkills(_UpdateSkill value),
    @required Result saveEducation(_SaveEducations value),
    @required Result updateEducation(_UpdateEducations value),
    @required Result saveCertificates(_SaveCertificates value),
    @required Result updateCertificates(_UpdateCertificates value),
    @required Result deleteCertificate(_DeleteCertificate value),
    @required Result deleteEducation(_DeleteEducation value),
    @required Result deleteSkill(_DeleteDomain value),
  }) {
    assert(submitUserProfile != null);
    assert(getUserProfile != null);
    assert(getCountries != null);
    assert(updateAvatar != null);
    assert(saveSocialMedia != null);
    assert(saveAbout != null);
    assert(saveSkills != null);
    assert(updateSkills != null);
    assert(saveEducation != null);
    assert(updateEducation != null);
    assert(saveCertificates != null);
    assert(updateCertificates != null);
    assert(deleteCertificate != null);
    assert(deleteEducation != null);
    assert(deleteSkill != null);
    return deleteEducation(this);
  }

  @override
  @optionalTypeArgs
  Result maybeMap<Result extends Object>({
    Result submitUserProfile(_SubmitUserProfile value),
    Result getUserProfile(_GetUserProfile value),
    Result getCountries(_GetCountries value),
    Result updateAvatar(_AvatarUpdate value),
    Result saveSocialMedia(_SaveSocialMediaHandles value),
    Result saveAbout(_SaveAbout value),
    Result saveSkills(_SaveSkills value),
    Result updateSkills(_UpdateSkill value),
    Result saveEducation(_SaveEducations value),
    Result updateEducation(_UpdateEducations value),
    Result saveCertificates(_SaveCertificates value),
    Result updateCertificates(_UpdateCertificates value),
    Result deleteCertificate(_DeleteCertificate value),
    Result deleteEducation(_DeleteEducation value),
    Result deleteSkill(_DeleteDomain value),
    @required Result orElse(),
  }) {
    assert(orElse != null);
    if (deleteEducation != null) {
      return deleteEducation(this);
    }
    return orElse();
  }
}

abstract class _DeleteEducation implements ProfileEvent {
  const factory _DeleteEducation(EducationStandard education) =
      _$_DeleteEducation;

  EducationStandard get education;
  _$DeleteEducationCopyWith<_DeleteEducation> get copyWith;
}

/// @nodoc
abstract class _$DeleteDomainCopyWith<$Res> {
  factory _$DeleteDomainCopyWith(
          _DeleteDomain value, $Res Function(_DeleteDomain) then) =
      __$DeleteDomainCopyWithImpl<$Res>;
  $Res call({Domain domain});
}

/// @nodoc
class __$DeleteDomainCopyWithImpl<$Res> extends _$ProfileEventCopyWithImpl<$Res>
    implements _$DeleteDomainCopyWith<$Res> {
  __$DeleteDomainCopyWithImpl(
      _DeleteDomain _value, $Res Function(_DeleteDomain) _then)
      : super(_value, (v) => _then(v as _DeleteDomain));

  @override
  _DeleteDomain get _value => super._value as _DeleteDomain;

  @override
  $Res call({
    Object domain = freezed,
  }) {
    return _then(_DeleteDomain(
      domain == freezed ? _value.domain : domain as Domain,
    ));
  }
}

/// @nodoc
class _$_DeleteDomain implements _DeleteDomain {
  const _$_DeleteDomain(this.domain) : assert(domain != null);

  @override
  final Domain domain;

  @override
  String toString() {
    return 'ProfileEvent.deleteSkill(domain: $domain)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other is _DeleteDomain &&
            (identical(other.domain, domain) ||
                const DeepCollectionEquality().equals(other.domain, domain)));
  }

  @override
  int get hashCode =>
      runtimeType.hashCode ^ const DeepCollectionEquality().hash(domain);

  @override
  _$DeleteDomainCopyWith<_DeleteDomain> get copyWith =>
      __$DeleteDomainCopyWithImpl<_DeleteDomain>(this, _$identity);

  @override
  @optionalTypeArgs
  Result when<Result extends Object>({
    @required Result submitUserProfile(),
    @required Result getUserProfile(),
    @required Result getCountries(),
    @required Result updateAvatar(String avatar),
    @required
        Result saveSocialMedia(
            String facebookUserName,
            String instagramUserName,
            String twitterUserName,
            String linkedinUserName),
    @required
        Result saveAbout(String month, String day, String year, String country,
            String state, String phoneNumber),
    @required Result saveSkills(List<Domain> domains),
    @required Result updateSkills(Domain domain),
    @required Result saveEducation(List<EducationStandard> educations),
    @required Result updateEducation(List<EducationStandard> educations),
    @required Result saveCertificates(Certificate certificates),
    @required Result updateCertificates(Certificate certificates),
    @required Result deleteCertificate(Certificate certificate),
    @required Result deleteEducation(EducationStandard education),
    @required Result deleteSkill(Domain domain),
  }) {
    assert(submitUserProfile != null);
    assert(getUserProfile != null);
    assert(getCountries != null);
    assert(updateAvatar != null);
    assert(saveSocialMedia != null);
    assert(saveAbout != null);
    assert(saveSkills != null);
    assert(updateSkills != null);
    assert(saveEducation != null);
    assert(updateEducation != null);
    assert(saveCertificates != null);
    assert(updateCertificates != null);
    assert(deleteCertificate != null);
    assert(deleteEducation != null);
    assert(deleteSkill != null);
    return deleteSkill(domain);
  }

  @override
  @optionalTypeArgs
  Result maybeWhen<Result extends Object>({
    Result submitUserProfile(),
    Result getUserProfile(),
    Result getCountries(),
    Result updateAvatar(String avatar),
    Result saveSocialMedia(String facebookUserName, String instagramUserName,
        String twitterUserName, String linkedinUserName),
    Result saveAbout(String month, String day, String year, String country,
        String state, String phoneNumber),
    Result saveSkills(List<Domain> domains),
    Result updateSkills(Domain domain),
    Result saveEducation(List<EducationStandard> educations),
    Result updateEducation(List<EducationStandard> educations),
    Result saveCertificates(Certificate certificates),
    Result updateCertificates(Certificate certificates),
    Result deleteCertificate(Certificate certificate),
    Result deleteEducation(EducationStandard education),
    Result deleteSkill(Domain domain),
    @required Result orElse(),
  }) {
    assert(orElse != null);
    if (deleteSkill != null) {
      return deleteSkill(domain);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  Result map<Result extends Object>({
    @required Result submitUserProfile(_SubmitUserProfile value),
    @required Result getUserProfile(_GetUserProfile value),
    @required Result getCountries(_GetCountries value),
    @required Result updateAvatar(_AvatarUpdate value),
    @required Result saveSocialMedia(_SaveSocialMediaHandles value),
    @required Result saveAbout(_SaveAbout value),
    @required Result saveSkills(_SaveSkills value),
    @required Result updateSkills(_UpdateSkill value),
    @required Result saveEducation(_SaveEducations value),
    @required Result updateEducation(_UpdateEducations value),
    @required Result saveCertificates(_SaveCertificates value),
    @required Result updateCertificates(_UpdateCertificates value),
    @required Result deleteCertificate(_DeleteCertificate value),
    @required Result deleteEducation(_DeleteEducation value),
    @required Result deleteSkill(_DeleteDomain value),
  }) {
    assert(submitUserProfile != null);
    assert(getUserProfile != null);
    assert(getCountries != null);
    assert(updateAvatar != null);
    assert(saveSocialMedia != null);
    assert(saveAbout != null);
    assert(saveSkills != null);
    assert(updateSkills != null);
    assert(saveEducation != null);
    assert(updateEducation != null);
    assert(saveCertificates != null);
    assert(updateCertificates != null);
    assert(deleteCertificate != null);
    assert(deleteEducation != null);
    assert(deleteSkill != null);
    return deleteSkill(this);
  }

  @override
  @optionalTypeArgs
  Result maybeMap<Result extends Object>({
    Result submitUserProfile(_SubmitUserProfile value),
    Result getUserProfile(_GetUserProfile value),
    Result getCountries(_GetCountries value),
    Result updateAvatar(_AvatarUpdate value),
    Result saveSocialMedia(_SaveSocialMediaHandles value),
    Result saveAbout(_SaveAbout value),
    Result saveSkills(_SaveSkills value),
    Result updateSkills(_UpdateSkill value),
    Result saveEducation(_SaveEducations value),
    Result updateEducation(_UpdateEducations value),
    Result saveCertificates(_SaveCertificates value),
    Result updateCertificates(_UpdateCertificates value),
    Result deleteCertificate(_DeleteCertificate value),
    Result deleteEducation(_DeleteEducation value),
    Result deleteSkill(_DeleteDomain value),
    @required Result orElse(),
  }) {
    assert(orElse != null);
    if (deleteSkill != null) {
      return deleteSkill(this);
    }
    return orElse();
  }
}

abstract class _DeleteDomain implements ProfileEvent {
  const factory _DeleteDomain(Domain domain) = _$_DeleteDomain;

  Domain get domain;
  _$DeleteDomainCopyWith<_DeleteDomain> get copyWith;
}

/// @nodoc
class _$ProfileStateTearOff {
  const _$ProfileStateTearOff();

// ignore: unused_element
  _ProfileState call(
      {String email,
      String name,
      String country,
      String age,
      String college,
      List<String> skills,
      String avatar,
      String faceBookLink,
      String instagramLink,
      String twitterLink,
      bool isInstagramLoading,
      List<Country> countries,
      Option<Either<ProfileFailure, Unit>> submitOption,
      Option<Either<ProfileFailure, Unit>> getProfileOption,
      Option<Either<ProfileFailure, Unit>> facebookOption,
      Option<Either<ProfileFailure, Unit>> twitterOption,
      Option<Either<ProfileFailure, Unit>> instagramOption,
      Option<Either<ProfileFailure, Unit>> linkedinOption,
      Option<Either<ProfileFailure, Unit>> certificateOption,
      Option<Either<ProfileFailure, Unit>> nameOption,
      Option<Either<ProfileFailure, Unit>> avatarOption,
      Option<Either<ProfileFailure, Unit>> collegeOption,
      Option<Either<ProfileFailure, Unit>> skillOption,
      Option<Either<ProfileFailure, Unit>> countryOption,
      bool showSocialMediaErrorMessages,
      Profile profile}) {
    return _ProfileState(
      email: email,
      name: name,
      country: country,
      age: age,
      college: college,
      skills: skills,
      avatar: avatar,
      faceBookLink: faceBookLink,
      instagramLink: instagramLink,
      twitterLink: twitterLink,
      isInstagramLoading: isInstagramLoading,
      countries: countries,
      submitOption: submitOption,
      getProfileOption: getProfileOption,
      facebookOption: facebookOption,
      twitterOption: twitterOption,
      instagramOption: instagramOption,
      linkedinOption: linkedinOption,
      certificateOption: certificateOption,
      nameOption: nameOption,
      avatarOption: avatarOption,
      collegeOption: collegeOption,
      skillOption: skillOption,
      countryOption: countryOption,
      showSocialMediaErrorMessages: showSocialMediaErrorMessages,
      profile: profile,
    );
  }
}

/// @nodoc
// ignore: unused_element
const $ProfileState = _$ProfileStateTearOff();

/// @nodoc
mixin _$ProfileState {
  String get email;
  String get name;
  String get country;
  String get age;
  String get college;
  List<String> get skills;
  String get avatar;
  String get faceBookLink;
  String get instagramLink;
  String get twitterLink;
  bool get isInstagramLoading;
  List<Country> get countries;
  Option<Either<ProfileFailure, Unit>> get submitOption;
  Option<Either<ProfileFailure, Unit>> get getProfileOption;
  Option<Either<ProfileFailure, Unit>> get facebookOption;
  Option<Either<ProfileFailure, Unit>> get twitterOption;
  Option<Either<ProfileFailure, Unit>> get instagramOption;
  Option<Either<ProfileFailure, Unit>> get linkedinOption;
  Option<Either<ProfileFailure, Unit>> get certificateOption;
  Option<Either<ProfileFailure, Unit>> get nameOption;
  Option<Either<ProfileFailure, Unit>> get avatarOption;
  Option<Either<ProfileFailure, Unit>> get collegeOption;
  Option<Either<ProfileFailure, Unit>> get skillOption;
  Option<Either<ProfileFailure, Unit>> get countryOption;
  bool get showSocialMediaErrorMessages;
  Profile get profile;

  $ProfileStateCopyWith<ProfileState> get copyWith;
}

/// @nodoc
abstract class $ProfileStateCopyWith<$Res> {
  factory $ProfileStateCopyWith(
          ProfileState value, $Res Function(ProfileState) then) =
      _$ProfileStateCopyWithImpl<$Res>;
  $Res call(
      {String email,
      String name,
      String country,
      String age,
      String college,
      List<String> skills,
      String avatar,
      String faceBookLink,
      String instagramLink,
      String twitterLink,
      bool isInstagramLoading,
      List<Country> countries,
      Option<Either<ProfileFailure, Unit>> submitOption,
      Option<Either<ProfileFailure, Unit>> getProfileOption,
      Option<Either<ProfileFailure, Unit>> facebookOption,
      Option<Either<ProfileFailure, Unit>> twitterOption,
      Option<Either<ProfileFailure, Unit>> instagramOption,
      Option<Either<ProfileFailure, Unit>> linkedinOption,
      Option<Either<ProfileFailure, Unit>> certificateOption,
      Option<Either<ProfileFailure, Unit>> nameOption,
      Option<Either<ProfileFailure, Unit>> avatarOption,
      Option<Either<ProfileFailure, Unit>> collegeOption,
      Option<Either<ProfileFailure, Unit>> skillOption,
      Option<Either<ProfileFailure, Unit>> countryOption,
      bool showSocialMediaErrorMessages,
      Profile profile});
}

/// @nodoc
class _$ProfileStateCopyWithImpl<$Res> implements $ProfileStateCopyWith<$Res> {
  _$ProfileStateCopyWithImpl(this._value, this._then);

  final ProfileState _value;
  // ignore: unused_field
  final $Res Function(ProfileState) _then;

  @override
  $Res call({
    Object email = freezed,
    Object name = freezed,
    Object country = freezed,
    Object age = freezed,
    Object college = freezed,
    Object skills = freezed,
    Object avatar = freezed,
    Object faceBookLink = freezed,
    Object instagramLink = freezed,
    Object twitterLink = freezed,
    Object isInstagramLoading = freezed,
    Object countries = freezed,
    Object submitOption = freezed,
    Object getProfileOption = freezed,
    Object facebookOption = freezed,
    Object twitterOption = freezed,
    Object instagramOption = freezed,
    Object linkedinOption = freezed,
    Object certificateOption = freezed,
    Object nameOption = freezed,
    Object avatarOption = freezed,
    Object collegeOption = freezed,
    Object skillOption = freezed,
    Object countryOption = freezed,
    Object showSocialMediaErrorMessages = freezed,
    Object profile = freezed,
  }) {
    return _then(_value.copyWith(
      email: email == freezed ? _value.email : email as String,
      name: name == freezed ? _value.name : name as String,
      country: country == freezed ? _value.country : country as String,
      age: age == freezed ? _value.age : age as String,
      college: college == freezed ? _value.college : college as String,
      skills: skills == freezed ? _value.skills : skills as List<String>,
      avatar: avatar == freezed ? _value.avatar : avatar as String,
      faceBookLink: faceBookLink == freezed
          ? _value.faceBookLink
          : faceBookLink as String,
      instagramLink: instagramLink == freezed
          ? _value.instagramLink
          : instagramLink as String,
      twitterLink:
          twitterLink == freezed ? _value.twitterLink : twitterLink as String,
      isInstagramLoading: isInstagramLoading == freezed
          ? _value.isInstagramLoading
          : isInstagramLoading as bool,
      countries:
          countries == freezed ? _value.countries : countries as List<Country>,
      submitOption: submitOption == freezed
          ? _value.submitOption
          : submitOption as Option<Either<ProfileFailure, Unit>>,
      getProfileOption: getProfileOption == freezed
          ? _value.getProfileOption
          : getProfileOption as Option<Either<ProfileFailure, Unit>>,
      facebookOption: facebookOption == freezed
          ? _value.facebookOption
          : facebookOption as Option<Either<ProfileFailure, Unit>>,
      twitterOption: twitterOption == freezed
          ? _value.twitterOption
          : twitterOption as Option<Either<ProfileFailure, Unit>>,
      instagramOption: instagramOption == freezed
          ? _value.instagramOption
          : instagramOption as Option<Either<ProfileFailure, Unit>>,
      linkedinOption: linkedinOption == freezed
          ? _value.linkedinOption
          : linkedinOption as Option<Either<ProfileFailure, Unit>>,
      certificateOption: certificateOption == freezed
          ? _value.certificateOption
          : certificateOption as Option<Either<ProfileFailure, Unit>>,
      nameOption: nameOption == freezed
          ? _value.nameOption
          : nameOption as Option<Either<ProfileFailure, Unit>>,
      avatarOption: avatarOption == freezed
          ? _value.avatarOption
          : avatarOption as Option<Either<ProfileFailure, Unit>>,
      collegeOption: collegeOption == freezed
          ? _value.collegeOption
          : collegeOption as Option<Either<ProfileFailure, Unit>>,
      skillOption: skillOption == freezed
          ? _value.skillOption
          : skillOption as Option<Either<ProfileFailure, Unit>>,
      countryOption: countryOption == freezed
          ? _value.countryOption
          : countryOption as Option<Either<ProfileFailure, Unit>>,
      showSocialMediaErrorMessages: showSocialMediaErrorMessages == freezed
          ? _value.showSocialMediaErrorMessages
          : showSocialMediaErrorMessages as bool,
      profile: profile == freezed ? _value.profile : profile as Profile,
    ));
  }
}

/// @nodoc
abstract class _$ProfileStateCopyWith<$Res>
    implements $ProfileStateCopyWith<$Res> {
  factory _$ProfileStateCopyWith(
          _ProfileState value, $Res Function(_ProfileState) then) =
      __$ProfileStateCopyWithImpl<$Res>;
  @override
  $Res call(
      {String email,
      String name,
      String country,
      String age,
      String college,
      List<String> skills,
      String avatar,
      String faceBookLink,
      String instagramLink,
      String twitterLink,
      bool isInstagramLoading,
      List<Country> countries,
      Option<Either<ProfileFailure, Unit>> submitOption,
      Option<Either<ProfileFailure, Unit>> getProfileOption,
      Option<Either<ProfileFailure, Unit>> facebookOption,
      Option<Either<ProfileFailure, Unit>> twitterOption,
      Option<Either<ProfileFailure, Unit>> instagramOption,
      Option<Either<ProfileFailure, Unit>> linkedinOption,
      Option<Either<ProfileFailure, Unit>> certificateOption,
      Option<Either<ProfileFailure, Unit>> nameOption,
      Option<Either<ProfileFailure, Unit>> avatarOption,
      Option<Either<ProfileFailure, Unit>> collegeOption,
      Option<Either<ProfileFailure, Unit>> skillOption,
      Option<Either<ProfileFailure, Unit>> countryOption,
      bool showSocialMediaErrorMessages,
      Profile profile});
}

/// @nodoc
class __$ProfileStateCopyWithImpl<$Res> extends _$ProfileStateCopyWithImpl<$Res>
    implements _$ProfileStateCopyWith<$Res> {
  __$ProfileStateCopyWithImpl(
      _ProfileState _value, $Res Function(_ProfileState) _then)
      : super(_value, (v) => _then(v as _ProfileState));

  @override
  _ProfileState get _value => super._value as _ProfileState;

  @override
  $Res call({
    Object email = freezed,
    Object name = freezed,
    Object country = freezed,
    Object age = freezed,
    Object college = freezed,
    Object skills = freezed,
    Object avatar = freezed,
    Object faceBookLink = freezed,
    Object instagramLink = freezed,
    Object twitterLink = freezed,
    Object isInstagramLoading = freezed,
    Object countries = freezed,
    Object submitOption = freezed,
    Object getProfileOption = freezed,
    Object facebookOption = freezed,
    Object twitterOption = freezed,
    Object instagramOption = freezed,
    Object linkedinOption = freezed,
    Object certificateOption = freezed,
    Object nameOption = freezed,
    Object avatarOption = freezed,
    Object collegeOption = freezed,
    Object skillOption = freezed,
    Object countryOption = freezed,
    Object showSocialMediaErrorMessages = freezed,
    Object profile = freezed,
  }) {
    return _then(_ProfileState(
      email: email == freezed ? _value.email : email as String,
      name: name == freezed ? _value.name : name as String,
      country: country == freezed ? _value.country : country as String,
      age: age == freezed ? _value.age : age as String,
      college: college == freezed ? _value.college : college as String,
      skills: skills == freezed ? _value.skills : skills as List<String>,
      avatar: avatar == freezed ? _value.avatar : avatar as String,
      faceBookLink: faceBookLink == freezed
          ? _value.faceBookLink
          : faceBookLink as String,
      instagramLink: instagramLink == freezed
          ? _value.instagramLink
          : instagramLink as String,
      twitterLink:
          twitterLink == freezed ? _value.twitterLink : twitterLink as String,
      isInstagramLoading: isInstagramLoading == freezed
          ? _value.isInstagramLoading
          : isInstagramLoading as bool,
      countries:
          countries == freezed ? _value.countries : countries as List<Country>,
      submitOption: submitOption == freezed
          ? _value.submitOption
          : submitOption as Option<Either<ProfileFailure, Unit>>,
      getProfileOption: getProfileOption == freezed
          ? _value.getProfileOption
          : getProfileOption as Option<Either<ProfileFailure, Unit>>,
      facebookOption: facebookOption == freezed
          ? _value.facebookOption
          : facebookOption as Option<Either<ProfileFailure, Unit>>,
      twitterOption: twitterOption == freezed
          ? _value.twitterOption
          : twitterOption as Option<Either<ProfileFailure, Unit>>,
      instagramOption: instagramOption == freezed
          ? _value.instagramOption
          : instagramOption as Option<Either<ProfileFailure, Unit>>,
      linkedinOption: linkedinOption == freezed
          ? _value.linkedinOption
          : linkedinOption as Option<Either<ProfileFailure, Unit>>,
      certificateOption: certificateOption == freezed
          ? _value.certificateOption
          : certificateOption as Option<Either<ProfileFailure, Unit>>,
      nameOption: nameOption == freezed
          ? _value.nameOption
          : nameOption as Option<Either<ProfileFailure, Unit>>,
      avatarOption: avatarOption == freezed
          ? _value.avatarOption
          : avatarOption as Option<Either<ProfileFailure, Unit>>,
      collegeOption: collegeOption == freezed
          ? _value.collegeOption
          : collegeOption as Option<Either<ProfileFailure, Unit>>,
      skillOption: skillOption == freezed
          ? _value.skillOption
          : skillOption as Option<Either<ProfileFailure, Unit>>,
      countryOption: countryOption == freezed
          ? _value.countryOption
          : countryOption as Option<Either<ProfileFailure, Unit>>,
      showSocialMediaErrorMessages: showSocialMediaErrorMessages == freezed
          ? _value.showSocialMediaErrorMessages
          : showSocialMediaErrorMessages as bool,
      profile: profile == freezed ? _value.profile : profile as Profile,
    ));
  }
}

/// @nodoc
class _$_ProfileState implements _ProfileState {
  const _$_ProfileState(
      {this.email,
      this.name,
      this.country,
      this.age,
      this.college,
      this.skills,
      this.avatar,
      this.faceBookLink,
      this.instagramLink,
      this.twitterLink,
      this.isInstagramLoading,
      this.countries,
      this.submitOption,
      this.getProfileOption,
      this.facebookOption,
      this.twitterOption,
      this.instagramOption,
      this.linkedinOption,
      this.certificateOption,
      this.nameOption,
      this.avatarOption,
      this.collegeOption,
      this.skillOption,
      this.countryOption,
      this.showSocialMediaErrorMessages,
      this.profile});

  @override
  final String email;
  @override
  final String name;
  @override
  final String country;
  @override
  final String age;
  @override
  final String college;
  @override
  final List<String> skills;
  @override
  final String avatar;
  @override
  final String faceBookLink;
  @override
  final String instagramLink;
  @override
  final String twitterLink;
  @override
  final bool isInstagramLoading;
  @override
  final List<Country> countries;
  @override
  final Option<Either<ProfileFailure, Unit>> submitOption;
  @override
  final Option<Either<ProfileFailure, Unit>> getProfileOption;
  @override
  final Option<Either<ProfileFailure, Unit>> facebookOption;
  @override
  final Option<Either<ProfileFailure, Unit>> twitterOption;
  @override
  final Option<Either<ProfileFailure, Unit>> instagramOption;
  @override
  final Option<Either<ProfileFailure, Unit>> linkedinOption;
  @override
  final Option<Either<ProfileFailure, Unit>> certificateOption;
  @override
  final Option<Either<ProfileFailure, Unit>> nameOption;
  @override
  final Option<Either<ProfileFailure, Unit>> avatarOption;
  @override
  final Option<Either<ProfileFailure, Unit>> collegeOption;
  @override
  final Option<Either<ProfileFailure, Unit>> skillOption;
  @override
  final Option<Either<ProfileFailure, Unit>> countryOption;
  @override
  final bool showSocialMediaErrorMessages;
  @override
  final Profile profile;

  @override
  String toString() {
    return 'ProfileState(email: $email, name: $name, country: $country, age: $age, college: $college, skills: $skills, avatar: $avatar, faceBookLink: $faceBookLink, instagramLink: $instagramLink, twitterLink: $twitterLink, isInstagramLoading: $isInstagramLoading, countries: $countries, submitOption: $submitOption, getProfileOption: $getProfileOption, facebookOption: $facebookOption, twitterOption: $twitterOption, instagramOption: $instagramOption, linkedinOption: $linkedinOption, certificateOption: $certificateOption, nameOption: $nameOption, avatarOption: $avatarOption, collegeOption: $collegeOption, skillOption: $skillOption, countryOption: $countryOption, showSocialMediaErrorMessages: $showSocialMediaErrorMessages, profile: $profile)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other is _ProfileState &&
            (identical(other.email, email) ||
                const DeepCollectionEquality().equals(other.email, email)) &&
            (identical(other.name, name) ||
                const DeepCollectionEquality().equals(other.name, name)) &&
            (identical(other.country, country) ||
                const DeepCollectionEquality()
                    .equals(other.country, country)) &&
            (identical(other.age, age) ||
                const DeepCollectionEquality().equals(other.age, age)) &&
            (identical(other.college, college) ||
                const DeepCollectionEquality()
                    .equals(other.college, college)) &&
            (identical(other.skills, skills) ||
                const DeepCollectionEquality().equals(other.skills, skills)) &&
            (identical(other.avatar, avatar) ||
                const DeepCollectionEquality().equals(other.avatar, avatar)) &&
            (identical(other.faceBookLink, faceBookLink) ||
                const DeepCollectionEquality()
                    .equals(other.faceBookLink, faceBookLink)) &&
            (identical(other.instagramLink, instagramLink) ||
                const DeepCollectionEquality()
                    .equals(other.instagramLink, instagramLink)) &&
            (identical(other.twitterLink, twitterLink) ||
                const DeepCollectionEquality()
                    .equals(other.twitterLink, twitterLink)) &&
            (identical(other.isInstagramLoading, isInstagramLoading) ||
                const DeepCollectionEquality()
                    .equals(other.isInstagramLoading, isInstagramLoading)) &&
            (identical(other.countries, countries) ||
                const DeepCollectionEquality()
                    .equals(other.countries, countries)) &&
            (identical(other.submitOption, submitOption) ||
                const DeepCollectionEquality()
                    .equals(other.submitOption, submitOption)) &&
            (identical(other.getProfileOption, getProfileOption) ||
                const DeepCollectionEquality()
                    .equals(other.getProfileOption, getProfileOption)) &&
            (identical(other.facebookOption, facebookOption) ||
                const DeepCollectionEquality()
                    .equals(other.facebookOption, facebookOption)) &&
            (identical(other.twitterOption, twitterOption) ||
                const DeepCollectionEquality()
                    .equals(other.twitterOption, twitterOption)) &&
            (identical(other.instagramOption, instagramOption) ||
                const DeepCollectionEquality()
                    .equals(other.instagramOption, instagramOption)) &&
            (identical(other.linkedinOption, linkedinOption) ||
                const DeepCollectionEquality()
                    .equals(other.linkedinOption, linkedinOption)) &&
            (identical(other.certificateOption, certificateOption) ||
                const DeepCollectionEquality()
                    .equals(other.certificateOption, certificateOption)) &&
            (identical(other.nameOption, nameOption) ||
                const DeepCollectionEquality()
                    .equals(other.nameOption, nameOption)) &&
            (identical(other.avatarOption, avatarOption) ||
                const DeepCollectionEquality()
                    .equals(other.avatarOption, avatarOption)) &&
            (identical(other.collegeOption, collegeOption) ||
                const DeepCollectionEquality()
                    .equals(other.collegeOption, collegeOption)) &&
            (identical(other.skillOption, skillOption) ||
                const DeepCollectionEquality()
                    .equals(other.skillOption, skillOption)) &&
            (identical(other.countryOption, countryOption) ||
                const DeepCollectionEquality()
                    .equals(other.countryOption, countryOption)) &&
            (identical(other.showSocialMediaErrorMessages, showSocialMediaErrorMessages) || const DeepCollectionEquality().equals(other.showSocialMediaErrorMessages, showSocialMediaErrorMessages)) &&
            (identical(other.profile, profile) || const DeepCollectionEquality().equals(other.profile, profile)));
  }

  @override
  int get hashCode =>
      runtimeType.hashCode ^
      const DeepCollectionEquality().hash(email) ^
      const DeepCollectionEquality().hash(name) ^
      const DeepCollectionEquality().hash(country) ^
      const DeepCollectionEquality().hash(age) ^
      const DeepCollectionEquality().hash(college) ^
      const DeepCollectionEquality().hash(skills) ^
      const DeepCollectionEquality().hash(avatar) ^
      const DeepCollectionEquality().hash(faceBookLink) ^
      const DeepCollectionEquality().hash(instagramLink) ^
      const DeepCollectionEquality().hash(twitterLink) ^
      const DeepCollectionEquality().hash(isInstagramLoading) ^
      const DeepCollectionEquality().hash(countries) ^
      const DeepCollectionEquality().hash(submitOption) ^
      const DeepCollectionEquality().hash(getProfileOption) ^
      const DeepCollectionEquality().hash(facebookOption) ^
      const DeepCollectionEquality().hash(twitterOption) ^
      const DeepCollectionEquality().hash(instagramOption) ^
      const DeepCollectionEquality().hash(linkedinOption) ^
      const DeepCollectionEquality().hash(certificateOption) ^
      const DeepCollectionEquality().hash(nameOption) ^
      const DeepCollectionEquality().hash(avatarOption) ^
      const DeepCollectionEquality().hash(collegeOption) ^
      const DeepCollectionEquality().hash(skillOption) ^
      const DeepCollectionEquality().hash(countryOption) ^
      const DeepCollectionEquality().hash(showSocialMediaErrorMessages) ^
      const DeepCollectionEquality().hash(profile);

  @override
  _$ProfileStateCopyWith<_ProfileState> get copyWith =>
      __$ProfileStateCopyWithImpl<_ProfileState>(this, _$identity);
}

abstract class _ProfileState implements ProfileState {
  const factory _ProfileState(
      {String email,
      String name,
      String country,
      String age,
      String college,
      List<String> skills,
      String avatar,
      String faceBookLink,
      String instagramLink,
      String twitterLink,
      bool isInstagramLoading,
      List<Country> countries,
      Option<Either<ProfileFailure, Unit>> submitOption,
      Option<Either<ProfileFailure, Unit>> getProfileOption,
      Option<Either<ProfileFailure, Unit>> facebookOption,
      Option<Either<ProfileFailure, Unit>> twitterOption,
      Option<Either<ProfileFailure, Unit>> instagramOption,
      Option<Either<ProfileFailure, Unit>> linkedinOption,
      Option<Either<ProfileFailure, Unit>> certificateOption,
      Option<Either<ProfileFailure, Unit>> nameOption,
      Option<Either<ProfileFailure, Unit>> avatarOption,
      Option<Either<ProfileFailure, Unit>> collegeOption,
      Option<Either<ProfileFailure, Unit>> skillOption,
      Option<Either<ProfileFailure, Unit>> countryOption,
      bool showSocialMediaErrorMessages,
      Profile profile}) = _$_ProfileState;

  @override
  String get email;
  @override
  String get name;
  @override
  String get country;
  @override
  String get age;
  @override
  String get college;
  @override
  List<String> get skills;
  @override
  String get avatar;
  @override
  String get faceBookLink;
  @override
  String get instagramLink;
  @override
  String get twitterLink;
  @override
  bool get isInstagramLoading;
  @override
  List<Country> get countries;
  @override
  Option<Either<ProfileFailure, Unit>> get submitOption;
  @override
  Option<Either<ProfileFailure, Unit>> get getProfileOption;
  @override
  Option<Either<ProfileFailure, Unit>> get facebookOption;
  @override
  Option<Either<ProfileFailure, Unit>> get twitterOption;
  @override
  Option<Either<ProfileFailure, Unit>> get instagramOption;
  @override
  Option<Either<ProfileFailure, Unit>> get linkedinOption;
  @override
  Option<Either<ProfileFailure, Unit>> get certificateOption;
  @override
  Option<Either<ProfileFailure, Unit>> get nameOption;
  @override
  Option<Either<ProfileFailure, Unit>> get avatarOption;
  @override
  Option<Either<ProfileFailure, Unit>> get collegeOption;
  @override
  Option<Either<ProfileFailure, Unit>> get skillOption;
  @override
  Option<Either<ProfileFailure, Unit>> get countryOption;
  @override
  bool get showSocialMediaErrorMessages;
  @override
  Profile get profile;
  @override
  _$ProfileStateCopyWith<_ProfileState> get copyWith;
}
