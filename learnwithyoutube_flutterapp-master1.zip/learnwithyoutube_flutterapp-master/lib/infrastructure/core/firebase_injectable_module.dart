import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:dio/dio.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter_app/core/strings.dart';
import 'package:flutter_app/domain/core/token_model.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:googleapis/calendar/v3.dart';
import 'package:hive/hive.dart';
import 'package:injectable/injectable.dart';

@registerModule
abstract class FirebaseInjectableModule {
  @lazySingleton
  GoogleSignIn get googleSignIn => GoogleSignIn(
        clientId:
            '1093936261329-d84hgpoqb5ugvld8hkb6p275krerp3rg.apps.googleusercontent.com',
        scopes: <String>[
          CalendarApi.calendarScope,
        ],
      );
  @lazySingleton
  FirebaseAuth get firebaseAuth => FirebaseAuth.instance;
  @lazySingleton
  FirebaseFirestore get firestore => FirebaseFirestore.instance;
  @lazySingleton
  Dio get dio => Dio();
  @lazySingleton
  Box<ResponseTokenModel> get box =>
      Hive.box<ResponseTokenModel>(HiveBoxNames.token);
}
