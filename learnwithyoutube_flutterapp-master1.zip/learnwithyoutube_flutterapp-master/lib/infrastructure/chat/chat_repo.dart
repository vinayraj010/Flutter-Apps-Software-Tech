import 'dart:convert';

import 'package:dartz/dartz.dart';
import 'package:flutter_app/core/strings.dart';
import 'package:flutter_app/domain/chat/attendance.dart';
import 'package:flutter_app/domain/chat/chat.dart';
import 'package:flutter_app/domain/chat/chat_failure.dart';
import 'package:flutter_app/domain/chat/i_chat_repo.dart';
import 'package:flutter_app/domain/chat/message.dart';
import 'package:flutter_app/domain/core/i_backend_request.dart';
import 'package:flutter_app/domain/core/token_model.dart';
import 'package:flutter_app/domain/core/value_objects.dart';
import 'package:flutter_app/infrastructure/core/api_endpoints.dart';
import 'package:flutter_app/infrastructure/core/backend_request.dart';
import 'package:hive/hive.dart';
import 'package:injectable/injectable.dart';

@prod
@RegisterAs(IChatRepo)
@lazySingleton
class ChatRepo extends IChatRepo {
  final IBackendRequest _backendRequest;
  final Box<ResponseTokenModel> _box;

  ChatRepo(this._backendRequest, this._box);
  @override
  Future<Either<ChatFailure, Unit>> createChat(
      {int userId, StringSingleLine title}) async {
    try {
      final String stringTitle = title.value.getOrElse(() => 'INVALID_TITLE');
      await _backendRequest
          .securedHTTPSRequest(
            endpoint: ApiEndpoint.createChat,
            method: HTTPMETHODS.post,
            data: json.encode({'user_id': userId, 'title': stringTitle}),
          )
          .then((value) => print(
              Chat.fromJson(value.data['data'] as Map<String, dynamic>)
                  .toString()));

      return right(unit);
    } catch (e) {
      return left(const ChatFailure.serverError());
    }
  }

  @override
  Future<Either<ChatFailure, Message>> getAllChats() async {
    try {
      return await _backendRequest.securedHTTPSRequest(
        endpoint: ApiEndpoint.getAllChats,
        method: HTTPMETHODS.get,
        data: {'role_id': _box.get(HiveBoxNames.token).roleId},
      ).then((value) =>
          right(Message.fromJson(value.data as Map<String, dynamic>)));
    } catch (e) {
      return left(const ChatFailure.serverError());
    }
  }

  @override
  Future<Either<ChatFailure, Unit>> addStudentAttendance(
      {int chatId, int teacherAttendanceId}) async {
    try {
      return await _backendRequest.securedHTTPSRequest(
        endpoint: ApiEndpoint.addStudentAttendance,
        method: HTTPMETHODS.post,
        data: {'chat_id': chatId, 'teacher_attendance_id': teacherAttendanceId},
      ).then((value) => right(unit));
    } catch (e) {
      return left(const ChatFailure.serverError());
    }
  }

  @override
  Future<Either<ChatFailure, Attendance>> addTeacherAttendance(
      {int chatId}) async {
    try {
      return await _backendRequest.securedHTTPSRequest(
        endpoint: ApiEndpoint.addTeacherAttendance,
        method: HTTPMETHODS.post,
        data: {'chat_id': chatId},
      ).then((value) => right(attendanceFromJson(value.data as String)));
    } catch (e) {
      return left(const ChatFailure.serverError());
    }
  }
}
