part of 'profile_bloc.dart';

@freezed
abstract class ProfileState with _$ProfileState {
  const factory ProfileState(
      {String email,
      String name,
      String country,
      String age,
      String college,
      List<String> skills,
      String avatar,
      String faceBookLink,
      String instagramLink,
      String twitterLink,
      bool isInstagramLoading,
      List<Country> countries,
      Option<Either<ProfileFailure, Unit>> submitOption,
      Option<Either<ProfileFailure, Unit>> getProfileOption,
      Option<Either<ProfileFailure, Unit>> facebookOption,
      Option<Either<ProfileFailure, Unit>> twitterOption,
      Option<Either<ProfileFailure, Unit>> instagramOption,
      Option<Either<ProfileFailure, Unit>> linkedinOption,
      Option<Either<ProfileFailure, Unit>> certificateOption,
      Option<Either<ProfileFailure, Unit>> nameOption,
      Option<Either<ProfileFailure, Unit>> avatarOption,
      Option<Either<ProfileFailure, Unit>> collegeOption,
      Option<Either<ProfileFailure, Unit>> skillOption,
      Option<Either<ProfileFailure, Unit>> countryOption,
      bool showSocialMediaErrorMessages,
      Profile profile}) = _ProfileState;

  factory ProfileState.initial() => ProfileState(
      submitOption: none(),
      countryOption: none(),
      skillOption: none(),
      collegeOption: none(),
      avatarOption: none(),
      certificateOption: none(),
      nameOption: none(),
      getProfileOption: none(),
      profile: Profile(),
      isInstagramLoading:false,
      showSocialMediaErrorMessages: false,
      countries: []);
}
