part of 'profile_bloc.dart';

@freezed
abstract class ProfileEvent with _$ProfileEvent {
  const factory ProfileEvent.submitUserProfile() = _SubmitUserProfile;
  const factory ProfileEvent.getUserProfile() = _GetUserProfile;
  const factory ProfileEvent.getCountries() = _GetCountries;
  //Update

  const factory ProfileEvent.updateAvatar(String avatar) = _AvatarUpdate;

  //Sections
  const factory ProfileEvent.saveSocialMedia({
    @required String facebookUserName,
    @required String instagramUserName,
    @required String twitterUserName,
    @required String linkedinUserName,
  }) = _SaveSocialMediaHandles;

  //Sections
  const factory ProfileEvent.saveAbout(
      {@required String month,
      @required String day,
      @required String year,
      @required String country,
      @required String state,
      @required String phoneNumber}) = _SaveAbout;

  const factory ProfileEvent.saveSkills(List<Domain> domains) = _SaveSkills;
  const factory ProfileEvent.updateSkills(Domain domain) = _UpdateSkill;
  const factory ProfileEvent.saveEducation(List<EducationStandard> educations) =
      _SaveEducations;
  const factory ProfileEvent.updateEducation(
      List<EducationStandard> educations) = _UpdateEducations;
  const factory ProfileEvent.saveCertificates(Certificate certificates) =
      _SaveCertificates;
  const factory ProfileEvent.updateCertificates(Certificate certificates) =
      _UpdateCertificates;

  //Delete
  const factory ProfileEvent.deleteCertificate(Certificate certificate) =
      _DeleteCertificate;
  const factory ProfileEvent.deleteEducation(EducationStandard education) =
      _DeleteEducation;
  const factory ProfileEvent.deleteSkill(Domain domain) = _DeleteDomain;
}
