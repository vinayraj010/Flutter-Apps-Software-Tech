part of 'message_bloc.dart';

@freezed
abstract class MessageState with _$MessageState {
  const factory MessageState({
    Message messages,
    List<MessageBody> listOfMessages,
    bool isLoading,
    bool showErrorMessage,
    NonNullString message,
    String currentUrl,
    bool showFilters,
    Option<List<MessageBody>> someOrNOSelectedElements,
    Option<ChatAppBarState> failureOrSuccessChatAppBarState,
    Option<String> nextUrl,
    Option<Either<MessageFailure, Unit>> failureOrSuccessGetMessage,
    Option<Either<MessageFailure, Unit>> failureOrSuccessSendMessage,
  }) = _MessageState;

  factory MessageState.initial() => MessageState(
      nextUrl: some(
          'https://api.learnwithyoutube.org/api/v1/get_chat_messages?page=1'),
      currentUrl:
          'https://api.learnwithyoutube.org/api/v1/get_chat_messages?page=1',
      isLoading: false,
      showErrorMessage: false,
      listOfMessages: [],
      message: NonNullString(''),
      failureOrSuccessChatAppBarState: some(ChatAppBarState.standard),
      someOrNOSelectedElements: none(),
      showFilters: false);
}

/*
Option<String> noneOrSome;
String data;



noneOrSome = none()
noneOrSome = some('Hello')






*/
