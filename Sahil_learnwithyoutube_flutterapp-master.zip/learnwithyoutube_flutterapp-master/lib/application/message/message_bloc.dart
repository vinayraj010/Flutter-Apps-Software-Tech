import 'dart:async';

import 'package:bloc/bloc.dart';
import 'package:dartz/dartz.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter_app/core/enums/chat_appbar_enum.dart';
import 'package:flutter_app/core/services/file_picker.dart';
import 'package:flutter_app/domain/chat/message.dart';
import 'package:flutter_app/domain/core/value_objects.dart';
import 'package:flutter_app/domain/message/i_message_repo.dart';
import 'package:flutter_app/domain/message/message_failure.dart';
import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:injectable/injectable.dart';

part 'message_bloc.freezed.dart';
part 'message_event.dart';
part 'message_state.dart';

@injectable
class MessageBloc extends Bloc<MessageEvent, MessageState> {
  MessageBloc(this._repo, this._filePickerService) : super(null);
  final IMessageRepo _repo;
  final FilePickerService _filePickerService;

  @override
  Stream<MessageState> mapEventToState(
    MessageEvent event,
  ) async* {
    yield* event.map(
      messageChanged: (e) async* {
        yield state.copyWith(
            message: NonNullString(e.message),
            failureOrSuccessGetMessage: none());
      },
      getChatMessages: _getChatMessageStream,
      sendMessage: (e) async* {
        yield state.copyWith(isLoading: true);
        final bool isMessageValid = state.message.isValid();
        Either<MessageFailure, Unit> successOrFailureSendMessage;

        if (isMessageValid) {
          successOrFailureSendMessage =
              await _repo.sendMessage(chatId: e.chaId, message: state.message);

          final failureOrSuccess = await _repo.getChatMessage(
              chatId: e.chaId,
              url:
                  'https://api.learnwithyoutube.org/api/v1/get_chat_messages?page=1');

          yield failureOrSuccess.fold(
              (l) => state.copyWith(
                  failureOrSuccessGetMessage: some(left(l)),
                  isLoading: false), (r) {
            state.listOfMessages.add(r.data.first);
            return state.copyWith(showErrorMessage: false);
          });

          yield state.copyWith(showErrorMessage: true);
        }

        yield state.copyWith(
            failureOrSuccessSendMessage: optionOf(successOrFailureSendMessage),
            message: NonNullString(''));
      },
      pickFile: _pickFile,
      switchToStandardAppBar: (e) async* {
        yield state.copyWith(
            failureOrSuccessChatAppBarState: some(ChatAppBarState.standard),
            someOrNOSelectedElements: none());
      },
      removeFromSelectedMessages: (e) async* {
        yield state.copyWith(someOrNOSelectedElements: none());

        final List<MessageBody> _selectedElements =
            state.someOrNOSelectedElements.fold(() => [], (a) => a);
        _selectedElements.remove(e.element);
        yield state.copyWith(
          someOrNOSelectedElements: some(_selectedElements),
          failureOrSuccessChatAppBarState: some(ChatAppBarState.selected),
        );
      },
      addToSelectedMessages: (e) async* {
        yield state.copyWith(someOrNOSelectedElements: none());
        final List<MessageBody> _selectedElements =
            state.someOrNOSelectedElements.fold(() => [], (a) => a);
        _selectedElements.add(e.element);
        yield state.copyWith(
          someOrNOSelectedElements: some(_selectedElements),
          failureOrSuccessChatAppBarState: some(ChatAppBarState.selected),
        );
      },
      switchToInfoAppBar: (e) async* {
        yield state.copyWith(
            failureOrSuccessChatAppBarState: some(ChatAppBarState.info));
      },
      showFilters: (e) async* {
        yield state.copyWith(showFilters: true);
      },
      hideFilters: (e) async* {
        yield state.copyWith(showFilters: false);
      },
    );
  }

  Stream<MessageState> _pickFile(_PickFile e) async* {
    Either<MessageFailure, Unit> successOrFailureSendMessage;

    final someOrNoPath =
        await _filePickerService.pickFile(fileType: e.fileType);

    yield* someOrNoPath.fold(
      () async* {
        //No file Chosen
      },
      (path) async* {
        successOrFailureSendMessage = await _repo.sendMultiMediaMessage(
            chatId: e.chatId, path: path, typeId: _getTypeId(e.fileType));
        yield* successOrFailureSendMessage.fold(
          (l) async* {},
          (r) async* {
            yield* _addMessage(e);
          },
        );
      },
    );
  }

  int _getTypeId(FileType type) {
    switch (type) {
      case FileType.image:
        return 2;

        break;
      case FileType.video:
        return 3;

        break;
      case FileType.audio:
        return 4;

        break;
      case FileType.custom:
        return 5;

        break;
      default:
        return 2;
    }
  }

  Stream<MessageState> _getChatMessageStream(e) async* {
    yield state.copyWith(isLoading: true);
    String nextUrl;
    state.nextUrl.fold(() => null, (a) => nextUrl = a);

    if (nextUrl != null) {
      final failureOrSuccess =
          await _repo.getChatMessage(chatId: e.chatId as int, url: nextUrl);

      yield failureOrSuccess.fold(
        (l) => state.copyWith(
            failureOrSuccessGetMessage: some(left(l)), isLoading: false),
        (r) {
          state.listOfMessages.addAll(r.data);
          return state.copyWith(
              messages: r,
              isLoading: false,
              currentUrl: '${r.path}?page=${r.currentPage}',
              nextUrl: r.nextPageUrl != null
                  ? some(r.nextPageUrl as String)
                  : none());
        },
      );
    } else {}
  }

  Stream<MessageState> _addMessage(e) async* {
    yield state.copyWith(isLoading: true);
    final failureOrSuccess = await _repo.getChatMessage(
        chatId: e.chatId as int, url: state.currentUrl);

    yield failureOrSuccess.fold(
      (l) => state.copyWith(
          failureOrSuccessGetMessage: some(left(l)), isLoading: false),
      (r) {
        state.listOfMessages.add(r.data.first);
        return state.copyWith(
            messages: r,
            isLoading: false,
            currentUrl: '${r.path}?page=${r.currentPage}',
            nextUrl:
                r.nextPageUrl != null ? some(r.nextPageUrl as String) : none());
      },
    );
  }

  @override
  // TODO: implement initialState
  MessageState get initialState => MessageState.initial();
}
