import 'package:file_picker/file_picker.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_app/application/profile/profile_bloc.dart';
import 'package:flutter_app/application/providers/profile_provider.dart';
import 'package:flutter_app/core/routes/route.gr.dart' as route;
import 'package:flutter_app/core/utils/clean_string.dart';
import 'package:flutter_app/domain/profile/profile.dart';
import 'package:flutter_app/presentation/core/palette.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:image_cropper/image_cropper.dart';
import 'package:injectable/injectable.dart';
import 'package:provider/provider.dart';

// final BuildContext context = route.Router.navigator.key.currentContext;
BuildContext context;
enum _CertificateParams { description, image, organisation, month, day, year }

@lazySingleton
class CertificateProvider extends ChangeNotifier {
  Certificate _certificate;
  String _selectedImage;
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  bool _showErrors = false;
  bool _isNameNotFilled = false;
  bool _isOrgNotFilled = false;
  bool _isMonthNotFilled = false;
  bool _isDayNotFilled = false;
  bool _isYearNotFilled = false;
  InputBorder _nameTextFieldBorder;
  InputBorder _orgTextFieldBorder;
  Color _monthDropDownBorder;
  Color _monthDropDownFillColor;
  InputBorder _dayTextFieldBorder;
  InputBorder _yearTextFieldBorder;

  static List<Certificate> _recentlyAdededCertificates = <Certificate>[
    Certificate(image: '')
  ];
  static List<Certificate> _deletedCertificates = <Certificate>[];

  Certificate get certificate => _certificate;
  GlobalKey<FormState> get formKey => _formKey;
  bool get showErrors => _showErrors;
  bool get isNameNotFilled => _isNameNotFilled;
  bool get isOrgNotFilled => _isOrgNotFilled;
  bool get isMonthNotFilled => _isMonthNotFilled;
  bool get isDayNotFilled => _isDayNotFilled;
  bool get isYearNotFilled => _isYearNotFilled;
  InputBorder get orgTextFieldBorder => _orgTextFieldBorder;
  InputBorder get nameTextFieldBorder => _nameTextFieldBorder;
  Color get monthDropDownBorder => _monthDropDownBorder;
  Color get monthDropDownFillColor => _monthDropDownFillColor;
  InputBorder get dayTextFieldBorder => _dayTextFieldBorder;
  InputBorder get yearTextFieldBorder => _yearTextFieldBorder;
  List<Certificate> get recentlyAdededCertificates =>
      _recentlyAdededCertificates;
  List<Certificate> get deletedCertificates => _deletedCertificates;

  String get selectedImage => _selectedImage;

  bool checkWhetherAllFieldsAllFilled() {
    return _recentlyAdededCertificates
        .where((element) =>
            cleanString(element.description).isEmpty ||
            cleanString(element.organization).isEmpty ||
            element.image.isEmpty ||
            element.month == null ||
            cleanString(element.day).isEmpty ||
            cleanString(element.year).isEmpty)
        .toList()
        .isNotEmpty;
  }

  bool _ifRemainingFieldsFilled(int index, _CertificateParams param) {
    final List<bool> _boolList = <bool>[];

    final List<_CertificateParams> _toBeConsideredParams = [
      _CertificateParams.day,
      _CertificateParams.month,
      _CertificateParams.year,
      _CertificateParams.image,
      _CertificateParams.description,
      _CertificateParams.organisation,
    ]..remove(param);

    for (final _CertificateParams _param in _toBeConsideredParams) {
      if (_param == _CertificateParams.description) {
        _boolList.add(
            cleanString(_recentlyAdededCertificates[index].description)
                .isNotEmpty);
      } else if (_param == _CertificateParams.organisation) {
        _boolList.add(
            cleanString(_recentlyAdededCertificates[index].organization)
                .isNotEmpty);
      } else if (_param == _CertificateParams.month) {
        _boolList.add(
            cleanString(_recentlyAdededCertificates[index].month).isNotEmpty);
      } else if (_param == _CertificateParams.day) {
        _boolList.add(
            cleanString(_recentlyAdededCertificates[index].day).isNotEmpty);
      } else if (_param == _CertificateParams.year) {
        _boolList.add(
            cleanString(_recentlyAdededCertificates[index].year).isNotEmpty);
      } else if (_param == _CertificateParams.image) {
        _boolList.add(
            cleanString(_recentlyAdededCertificates[index].image).isNotEmpty);
      }
    }

    return _boolList.contains(true);
  }

  MaterialStateProperty<BorderSide> addFieldBorder() {
    return MaterialStateProperty.all(BorderSide(
        color: checkWhetherAllFieldsAllFilled()
            ? Palette.cc4c4c4
            : Palette.onBlue));
  }

  void addAllPreviousCertificatesToList() {
    final List<Certificate> _allList =
        BlocProvider.of<ProfileBloc>(context).state.profile.certificates;
    _recentlyAdededCertificates.addAll(_allList);
    // notifyListeners();
  }

  //Call this Before Field
  void checkWhetherFieldsFilled({@required int index}) {
    _isNameNotFilled =
        cleanString(_recentlyAdededCertificates[index].description).isEmpty;

    _nameTextFieldBorder = OutlineInputBorder(
        borderSide: BorderSide(
            color: _isNameNotFilled ? Palette.c686868 : Palette.onBlue),
        borderRadius: BorderRadius.circular(3));

    _isOrgNotFilled =
        cleanString(_recentlyAdededCertificates[index].organization).isEmpty;

    _orgTextFieldBorder = OutlineInputBorder(
        borderSide: BorderSide(
            color: _isOrgNotFilled ? Palette.c686868 : Palette.onBlue),
        borderRadius: BorderRadius.circular(3));
    _isMonthNotFilled = _recentlyAdededCertificates[index].month == null;
    _monthDropDownBorder = _isMonthNotFilled ? Palette.c686868 : Palette.onBlue;
    _monthDropDownFillColor =
        _isMonthNotFilled ? Palette.cafafafa : Palette.onBackground;

    _isDayNotFilled =
        cleanString(_recentlyAdededCertificates[index].day).isEmpty;

    _dayTextFieldBorder = OutlineInputBorder(
        borderSide: BorderSide(
            color: _isDayNotFilled ? Palette.c686868 : Palette.onBlue),
        borderRadius: BorderRadius.circular(3));

    //Day
    _isYearNotFilled =
        cleanString(_recentlyAdededCertificates[index].year).isEmpty;

    _yearTextFieldBorder = OutlineInputBorder(
        borderSide: BorderSide(
            color: _isYearNotFilled ? Palette.c686868 : Palette.onBlue),
        borderRadius: BorderRadius.circular(3));

    // notifyListeners();
  }

  void onNameChanged({
    @required String value,
    @required int index,
  }) {
    try {
      final Certificate _existingCertificateInList =
          _recentlyAdededCertificates.elementAt(index);
      _existingCertificateInList.description = cleanString(value);

      _recentlyAdededCertificates.removeAt(index);

      _recentlyAdededCertificates.insert(index, _existingCertificateInList);
    } catch (e) {
      _certificate.description = cleanString(value);
      _recentlyAdededCertificates.insert(index, _certificate);
    }

    notifyListeners();
  }

  void onOrganisationChanged({
    @required String value,
    @required int index,
  }) {
    try {
      final Certificate _existingCertificateInList =
          _recentlyAdededCertificates.elementAt(index);
      _existingCertificateInList.organization = cleanString(value);

      _recentlyAdededCertificates.removeAt(index);

      _recentlyAdededCertificates.insert(index, _existingCertificateInList);
    } catch (e) {
      _certificate.organization = cleanString(value);
      _recentlyAdededCertificates.insert(index, _certificate);
    }

    notifyListeners();
  }

  void onMonthChanged({
    @required String value,
    @required int index,
  }) {
    _recentlyAdededCertificates[index].month = value;

    notifyListeners();
  }

  void onDayChanged({
    @required String value,
    @required int index,
  }) {
    try {
      final Certificate _existingCertificateInList =
          _recentlyAdededCertificates.elementAt(index);
      _existingCertificateInList.day = cleanString(value);

      _recentlyAdededCertificates.removeAt(index);

      _recentlyAdededCertificates.insert(index, _existingCertificateInList);
    } catch (e) {
      _certificate.day = cleanString(value);
      _recentlyAdededCertificates.insert(index, _certificate);
    }

    notifyListeners();
  }

  void onYearChanged({
    @required String value,
    @required int index,
  }) {
    try {
      final Certificate _existingCertificateInList =
          _recentlyAdededCertificates.elementAt(index);
      _existingCertificateInList.year = cleanString(value);

      _recentlyAdededCertificates.removeAt(index);

      _recentlyAdededCertificates.insert(index, _existingCertificateInList);
    } catch (e) {
      _certificate.year = cleanString(value);
      _recentlyAdededCertificates.insert(index, _certificate);
    }

    notifyListeners();
  }

  Color imageBorderColor(int index) {
    if (recentlyAdededCertificates[index].image == '') {
      if (showErrors &&
          _ifRemainingFieldsFilled(index, _CertificateParams.image)) {
        return Palette.onRed;
      } else {
        return Palette.onBlue;
      }
    } else {
      return Palette.onBlue;
    }
  }

  String validatorForName({
    @required String value,
    @required int index,
  }) {
    if (_ifRemainingFieldsFilled(index, _CertificateParams.description) &&
        cleanString(value).isEmpty) {
      if (cleanString(value).length > 500) {
        return 'Should be less than 500 characters';
      } else {
        return '* Required';
      }
    } else {
      return null;
    }
  }

  String validatorForOrg({
    @required String value,
    @required int index,
  }) {
    if (_ifRemainingFieldsFilled(index, _CertificateParams.organisation) &&
        cleanString(value).isEmpty) {
      return '* Required';
    } else {
      return null;
    }
  }

  String validatorForDay({
    @required String value,
    @required int index,
  }) {
    if (_ifRemainingFieldsFilled(index, _CertificateParams.day)) {
      if (cleanString(value).isEmpty) {
        return '* Required';
      } else if (!(int.parse(cleanString(value)) >= 1 &&
          int.parse(cleanString(value)) <= 31)) {
        return 'Invalid Day';
      } else {
        return null;
      }
    } else {
      return null;
    }
  }

  String validatorForYear({
    @required String value,
    @required int index,
  }) {
    if (_ifRemainingFieldsFilled(index, _CertificateParams.year)) {
      if (cleanString(value).isEmpty) {
        return '* Required';
      } else if (!(int.parse(cleanString(value)) >=
              (DateTime.now().year - 100) &&
          int.parse(cleanString(value)) <= (DateTime.now().year + 100))) {
        return 'Invalid Year';
      } else {
        return null;
      }
    } else {
      return null;
    }
  }

  String validatorForMonth({
    @required String value,
    @required int index,
  }) {
    if (_ifRemainingFieldsFilled(index, _CertificateParams.month) &&
        cleanString(value).isEmpty) {
      return '* Required';
    } else {
      return null;
    }
  }

  Future<void> pickImage(int index) async {
    await FilePicker.platform
        .pickFiles(
      type: FileType.image,
      allowCompression: true,
    )
        .then((result) async {
      if (result != null) {
        final path = result.files.single.path;
        await ImageCropper.cropImage(
            sourcePath: path,
            aspectRatioPresets: [
              CropAspectRatioPreset.square,
              CropAspectRatioPreset.ratio3x2,
              CropAspectRatioPreset.original,
              CropAspectRatioPreset.ratio4x3,
              CropAspectRatioPreset.ratio16x9
            ],
            androidUiSettings: AndroidUiSettings(
                initAspectRatio: CropAspectRatioPreset.original,
                toolbarColor: Palette.white,
                statusBarColor: Colors.black,
                lockAspectRatio: false,
                hideBottomControls: true,
                toolbarTitle: 'Crop Certificate',
                activeControlsWidgetColor: Palette.onBlue),
            iosUiSettings: const IOSUiSettings(
              minimumAspectRatio: 1.0,
            )).then(
          (value) {
            if (value != null) {
              final _path = value.path;
              _recentlyAdededCertificates[index].image = _path;
              notifyListeners();
            }
          },
        );
      }
    });
  }

  //TODO: Add new fields to top of the list
  void onAddFieldPressed() {
    if (!checkWhetherAllFieldsAllFilled()) {
      _recentlyAdededCertificates.add(Certificate(image: ''));

      notifyListeners();
    }
  }

  void showErrorsToTrue() {
    _showErrors = true;
    notifyListeners();
  }

  void _saveCertificates() {
    final List<Certificate> _toBeAddedCertificates =
        _recentlyAdededCertificates.where((e) => e.id == null).toList();

    for (final Certificate certificate in _toBeAddedCertificates) {
      BlocProvider.of<ProfileBloc>(context)
          .add(ProfileEvent.saveCertificates(certificate));
    }

    final List<Certificate> _toBeUpdatedCertificates =
        _recentlyAdededCertificates.where((e) => e?.id != null).toList();

    for (final Certificate certificate in _toBeUpdatedCertificates) {
      BlocProvider.of<ProfileBloc>(context)
          .add(ProfileEvent.updateCertificates(certificate));
    }

    //Get Fresh Profile
    BlocProvider.of<ProfileBloc>(context)
        .add(const ProfileEvent.getUserProfile());
  }

  void _deleteCertificates() {
    for (final Certificate certificate in _deletedCertificates) {
      BlocProvider.of<ProfileBloc>(context)
          .add(ProfileEvent.deleteCertificate(certificate));
    }
  }

  void onSavePressed() {
    if (_formKey.currentState.validate() &&
        //Check if image is attached
        (_recentlyAdededCertificates
            .where((element) =>
                cleanString(element.description).isNotEmpty &&
                cleanString(element.image).isEmpty)
            .toList()
            .isEmpty)) {
      Provider.of<ProfileProvider>(context, listen: false).startLoading();

      Navigator.pop(context);
      _deleteCertificates();
      _saveCertificates();

      resetAll();
    } else {
      _showErrors = true;
    }
    notifyListeners();
  }

  void resetAll() {
    BlocProvider.of<ProfileBloc>(context)
        .add(const ProfileEvent.getUserProfile());
    _recentlyAdededCertificates = <Certificate>[Certificate(image: '')];

    _deletedCertificates.clear();

    _certificate = Certificate(image: '');
    _showErrors = false;
    _isNameNotFilled = false;
    _isOrgNotFilled = false;
    _isMonthNotFilled = false;
    _isDayNotFilled = false;
    _isYearNotFilled = false;
    notifyListeners();
  }

  void saveImage(int index) {
    _recentlyAdededCertificates[index].image = _selectedImage;
    notifyListeners();
  }

  void assignSelectedImageToExistingImage(int index) {
    _selectedImage = _recentlyAdededCertificates[index].image;
    notifyListeners();
  }

  Future<void> changeImage(int index) async {
    await FilePicker.platform
        .pickFiles(
      type: FileType.image,
      allowCompression: true,
    )
        .then((result) async {
      if (result != null) {
        final path = result.files.single.path;
        await ImageCropper.cropImage(
            sourcePath: path,
            aspectRatioPresets: [
              CropAspectRatioPreset.square,
              CropAspectRatioPreset.ratio3x2,
              CropAspectRatioPreset.original,
              CropAspectRatioPreset.ratio4x3,
              CropAspectRatioPreset.ratio16x9
            ],
            androidUiSettings: AndroidUiSettings(
                initAspectRatio: CropAspectRatioPreset.original,
                toolbarColor: Palette.white,
                statusBarColor: Colors.black,
                lockAspectRatio: false,
                hideBottomControls: true,
                toolbarTitle: 'Crop Certificate',
                activeControlsWidgetColor: Palette.onBlue),
            iosUiSettings: const IOSUiSettings(
              minimumAspectRatio: 1.0,
            )).then(
          (value) {
            if (value != null) {
              final _path = value.path;
              _selectedImage = _path;
              notifyListeners();
            }
          },
        );
      }
    });
  }

  void removeAndAddToDelete(int index) {
    _deletedCertificates.add(_recentlyAdededCertificates.elementAt(index));
    _recentlyAdededCertificates.removeAt(index);
    notifyListeners();
  }

  bool isOnline(int index) {
    return _recentlyAdededCertificates[index].id != null;
  }
}
