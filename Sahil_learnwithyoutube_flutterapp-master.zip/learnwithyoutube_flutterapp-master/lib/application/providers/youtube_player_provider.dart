import 'package:flutter/cupertino.dart';
import 'package:injectable/injectable.dart';
import 'package:youtube_player_flutter/youtube_player_flutter.dart';

@lazySingleton
class PlayerProvider extends ChangeNotifier {
  YoutubePlayerController _youtubePlayerController;

  YoutubePlayerController get youtubePlayerController =>
      _youtubePlayerController;


  ///InitState
  void initilizeYoutubePlayer(YoutubePlayerController newController) {
    _youtubePlayerController = newController;
    notifyListeners();
  }


  ///Dispose
  void disposePlayer() {
    if (_youtubePlayerController.hasListeners) {
      _youtubePlayerController.dispose();
    }
  }
}
