part of 'chat_bloc.dart';

@freezed
abstract class ChatEvent with _$ChatEvent {
  const factory ChatEvent.getAllChats() = _GetAllChats;
  const factory ChatEvent.titleChanged(String title) = _TitleChanged;
  const factory ChatEvent.createChat({int userId}) = _CreateChat;
  const factory ChatEvent.addTeacherAttendance({int chatId}) =
      _AddTeacherAttendance;
  const factory ChatEvent.addStudentAttendance(
      {int chatId, int teacherAttendanceId}) = _AddStudentAttendance;
}
