import 'dart:async';

import 'package:bloc/bloc.dart';
import 'package:dartz/dartz.dart';
import 'package:flutter_app/domain/chat/attendance.dart';
import 'package:flutter_app/domain/chat/chat_failure.dart';
import 'package:flutter_app/domain/chat/i_chat_repo.dart';
import 'package:flutter_app/domain/chat/message.dart';
import 'package:flutter_app/domain/core/value_objects.dart';
import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:injectable/injectable.dart';

part 'chat_bloc.freezed.dart';
part 'chat_event.dart';
part 'chat_state.dart';

@injectable
class ChatBloc extends Bloc<ChatEvent, ChatState> {
  ChatBloc(this._iChatRepo) : super(null);

  final IChatRepo _iChatRepo;

  @override
  Stream<ChatState> mapEventToState(
    ChatEvent event,
  ) async* {
    yield* event.map(
      titleChanged: (e) async* {
        yield state.copyWith(
            title: StringSingleLine(e.title),
            failureOrSuccessForCRUDChat: none());
      },
      getAllChats: (e) async* {
        final successOrFailure = await _iChatRepo.getAllChats();
        yield successOrFailure.fold(
            (l) => state.copyWith(failureOrSuccessForCRUDChat: some(left(l))),
            (r) => state.copyWith(allChats: r));
      },
      createChat: (e) async* {
        Either<ChatFailure, Unit> failureOrSuccessForCRUDChat;
        if (state.title.isValid()) {
          failureOrSuccessForCRUDChat =
              await _iChatRepo.createChat(userId: e.userId, title: state.title);

          yield state.copyWith(
            failureOrSuccessForCRUDChat: optionOf(failureOrSuccessForCRUDChat),
            showErrorMessage: true,
          );
        }

        yield state.copyWith(
          failureOrSuccessForCRUDChat: optionOf(failureOrSuccessForCRUDChat),
          showErrorMessage: true,
        );
      },
      addTeacherAttendance: (e) async* {
        Either<ChatFailure, Attendance> failureOrSuccessForAttendance;

        failureOrSuccessForAttendance =
            await _iChatRepo.addTeacherAttendance(chatId: e.chatId);

        yield failureOrSuccessForAttendance.fold(
          (l) => state.copyWith(failureOrSuccessForAttendance: some(left(l))),
          (r) => state.copyWith(attendance: r),
        );
      },
      addStudentAttendance: (e) async* {
        Either<ChatFailure, Unit> failureOrSuccessForAttendance;

        failureOrSuccessForAttendance = await _iChatRepo.addStudentAttendance(
            chatId: e.chatId, teacherAttendanceId: e.teacherAttendanceId);

        yield failureOrSuccessForAttendance.fold(
          (l) => state.copyWith(
              failureOrSuccessForAttendance:
                  optionOf(failureOrSuccessForAttendance)),
          (r) => state.copyWith(failureOrSuccessForAttendance: none()),
        );
      },
    );
  }

  @override
  ChatState get initialState => ChatState.initial();
}
