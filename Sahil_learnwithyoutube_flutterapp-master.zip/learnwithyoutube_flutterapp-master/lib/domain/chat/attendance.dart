// To parse this JSON data, do
//
//     final attendance = attendanceFromJson(jsonString);

import 'dart:convert';

Attendance attendanceFromJson(String str) =>
    Attendance.fromJson(json.decode(str) as Map<String, dynamic>);

String attendanceToJson(Attendance data) => json.encode(data.toJson());

class Attendance {
  Attendance({
    this.id,
    this.teacherId,
    this.chatId,
    this.startTime,
    this.endTime,
    this.periodName,
    this.date,
    this.day,
    this.createdAt,
    this.updatedAt,
    this.teacher,
    this.classroom,
  });

  final int id;
  final int teacherId;
  final int chatId;
  final String startTime;
  final String endTime;
  final String periodName;
  final String date;
  final String day;
  final DateTime createdAt;
  final DateTime updatedAt;
  final Teacher teacher;
  final Classroom classroom;

  Attendance copyWith({
    int id,
    int teacherId,
    int chatId,
    String startTime,
    String endTime,
    String periodName,
    String date,
    String day,
    DateTime createdAt,
    DateTime updatedAt,
    Teacher teacher,
    Classroom classroom,
  }) =>
      Attendance(
        id: id ?? this.id,
        teacherId: teacherId ?? this.teacherId,
        chatId: chatId ?? this.chatId,
        startTime: startTime ?? this.startTime,
        endTime: endTime ?? this.endTime,
        periodName: periodName ?? this.periodName,
        date: date ?? this.date,
        day: day ?? this.day,
        createdAt: createdAt ?? this.createdAt,
        updatedAt: updatedAt ?? this.updatedAt,
        teacher: teacher ?? this.teacher,
        classroom: classroom ?? this.classroom,
      );

  factory Attendance.fromJson(Map<String, dynamic> json) => Attendance(
        id: json["id"] as int,
        teacherId: json["teacher_id"] as int,
        chatId: json["chat_id"] as int,
        startTime: json["start_time"] as String,
        endTime: json["end_time"] as String,
        periodName: json["period_name"] as String,
        date: json["date"] as String,
        day: json["day"] as String,
        createdAt: DateTime.parse(json["created_at"] as String),
        updatedAt: DateTime.parse(json["updated_at"] as String),
        teacher: Teacher.fromJson(json["teacher"] as Map<String, dynamic>),
        classroom:
            Classroom.fromJson(json["classroom"] as Map<String, dynamic>),
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "teacher_id": teacherId,
        "chat_id": chatId,
        "start_time": startTime,
        "end_time": endTime,
        "period_name": periodName,
        "date": date,
        "day": day,
        "created_at": createdAt.toIso8601String(),
        "updated_at": updatedAt.toIso8601String(),
        "teacher": teacher.toJson(),
        "classroom": classroom.toJson(),
      };
}

class Classroom {
  Classroom({
    this.id,
    this.title,
    this.receiverId,
    this.creatorId,
    this.chatTypeId,
    this.isSupport,
    this.createdAt,
    this.updatedAt,
  });

  final int id;
  final String title;
  final int receiverId;
  final int creatorId;
  final int chatTypeId;
  final int isSupport;
  final DateTime createdAt;
  final DateTime updatedAt;

  Classroom copyWith({
    int id,
    String title,
    int receiverId,
    int creatorId,
    int chatTypeId,
    int isSupport,
    DateTime createdAt,
    DateTime updatedAt,
  }) =>
      Classroom(
        id: id ?? this.id,
        title: title ?? this.title,
        receiverId: receiverId ?? this.receiverId,
        creatorId: creatorId ?? this.creatorId,
        chatTypeId: chatTypeId ?? this.chatTypeId,
        isSupport: isSupport ?? this.isSupport,
        createdAt: createdAt ?? this.createdAt,
        updatedAt: updatedAt ?? this.updatedAt,
      );

  factory Classroom.fromJson(Map<String, dynamic> json) => Classroom(
        id: json["id"] as int,
        title: json["title"] as String,
        receiverId: json["receiver_id"] as int,
        creatorId: json["creator_id"] as int,
        chatTypeId: json["chat_type_id"] as int,
        isSupport: json["is_support"] as int,
        createdAt: DateTime.parse(json["created_at"] as String),
        updatedAt: DateTime.parse(json["updated_at"] as String),
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "title": title,
        "receiver_id": receiverId,
        "creator_id": creatorId,
        "chat_type_id": chatTypeId,
        "is_support": isSupport,
        "created_at": createdAt.toIso8601String(),
        "updated_at": updatedAt.toIso8601String(),
      };
}

class Teacher {
  Teacher({
    this.id,
    this.name,
    this.uniqueId,
    this.avatar,
    this.email,
    this.age,
    this.phone,
    this.slug,
    this.shortBio,
    this.facebookLink,
    this.instagramLink,
    this.githubLink,
    this.twitterUrl,
    this.linkedinUrl,
    this.profileLink,
    this.flag,
    this.roleId,
    this.languageId,
    this.countryId,
    this.createdAt,
    this.updatedAt,
  });

  final int id;
  final String name;
  final String uniqueId;
  final String avatar;
  final String email;
  final dynamic age;
  final dynamic phone;
  final dynamic slug;
  final dynamic shortBio;
  final dynamic facebookLink;
  final dynamic instagramLink;
  final dynamic githubLink;
  final dynamic twitterUrl;
  final dynamic linkedinUrl;
  final dynamic profileLink;
  final String flag;
  final int roleId;
  final int languageId;
  final dynamic countryId;
  final dynamic createdAt;
  final dynamic updatedAt;

  Teacher copyWith({
    int id,
    String name,
    String uniqueId,
    String avatar,
    String email,
    dynamic age,
    dynamic phone,
    dynamic slug,
    dynamic shortBio,
    dynamic facebookLink,
    dynamic instagramLink,
    dynamic githubLink,
    dynamic twitterUrl,
    dynamic linkedinUrl,
    dynamic profileLink,
    String flag,
    int roleId,
    int languageId,
    dynamic countryId,
    dynamic createdAt,
    dynamic updatedAt,
  }) =>
      Teacher(
        id: id ?? this.id,
        name: name ?? this.name,
        uniqueId: uniqueId ?? this.uniqueId,
        avatar: avatar ?? this.avatar,
        email: email ?? this.email,
        age: age ?? this.age,
        phone: phone ?? this.phone,
        slug: slug ?? this.slug,
        shortBio: shortBio ?? this.shortBio,
        facebookLink: facebookLink ?? this.facebookLink,
        instagramLink: instagramLink ?? this.instagramLink,
        githubLink: githubLink ?? this.githubLink,
        twitterUrl: twitterUrl ?? this.twitterUrl,
        linkedinUrl: linkedinUrl ?? this.linkedinUrl,
        profileLink: profileLink ?? this.profileLink,
        flag: flag ?? this.flag,
        roleId: roleId ?? this.roleId,
        languageId: languageId ?? this.languageId,
        countryId: countryId ?? this.countryId,
        createdAt: createdAt ?? this.createdAt,
        updatedAt: updatedAt ?? this.updatedAt,
      );

  factory Teacher.fromJson(Map<String, dynamic> json) => Teacher(
        id: json["id"] as int,
        name: json["name"] as String,
        uniqueId: json["unique_id"] as String,
        avatar: json["avatar"] as String,
        email: json["email"] as String,
        age: json["age"],
        phone: json["phone"],
        slug: json["slug"],
        shortBio: json["short_bio"],
        facebookLink: json["facebook_link"],
        instagramLink: json["instagram_link"],
        githubLink: json["github_link"],
        twitterUrl: json["twitter_url"],
        linkedinUrl: json["linkedin_url"],
        profileLink: json["profile_link"],
        flag: json["flag"] as String,
        roleId: json["role_id"] as int,
        languageId: json["language_id"] as int,
        countryId: json["country_id"],
        createdAt: json["created_at"],
        updatedAt: json["updated_at"],
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "name": name,
        "unique_id": uniqueId,
        "avatar": avatar,
        "email": email,
        "age": age,
        "phone": phone,
        "slug": slug,
        "short_bio": shortBio,
        "facebook_link": facebookLink,
        "instagram_link": instagramLink,
        "github_link": githubLink,
        "twitter_url": twitterUrl,
        "linkedin_url": linkedinUrl,
        "profile_link": profileLink,
        "flag": flag,
        "role_id": roleId,
        "language_id": languageId,
        "country_id": countryId,
        "created_at": createdAt,
        "updated_at": updatedAt,
      };
}
