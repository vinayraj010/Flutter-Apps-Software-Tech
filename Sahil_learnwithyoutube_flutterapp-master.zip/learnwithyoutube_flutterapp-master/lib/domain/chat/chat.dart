// To parse this JSON data, do
//
//     final chat = chatFromJson(jsonString);

import 'dart:convert';

Chat chatFromJson(String str) =>
    Chat.fromJson(json.decode(str) as Map<String, dynamic>);

class Chat {
  Chat({
    this.chatId,
    this.userId,
    this.title,
    this.receiverId,
    this.creatorId,
    this.chatTypeId,
    this.isSupport,
    this.createdAt,
    this.updatedAt,
  });

  final int chatId;
  final int userId;
  final String title;
  final int receiverId;
  final int creatorId;
  final int chatTypeId;
  final int isSupport;
  final DateTime createdAt;
  final DateTime updatedAt;

  Chat copyWith({
    int id,
    String title,
    int receiverId,
    int creatorId,
    int chatTypeId,
    int isSupport,
    DateTime createdAt,
    DateTime updatedAt,
  }) =>
      Chat(
        chatId: chatId ?? chatId,
        title: title ?? this.title,
        receiverId: receiverId ?? this.receiverId,
        creatorId: creatorId ?? this.creatorId,
        chatTypeId: chatTypeId ?? this.chatTypeId,
        isSupport: isSupport ?? this.isSupport,
        createdAt: createdAt ?? this.createdAt,
        updatedAt: updatedAt ?? this.updatedAt,
      );

  factory Chat.fromJson(Map<String, dynamic> json) => Chat(
        chatId: json["pivot"]["chat_id"] as int,
        userId: json["pivot"]["user_id"] as int,
        title: json["title"] as String,
        receiverId: json["receiver_id"] as int,
        creatorId: json["creator_id"] as int,
        chatTypeId: json["chat_type_id"] as int,
        isSupport: json["is_support"] as int,
        createdAt: DateTime.parse(json["created_at"] as String),
        updatedAt: DateTime.parse(json["updated_at"] as String),
      );
}
