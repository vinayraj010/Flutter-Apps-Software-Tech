import 'package:form_validators/form_validators.dart';

class FacebookUsernameValidator implements IValidator {
  final String message;

  const FacebookUsernameValidator(this.message);

  @override
  bool call(String value) {
    const _regex = r"""^(?!.*\.(?:com|net))[A-Za-z0-9.]{5,}$""";
    // r"""^(?!.*\.\.)(?!.*\.$)[^\W][\w.]{0,29}$""";
   if (value == null || value.isEmpty) {
      return false;
    } else if (RegExp(_regex).hasMatch(value)) {
      return false;
    } else {
      return true;
    }
  }
}
