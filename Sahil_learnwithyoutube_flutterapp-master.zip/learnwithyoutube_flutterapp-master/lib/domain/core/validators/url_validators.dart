import 'package:flutter_app/domain/profile/value_objects.dart';
import 'package:form_validators/form_validators.dart';

class NotUrlValidator implements IValidator {
  final String message;

 const NotUrlValidator(this.message);

  @override
  bool call(String value) {
    if (!Url(value).isValid()) {
      return false;
    } else {
      return true;
    }
  }
}
