import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:meta/meta.dart';

part 'backend_failure.freezed.dart';

@freezed
abstract class BackendFailure with _$BackendFailure {
  const factory BackendFailure.serverError() = ServerError;
  const factory BackendFailure.tokenError() = TokenError;
}
