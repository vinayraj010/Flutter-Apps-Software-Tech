import 'dart:ui';

Color makeColorOpaque(Color color) {
  return color.withOpacity(1);
}
