import 'value_objects.dart';

abstract class IEntity {
  UniqueId get id;
}
