// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies

part of 'backend_failure.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

/// @nodoc
class _$BackendFailureTearOff {
  const _$BackendFailureTearOff();

// ignore: unused_element
  ServerError serverError() {
    return const ServerError();
  }

// ignore: unused_element
  TokenError tokenError() {
    return const TokenError();
  }
}

/// @nodoc
// ignore: unused_element
const $BackendFailure = _$BackendFailureTearOff();

/// @nodoc
mixin _$BackendFailure {
  @optionalTypeArgs
  Result when<Result extends Object>({
    @required Result serverError(),
    @required Result tokenError(),
  });
  @optionalTypeArgs
  Result maybeWhen<Result extends Object>({
    Result serverError(),
    Result tokenError(),
    @required Result orElse(),
  });
  @optionalTypeArgs
  Result map<Result extends Object>({
    @required Result serverError(ServerError value),
    @required Result tokenError(TokenError value),
  });
  @optionalTypeArgs
  Result maybeMap<Result extends Object>({
    Result serverError(ServerError value),
    Result tokenError(TokenError value),
    @required Result orElse(),
  });
}

/// @nodoc
abstract class $BackendFailureCopyWith<$Res> {
  factory $BackendFailureCopyWith(
          BackendFailure value, $Res Function(BackendFailure) then) =
      _$BackendFailureCopyWithImpl<$Res>;
}

/// @nodoc
class _$BackendFailureCopyWithImpl<$Res>
    implements $BackendFailureCopyWith<$Res> {
  _$BackendFailureCopyWithImpl(this._value, this._then);

  final BackendFailure _value;
  // ignore: unused_field
  final $Res Function(BackendFailure) _then;
}

/// @nodoc
abstract class $ServerErrorCopyWith<$Res> {
  factory $ServerErrorCopyWith(
          ServerError value, $Res Function(ServerError) then) =
      _$ServerErrorCopyWithImpl<$Res>;
}

/// @nodoc
class _$ServerErrorCopyWithImpl<$Res> extends _$BackendFailureCopyWithImpl<$Res>
    implements $ServerErrorCopyWith<$Res> {
  _$ServerErrorCopyWithImpl(
      ServerError _value, $Res Function(ServerError) _then)
      : super(_value, (v) => _then(v as ServerError));

  @override
  ServerError get _value => super._value as ServerError;
}

/// @nodoc
class _$ServerError implements ServerError {
  const _$ServerError();

  @override
  String toString() {
    return 'BackendFailure.serverError()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) || (other is ServerError);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  Result when<Result extends Object>({
    @required Result serverError(),
    @required Result tokenError(),
  }) {
    assert(serverError != null);
    assert(tokenError != null);
    return serverError();
  }

  @override
  @optionalTypeArgs
  Result maybeWhen<Result extends Object>({
    Result serverError(),
    Result tokenError(),
    @required Result orElse(),
  }) {
    assert(orElse != null);
    if (serverError != null) {
      return serverError();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  Result map<Result extends Object>({
    @required Result serverError(ServerError value),
    @required Result tokenError(TokenError value),
  }) {
    assert(serverError != null);
    assert(tokenError != null);
    return serverError(this);
  }

  @override
  @optionalTypeArgs
  Result maybeMap<Result extends Object>({
    Result serverError(ServerError value),
    Result tokenError(TokenError value),
    @required Result orElse(),
  }) {
    assert(orElse != null);
    if (serverError != null) {
      return serverError(this);
    }
    return orElse();
  }
}

abstract class ServerError implements BackendFailure {
  const factory ServerError() = _$ServerError;
}

/// @nodoc
abstract class $TokenErrorCopyWith<$Res> {
  factory $TokenErrorCopyWith(
          TokenError value, $Res Function(TokenError) then) =
      _$TokenErrorCopyWithImpl<$Res>;
}

/// @nodoc
class _$TokenErrorCopyWithImpl<$Res> extends _$BackendFailureCopyWithImpl<$Res>
    implements $TokenErrorCopyWith<$Res> {
  _$TokenErrorCopyWithImpl(TokenError _value, $Res Function(TokenError) _then)
      : super(_value, (v) => _then(v as TokenError));

  @override
  TokenError get _value => super._value as TokenError;
}

/// @nodoc
class _$TokenError implements TokenError {
  const _$TokenError();

  @override
  String toString() {
    return 'BackendFailure.tokenError()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) || (other is TokenError);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  Result when<Result extends Object>({
    @required Result serverError(),
    @required Result tokenError(),
  }) {
    assert(serverError != null);
    assert(tokenError != null);
    return tokenError();
  }

  @override
  @optionalTypeArgs
  Result maybeWhen<Result extends Object>({
    Result serverError(),
    Result tokenError(),
    @required Result orElse(),
  }) {
    assert(orElse != null);
    if (tokenError != null) {
      return tokenError();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  Result map<Result extends Object>({
    @required Result serverError(ServerError value),
    @required Result tokenError(TokenError value),
  }) {
    assert(serverError != null);
    assert(tokenError != null);
    return tokenError(this);
  }

  @override
  @optionalTypeArgs
  Result maybeMap<Result extends Object>({
    Result serverError(ServerError value),
    Result tokenError(TokenError value),
    @required Result orElse(),
  }) {
    assert(orElse != null);
    if (tokenError != null) {
      return tokenError(this);
    }
    return orElse();
  }
}

abstract class TokenError implements BackendFailure {
  const factory TokenError() = _$TokenError;
}
