import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:flutter_app/domain/core/backend_failure.dart';
import 'package:flutter_app/infrastructure/core/backend_request.dart';

abstract class IBackendRequest {
  Future<Either<BackendFailure, Unit>> refreshFirebase();
  Future<Either<BackendFailure, Unit>> verifyFirebaseAccessToken(
      {String accessToken, int roleId});
  Future<Response> securedHTTPSRequest(
      {String endpoint, HTTPMETHODS method, dynamic data, String headers});
}
