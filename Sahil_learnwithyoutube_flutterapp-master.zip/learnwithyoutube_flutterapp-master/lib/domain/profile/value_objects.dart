import 'package:dartz/dartz.dart';
import 'package:flutter_app/domain/core/failures.dart';
import 'package:flutter_app/domain/core/value_objects.dart';
import 'package:flutter_app/domain/core/value_validators.dart';

class Url extends ValueObject<String> {
  @override
  final Either<ValueFailure<String>, String> value;

  factory Url(String input) {
    assert(input != null);
    return Url._(
      validateUrl(input),
    );
  }

  const Url._(this.value);
}
