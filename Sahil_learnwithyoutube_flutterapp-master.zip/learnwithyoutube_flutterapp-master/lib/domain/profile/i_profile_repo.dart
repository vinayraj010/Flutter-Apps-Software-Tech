import 'package:dartz/dartz.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter_app/domain/core/country.dart';
import 'package:flutter_app/domain/profile/profile.dart';
import 'package:flutter_app/domain/profile/profile_failure.dart';

abstract class IProfileRepo {
  Future<Either<ProfileFailure, Profile>> submitUserProfile({
    @required String name,
    @required String email,
    @required int country,
    String avatar,
    @required int age,
    @required String college,
    List<String> domains,
  });
  Future<Either<ProfileFailure, Profile>> getUserProfile();
  Future<Either<ProfileFailure, Profile>> updateName(String name);
  Future<Either<ProfileFailure, Profile>> updateCountry(String country);
  Future<Either<ProfileFailure, Profile>> updateAvatar(String avatar);
  Future<Either<ProfileFailure, Profile>> updateUserProfile(
      Map<String, dynamic> data);

  //Skills
  Future<Either<ProfileFailure, Unit>> addDomains(List<Domain> domains);
  Future<Either<ProfileFailure, Unit>> updateDomains(Domain domain);
  Future<Either<ProfileFailure, Unit>> deleteDomain(Domain domain);

  //Education
  Future<Either<ProfileFailure, Unit>> addEducation(
      List<EducationStandard> educations);
  Future<Either<ProfileFailure, Unit>> updateEducationInstitute(
      List<EducationStandard> educations);
  Future<Either<ProfileFailure, Unit>> updateEducationStandard(
      List<EducationStandard> educations);
  Future<Either<ProfileFailure, Unit>> deleteEducation(
      EducationStandard education);

  //Certificates
  Future<Either<ProfileFailure, Unit>> addUserCertificate(
      Certificate certificates);
  Future<Either<ProfileFailure, Unit>> updateUserCertificate(
      Certificate certificates);
  Future<Either<ProfileFailure, Unit>> deleteUserCertificate(
      Certificate certificate);

  //Certificates
  Future<Either<ProfileFailure, Profile>> addSocialMedia(
    String facebookUserName,
    String instagramUserName,
    String twitterUserName,
    String linkedinUserName,
  );

  //Countries
  Future<Either<ProfileFailure, List<Country>>> getCountries();
}
