import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:meta/meta.dart';

part 'profile_failure.freezed.dart';

@freezed
abstract class ProfileFailure with _$ProfileFailure {
  const factory ProfileFailure.serverError() = _ServerError;
  const factory ProfileFailure.invalidEmailError() = _InvalidEmailError;
  const factory ProfileFailure.invalidUrlError() = _InvalidUrlError;
  const factory ProfileFailure.allFieldsNotFilledError({String message}) = _AllFieldsNotFilledError;
}
