import 'dart:developer';

import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:flutter_app/core/strings.dart';
import 'package:flutter_app/domain/chat/message.dart';
import 'package:flutter_app/domain/core/i_backend_request.dart';
import 'package:flutter_app/domain/core/token_model.dart';
import 'package:flutter_app/domain/core/value_objects.dart';
import 'package:flutter_app/domain/message/i_message_repo.dart';
import 'package:flutter_app/domain/message/message_failure.dart';
import 'package:flutter_app/infrastructure/core/api_endpoints.dart';
import 'package:flutter_app/infrastructure/core/backend_request.dart';
import 'package:hive/hive.dart';
import 'package:http_parser/http_parser.dart';
import 'package:injectable/injectable.dart';

@prod
@lazySingleton
class MessageRepo extends IMessageRepo {
  final IBackendRequest _backendRequest;
  final Box<ResponseTokenModel> _box;

  MessageRepo(this._backendRequest, this._box);
  @override
  Future<Either<MessageFailure, Message>> getChatMessage(
      {int chatId, String url}) async {
    try {
      return await _backendRequest
          .securedHTTPSRequest(
              endpoint: '$url&chat_id=$chatId', method: HTTPMETHODS.get)
          .then((value) => right(
              Message.fromJson(value.data['data'] as Map<String, dynamic>)));
    } catch (e) {
      return left(const MessageFailure.serverError());
    }
  }

  @override
  Future<Either<MessageFailure, Unit>> sendMessage(
      {NonNullString message, int chatId}) async {
    try {
      final String messageString =
          message.value.getOrElse(() => 'INVALID_MESSAGE');
      return await _backendRequest
          .securedHTTPSRequest(
              endpoint: ApiEndpoint.sendMessage,
              data: {
                'chat_id': chatId,
                'message': messageString,
                'role_id': _box.get(HiveBoxNames.token).roleId
              },
              method: HTTPMETHODS.post)
          .catchError((onError) {
        print((onError as DioError).request.data);
      }).then((value) => right(unit));
    } catch (e) {
      return left(const MessageFailure.serverError());
    }
  }

  @override
  Future<Either<MessageFailure, Unit>> sendMultiMediaMessage(
      {int chatId, String path, int typeId}) async {
    final Map<String, dynamic> body = {
      'chat_id': chatId,
      'role_id': _box.get(HiveBoxNames.token).roleId,
      'type_id': typeId
    };

    final FormData formData = FormData.fromMap(body);

    final MultipartFile file = await MultipartFile.fromFile(
      path,
      contentType: MediaType('video', '.mp4'),
    );
    formData.files.add(MapEntry('file', file));

    try {
      return await _backendRequest
          .securedHTTPSRequest(
              endpoint: ApiEndpoint.sendMultiMedia,
              data: formData,
              method: HTTPMETHODS.post,
              headers: 'multipart/form-data')
          .catchError((onError) {})
          .then((value) {
        log(value.toString());
        return value == null
            ? left(const MessageFailure.serverError())
            : right(unit);
      });
    } catch (e) {
      return left(const MessageFailure.serverError());
    }
  }
}
