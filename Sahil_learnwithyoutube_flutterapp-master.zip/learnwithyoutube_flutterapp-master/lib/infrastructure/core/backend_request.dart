import 'dart:developer';

import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter_app/core/strings.dart';
import 'package:flutter_app/domain/core/backend_failure.dart';
import 'package:flutter_app/domain/core/i_backend_request.dart';
import 'package:flutter_app/domain/core/token_model.dart';
import 'package:flutter_app/infrastructure/core/api_endpoints.dart';
import 'package:hive/hive.dart';
import 'package:injectable/injectable.dart';

enum HTTPMETHODS { get, post, patch, delete }

@prod
@lazySingleton
class BackendRequest extends IBackendRequest {
  final Dio _dio;
  final Box<ResponseTokenModel> _box;

  BackendRequest(this._dio, this._box);

  @override
  // ignore: missing_return
  Future<Response> securedHTTPSRequest(
      {@required String endpoint,
      @required HTTPMETHODS method,
      @required dynamic data,
      String headers}) async {
    final Dio dio = Dio();

    dio.options.headers['content-type'] = headers ?? 'application/json';
    dio.options.headers["authorization"] =
        "Bearer ${_box.get(HiveBoxNames.token).accessToken}";
    Response dioResponse;

    // log(_box.get(HiveBoxNames.token).accessToken);

    try {
      if (method == HTTPMETHODS.get) {
        dioResponse = await dio.get(endpoint,
            queryParameters: data as Map<String, dynamic>);
      } else if (method == HTTPMETHODS.post) {
        dioResponse = await dio.post(endpoint, data: data);
      } else if (method == HTTPMETHODS.patch) {
        dioResponse = await dio.patch(endpoint, data: data);
      } else if (method == HTTPMETHODS.delete) {
        dioResponse = await dio.delete(endpoint, data: data);
      } else {
        dioResponse = await dio.get(endpoint,
            queryParameters: data as Map<String, dynamic>);
      }
      return dioResponse;
    } catch (e) {
      if (e is DioError && e.response.statusCode == 401) {
        await refreshFirebase();
        log('Token Refreshed Successfully');
        return securedHTTPSRequest(
            method: method, data: data, endpoint: endpoint, headers: headers);
      } else {
        return dioResponse;
      }
    }
  }

  @override
  Future<Either<BackendFailure, Unit>> refreshFirebase() async {
    final ResponseTokenModel _tokenModel = _box.get(HiveBoxNames.token);
    final Response _dioResponse =
        await _dio.post(ApiEndpoint.refreshFirebase, data: {
      'unique_id': _tokenModel.uniqueId,
      'user_role': _tokenModel.roleId,
      'refresh_token': _tokenModel.refreshToken,
    });

    if (_dioResponse.statusCode != 200) {
      return left(const BackendFailure.serverError());
    } else {
      final String newAccessToken =
          _dioResponse.data['data']['access_token'] as String;

      final ResponseTokenModel _oldResponseModel = _box.get(HiveBoxNames.token);

      _box.put(HiveBoxNames.token,
          _oldResponseModel.copyWith(accessToken: newAccessToken));

      return right(unit);
    }
  }

  @override
  Future<Either<BackendFailure, Unit>> verifyFirebaseAccessToken(
      {String accessToken, int roleId}) async {
    final Response _dioResponse = await _dio.post(
      ApiEndpoint.verifyFirebaseAccessToken,
      data: {'access_token': accessToken, 'user_role': roleId},
    );

    if (_dioResponse.statusCode != 200) {
      return left(const BackendFailure.serverError());
    } else {
      final ResponseTokenModel _responseModel = ResponseTokenModel.fromJson(
          _dioResponse.data['data'] as Map<String, dynamic>);
      _box.put(HiveBoxNames.token, _responseModel.copyWith(roleId: roleId));
      log('Token verified Successfully');

      return right(unit);
    }
  }
}
