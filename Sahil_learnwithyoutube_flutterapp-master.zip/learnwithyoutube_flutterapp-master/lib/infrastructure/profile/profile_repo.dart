import 'dart:convert';

import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:flutter_app/domain/core/country.dart';
import 'package:flutter_app/domain/core/i_backend_request.dart';
import 'package:flutter_app/domain/profile/i_profile_repo.dart';
import 'package:flutter_app/domain/profile/profile.dart';
import 'package:flutter_app/domain/profile/profile_failure.dart';
import 'package:flutter_app/infrastructure/core/api_endpoints.dart';
import 'package:flutter_app/infrastructure/core/backend_request.dart';
import 'package:injectable/injectable.dart';

@prod
@lazySingleton
class ProfileRepo extends IProfileRepo {
  final IBackendRequest _backendRequest;
  final Dio _dio;

  ProfileRepo(this._backendRequest, this._dio);

  /*
  @override
  Future<Either<ProfileFailure, Profile>> addFacebookLink(String url) async {
    try {
      return await _backendRequest
          .securedHTTPSRequest(
              endpoint: ApiEndpoint.addUserFacebookLink,
              data: {'facebook_link': url},
              method: HTTPMETHODS.post)
          .then((response) async {
        if (response.statusCode != 200) {
          return left(const ProfileFailure.serverError());
        } else {
          return right(Profile.fromJson(
              response.data['data'][0] as Map<String, dynamic>));
        }
      });
    } catch (e) {
      return left(const ProfileFailure.serverError());
    }
  }

  @override
  Future<Either<ProfileFailure, Profile>> addInstagramLink(String url) async {
    try {
      return await _backendRequest
          .securedHTTPSRequest(
              endpoint: ApiEndpoint.addUserInstagramLink,
              data: {'instagram_link': url},
              method: HTTPMETHODS.post)
          .then((response) async {
        if (response.statusCode != 200) {
          return left(const ProfileFailure.serverError());
        } else {
          return right(Profile.fromJson(
              response.data['data'][0] as Map<String, dynamic>));
        }
      });
    } catch (e) {
      return left(const ProfileFailure.serverError());
    }
  }

  @override
  Future<Either<ProfileFailure, Profile>> addLinkedinLink(String url) async {
    try {
      return await _backendRequest
          .securedHTTPSRequest(
              endpoint: ApiEndpoint.updateUserProfile,
              data: {'linkedin_url': url},
              method: HTTPMETHODS.post)
          .then((response) async {
        if (response.statusCode != 200) {
          return left(const ProfileFailure.serverError());
        } else {
          return right(Profile.fromJson(
              response.data['data'][0] as Map<String, dynamic>));
        }
      });
    } catch (e) {
      return left(const ProfileFailure.serverError());
    }
  }



  @override
  Future<Either<ProfileFailure, Profile>> addTwitterLink(String url) async {
    try {
      return await _backendRequest
          .securedHTTPSRequest(
              endpoint: ApiEndpoint.addUserTwitterLink,
              data: {'twitter_url': url},
              method: HTTPMETHODS.post)
          .then((response) async {
        if (response.statusCode != 200) {
          return left(const ProfileFailure.serverError());
        } else {
          return right(Profile.fromJson(
              response.data['data'][0] as Map<String, dynamic>));
        }
      });
    } catch (e) {
      return left(const ProfileFailure.serverError());
    }
  }
  */

  @override
  Future<Either<ProfileFailure, Unit>> addUserCertificate(
      Certificate certificate) async {
    /*
         await MultipartFile.fromFile(certificate.image,
              filename: certificate.image.split('/').last)
              */

    FormData certificateFormData;

    final Map<String, dynamic> _map = certificate.toJson();

    _map.addAll({
      "certificate_image": await MultipartFile.fromFile(certificate.image,
          filename: certificate.image.split('/').last)
    });
    certificateFormData = FormData.fromMap(_map);

    try {
      return await _backendRequest
          .securedHTTPSRequest(
        endpoint: ApiEndpoint.addUserCertificate,
        //Formdata
        method: HTTPMETHODS.post,
        data: certificateFormData,
        headers: 'multipart/form-data',
      )
          .then((response) async {
        if (response.statusCode != 200) {
          return left(const ProfileFailure.serverError());
        } else {
          return right(unit);
        }
      });
    } catch (e) {
      return left(const ProfileFailure.serverError());
    }
  }

  @override
  Future<Either<ProfileFailure, Profile>> getUserProfile() async {
    try {
      return await _backendRequest
          .securedHTTPSRequest(endpoint: ApiEndpoint.getUserProfile)
          .then((response) async {
        if (response.statusCode != 200) {
          return left(const ProfileFailure.serverError());
        } else {
          return right(Profile.fromJson(
              response.data['data'][0] as Map<String, dynamic>));
        }
      });
    } catch (e) {
      return left(const ProfileFailure.serverError());
    }
  }

  @override
  Future<Either<ProfileFailure, Profile>> submitUserProfile(
      {String name,
      String email,
      int country,
      int age,
      String college,
      String avatar,
      List<String> domains}) async {
    // TODO: implement submitUserProfile
    try {
      return await _backendRequest.securedHTTPSRequest(
        endpoint: ApiEndpoint.submitUserProfile,
        method: HTTPMETHODS.post,
        data: {
          'name': name,
          'age': age,
          'email': email,
          'country': country,
          'college': college,
          'avatar': avatar,
          'domains': domains
        },
      ).catchError((onError) {
        return left(const ProfileFailure.serverError());
      }).then((response) async {
        if (response.statusCode != 200) {
          return left(const ProfileFailure.serverError());
        } else {
          return right(Profile.fromJson(
              response.data['data'][0] as Map<String, dynamic>));
        }
      });
    } catch (e) {
      return left(const ProfileFailure.serverError());
    }
  }

  @override
  Future<Either<ProfileFailure, List<Country>>> getCountries() async {
    try {
      return await _dio.get(ApiEndpoint.getAllCountries).then(
          (response) => right(countryFromJson(response.data['data'] as List)));
    } catch (e) {
      return left(const ProfileFailure.serverError());
    }
  }

  @override
  @override
  Future<Either<ProfileFailure, Profile>> updateAvatar(String avatar) async {
    final FormData formData = FormData();

    final MultipartFile file = await MultipartFile.fromFile(avatar);
    formData.files.add(MapEntry('avatar', file));
    try {
      return await _backendRequest
          .securedHTTPSRequest(
        endpoint: ApiEndpoint.updateUserProfile,
        method: HTTPMETHODS.post,
        data: formData,
        headers: 'multipart/form-data',
      )
          .catchError((onError) {
        return left(const ProfileFailure.serverError());
      }).then((response) async {
        if (response.statusCode != 200) {
          return left(const ProfileFailure.serverError());
        } else {
          return right(Profile.fromJson(
              response.data['data'][0] as Map<String, dynamic>));
        }
      });
    } catch (e) {
      return left(const ProfileFailure.serverError());
    }
  }

  /*

  @override
  Future<Either<ProfileFailure, Profile>> updateCollege(String college) async {
    try {
      return await _backendRequest.securedHTTPSRequest(
        endpoint: ApiEndpoint.updateUserProfile,
        method: HTTPMETHODS.post,
        data: {'college': college},
      ).catchError((onError) {
        return left(const ProfileFailure.serverError());
      }).then((response) async {
        if (response.statusCode != 200) {
          return left(const ProfileFailure.serverError());
        } else {
          return right(Profile.fromJson(
              response.data['data'][0] as Map<String, dynamic>));
        }
      });
    } catch (e) {
      return left(const ProfileFailure.serverError());
    }
  }

  */

  @override
  Future<Either<ProfileFailure, Profile>> updateCountry(String country) async {
    try {
      return await _backendRequest.securedHTTPSRequest(
        endpoint: ApiEndpoint.updateUserProfile,
        method: HTTPMETHODS.post,
        data: {'country': country},
      ).catchError((onError) {
        return left(const ProfileFailure.serverError());
      }).then((response) async {
        if (response.statusCode != 200) {
          return left(const ProfileFailure.serverError());
        } else {
          return right(Profile.fromJson(
              response.data['data'][0] as Map<String, dynamic>));
        }
      });
    } catch (e) {
      return left(const ProfileFailure.serverError());
    }
  }

  @override
  Future<Either<ProfileFailure, Unit>> updateDomains(Domain domain) async {
    final Map<String, dynamic> args = {
      "skill_id": domain.id,
      "skill_name": domain.name,
      "skill_experience": domain.value,
    };
    final dynamic _data = jsonEncode(args);

    try {
      return await _backendRequest
          .securedHTTPSRequest(
        endpoint: ApiEndpoint.updateDomain,
        method: HTTPMETHODS.post,
        data: _data,
      )
          .catchError((onError) {
        return left(const ProfileFailure.serverError());
      }).then((response) async {
        if (response.statusCode != 200) {
          return left(const ProfileFailure.serverError());
        } else {
          return right(unit);
        }
      });
    } catch (e) {
      return left(const ProfileFailure.serverError());
    }
  }

  @override
  Future<Either<ProfileFailure, Profile>> updateName(String name) async {
    try {
      return await _backendRequest.securedHTTPSRequest(
        endpoint: ApiEndpoint.updateUserProfile,
        method: HTTPMETHODS.post,
        data: {'name': name},
      ).catchError((onError) {
        return left(const ProfileFailure.serverError());
      }).then((response) async {
        if (response.statusCode != 200) {
          return left(const ProfileFailure.serverError());
        } else {
          return right(Profile.fromJson(
              response.data['data'][0] as Map<String, dynamic>));
        }
      });
    } catch (e) {
      return left(const ProfileFailure.serverError());
    }
  }

  @override
  Future<Either<ProfileFailure, Unit>> updateEducationInstitute(
      List<EducationStandard> educations) async {
    final List<String> institute =
        educations.map((education) => education.instituteName.name).toList();
    final List<int> ids =
        educations.map((education) => education.instituteName.id).toList();
    final Map<String, dynamic> args = {
      "education_institute_ids": ids,
      "education_institutes": institute,
    };
    final dynamic _data = jsonEncode(args);
    try {
      return await _backendRequest
          .securedHTTPSRequest(
        endpoint: ApiEndpoint.updateEducationInstitute,
        method: HTTPMETHODS.post,
        data: _data,
      )
          .catchError((onError) {
        return left(const ProfileFailure.serverError());
      }).then((response) async {
        if (response.statusCode != 200) {
          return left(const ProfileFailure.serverError());
        } else {
          return right(unit);
        }
      });
    } catch (e) {
      return left(const ProfileFailure.serverError());
    }
  }

  @override
  Future<Either<ProfileFailure, Unit>> updateEducationStandard(
      List<EducationStandard> educations) async {
    final List<String> standards =
        educations.map((education) => education.standardName.name).toList();
    final List<int> ids =
        educations.map((education) => education.standardName.id).toList();
    final Map<String, dynamic> args = {
      "education_standard_ids": ids,
      "education_standards": standards,
    };
    final dynamic _data = jsonEncode(args);
    try {
      return await _backendRequest
          .securedHTTPSRequest(
        endpoint: ApiEndpoint.updateEducationStandard,
        method: HTTPMETHODS.post,
        data: _data,
      )
          .catchError((onError) {
        return left(const ProfileFailure.serverError());
      }).then((response) async {
        if (response.statusCode != 200) {
          return left(const ProfileFailure.serverError());
        } else {
          return right(unit);
        }
      });
    } catch (e) {
      return left(const ProfileFailure.serverError());
    }
  }

  @override
  Future<Either<ProfileFailure, Profile>> updateUserProfile(
      Map<String, dynamic> data) async {
    try {
      return await _backendRequest
          .securedHTTPSRequest(
        endpoint: ApiEndpoint.updateUserProfile,
        method: HTTPMETHODS.post,
        data: data,
      )
          .catchError((onError) {
        return left(const ProfileFailure.serverError());
      }).then((response) async {
        if (response.statusCode != 200) {
          return left(const ProfileFailure.serverError());
        } else {
          return right(Profile.fromJson(
              response.data['data'][0] as Map<String, dynamic>));
        }
      });
    } catch (e) {
      return left(const ProfileFailure.serverError());
    }
  }

  @override
  Future<Either<ProfileFailure, Profile>> addSocialMedia(
      String facebookUserName,
      String instagramUserName,
      String twitterUserName,
      String linkedinUserName) async {
    final Map<String, dynamic> _data = {
      'facebook_link': facebookUserName,
      'instagram_link': instagramUserName,
      'twitter_url': twitterUserName,
      'linkedin_url': linkedinUserName
    };
    try {
      return await _backendRequest
          .securedHTTPSRequest(
        endpoint: ApiEndpoint.updateUserProfile,
        method: HTTPMETHODS.post,
        data: _data,
      )
          .catchError((onError) {
        return left(const ProfileFailure.serverError());
      }).then((response) async {
        if (response.statusCode != 200) {
          return left(const ProfileFailure.serverError());
        } else {
          return right(Profile.fromJson(
              response.data['data'][0] as Map<String, dynamic>));
        }
      });
    } catch (e) {
      return left(const ProfileFailure.serverError());
    }
  }

  @override
  Future<Either<ProfileFailure, Unit>> addDomains(List<Domain> domains) async {
    final List<String> domain = domains.map((domain) => domain.name).toList();
    final List<double> experience =
        domains.map((domain) => domain.value).toList();
    final Map<String, dynamic> args = {
      "skill_name": domain,
      "skill_experience": experience,
    };
    final dynamic _data = jsonEncode(args);

    try {
      return await _backendRequest
          .securedHTTPSRequest(
        endpoint: ApiEndpoint.updateUserProfile,
        method: HTTPMETHODS.post,
        data: _data,
      )
          .catchError((onError) {
        return left(const ProfileFailure.serverError());
      }).then((response) async {
        if (response.statusCode != 200) {
          return left(const ProfileFailure.serverError());
        } else {
          return right(unit);
        }
      });
    } catch (e) {
      return left(const ProfileFailure.serverError());
    }
  }

  @override
  Future<Either<ProfileFailure, Unit>> addEducation(
      List<EducationStandard> educations) async {
    final List<String> standards =
        educations.map((education) => education.standardName.name).toList();
    final List<String> institutes =
        educations.map((education) => education.instituteName.name).toList();
    final Map<String, dynamic> args = {
      "education_institute": institutes,
      "education_standard": standards,
    };
    final dynamic _data = jsonEncode(args);
    try {
      return await _backendRequest
          .securedHTTPSRequest(
        endpoint: ApiEndpoint.updateUserProfile,
        method: HTTPMETHODS.post,
        data: _data,
      )
          .catchError((onError) {
        return left(const ProfileFailure.serverError());
      }).then((response) async {
        if (response.statusCode != 200) {
          return left(const ProfileFailure.serverError());
        } else {
          return right(unit);
        }
      });
    } catch (e) {
      return left(const ProfileFailure.serverError());
    }
  }

  @override
  Future<Either<ProfileFailure, Unit>> updateUserCertificate(
      Certificate certificate) async {
    // TODO: implement updateUserCertificate
    //
    //  final List<FormData> certificateFormData = [];
    //
    FormData certificateFormData;

    final Map<String, dynamic> _map = certificate.toJson();

    _map.addAll({
      "certificate_image": await MultipartFile.fromFile(certificate.image,
          filename: certificate.image.split('/').last),
      "certificate_id": certificate.id
    });

    certificateFormData = FormData.fromMap(_map);

    try {
      return await _backendRequest
          .securedHTTPSRequest(
        endpoint: ApiEndpoint.updateUserCertificate,
        //Formdata
        method: HTTPMETHODS.post,
        data: certificateFormData,
        headers: 'multipart/form-data',
      )
          .then((response) async {
        if (response.statusCode != 200) {
          return left(const ProfileFailure.serverError());
        } else {
          return right(unit);
        }
      });
    } catch (e) {
      return left(const ProfileFailure.serverError());
    }
  }

  @override
  Future<Either<ProfileFailure, Unit>> deleteDomain(Domain domain) async {
    final Map<String, dynamic> args = {
      "domain_id": domain.pivot.domainId,
    };
    try {
      return await _backendRequest
          .securedHTTPSRequest(
              endpoint: ApiEndpoint.deleteDomain,
              data: args,
              method: HTTPMETHODS.get)
          .catchError((onError) {
        return left(const ProfileFailure.serverError());
      }).then((response) async {
        if (response.statusCode != 200) {
          return left(const ProfileFailure.serverError());
        } else {
          return right(unit);
        }
      });
    } catch (e) {
      return left(const ProfileFailure.serverError());

      ///Client Error
    }
  }

  @override
  Future<Either<ProfileFailure, Unit>> deleteEducation(
      EducationStandard education) async {
    final Map<String, dynamic> args = {
      "education_id": education.id,
    };
    try {
      return await _backendRequest
          .securedHTTPSRequest(
              endpoint: ApiEndpoint.deleteEducation,
              data: args,
              method: HTTPMETHODS.get)
          .catchError((onError) {
        return left(const ProfileFailure.serverError());
      }).then((response) async {
        if (response.statusCode != 200) {
          return left(const ProfileFailure.serverError());
        } else {
          return right(unit);
        }
      });
    } catch (e) {
      return left(const ProfileFailure.serverError());

      ///Client Error
    }
  }

  @override
  Future<Either<ProfileFailure, Unit>> deleteUserCertificate(
      Certificate certificate) async {
    final Map<String, dynamic> args = {
      "certificate_id": certificate.id,
    };
    try {
      return await _backendRequest
          .securedHTTPSRequest(
              endpoint: ApiEndpoint.deleteCertificate,
              data: args,
              method: HTTPMETHODS.get)
          .then((response) async {
        if (response.statusCode != 200) {
          return left(const ProfileFailure.serverError());
        } else {
          return right(unit);
        }
      });
    } catch (e) {
      return left(const ProfileFailure.serverError());

      ///Client Error
    }
  }
}
