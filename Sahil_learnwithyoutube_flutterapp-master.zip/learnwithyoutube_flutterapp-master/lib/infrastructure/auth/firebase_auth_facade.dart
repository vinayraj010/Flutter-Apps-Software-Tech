import 'dart:developer';

import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:firebase_auth/firebase_auth.dart' hide User;
import 'package:flutter/services.dart';
import 'package:flutter_app/application/providers/auth_provider.dart';
import 'package:flutter_app/core/strings.dart';
import 'package:flutter_app/domain/auth/auth_failure.dart';
import 'package:flutter_app/domain/auth/i_auth_facade.dart';
import 'package:flutter_app/domain/auth/value_objects.dart';
import 'package:flutter_app/domain/core/i_backend_request.dart';
import 'package:flutter_app/domain/core/token_model.dart';
import 'package:flutter_app/infrastructure/auth/firebase_user_mapper.dart';
import 'package:flutter_app/infrastructure/core/api_endpoints.dart';
import 'package:flutter_app/infrastructure/core/backend_request.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:hive/hive.dart';
import 'package:injectable/injectable.dart';
import 'package:meta/meta.dart';

@prod
@lazySingleton
class FirebaseAuthFacade implements IAuthFacade {
  final FirebaseAuth _firebaseAuth;
  final GoogleSignIn _googleSignIn;
  final Dio _dio;
  final IBackendRequest _sendBackendRequest;
  final Box<ResponseTokenModel> _box;
  final FirebaseUserMapper _firebaseUserMapper;
  final AuthProvider _authProvider;

  FirebaseAuthFacade(
    this._firebaseAuth,
    this._googleSignIn,
    this._firebaseUserMapper,
    this._dio,
    this._sendBackendRequest,
    this._box,
    this._authProvider,
  );

  @override
  Future<Option<Unit>> getSignedInUser() async {
    return _box.isEmpty ? none() : some(unit);
  }

  @override
  Future<Either<AuthFailure, Unit>> registerWithEmailAndPassword({
    @required EmailAddress emailAddress,
    @required Password password,
  }) async {
    final emailAddressStr = emailAddress.value.getOrElse(() => 'INVALID EMAIL');
    final passwordStr = password.value.getOrElse(() => 'INVALID PASSWORD');
    try {
      return await _firebaseAuth
          .createUserWithEmailAndPassword(
        email: emailAddressStr,
        password: passwordStr,
      )
          .then((userCredentails) async {
        final String accessToken = await userCredentails.user.getIdToken();
        const int roleId = 1;

        await _sendBackendRequest.verifyFirebaseAccessToken(
            accessToken: accessToken, roleId: roleId);

        return right(unit);
      });
    } catch (e) {
      if (e.code == 'email-already-in-use') {
        return left(const AuthFailure.emailAlreadyInUse());
      } else {
        return left(const AuthFailure.serverError());
      }
    }
  }

  @override
  Future<Either<AuthFailure, Unit>> signInWithEmailAndPassword({
    @required EmailAddress emailAddress,
    @required Password password,
  }) async {
    final emailAddressStr = emailAddress.value.getOrElse(() => 'INVALID EMAIL');
    final passwordStr = password.value.getOrElse(() => 'INVALID PASSWORD');
    try {
      return await _firebaseAuth
          .signInWithEmailAndPassword(
        email: emailAddressStr,
        password: passwordStr,
      )
          .then((userCredentails) async {
        final String accessToken = await userCredentails.user.getIdToken();
        const int roleId = 1;

        await _sendBackendRequest.verifyFirebaseAccessToken(
            accessToken: accessToken, roleId: roleId);

        return right(unit);
      });
    } on FirebaseAuthException catch (e) {
      if (e.code == 'wrong-password' || e.code == 'user-not-found') {
        return left(const AuthFailure.invalidEmailAndPasswordCombination());
      }
      return left(const AuthFailure.serverError());
    }
  }

  @override
  Future<Either<AuthFailure, Unit>> signInWithGoogle() async {
    try {
      final googleUser = await _googleSignIn.signIn();

      if (googleUser == null) {
        return left(const AuthFailure.cancelledByUser());
      }

      final googleAuthentication = await googleUser.authentication;
      final authCredential = GoogleAuthProvider.credential(
        accessToken: googleAuthentication.accessToken,
        idToken: googleAuthentication.idToken,
      );
      return _firebaseAuth.signInWithCredential(authCredential).then((r) async {
        final String accessToken = await r.user.getIdToken();

        _authProvider.updateAccessToken(accessToken);

        return right(unit);
      });
    } on PlatformException catch (_) {
      return left(const AuthFailure.serverError());
    }
  }

  Future<void> _backendLogout() async {
    final Response _dioResponse = await _sendBackendRequest.securedHTTPSRequest(
        endpoint: ApiEndpoint.logout, method: HTTPMETHODS.post);
    log('Logout statusCode :${_dioResponse.statusCode}');

    _box.delete(HiveBoxNames.token);
  }

  @override
  Future<void> signOut() async {
    return Future.wait(
        [_googleSignIn.signOut(), _firebaseAuth.signOut(), _backendLogout()]);
  }

  @override
  Future<Either<AuthFailure, Unit>> registerUserType({int roleId}) async {
    try {
      final String accessToken = _authProvider.accessToken;

      return await _sendBackendRequest
          .verifyFirebaseAccessToken(accessToken: accessToken, roleId: roleId)
          .then((either) {
        return either.fold(
          (l) => left(const AuthFailure.serverError()),
          (r) => right(unit),
        );
      });
    } on PlatformException catch (_) {
      print('Error');
      return left(const AuthFailure.serverError());
    }
  }
}
