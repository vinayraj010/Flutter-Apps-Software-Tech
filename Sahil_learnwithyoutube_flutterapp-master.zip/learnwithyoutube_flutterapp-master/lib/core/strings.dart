mixin HiveBoxNames {
  static const String token = 'Token';
  static const String profile = 'Profile';
  static const String countries = 'Countries';
}
