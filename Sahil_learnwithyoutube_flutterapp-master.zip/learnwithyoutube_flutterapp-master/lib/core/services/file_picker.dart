import 'package:dartz/dartz.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/foundation.dart';
import 'package:injectable/injectable.dart';

@injectable
class FilePickerService {
  Future<Option<String>> pickFile({@required FileType fileType}) async {
    final FilePickerResult result = await FilePicker.platform.pickFiles(
      type: fileType,
      withData: true,
      allowedExtensions: fileType == FileType.custom
          ? ['docx', 'doc', 'xlsx', 'xls', 'pptx', 'ppt', 'pdf', 'txt']
          : null,
      allowCompression: true,
    );
    if (result != null) {
      final path = result.files.single.path;
      return some(path);
    } else {
      return none();
    }
  }
}
