enum CalendarEntry { day, threeDays, week, month }
