enum ChatAppBarState { standard, selected, info }
