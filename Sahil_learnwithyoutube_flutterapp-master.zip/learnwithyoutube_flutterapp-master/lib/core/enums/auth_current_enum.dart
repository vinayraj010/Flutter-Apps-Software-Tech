enum CURRENT_PAGE { login, user }
enum ON_PAGE { one, two, three }
