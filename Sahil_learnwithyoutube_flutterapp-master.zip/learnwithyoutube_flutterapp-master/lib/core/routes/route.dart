import 'package:auto_route/auto_route.dart';
import 'package:flutter_app/presentation/calendar/calendar_day_page.dart';
import 'package:flutter_app/presentation/calendar/calendar_holder.dart';
import 'package:flutter_app/presentation/calendar/update_form_page.dart';
import 'package:flutter_app/presentation/core/pages/loading_page.dart';
import 'package:flutter_app/presentation/home/pages/chat_page.dart';
import 'package:flutter_app/presentation/home/pages/home_page.dart';
import 'package:flutter_app/presentation/login/pages/auth_checker.dart';
import 'package:flutter_app/presentation/login/pages/login_page.dart';
import 'package:flutter_app/presentation/login/pages/onboarding_page.dart';

@MaterialAutoRouter()
class $Routers {
  SplashPage splashScreen;
  HandleAuthPage handleAuthPage;
  HomePage homePage;
  ChatPage chatPage;
  UpdateFormPage updateFormPage;
  CalendarHolder calendarHomePage;
  CalendarDayPage calendarDayPage;
  OnBoardingPage onBoardingPage;
  LoadingPage loadingPage;
}
