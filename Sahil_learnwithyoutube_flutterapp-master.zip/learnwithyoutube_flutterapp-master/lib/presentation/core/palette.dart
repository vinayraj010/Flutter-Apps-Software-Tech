import 'package:flutter/material.dart';

mixin Palette {
  static Color darkBlue = const Color(0xff112d4e);
  static Color lightBlue = const Color(0xff3f72af);
  static Color bluishWhite = const Color(0xffdbe2ef);
  static Color greyWhite = const Color(0xfff9f7f7);
  static Color white = Colors.white;
  static Color black75 = Colors.black.withOpacity(0.75);
  static Color black50 = Colors.black.withOpacity(0.5);
  static Color onBackground = const Color(0xffF1EDFF);
  static Color onBlue = const Color(0xff6646E7);
  static Color onRed = const Color(0xffFF0000);
  static Color onHeading1 = const Color(0xff231F20);
  static Color onHeading2 = const Color(0xff231F20).withOpacity(0.65);
  static Color c1d1d1d = const Color(0xff1d1d1d);
  static Color cc4c4c4 = const Color(0xffc4c4c4);
  static Color c686868 = const Color(0xff686868);
  static Color cafadad = const Color(0xffAFADAD);
  static Color cafafafa = const Color(0xffFAFAFA);
  static Color userChatColor = const Color(0xffDDD4FE);

  static Color sliderGreen = const Color(0xff77AF44);
  static Color sliderYellow = const Color(0xffFEBE16);
  static Color sliderRed = const Color(0xffFF0000);
}
