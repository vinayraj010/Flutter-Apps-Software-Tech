import 'package:flutter/material.dart';
import 'package:flutter_app/application/message/message_bloc.dart';
import 'package:flutter_app/presentation/core/palette.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_svg/svg.dart';

class ChatSelectedAppbar extends StatelessWidget with PreferredSizeWidget {
  const ChatSelectedAppbar({
    Key key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return PreferredSize(
      preferredSize: const Size.fromHeight(60),
      child: DecoratedBox(
        decoration: const BoxDecoration(boxShadow: [
          BoxShadow(
              color: const Color.fromRGBO(21, 12, 58, 0.21),
              blurRadius: 33,
              spreadRadius: 15,
              offset: Offset(0, 15))
        ]),
        child: AppBar(
          toolbarHeight: 60,
          backgroundColor: Palette.onBlue,
          elevation: 0,
          titleSpacing: 0.0,
          title: Padding(
            padding: EdgeInsets.only(left: 30),
            child: GestureDetector(
              onTap: () => BlocProvider.of<MessageBloc>(context)
                  .add(const MessageEvent.switchToStandardAppBar()),
              child: RotatedBox(
                  quarterTurns: 1,
                  child: SvgPicture.asset('assets/chat/arrow.svg')),
            ),
          ),
          actions: <Widget>[
            GestureDetector(
              child: SvgPicture.asset('assets/chat/appbar/forward.svg'),
            ),
            const SizedBox(width: 28),
            GestureDetector(
              child: SvgPicture.asset('assets/chat/appbar/label.svg'),
            ),
            const SizedBox(width: 28),
            GestureDetector(
              child: SvgPicture.asset('assets/chat/appbar/calendar.svg'),
            ),
            const SizedBox(width: 28),
            GestureDetector(
              child: SvgPicture.asset('assets/chat/appbar/help.svg'),
            ),
            const SizedBox(width: 28),
            GestureDetector(
              child: SvgPicture.asset('assets/chat/appbar/copy.svg'),
            ),
            const SizedBox(width: 28),
          ],
        ),
      ),
    );
  }

  @override
  // TODO: implement preferredSize
  Size get preferredSize => const Size.fromHeight(60);
}
