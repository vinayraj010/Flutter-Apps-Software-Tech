import 'dart:collection';

import 'package:flutter/material.dart';
import 'package:flutter_app/domain/chat/message.dart';
import 'package:flutter_app/presentation/core/palette.dart';
import 'package:flutter_cached_pdfview/flutter_cached_pdfview.dart';
// import 'package:flutter_downloader/flutter_downloader.dart';
import 'package:flutter_svg/svg.dart';
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';

class DocumentMessage extends StatelessWidget {
  DocumentMessage({
    Key key,
    @required this.element,
  }) : super(key: key);

  final MessageBody element;

  final ValueNotifier<int> _pagesNotifier = ValueNotifier<int>(0);

  final HashMap<String, Widget> _hashMap = HashMap<String, Widget>();

  @override
  Widget build(BuildContext context) {
    if (_hashMap[element.message] == null) {
      _hashMap[element.message] = GestureDetector(
        onTap: () async {
          // final status = await Permission.storage.request();

          // if (status.isGranted) {
          //   final externalDir = await getExternalStorageDirectory();

          //   final id = await FlutterDownloader.enqueue(
          //       url: element.message,
          //       savedDir: externalDir.path,
          //       fileName: element.message.split('/').last);
          // } else {
          //   print("Permission deined");
          // }
        },
        child: AnimatedBuilder(
          animation: Listenable.merge([_pagesNotifier]),
          builder: (context, child) {
            return Column(
              children: [
                Stack(
                  alignment: Alignment.bottomCenter,
                  children: [
                    LimitedBox(
                      maxWidth: MediaQuery.of(context).size.width * 0.75,
                      maxHeight: MediaQuery.of(context).size.width * 0.75,
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(10),
                        child: PDF(
                          gestureRecognizers: {},
                          onViewCreated: (controller) {},
                          pageSnap: false,
                          onRender: (pages) {
                            _pagesNotifier.value = pages;
                          },
                        ).fromUrl(
                          element.message,
                          placeholder: (progress) {
                            return Center(
                              child: CircularProgressIndicator(
                                value: progress,
                                valueColor: AlwaysStoppedAnimation<Color>(
                                    Palette.onBlue),
                              ),
                            );
                          },
                        ),
                      ),
                    ),
                    Container(
                      height: 52,
                      decoration: const BoxDecoration(
                          color: Color(0xffEBE7F7),
                          borderRadius: BorderRadius.only(
                            bottomLeft: Radius.circular(10),
                            bottomRight: Radius.circular(10),
                          )),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          const SizedBox(width: 12),
                          SvgPicture.asset('assets/chat/file.svg'),
                          const SizedBox(width: 12),
                          Flexible(
                            child: Text(
                              element.message.split('/').last,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                          const SizedBox(width: 12),
                        ],
                      ),
                    )
                  ],
                ),
                const SizedBox(height: 8),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    if (_pagesNotifier.value > 1)
                      Text(
                        '${_pagesNotifier.value} pages',
                        style: const TextStyle(color: Color(0xff686868)),
                      )
                    else
                      Text(
                        '${_pagesNotifier.value} page',
                        style: const TextStyle(color: Color(0xff686868)),
                      ),
                    const Text(
                      'PDF',
                      style: TextStyle(color: Color(0xff686868)),
                    )
                  ],
                )
              ],
            );
          },
        ),
      );

      return _hashMap[element.message];
    } else {
      return _hashMap[element.message];
    }
  }
}
