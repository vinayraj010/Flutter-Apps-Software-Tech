import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_app/domain/chat/message.dart';

class ImageMessage extends StatelessWidget {
  final MessageBody element;
  const ImageMessage({
    Key key,
    this.element,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => Navigator.push(
          context,
          MaterialPageRoute(
              builder: (_) => SafeArea(
                      child: Scaffold(
                    backgroundColor: Colors.black,
                    body: Center(
                      child: CachedNetworkImage(
                        imageUrl: element.message,
                      ),
                    ),
                  )))),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(14),
        child: CachedNetworkImage(
          imageUrl: element.message,
          fit: BoxFit.cover,
          height: MediaQuery.of(context).size.width * 0.75,
          width: MediaQuery.of(context).size.width * 0.75,
        ),
      ),
    );
  }
}
