import 'dart:collection';
import 'dart:io';

import 'package:better_player/better_player.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_app/domain/chat/message.dart';
import 'package:flutter_app/presentation/core/palette.dart';
import 'package:path_provider/path_provider.dart';
import 'package:video_thumbnail/video_thumbnail.dart';

class VideoMessage extends StatelessWidget {
  VideoMessage({
    Key key,
    this.element,
  }) : super(key: key);

  final HashMap<String, Widget> _hashMap = HashMap<String, Widget>();
  final MessageBody element;

  @override
  Widget build(BuildContext context) {
    Future<String> _future(String url) async {
      return VideoThumbnail.thumbnailFile(
        video: url ?? '',
        thumbnailPath: (await getTemporaryDirectory()).path,
      );
    }

    if (_hashMap[element.message] == null) {
      _hashMap[element.message] = FutureBuilder<String>(
        future: _future(element.message),
        builder: (BuildContext context, AsyncSnapshot<String> snapshot) {
          if (snapshot.connectionState == ConnectionState.done) {
            final file = File(snapshot.data);

            final bytes = file.readAsBytesSync();
            final _image = Image.memory(
              bytes,
              fit: BoxFit.cover,
              height: MediaQuery.of(context).size.width * 0.75,
              width: MediaQuery.of(context).size.width * 0.75,
            );

            return GestureDetector(
                onTap: () => Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (_) => _FullScreen(
                              url: element.message,
                            ))),
                child: Stack(
                  alignment: Alignment.center,
                  children: [
                    ClipRRect(
                      borderRadius: BorderRadius.circular(14),
                      child: _image,
                    ),
                    IconButton(
                      color: Palette.white,
                      onPressed: () {},
                      icon: const Icon(
                        Icons.play_arrow,
                      ),
                    ),
                  ],
                ));
          } else {
            return const CupertinoActivityIndicator();
          }
        },
      );
      return _hashMap[element.message];
    } else {
      return _hashMap[element.message];
    }
  }
}

class _FullScreen extends StatelessWidget {
  final String url;

  const _FullScreen({Key key, this.url}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
          backgroundColor: Colors.black, body: BetterPlayer.network(url)),
    );
  }
}
