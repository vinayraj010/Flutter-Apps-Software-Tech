import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter_app/application/message/message_bloc.dart';
import 'package:flutter_app/presentation/core/palette.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_svg/flutter_svg.dart';

import 'message_widget.dart';

class ChatTabbarView extends StatefulWidget {
  const ChatTabbarView({
    Key key,
    @required int chatId,
    @required TextEditingController controller,
    this.state,
  })  : _chatId = chatId,
        _controller = controller,
        super(key: key);

  final int _chatId;
  final TextEditingController _controller;
  final MessageState state;

  @override
  _ChatTabbarViewState createState() => _ChatTabbarViewState();
}

class _ChatTabbarViewState extends State<ChatTabbarView>
    with SingleTickerProviderStateMixin {
  AnimationController _animationController;

  @override
  void initState() {
    _animationController = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 150));
    super.initState();
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  Widget _attachmentBuilder(
      {@required String path,
      @required Color bgColor,
      @required FileType fileType}) {
    return InkWell(
      onTap: () {
        BlocProvider.of<MessageBloc>(context).add(
            MessageEvent.pickFile(chatId: widget._chatId, fileType: fileType));
      },
      child: Container(
        height: 60,
        width: 60,
        alignment: Alignment.center,
        decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(10), color: bgColor),
        child: SvgPicture.asset(
          'assets/chat/attachments/$path.svg',
          height: 20,
          width: 20,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        if (widget.state.listOfMessages.isNotEmpty)
          MessageWidget(
            messages: widget.state.listOfMessages,
            chatId: widget._chatId,
            isLoading: widget.state.isLoading,
            state: widget.state
          )
        else
          Container(),
        Stack(
          overflow: Overflow.visible,
          clipBehavior: Clip.antiAliasWithSaveLayer,
          children: [
            Positioned(
              bottom: 75,
              child: FadeTransition(
                opacity: _animationController,
                child: Container(
                  height: 103,
                  width: MediaQuery.of(context).size.width - 30,
                  decoration: BoxDecoration(
                      color: Palette.white,
                      borderRadius: BorderRadius.circular(10)),
                  margin:
                      const EdgeInsets.symmetric(horizontal: 15, vertical: 11),
                  child: Row(
                    mainAxisSize: MainAxisSize.max,
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      _attachmentBuilder(
                          bgColor: Color(0xffFD5959),
                          path: 'file',
                          fileType: FileType.custom),
                      _attachmentBuilder(
                          bgColor: Color(0xffFEBE16),
                          path: 'camera',
                          fileType: FileType.image),
                      _attachmentBuilder(
                          bgColor: Color(0xff77AF44),
                          path: 'image',
                          fileType: FileType.image),
                      _attachmentBuilder(
                          bgColor: Color(0xff6646E7),
                          path: 'audio',
                          fileType: FileType.audio),
                    ],
                  ),
                ),
              ),
            ),
            Container(
              height: 64,
              decoration: BoxDecoration(
                  color: Palette.white, borderRadius: BorderRadius.circular(8)),
              margin: const EdgeInsets.symmetric(horizontal: 15, vertical: 11),
              child: Row(
                children: [
                  Expanded(
                    child: SizedBox(
                      height: 64,
                      child: TextFormField(
                        controller: widget._controller,
                        validator: (value) =>
                            BlocProvider.of<MessageBloc>(context)
                                .state
                                .message
                                .value
                                .fold(
                                    (l) => l.maybeMap(
                                          orElse: () => null,
                                          empty: (value) => 'Invalid Message',
                                        ),
                                    (r) => null),
                        onChanged: (value) {
                          BlocProvider.of<MessageBloc>(context)
                              .add(MessageEvent.messageChanged(value));
                        },
                        keyboardType: TextInputType.text,
                        decoration: InputDecoration(
                            hintText: "Type a message...",
                            contentPadding: const EdgeInsets.all(18),
                            border: const OutlineInputBorder(
                                borderSide: BorderSide.none),
                            hintMaxLines: 2),
                      ),
                    ),
                  ),
                  SvgPicture.asset('assets/chat/emoji.svg'),
                  const SizedBox(width: 12),
                  GestureDetector(
                    onTap: () {
                      if (_animationController.isCompleted) {
                        _animationController.reverse();
                      } else {
                        _animationController.forward();
                      }
                    },
                    child: AnimatedSwitcher(
                        duration: const Duration(milliseconds: 100),
                        child: _animationController.status ==
                                AnimationStatus.completed
                            ? Icon(
                                Icons.close,
                              )
                            : SvgPicture.asset(
                                'assets/chat/attach.svg',
                              )),
                  ),
                  _Send(
                    chatId: widget._chatId,
                    controller: widget._controller,
                    state: widget.state,
                  ),
                ],
              ),
            ),
          ],
        ),
      ],
    );
  }
}

class _Send extends StatelessWidget {
  const _Send({
    Key key,
    @required int chatId,
    @required TextEditingController controller,
    this.state,
  })  : _chatId = chatId,
        _controller = controller,
        super(key: key);

  final MessageState state;

  final int _chatId;
  final TextEditingController _controller;

  @override
  Widget build(BuildContext context) {
    void _onMediaPressed() {
      showModalBottomSheet(
          context: context,
          elevation: 0,
          backgroundColor: Colors.black,
          builder: (context) {
            return Column(
              children: <Widget>[
                Container(
                  padding: EdgeInsets.symmetric(vertical: 15),
                  child: Row(
                    children: <Widget>[
                      FlatButton(
                        child: Icon(
                          Icons.close,
                          color: Palette.white,
                        ),
                        onPressed: () => Navigator.maybePop(context),
                      ),
                      Expanded(
                        child: Align(
                          alignment: Alignment.centerLeft,
                          child: Text(
                            "Add Media",
                            style: TextStyle(
                                color: Colors.white,
                                fontSize: 20,
                                fontWeight: FontWeight.bold),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                Flexible(
                  child: ListView(
                    children: <Widget>[
                      ModalTile(
                        title: "Images",
                        subtitle: "Share Photos",
                        icon: Icons.image,
                        onTap: () {
                          Navigator.pop(context);

                          BlocProvider.of<MessageBloc>(context).add(
                              MessageEvent.pickFile(
                                  chatId: _chatId, fileType: FileType.image));
                        },
                      ),
                      ModalTile(
                        title: "Videos",
                        subtitle: "Share Videos",
                        icon: Icons.video_collection,
                        onTap: () {
                          Navigator.pop(context);
                          BlocProvider.of<MessageBloc>(context).add(
                              MessageEvent.pickFile(
                                  chatId: _chatId, fileType: FileType.video));
                        },
                      ),
                      ModalTile(
                        title: "Audio",
                        subtitle: "Share Audios",
                        icon: Icons.audiotrack,
                        onTap: () {
                          Navigator.pop(context);

                          BlocProvider.of<MessageBloc>(context).add(
                              MessageEvent.pickFile(
                                  chatId: _chatId, fileType: FileType.audio));
                        },
                      ),
                      ModalTile(
                        title: "Document",
                        subtitle: "Share Documents",
                        icon: Icons.tab,
                        onTap: () {
                          Navigator.pop(context);

                          BlocProvider.of<MessageBloc>(context).add(
                              MessageEvent.pickFile(
                                  chatId: _chatId, fileType: FileType.custom));
                        },
                      ),
                    ],
                  ),
                ),
              ],
            );
          });
    }

    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 10),
      child: AnimatedSwitcher(
          duration: const Duration(milliseconds: 150),
          child: (state.message?.isValid() ?? true)
              ? GestureDetector(
                  onTap: () {
                    BlocProvider.of<MessageBloc>(context)
                        .add(MessageEvent.sendMessage(chaId: _chatId));
                    _controller.clear();
                  },
                  child: Container(
                      height: 44,
                      width: 44,
                      padding: const EdgeInsets.symmetric(
                          vertical: 8.75, horizontal: 11),
                      decoration: BoxDecoration(
                          color: const Color(0xffFF0606),
                          borderRadius: BorderRadius.circular(8)),
                      key: ValueKey(state.message?.isValid() ?? false),
                      child: Icon(
                        Icons.send,
                        color: Palette.white,
                      )),
                )
              : GestureDetector(
                  onTap: _onMediaPressed,
                  child: Container(
                      height: 44,
                      width: 44,
                      padding: const EdgeInsets.symmetric(
                          vertical: 8.75, horizontal: 11),
                      decoration: BoxDecoration(
                          color: const Color(0xffFF0606),
                          borderRadius: BorderRadius.circular(8)),
                      key: ValueKey(state.message?.isValid() ?? false),
                      child: SvgPicture.asset('assets/chat/mic.svg')),
                )),
    );
  }
}

class ModalTile extends StatelessWidget {
  final String title;
  final String subtitle;
  final IconData icon;
  final VoidCallback onTap;

  const ModalTile({
    @required this.title,
    @required this.subtitle,
    @required this.icon,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: 15),
      child: CustomTile(
        mini: false,
        onTap: onTap,
        leading: Container(
          margin: const EdgeInsets.only(right: 10),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(5),
            color: Colors.white.withOpacity(0.1),
          ),
          padding: const EdgeInsets.all(16),
          child: Icon(
            icon,
            color: Palette.white,
            size: 30,
          ),
        ),
        subtitle: Text(
          subtitle,
          style: TextStyle(
            color: Palette.white.withOpacity(0.5),
            fontSize: 14,
          ),
        ),
        title: Text(
          title,
          style: TextStyle(
            fontWeight: FontWeight.bold,
            color: Colors.white,
            fontSize: 18,
          ),
        ),
      ),
    );
  }
}

class CustomTile extends StatelessWidget {
  final Widget leading;
  final Widget title;
  final Widget icon;
  final Widget subtitle;
  final Widget trailing;
  final EdgeInsets margin;
  final bool mini;
  final GestureTapCallback onTap;
  final GestureLongPressCallback onLongPress;

  CustomTile({
    @required this.leading,
    @required this.title,
    this.icon,
    @required this.subtitle,
    this.trailing,
    this.margin = const EdgeInsets.all(0),
    this.onTap,
    this.onLongPress,
    this.mini = true,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      onLongPress: onLongPress,
      child: Container(
        padding: EdgeInsets.symmetric(horizontal: mini ? 10 : 0),
        margin: margin,
        child: Row(
          children: <Widget>[
            leading,
            Expanded(
              child: Container(
                margin: EdgeInsets.only(left: mini ? 10 : 15),
                padding: EdgeInsets.symmetric(vertical: mini ? 3 : 20),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: <Widget>[
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        title,
                        SizedBox(height: 5),
                        Row(
                          children: <Widget>[
                            icon ?? Container(),
                            subtitle,
                          ],
                        )
                      ],
                    ),
                    trailing ?? Container(),
                  ],
                ),
              ),
            )
          ],
        ),
      ),
    );
  }
}
