import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_app/application/message/message_bloc.dart';
import 'package:flutter_app/presentation/core/palette.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_svg/svg.dart';
import 'package:google_fonts/google_fonts.dart';

import 'appbar_textfield.dart';

class ChatAppbar extends StatefulWidget with PreferredSizeWidget {
  const ChatAppbar({
    Key key,
  }) : super(key: key);

  @override
  _ChatAppbarState createState() => _ChatAppbarState();

  @override
  Size get preferredSize => const Size.fromHeight(60);
}

class _ChatAppbarState extends State<ChatAppbar> {
  @override
  Widget build(BuildContext context) {
    return PreferredSize(
      preferredSize: const Size.fromHeight(60),
      child: DecoratedBox(
        decoration: const BoxDecoration(boxShadow: [
          BoxShadow(
              color: Color.fromRGBO(21, 12, 58, 0.21),
              blurRadius: 33,
              spreadRadius: 15,
              offset: Offset(0, 15))
        ]),
        child: AppBarTextField(
          toolbarHeight: 60,
          autofocus: false,
          backgroundColor: Palette.onBlue,
          backBtnIcon: RotatedBox(
              quarterTurns: 1,
              child: SvgPicture.asset('assets/chat/arrow.svg')),
          onSearchPressed: () => BlocProvider.of<MessageBloc>(context)
              .add(const MessageEvent.showFilters()),
          onBackPressed: () {
            BlocProvider.of<MessageBloc>(context)
                .add(const MessageEvent.hideFilters());
            FocusScope.of(context).unfocus(); //Close all Focus Nodes
          },
          searchContainerColor: Palette.onBlue,
          clearBtnIcon: const Icon(Icons.clear_rounded, color: Colors.white),
          style: TextStyle(
            color: Palette.onBackground,
            fontFamily: GoogleFonts.poppins().fontFamily,
          ),
          decoration: InputDecoration(
              hintText: 'filter by...',
              contentPadding: const EdgeInsets.all(0),
              hintStyle: TextStyle(
                  color: Palette.onBackground,
                  fontFamily: GoogleFonts.poppins().fontFamily),
              border: const OutlineInputBorder(borderSide: BorderSide.none)),
          elevation: 0,
          searchButtonIcon: SvgPicture.asset('assets/chat/filter.svg'),
          titleSpacing: 0.0,
          title: Padding(
            padding: EdgeInsets.only(left: 30),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.start,
              children: <Widget>[
                Container(
                  height: 40,
                  width: 40,
                  padding: const EdgeInsets.all(3),
                  decoration: BoxDecoration(
                      shape: BoxShape.circle, color: Palette.white),
                  child: ClipOval(
                    child: CachedNetworkImage(
                      imageUrl:
                          'https://images.unsplash.com/photo-1585637071663-799845ad5212?ixid=MXwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHw%3D&ixlib=rb-1.2.1&auto=format&fit=crop&w=1050&q=80',
                      fit: BoxFit.fill,
                    ),
                  ),
                ),
                Padding(
                  padding: EdgeInsets.only(left: 16),
                  child: Text(
                    "Class IV-VI",
                    style: TextStyle(
                      fontSize: 20.0,
                      color: Palette.white,
                      fontWeight: FontWeight.w600,
                      fontFamily: GoogleFonts.poppins().fontFamily,
                    ),
                  ),
                )
              ],
            ),
          ),
          trailingActionButtons: <Widget>[
            GestureDetector(
              onTap: () {
                BlocProvider.of<MessageBloc>(context)
                    .add(const MessageEvent.switchToInfoAppBar());
              },
              child: SvgPicture.asset('assets/chat/arrow.svg'),
            ),
            const SizedBox(width: 28),
          ],
        ),
      ),
    );
  }
}
