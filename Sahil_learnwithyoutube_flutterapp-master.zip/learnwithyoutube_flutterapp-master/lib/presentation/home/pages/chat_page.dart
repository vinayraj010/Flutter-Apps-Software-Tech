import 'package:dartz/dartz.dart' hide State;
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_app/application/message/message_bloc.dart';
import 'package:flutter_app/core/enums/chat_appbar_enum.dart';
import 'package:flutter_app/presentation/core/palette.dart';
import 'package:flutter_app/presentation/home/widgets/chat_appbar.dart';
import 'package:flutter_app/presentation/home/widgets/chat_info_appbar.dart';
import 'package:flutter_app/presentation/home/widgets/chat_selected_appbar.dart';
import 'package:flutter_app/presentation/home/widgets/chat_tabbar_view.dart';
import 'package:flutter_app/presentation/home/widgets/filter_chip.dart';
import 'package:flutter_app/presentation/home/widgets/info_column.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class ChatPage extends StatefulWidget {
  @override
  _ChatPageState createState() => _ChatPageState();
}

class _ChatPageState extends State<ChatPage> {
  int _chatId;
  TextEditingController _controller;

  @override
  void initState() {
    _chatId = 56;
    _controller = TextEditingController();
    BlocProvider.of<MessageBloc>(context)
        .add(MessageEvent.getChatMessages(chatId: _chatId));

    super.initState();
  }

  PreferredSizeWidget _getAppBar(Option<ChatAppBarState> option) {
    return option.fold(() => const ChatAppbar(), (a) {
      switch (a) {
        case ChatAppBarState.standard:
          return const ChatAppbar();

          break;
        case ChatAppBarState.selected:
          return const ChatSelectedAppbar();

          break;
        case ChatAppBarState.info:
          return const ChatInfoAppbar();

          break;
        default:
          return const ChatAppbar();
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return BlocConsumer<MessageBloc, MessageState>(
      listener: (context, state) {},
      builder: (context, state) {
        if (state.messages == null) {
          return const Scaffold(
            body: Center(
              child: CupertinoActivityIndicator(),
            ),
          );
        } else {
          return Form(
            child: Scaffold(
                backgroundColor: Palette.onBackground,
                appBar: _getAppBar(state.failureOrSuccessChatAppBarState),
                body: Stack(
                  alignment: Alignment.topCenter,
                  children: [
                    _getBody(state),
                    AnimatedSwitcher(
                      duration: const Duration(milliseconds: 200),
                      switchOutCurve: Curves.easeOutExpo,
                      child: !state.showFilters
                          ? const SizedBox.shrink()
                          : Column(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                PhysicalModel(
                                  elevation: 2,
                                  color: Colors.black,
                                  child: Container(
                                    padding: const EdgeInsets.symmetric(
                                        vertical: 10),
                                    color: const Color(0xffF1EDFF),
                                    alignment: Alignment.topCenter,
                                    child: Wrap(
                                      spacing: 14,
                                      runSpacing: -6,
                                      crossAxisAlignment:
                                          WrapCrossAlignment.center,
                                      children: [
                                        FilterLabelChip(
                                            onTap: null,
                                            title: 'Teacher',
                                            color: const Color(0xffFCB500)
                                                .withOpacity(0.45)),
                                        FilterLabelChip(
                                            onTap: null,
                                            title: 'Students',
                                            color: const Color(0xffFF0000)
                                                .withOpacity(0.32)),
                                        FilterLabelChip(
                                            onTap: null,
                                            title: 'Tests',
                                            color: const Color(0xff77AF44)
                                                .withOpacity(0.65)),
                                        FilterLabelChip(
                                            onTap: null,
                                            title: 'Notes',
                                            color: const Color(0xff6646E7)
                                                .withOpacity(0.47)),
                                        FilterLabelChip(
                                            onTap: null,
                                            title: 'Assignments',
                                            color: const Color(0xffA796EC)),
                                        FilterLabelChip(
                                            onTap: null,
                                            title: 'Labels',
                                            color: const Color(0xffF2D088)),
                                        FilterLabelChip(
                                            onTap: null,
                                            title: 'Documents',
                                            color: const Color(0xffED9B9B)),
                                        FilterLabelChip(
                                            onTap: null,
                                            title: 'Images',
                                            color: const Color(0xff9EC182)),
                                        FilterLabelChip(
                                            onTap: null,
                                            title: 'Links',
                                            color: const Color(0xffED9B9B)),
                                        FilterLabelChip(
                                            onTap: null,
                                            title: 'Videos',
                                            color: const Color(0xff6646E7)
                                                .withOpacity(0.47)),
                                      ],
                                    ),
                                  ),
                                ),
                              ],
                            ),
                    )
                  ],
                )),
          );
        }
      },
    );
  }

  Widget _getBody(MessageState state) {
    return state.failureOrSuccessChatAppBarState.fold(
        () => ChatTabbarView(
              chatId: _chatId,
              controller: _controller,
              state: state,
            ), (a) {
      switch (a) {
        case ChatAppBarState.standard:
          return ChatTabbarView(
            chatId: _chatId,
            controller: _controller,
            state: state,
          );
          break;

        case ChatAppBarState.info:
          return ChatInfoColumn();

          break;
        default:
          return ChatTabbarView(
            chatId: _chatId,
            controller: _controller,
            state: state,
          );
      }
    });
  }
}
