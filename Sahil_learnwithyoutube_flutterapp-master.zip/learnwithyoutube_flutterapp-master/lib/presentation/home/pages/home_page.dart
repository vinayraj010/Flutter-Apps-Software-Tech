import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_app/application/auth/auth_bloc.dart';
import 'package:flutter_app/application/profile/profile_bloc.dart';
import 'package:flutter_app/core/routes/route.gr.dart' as route;
import 'package:flutter_app/presentation/login/pages/login_page.dart';
import 'package:flutter_app/presentation/profile/pages/profile_page.dart'
    as profile;
import 'package:flutter_bloc/flutter_bloc.dart';

class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  @override
  void initState() {
    //Get Profile from Hive
    BlocProvider.of<ProfileBloc>(context)
        .add(const ProfileEvent.getUserProfile());
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return BlocListener<AuthBloc, AuthState>(
      listener: (context, state) {
        state.maybeMap(
          orElse: () {},
          unauthenticated: (value) => Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => HandleAuthPage()),
          ),
        );
      },
      child: SafeArea(child: profile.ProfilePage()),
    );
  }
}
