import 'package:flutter/material.dart';
import 'package:flutter_app/application/auth/auth_bloc.dart';
import 'package:flutter_app/application/calendar/calendar_bloc.dart';
import 'package:flutter_app/application/chat/chat_bloc.dart';
import 'package:flutter_app/application/message/message_bloc.dart';
import 'package:flutter_app/application/profile/profile_bloc.dart';
import 'package:flutter_app/application/providers/auth_provider.dart';
import 'package:flutter_app/application/providers/calendar_provider.dart';
import 'package:flutter_app/application/providers/certificate_provider.dart';
import 'package:flutter_app/application/providers/education_provider.dart';
import 'package:flutter_app/application/providers/onboard_provider.dart';
import 'package:flutter_app/application/providers/profile_provider.dart';
import 'package:flutter_app/application/providers/skill_provider.dart';
import 'package:flutter_app/application/providers/youtube_player_provider.dart';
import 'package:flutter_app/core/routes/route.gr.dart' as route;
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:get/get_navigation/src/root/get_material_app.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:nested/nested.dart';
import 'package:provider/provider.dart';

import '../injection.dart';
import 'core/palette.dart';

class AppWidget extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: _providers,
      child: GetMaterialApp(
        title: 'LearnWithYoutube',
        theme: ThemeData(
          primaryColor: Colors.white,
          backgroundColor: Colors.white,
          accentColor: Palette.onBackground,
          accentColorBrightness: Brightness.light,
          textTheme: GoogleFonts.poppinsTextTheme(),
        ).copyWith(
            pageTransitionsTheme: const PageTransitionsTheme(
          builders: <TargetPlatform, PageTransitionsBuilder>{
            TargetPlatform.android: ZoomPageTransitionsBuilder(),
          },
        )),
        debugShowCheckedModeBanner: false,
        // home:
        // home: LoadingPage(),
        onGenerateRoute: route.Router.onGenerateRoute,
        initialRoute: route.Router.splashScreen,
        //   navigatorKey: route.Router.navigator.key,
      ),
    );
  }
}

//Registration of State Managements
final List<SingleChildStatelessWidget> _providers = [
  BlocProvider(
    create: (_) => getIt<AuthBloc>()..add(const AuthEvent.authCheckRequested()),
  ),
  BlocProvider(
    create: (_) =>
        getIt<CalendarBloc>()..add(const CalendarEvent.getGoogleEvents()),
  ),
  BlocProvider(
    create: (_) => getIt<ChatBloc>(),
  ),
  BlocProvider(
    create: (_) => getIt<ProfileBloc>()..add(const ProfileEvent.getCountries()),
  ),
  BlocProvider(
    create: (_) => getIt<MessageBloc>(),
  ),
  ChangeNotifierProvider(
    create: (context) => AuthProvider(),
  ),
  ChangeNotifierProvider(
    create: (context) => OnBoardProvider(),
  ),
  ChangeNotifierProvider(
    create: (context) => getIt<CalendarProvider>(),
  ),
  ChangeNotifierProvider(
    create: (context) => getIt<EducationProvider>(),
  ),
  ChangeNotifierProvider(
    create: (context) => getIt<SkillProvider>(),
  ),
  ChangeNotifierProvider(
    create: (context) => getIt<CertificateProvider>(),
  ),
  ChangeNotifierProvider(
    create: (context) => getIt<PlayerProvider>(),
  ),
  ChangeNotifierProvider(
    create: (context) => getIt<ProfileProvider>()..startLoading(),
  ),
];
