import 'package:flutter/material.dart';
import 'package:flutter_app/application/profile/profile_bloc.dart';
import 'package:flutter_app/domain/profile/profile.dart';
import 'package:flutter_app/presentation/core/palette.dart';
import 'package:flutter_app/presentation/profile/widgets/dialogs/socialmedia_dialog.dart';
import 'package:flutter_app/presentation/profile/widgets/section_holder.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:url_launcher/url_launcher.dart';

class SocialMedia extends StatefulWidget {
  const SocialMedia({
    Key key,
    this.state,
  }) : super(key: key);

  final ProfileState state;

  @override
  _SocialMediaState createState() => _SocialMediaState();
}

class _SocialMediaState extends State<SocialMedia> {
  String _splitUserName(String url) {
    if (url == null || url.isEmpty || url == 'null') {
      return '';
    }

    if (url.split('/').last.isEmpty) {
      return url.split('/').elementAt(url.split('/').length - 2);
    } else {
      return url.split('/').last;
    }
  }

  @override
  Widget build(BuildContext context) {
    return SectionHolder(
        title: 'Social media handles',
        icon: 'social_media',
        onEditPressed: SocialMediaDialog(),
        child: BlocBuilder<ProfileBloc, ProfileState>(
          builder: (context, state) {
            final Profile _profile = state.profile;
            if (_splitUserName(_profile.instagramLink).isEmpty &&
                _splitUserName(_profile.facebookLink).isEmpty &&
                _splitUserName(_profile.linkedinUrl).isEmpty &&
                _splitUserName(_profile.twitterUrl).isEmpty) {
              return const _Empty();
            }
            return Padding(
              padding: const EdgeInsets.only(bottom: 20),
              child: Column(
                children: [
                  if (_splitUserName(_profile.instagramLink).isNotEmpty)
                    _Child(
                      asset: 'instagram',
                      title: 'Instagram',
                      url: _profile.instagramLink,
                      value: _splitUserName(_profile.instagramLink),
                    ),
                  if (_splitUserName(_profile.twitterUrl).isNotEmpty)
                    _Child(
                      asset: 'twitter',
                      title: 'Twitter',
                      url: _profile.twitterUrl,
                      value: _splitUserName(_profile.twitterUrl),
                    ),
                  if (_splitUserName(_profile.facebookLink).isNotEmpty)
                    _Child(
                      asset: 'facebook',
                      title: 'Facebook',
                      url: _profile.facebookLink,
                      value: _splitUserName(_profile.facebookLink),
                    ),
                  if (_splitUserName(_profile.linkedinUrl).isNotEmpty)
                    _Child(
                      asset: 'linkedin',
                      title: 'Linkedin',
                      url: _profile.linkedinUrl,
                      value: _splitUserName(_profile.linkedinUrl),
                    ),
                ],
              ),
            );
          },
        ));
  }
}

class _Empty extends StatelessWidget {
  const _Empty({
    Key key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        SvgPicture.asset('assets/profile/empty_pen.svg'),
        const SizedBox(
          height: 5,
        ),
        Text(
          'Link your social media handles \nand boost up your profile',
          textAlign: TextAlign.center,
          style: TextStyle(
            color: Color(0xffAFADAD),
            fontSize: 11,
            fontWeight: FontWeight.w400,
          ),
        ),
      ],
    );
  }
}

class _Child extends StatelessWidget {
  final String title;
  final String value;
  final String asset;
  final String url;

  const _Child({
    Key key,
    this.title,
    this.asset,
    this.value,
    this.url,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10, left: 6, right: 6),
      child: GestureDetector(
        onTap: () async {
          await launch(url);
        },
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(
              child: Row(
                children: [
                  SvgPicture.asset('assets/profile/$asset.svg'),
                  const SizedBox(
                    width: 11,
                  ),
                  Text(
                    title,
                    style: TextStyle(
                      color: Palette.c1d1d1d,
                      fontSize: 14,
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              child: Text(
                value,
                style: TextStyle(
                  color: Palette.c1d1d1d,
                  fontSize: 14,
                  fontWeight: FontWeight.w400,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class SocialMediaBackground extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return SectionHolder(
      title: 'Social Media',
      icon: 'social_media',
      onEditPressed: SocialMediaDialog(),
      child: const _Empty(),
    );
  }
}
