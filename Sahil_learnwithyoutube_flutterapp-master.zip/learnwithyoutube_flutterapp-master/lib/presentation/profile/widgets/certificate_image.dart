import 'dart:io';
import 'dart:ui';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:dotted_border/dotted_border.dart';
import 'package:flutter/material.dart'
    hide DropdownButton, DropdownMenuItem, DropdownButtonFormField;
import 'package:flutter_app/application/providers/certificate_provider.dart';
import 'package:flutter_app/domain/profile/value_objects.dart';
import 'package:flutter_app/presentation/core/palette.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:provider/provider.dart';

class CertificateImageHolder extends StatelessWidget {
  final CertificateProvider provider;
  final int index;

  const CertificateImageHolder({
    Key key,
    @required this.provider,
    @required this.index,
  }) : super(key: key);
  @override
  Widget build(BuildContext context) {
    if (provider.recentlyAdededCertificates[index].image == '') {
      return Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          RaisedButton(
            elevation: 0,
            color: Palette.white,
            onPressed: () async => provider.pickImage(index),
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            child: SizedBox(
              height: 50,
              width: 130,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  SvgPicture.asset(
                    'assets/profile/upload.svg',
                    color: Colors.black,
                    height: 17,
                    width: 17,
                  ),
                  const SizedBox(
                    width: 10,
                  ),
                  const Text(
                    'Upload',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                        color: Colors.black,
                        fontSize: 16,
                        fontWeight: FontWeight.w600),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(
            height: 10,
          ),
          Text(
            'upload a jpeg, png\nof your certificate',
            textAlign: TextAlign.center,
            style: TextStyle(color: Palette.cafadad),
          )
        ],
      );
    } else if (Url(provider.recentlyAdededCertificates[index].image)
        .isValid()) {
      return GestureDetector(
        onTap: () async => _showChangeImageDialog(index),
        child: CachedNetworkImage(
          imageUrl: provider.recentlyAdededCertificates[index].image,
          height: 221,
          // width: 264,
          fit: BoxFit.cover,
        ),
      );
    } else {
      return GestureDetector(
        onTap: () async => _showChangeImageDialog(index),
        child: Image.file(
          File(provider.recentlyAdededCertificates[index].image),
          height: 221,
          // width: 264,
          fit: BoxFit.cover,
        ),
      );
    }
  }
}

Future<void> _showChangeImageDialog(int index) async {
  Provider.of<CertificateProvider>(context, listen: false)
      .assignSelectedImageToExistingImage(index);

  await showDialog(
    barrierDismissible: false,
    context: context,
    builder: (_) {
      return Consumer<CertificateProvider>(builder: (_, provider, child) {
        return BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 5, sigmaY: 5),
          child: Dialog(
              elevation: 100,
              insetPadding: const EdgeInsets.symmetric(horizontal: 20),
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(15)),
              backgroundColor: Palette.onBackground,
              child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 24),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const SizedBox(
                        height: 21,
                      ),
                      GestureDetector(
                        onTap: () => Navigator.pop(context),
                        child: const Align(
                          alignment: Alignment.centerRight,
                          child: Icon(
                            FontAwesomeIcons.times,
                            size: 17,
                            color: Color(0xff1d1d1d),
                          ),
                        ),
                      ),
                      const SizedBox(
                        height: 16,
                      ),
                      DottedBorder(
                        dashPattern: const [8, 8, 8, 8],
                        color: Palette.onBlue,
                        child: Container(
                          alignment: Alignment.center,
                          height: 250,
                          width: 330,
                          decoration: BoxDecoration(color: Palette.white),
                          padding: const EdgeInsets.all(20),
                          child: _image(provider.selectedImage),
                        ),
                      ),
                      const SizedBox(
                        height: 24,
                      ),
                      _text(),
                      const SizedBox(
                        height: 40,
                      ),
                      _actionButtons(provider, index),
                      const SizedBox(
                        height: 40,
                      ),
                    ],
                  ))),
        );
      });
    },
  );
}

Widget _actionButtons(CertificateProvider provider, int index) {
  return Row(
    children: [
      Expanded(
        child: RaisedButton(
          elevation: 0,
          color: Palette.white,
          onPressed: () async => provider.changeImage(index),
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          child: SizedBox(
            height: 50,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                SvgPicture.asset(
                  'assets/repeat.svg',
                ),
                const SizedBox(
                  width: 10,
                ),
                Text(
                  'Change',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                      color: Palette.onBlue,
                      fontSize: 16,
                      fontWeight: FontWeight.w600),
                ),
              ],
            ),
          ),
        ),
      ),
      const SizedBox(
        width: 38,
      ),
      Expanded(
        child: RaisedButton(
          elevation: 0,
          color: Palette.onBlue,
          onPressed: () {
            provider.saveImage(index);
            Navigator.pop(context);
          },
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          child: SizedBox(
            height: 50,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                SvgPicture.asset(
                  'assets/download.svg',
                ),
                const SizedBox(
                  width: 10,
                ),
                Text(
                  'Save',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                      color: Palette.white,
                      fontSize: 16,
                      fontWeight: FontWeight.w600),
                ),
              ],
            ),
          ),
        ),
      )
    ],
  );
}

Widget _image(String selectedImage) {
  if (Url(selectedImage).isValid()) {
    return CachedNetworkImage(imageUrl: selectedImage);
  } else {
    return Image.file(File(selectedImage));
  }
}

Text _text() {
  return const Text(
    'Looks great !',
    textAlign: TextAlign.center,
    style: TextStyle(color: Color(0xff1D1D1D), fontSize: 16),
  );
}
