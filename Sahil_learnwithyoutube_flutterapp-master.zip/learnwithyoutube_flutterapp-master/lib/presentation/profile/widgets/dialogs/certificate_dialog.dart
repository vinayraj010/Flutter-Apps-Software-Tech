import 'package:flutter/material.dart'
    hide DropdownButton, DropdownMenuItem, DropdownButtonFormField;
import 'package:flutter_app/application/providers/certificate_provider.dart';
import 'package:flutter_app/core/routes/route.gr.dart' as route;
import 'package:flutter_app/presentation/core/palette.dart';
import 'package:flutter_app/presentation/profile/widgets/certificate_field.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

import '../add_dialog.dart';

// final BuildContext context = route.Router.navigator.key.currentContext;
BuildContext context;

class CertificateDialog {
  void call() async {
    Provider.of<CertificateProvider>(context, listen: false)
        .addAllPreviousCertificatesToList();

    return await showDialog(
        context: context,
        builder: (_) => Consumer<CertificateProvider>(
              builder: (_, provider, child) {
                return AddDialog(
                  asset: 'certificate',
                  heading: 'Certificates',
                  onExit: provider.resetAll,
                  child: Form(
                    key: provider.formKey,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        for (int i = 0;
                            i < provider.recentlyAdededCertificates.length;
                            i++)
                          CertificateField(
                            index: i,
                            provider: provider,
                            key: ValueKey(
                                provider.recentlyAdededCertificates[i]?.id),
                          ),
                        const SizedBox(
                          height: 20,
                        ),
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Padding(
                              padding: const EdgeInsets.only(top: 6),
                              child:
                                  SvgPicture.asset('assets/profile/info.svg'),
                            ),
                            const SizedBox(
                              width: 10,
                            ),
                            Text(
                              'This information will get\nreflected in your public profile',
                              style: TextStyle(
                                  fontSize: 12,
                                  fontWeight: FontWeight.w400,
                                  color: Palette.onBlue,
                                  fontFamily: GoogleFonts.poppins().fontFamily),
                            ),
                          ],
                        ),
                        const SizedBox(
                          height: 25,
                        ),
                        Padding(
                          padding: const EdgeInsets.only(left: 10),
                          child: Row(
                            children: [
                              Expanded(
                                child: OutlinedButton(
                                  style: ButtonStyle(
                                      elevation: MaterialStateProperty.all(0),
                                      side: provider.addFieldBorder(),
                                      shape: MaterialStateProperty.all(
                                          RoundedRectangleBorder(
                                              borderRadius:
                                                  BorderRadius.circular(16)))),
                                  onPressed: provider.onAddFieldPressed,
                                  child: SizedBox(
                                    height: 50,
                                    child: SvgPicture.asset(
                                      'assets/profile/add_field.svg',
                                      color: provider
                                              .checkWhetherAllFieldsAllFilled()
                                          ? Palette.cc4c4c4
                                          : null,
                                    ),
                                  ),
                                ),
                              ),
                              const SizedBox(width: 12),
                              Expanded(
                                child: RaisedButton(
                                  elevation: 0,
                                  color: Palette.onBlue,
                                  onPressed: provider.onSavePressed,
                                  shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(16)),
                                  child: SizedBox(
                                    height: 50,
                                    child: SvgPicture.asset(
                                      'assets/profile/about_save.svg',
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ));
  }
}
