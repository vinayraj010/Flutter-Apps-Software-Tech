import 'package:flutter/material.dart';
import 'package:flutter_app/application/profile/profile_bloc.dart';
import 'package:flutter_app/application/providers/skill_provider.dart';
import 'package:flutter_app/core/routes/route.gr.dart' as route;
import 'package:flutter_app/presentation/core/palette.dart';
import 'package:flutter_app/presentation/profile/widgets/dialogs/validation_textfield.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_svg/svg.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

import '../add_dialog.dart';

BuildContext context;

class SkillDialog {
  void call() async {
    Provider.of<SkillProvider>(context, listen: false)
        .addAllPreviousSkillsToList();

    return await showDialog(
        context: context,
        builder: (_) => BlocBuilder<ProfileBloc, ProfileState>(
              builder: (context, state) {
                return Consumer<SkillProvider>(
                  builder: (context, provider, child) {
                    //Dialog
                    return AddDialog(
                      asset: 'skills',
                      heading: 'Skills',
                      onExit: provider.resetAll,
                      child: Form(
                        key: provider.formKey,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            for (int i = 0;
                                i < provider.recentlyAdededSkills.length;
                                i++)
                              _Field(index: i, provider: provider),
                            const SizedBox(
                              height: 20,
                            ),
                            Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Padding(
                                  padding: const EdgeInsets.only(top: 6),
                                  child: SvgPicture.asset(
                                      'assets/profile/info.svg'),
                                ),
                                const SizedBox(
                                  width: 10,
                                ),
                                Text(
                                  'This information will get\nreflected in your public profile',
                                  style: TextStyle(
                                      fontSize: 12,
                                      fontWeight: FontWeight.w400,
                                      color: Palette.onBlue,
                                      fontFamily:
                                          GoogleFonts.poppins().fontFamily),
                                ),
                              ],
                            ),
                            const SizedBox(
                              height: 25,
                            ),
                            Padding(
                              padding: const EdgeInsets.only(left: 10),
                              child: Row(
                                children: [
                                  Expanded(
                                    child: OutlinedButton(
                                      style: ButtonStyle(
                                          elevation:
                                              MaterialStateProperty.all(0),
                                          side: provider.addFieldBorder(),
                                          shape: MaterialStateProperty.all(
                                              RoundedRectangleBorder(
                                                  borderRadius:
                                                      BorderRadius.circular(
                                                          16)))),
                                      onPressed: provider.onAddFieldPressed,
                                      child: SizedBox(
                                        height: 50,
                                        child: SvgPicture.asset(
                                          'assets/profile/add_field.svg',
                                          color: provider
                                                  .checkWhetherSkillNameisFilled()
                                              ? Palette.cc4c4c4
                                              : null,
                                        ),
                                      ),
                                    ),
                                  ),
                                  const SizedBox(width: 12),
                                  Expanded(
                                    child: RaisedButton(
                                      elevation: 0,
                                      color: Palette.onBlue,
                                      onPressed: provider.onSavePressed,
                                      shape: RoundedRectangleBorder(
                                          borderRadius:
                                              BorderRadius.circular(16)),
                                      child: SizedBox(
                                        height: 50,
                                        child: SvgPicture.asset(
                                          'assets/profile/about_save.svg',
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                );
              },
            ));
  }
}

class _Field extends StatelessWidget {
  static final List<Color> _sliderColors = [
    Palette.sliderGreen,
    Palette.sliderYellow,
    Palette.sliderRed,
  ];

  final int index;
  final SkillProvider provider;

  const _Field({Key key, this.index, this.provider}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    provider.checkWhetherFieldsFilled(index: index);
    return Column(
      children: [
        Row(
          children: [
            SvgPicture.asset('assets/profile/skill_small.svg'),
            const SizedBox(
              width: 10,
            ),
            Text(
              'Skill ${provider.recentlyAdededSkills.length - index}',
              style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                  color: Palette.c686868,
                  fontFamily: GoogleFonts.poppins().fontFamily),
            ),
          ],
        ),
        const SizedBox(
          height: 10,
        ),
        Row(
          children: [
            Flexible(
              child: ValidationTextField(
                key: ValueKey(provider.recentlyAdededSkills[index].id),
                formKey: provider.formKey,
                keyboardType: TextInputType.text,
                initialValue: provider.recentlyAdededSkills[index].name,
                validator: (String value) =>
                    provider.validatorForSkillName(value: value, index: index),
                onChanged: (value) =>
                    provider.onSkillNameChanged(value: value, index: index),
                hintText: 'eg. Photoshop',
                isNotFilled: provider.isSkillNameNotFilled,
                border: provider.skillNameTextFieldBorder,
              ),
            ),
            const SizedBox(
              width: 10,
            ),
            Visibility(
              visible: provider.isOnline(index),
              child: GestureDetector(
                onTap: () => provider.removeAndAddToDelete(index),
                child: SvgPicture.asset(
                  'assets/profile/bin.svg',
                ),
              ),
            ),
          ],
        ),
        const SizedBox(
          height: 10,
        ),
        Padding(
          padding: const EdgeInsets.only(left: 10),
          child: SliderTheme(
            data: SliderThemeData(
              trackHeight: 7,
              thumbShape:
                  const RoundSliderThumbShape(enabledThumbRadius: 27 / 2),
              trackShape: CustomTrackShape(),
            ),
            child: Slider.adaptive(
              divisions: 4,
              min: 1.0,
              onChanged: (double newSliderValue) => provider.onSliderChanged(
                  newSliderValue: newSliderValue, index: index),
              value: double.parse(
                  provider.recentlyAdededSkills[index].pivot.experience),
              max: 5,
              activeColor: _sliderColors[index % 3],
              inactiveColor: _sliderColors[index % 3].withOpacity(.3),
            ),
          ),
        ),
        const SizedBox(
          height: 30,
        ),
      ],
    );
  }
}
