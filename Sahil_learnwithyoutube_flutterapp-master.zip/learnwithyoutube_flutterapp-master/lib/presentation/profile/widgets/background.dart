import 'package:flutter/material.dart';
import 'package:flutter_app/presentation/profile/widgets/section_holder.dart';

class ProfileBackground extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return SectionHolder(
      title: 'About',
      icon: 'about',
      isShowPen: false,
      onEditPressed: () {},
      child: Placeholder(
        color: Colors.transparent,
      ),
    );
  }
}
