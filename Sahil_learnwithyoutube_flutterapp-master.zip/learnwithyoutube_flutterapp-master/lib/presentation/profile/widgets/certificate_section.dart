import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_app/application/profile/profile_bloc.dart';
import 'package:flutter_app/core/utils/convert_date.dart';
import 'package:flutter_app/domain/profile/profile.dart';
import 'package:flutter_app/presentation/core/palette.dart';
import 'package:flutter_app/presentation/profile/widgets/dialogs/certificate_dialog.dart';
import 'package:flutter_app/presentation/profile/widgets/image_viewer.dart';
import 'package:flutter_app/presentation/profile/widgets/section_holder.dart';
import 'package:flutter_svg/svg.dart';
import 'package:scrolling_page_indicator/scrolling_page_indicator.dart';

class CertificateSection extends StatefulWidget {
  const CertificateSection({
    Key key,
    this.state,
  }) : super(key: key);

  final ProfileState state;

  @override
  _CertificateSectionState createState() => _CertificateSectionState();
}

class _CertificateSectionState extends State<CertificateSection> {
  final PageController _pageController = PageController();

  @override
  Widget build(BuildContext context) {
    return SectionHolder(
      title: 'Certificates',
      icon: widget.state.profile.certificates.isEmpty
          ? 'certificate'
          : 'certificate_two',
      onEditPressed: CertificateDialog(),
      child: widget.state.profile.certificates.isEmpty
          ? const _Empty()
          : Column(
              children: [
                LimitedBox(
                  maxHeight: 250,
                  child: PageView.builder(
                    controller: _pageController,
                    itemCount: widget.state.profile.certificates.length,
                    itemBuilder: (context, index) {
                      final Certificate _certificate =
                          widget.state.profile.certificates[index];

                      return _Child(
                        title: _certificate.description,
                        orgName: _certificate.organization,
                        date: rawStringToDate(_certificate.issuingDate),
                        img: widget.state.profile.certificates[index].image,
                      );
                    },
                  ),
                ),
                const SizedBox(
                  height: 30,
                ),
                ScrollingPageIndicator(
                  dotSelectedColor: Palette.onBlue,
                  dotSelectedSize: 8,
                  controller: _pageController,
                  visibleDotCount: 7,
                  itemCount: widget.state.profile.certificates.length,
                )
              ],
            ),
    );
  }
}

class _Empty extends StatelessWidget {
  const _Empty({
    Key key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        SvgPicture.asset('assets/profile/empty_pen.svg'),
        const SizedBox(
          height: 5,
        ),
        const Text(
          'Add your certificates \nand boost up your profile',
          textAlign: TextAlign.center,
          style: TextStyle(
            color: Color(0xffAFADAD),
            fontSize: 11,
            fontWeight: FontWeight.w400,
          ),
        ),
      ],
    );
  }
}

class _Child extends StatelessWidget {
  final String title;
  final String orgName;
  final String date;
  final String img;

  const _Child({Key key, this.title, this.orgName, this.date, this.img})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(left: 6, right: 6),
      child: GestureDetector(
        onTap: () => Navigator.push(
            context, MaterialPageRoute(builder: (_) => ImageViewer(url: img))),
        child: Container(
          alignment: Alignment.topCenter,
          decoration: BoxDecoration(
            border: Border.all(color: Palette.onBlue, width: 2),
            borderRadius: BorderRadius.circular(20),
          ),
          child: Stack(
            alignment: Alignment.bottomCenter,
            children: [
              DecoratedBox(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(16),
                ),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(16),
                  child: CachedNetworkImage(
                    imageUrl: img,
                    height: 250,
                    fit: BoxFit.cover,
                    width: MediaQuery.of(context).size.width,
                  ),
                ),
              ),
              Container(
                height: 80,
                decoration: BoxDecoration(
                  color: Palette.onBackground,
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: Palette.onBlue, width: 2),
                ),
                child: ListTile(
                  title: Text(
                    title,
                    style:
                        const TextStyle(color: Color(0xff6646E7), fontSize: 11),
                  ),
                  isThreeLine: true,
                  subtitle: Text(
                    orgName,
                    style: const TextStyle(
                        color: Color(0xff6646E7),
                        fontSize: 14,
                        fontWeight: FontWeight.w600),
                  ),
                  trailing: Text(
                    date,
                    style: const TextStyle(
                        color: Color(0xff6646E7),
                        fontSize: 8,
                        fontWeight: FontWeight.w400),
                  ),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}

class CertificateBackground extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return SectionHolder(
        title: 'Certificates',
        icon: 'certificate_two',
        onEditPressed: CertificateDialog(),
        child: const _Empty());
  }
}
