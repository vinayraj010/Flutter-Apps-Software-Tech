import 'package:animations/animations.dart';
import 'package:flutter/material.dart';
import 'package:flutter_app/application/providers/onboard_provider.dart';
import 'package:flutter_app/core/enums/auth_current_enum.dart';
import 'package:flutter_app/core/routes/route.gr.dart' as route;
import 'package:flutter_app/presentation/core/palette.dart';
import 'package:flutter_app/presentation/login/pages/login_page.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:provider/provider.dart';

class OnBoardingPage extends StatefulWidget {
  @override
  _OnBoardingPageState createState() => _OnBoardingPageState();
}

class _OnBoardingPageState extends State<OnBoardingPage> {
  @override
  Widget build(BuildContext context) {
    final OnBoardProvider _onBoardProvider =
        Provider.of<OnBoardProvider>(context);
    Widget _pageDecider() {
      switch (_onBoardProvider.currentPage) {
        case ON_PAGE.one:
          return _PageOne(
            key: UniqueKey(),
            pageNumber: 1,
            on_page: ON_PAGE.two,
          );

          break;
        case ON_PAGE.two:
          return _PageOne(
            key: UniqueKey(),
            pageNumber: 2,
            on_page: ON_PAGE.three,
          );

          break;
        case ON_PAGE.three:
          return _PageOne(
            key: UniqueKey(),
            pageNumber: 3,
            on_page: ON_PAGE.one,
          );

          break;
        default:
          return _PageOne(
            key: UniqueKey(),
            pageNumber: 1,
            on_page: ON_PAGE.two,
          );
      }
    }

    return SafeArea(
      child: Container(
        decoration: BoxDecoration(
          color: Palette.white,
        ),
        padding: const EdgeInsets.all(15),
        child: PageTransitionSwitcher(
          duration: const Duration(milliseconds: 350),
          transitionBuilder: (Widget child, Animation<double> primaryAnimation,
              Animation<double> secondaryAnimation) {
            return Scaffold(
              backgroundColor: Palette.onBackground,
              body: ClipRRect(
                borderRadius: BorderRadius.circular(18),
                child: Stack(
                  key: ValueKey(
                      Provider.of<OnBoardProvider>(context).currentPage),
                  alignment: Alignment.bottomCenter,
                  children: [
                    SharedAxisTransition(
                      animation: primaryAnimation,
                      secondaryAnimation: secondaryAnimation,
                      transitionType: SharedAxisTransitionType.horizontal,
                      child: child,
                    ),
                    Container(
                      margin: const EdgeInsets.only(bottom: 21),
                      child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: ON_PAGE.values.map((e) {
                            return Container(
                              height: 8,
                              width: 15,
                              decoration: BoxDecoration(
                                borderRadius: _onBoardProvider.currentPage != e
                                    ? null
                                    : BorderRadius.circular(50),
                                shape: _onBoardProvider.currentPage == e
                                    ? BoxShape.rectangle
                                    : BoxShape.circle,
                                color: _onBoardProvider.currentPage == e
                                    ? Palette.onRed
                                    : Color(0xffb1b1b1),
                              ),
                            );
                          }).toList()),
                    ),
                  ],
                ),
              ),
            );
          },
          child: _pageDecider(),
        ),
      ),
    );
  }
}

class _PageOne extends StatelessWidget {
  final int pageNumber;
  final ON_PAGE on_page;

  const _PageOne({Key key, this.pageNumber, this.on_page}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return DecoratedBox(
      decoration: BoxDecoration(
        color: Palette.onBackground,
      ),
      child: Column(
        children: [
          Expanded(
            child: Container(
              width: double.maxFinite,
              padding: const EdgeInsets.all(50),
              decoration: BoxDecoration(
                borderRadius: const BorderRadius.only(
                  bottomLeft: Radius.circular(18),
                  bottomRight: Radius.circular(18),
                ),
                color: Palette.onBlue,
              ),
              child: SvgPicture.asset('assets/onboarding/$pageNumber.svg'),
            ),
          ),
          Expanded(
            child: Container(
              padding: const EdgeInsets.only(top: 42),
              child: Column(
                children: [
                  Text(
                    'Lorem ipsum dolor',
                    style: TextStyle(
                        color: Palette.onHeading1,
                        fontSize: 30,
                        fontWeight: FontWeight.w700),
                  ),
                  const SizedBox(
                    height: 21,
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 60),
                    child: Text(
                      'Lorem ipsum dolor sit amet, consectetur adipiscing elit. ',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        color: Palette.onHeading2,
                        fontWeight: FontWeight.w400,
                      ),
                    ),
                  ),
                  const SizedBox(
                    height: 21,
                  ),
                  if (on_page == ON_PAGE.one)
                    GestureDetector(
                      key: const ValueKey(1),
                      onTap: () {
                        // Provider.of<OnBoardProvider>(context, listen: false)
                        //     .updateCurrentPage(on_page);
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => HandleAuthPage()),
                        );
                      },
                      child: FittedBox(
                        child: Container(
                          height: 60,
                          alignment: Alignment.center,
                          padding: const EdgeInsets.symmetric(horizontal: 33),
                          decoration: BoxDecoration(
                            color: Palette.onRed,
                            borderRadius: BorderRadius.circular(50),
                            boxShadow: [
                              BoxShadow(
                                  color: Palette.onRed.withOpacity(0.55),
                                  blurRadius: 54,
                                  offset: const Offset(0, 20))
                            ],
                          ),
                          child: Text(
                            'Get Started',
                            style: TextStyle(
                                color: Palette.white,
                                fontSize: 20,
                                fontWeight: FontWeight.w600),
                          ),
                        ),
                      ),
                    )
                  else
                    GestureDetector(
                      key: const ValueKey(2),
                      onTap: () {
                        Provider.of<OnBoardProvider>(context, listen: false)
                            .updateCurrentPage(on_page);
                      },
                      child: Container(
                        height: 60,
                        width: 60,
                        padding: const EdgeInsets.all(14),
                        decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: Palette.onRed,
                            boxShadow: [
                              BoxShadow(
                                  color: Palette.onRed.withOpacity(0.55),
                                  blurRadius: 54,
                                  offset: const Offset(0, 20))
                            ]),
                        child: SvgPicture.asset(
                          'assets/onboarding/arrow_right.svg',
                        ),
                      ),
                    )
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
