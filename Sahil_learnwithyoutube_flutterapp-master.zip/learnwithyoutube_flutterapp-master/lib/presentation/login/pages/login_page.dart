import 'dart:ui';

import 'package:animations/animations.dart';
import 'package:flushbar/flushbar_helper.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_app/application/auth/sign_in_form/sign_in_form_bloc.dart';
import 'package:flutter_app/application/providers/auth_provider.dart';
import 'package:flutter_app/core/enums/auth_current_enum.dart';
import 'package:flutter_app/core/routes/route.gr.dart' as route;
import 'package:flutter_app/presentation/core/pages/loading_page.dart';
import 'package:flutter_app/presentation/core/palette.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:provider/provider.dart';

import '../../../injection.dart';

class HandleAuthPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return BlocProvider(
        create: (context) => getIt<SignInFormBloc>(),
        child: BlocConsumer<SignInFormBloc, SignInFormState>(
          listener: (context, state) {
            state.authFailureOrSuccessOption.fold(
              () {},
              (either) {
                either.fold(
                  (failure) {
                    FlushbarHelper.createError(
                      message: failure.map(
                        cancelledByUser: (_) => 'Cancelled',
                        serverError: (_) => 'Server error',
                        emailAlreadyInUse: (_) => 'Email already in use',
                        invalidEmailAndPasswordCombination: (_) =>
                            'Invalid email and password combination',
                      ),
                    ).show(context);
                  },
                  (_) {
                    Provider.of<AuthProvider>(context, listen: false)
                        .updateCurrentPage(CURRENT_PAGE.user);
                  },
                );
              },
            );
            state.registerOption.fold(
              () {},
              (either) {
                either.fold(
                  (failure) {
                    FlushbarHelper.createError(
                      message: failure.map(
                        cancelledByUser: (_) => 'Cancelled',
                        serverError: (_) => 'Server error',
                        emailAlreadyInUse: (_) => 'Email already in use',
                        invalidEmailAndPasswordCombination: (_) =>
                            'Invalid email and password combination',
                      ),
                    ).show(context);
                  },
                  (_) {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => HandleAuthPage()),
                    );
                  },
                );
              },
            );
          },
          builder: (context, state) {
            return SafeArea(
              child: Stack(
                alignment: Alignment.center,
                children: [
                  PageTransitionSwitcher(
                    transitionBuilder: (Widget child,
                        Animation<double> primaryAnimation,
                        Animation<double> secondaryAnimation) {
                      return SharedAxisTransition(
                        transitionType: SharedAxisTransitionType.vertical,
                        secondaryAnimation: secondaryAnimation,
                        animation: primaryAnimation,
                        child: child,
                      );
                    },
                    child: Provider.of<AuthProvider>(context).currentPage ==
                            CURRENT_PAGE.login
                        ? LoginPage()
                        : UserTypePage(),
                  ),
                  Visibility(
                    visible: state.isSubmitting,
                    child: Center(
                      child: LoadingPage(),
                    ),
                  ),
                ],
              ),
            );
          },
        ));
  }
}

class LoginPage extends StatefulWidget {
  @override
  _LoginPageState createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  bool _isSelected = false;
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      color: Palette.white,
      child: ClipRRect(
        borderRadius: BorderRadius.circular(15),
        child: Stack(
          alignment: Alignment.bottomRight,
          children: [
            Scaffold(
              backgroundColor: Palette.onBackground,
              body: Column(
                children: <Widget>[
                  const Spacer(),
                  Image.asset('assets/logo.png'),
                  const Spacer(),
                  const Text(
                    'Login with',
                    style: TextStyle(color: Color(0xff686868), fontSize: 20),
                  ),
                  const SizedBox(
                    height: 26,
                  ),
                  Container(
                    margin: const EdgeInsets.symmetric(horizontal: 76),
                    height: 60,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(52),
                      color: Palette.onBlue,
                    ),
                    child: RaisedButton(
                      padding: const EdgeInsets.all(0),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(52),
                      ),
                      color: Palette.onBlue,
                      elevation: 10,
                      onPressed: () {
                        setState(() {
                          _isSelected = true;
                        });
                        // context.bloc<SignInFormBloc>().add(
                        //     const SignInFormEvent.signInWithGooglePressed());
                      },
                      child: Row(
                        children: [
                          const SizedBox(
                            width: 2,
                          ),
                          Image.asset('assets/google_logo.png'),
                          const Spacer(),
                          Text(
                            'Google',
                            style: TextStyle(
                                color: Palette.onBackground,
                                fontSize: 22,
                                fontWeight: FontWeight.w700),
                          ),
                          const Spacer(
                            flex: 2,
                          )
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(
                    height: 40,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      SvgPicture.asset('assets/smile_face.svg'),
                      const SizedBox(
                        width: 8,
                      ),
                      Text(
                        'You are just one step away !',
                        style: TextStyle(color: Palette.onBlue, fontSize: 14),
                      ),
                    ],
                  ),
                  const Spacer(
                    flex: 2,
                  ),
                ],
              ),
            ),
            SvgPicture.asset('assets/background.svg'),
            Visibility(
              visible: _isSelected,
              child: BackdropFilter(
                filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
                child: Center(
                  child: LoadingPage(),
                ),
              ),
            )
          ],
        ),
      ),
    );
  }
}

class UserTypePage extends StatefulWidget {
  @override
  _UserTypePageState createState() => _UserTypePageState();
}

class _UserTypePageState extends State<UserTypePage> {
  bool _isSelected = false;
  @override
  Widget build(BuildContext context) {
    void navigateToHomePage(int roleId) {
      setState(() {
        _isSelected = true;
      });
      // context
      //     .bloc<SignInFormBloc>()
      //     .add(SignInFormEvent.registerUserType(roleId));
      // Provider.of<AuthProvider>(context, listen: false)
      //     .updateCurrentPage(CURRENT_PAGE.login);
    }

    Widget _typeButton({@required VoidCallback onTap, @required String title}) {
      return FittedBox(
        child: Container(
          // margin: const EdgeInsets.symmetric(horizontal: 76),
          // padding: const EdgeInsets.symmetric(horizontal: 50),
          height: 60,
          alignment: Alignment.center,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(52),
            color: Palette.onBlue,
          ),
          child: RaisedButton(
            padding: const EdgeInsets.symmetric(horizontal: 50),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(52),
            ),
            color: Palette.onBlue,
            elevation: 10,
            onPressed: onTap,
            child: Center(
              child: Text(
                title,
                style: TextStyle(
                    color: Palette.onBackground,
                    fontSize: 20,
                    fontWeight: FontWeight.w700),
              ),
            ),
          ),
        ),
      );
    }

    return Container(
      padding: const EdgeInsets.all(14),
      color: Palette.white,
      child: ClipRRect(
        borderRadius: BorderRadius.circular(15),
        child: Stack(
          alignment: Alignment.bottomRight,
          children: [
            Scaffold(
              backgroundColor: Palette.onBackground,
              body: Center(
                child: Column(
                  children: <Widget>[
                    const Spacer(),
                    Image.asset('assets/logo.png'),
                    const Spacer(),
                    const Text(
                      'Login with',
                      style: TextStyle(color: Color(0xff686868), fontSize: 20),
                    ),
                    const SizedBox(
                      height: 24,
                    ),
                    _typeButton(
                      onTap: () {
                        navigateToHomePage(1);
                      },
                      title: 'Student',
                    ),
                    const SizedBox(
                      height: 35,
                    ),
                    _typeButton(
                      onTap: () {
                        navigateToHomePage(2);
                      },
                      title: 'Teacher',
                    ),
                    const SizedBox(
                      height: 35,
                    ),
                    _typeButton(
                      onTap: () {
                        // navigateToHomePage(3);
                      },
                      title: 'Parents',
                    ),
                    const Spacer(
                      flex: 2,
                    ),
                  ],
                ),
              ),
            ),
            SvgPicture.asset('assets/background.svg'),
            Visibility(
              visible: _isSelected,
              child: BackdropFilter(
                filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
                child: Center(
                  child: LoadingPage(),
                ),
              ),
            )
          ],
        ),
      ),
    );
  }
}
