package com.example.jhatpat

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
