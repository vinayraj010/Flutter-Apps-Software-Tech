// ignore_for_file: constant_identifier_names

import 'package:flutter/material.dart';

class AppColors {
  static const Color HOMEPAGE_LINEAR_1 = Color(0xff2A529B);
  static const Color HOMEPAGE_LINEAR_2 = Color(0xff15294E);
  static const Color WHITE = Color(0xffffffff);
  static const Color BUTTON = Color(0xff172D56);
  static const Color HEADING = Color(0xff2F2E41);
  static const Color BACKGROUNDSTACK = Color(0xffF1F3F6);
  static const Color ELEMENTHEADING = Color(0xff1F3D73);
}
