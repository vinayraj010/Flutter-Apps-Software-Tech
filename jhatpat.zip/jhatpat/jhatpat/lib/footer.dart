// ignore_for_file: prefer_const_constructors, prefer_const_literals_to_create_immutables

import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:jhatpat/privacy.dart';
import 'package:jhatpat/refund.dart';
import 'package:jhatpat/terms.dart';

import 'contants.dart';

class Footer extends StatelessWidget {
  const Footer({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    var screenSize = MediaQuery.of(context).size;
    return SizedBox(
      width: screenSize.width,
      height: screenSize.height * 0.6,
      child: Stack(children: [
        Container(
          height: screenSize.height * 0.58,
          width: screenSize.width * 0.85,
          decoration: BoxDecoration(
              color: AppColors.BACKGROUNDSTACK,
              borderRadius: BorderRadius.only(topRight: Radius.circular(160)),
              border: Border.all(color: Colors.grey)),
        ),
        Positioned(
          bottom: 1,
          child: Container(
            height: screenSize.height * 0.56,
            width: screenSize.width * 0.84,
            decoration: const BoxDecoration(
                borderRadius: BorderRadius.only(topRight: Radius.circular(160)),
                gradient: LinearGradient(colors: [
                  AppColors.HOMEPAGE_LINEAR_1,
                  AppColors.HOMEPAGE_LINEAR_2
                ])),
            child: Padding(
              padding: EdgeInsets.all(screenSize.height * 0.05),
            ),
          ),
        ),
        Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              'Get In Touch',
              style: TextStyle(
                  color: AppColors.WHITE,
                  fontSize: 48,
                  fontWeight: FontWeight.bold),
            ),
            SizedBox(
              height: screenSize.height * 0.05,
            ),
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Jhatpat Bill',
                      style: TextStyle(
                          color: AppColors.WHITE,
                          fontSize: 28,
                          fontWeight: FontWeight.bold),
                    ),
                    SizedBox(
                      height: 20,
                    ),
                    Text(
                      'Invoicing Made Easy for your Business,\nBill kar Jhatpat',
                      style: TextStyle(
                        color: AppColors.WHITE,
                      ),
                    ),
                    SizedBox(
                      height: 24,
                    ),
                    Text(
                      'Contact',
                      style: TextStyle(
                          color: AppColors.WHITE,
                          fontSize: 22,
                          fontWeight: FontWeight.bold),
                    ),
                    SizedBox(
                      height: 20,
                    ),
                    Row(
                      children: [
                        Icon(
                          Icons.email,
                          color: AppColors.WHITE,
                        ),
                        SizedBox(
                          width: 4,
                        ),
                        Text(
                          'bradvicesolutionspvt@gmail.com',
                          style: TextStyle(color: AppColors.WHITE),
                        )
                      ],
                    ),
                    SizedBox(
                      height: 10,
                    ),
                    Row(
                      children: [
                        Icon(
                          Icons.wifi_calling_3,
                          color: AppColors.WHITE,
                        ),
                        SizedBox(
                          width: 4,
                        ),
                        Text(
                          '+91-7742330144',
                          style: TextStyle(color: AppColors.WHITE),
                        )
                      ],
                    ),
                    SizedBox(
                      height: 10,
                    ),
                    Row(
                      children: [
                        Icon(
                          Icons.location_on_outlined,
                          color: AppColors.WHITE,
                        ),
                        SizedBox(
                          width: 4,
                        ),
                        Text(
                          'FF-27,Cross Road Mall, Center \nSpine, Vidhyadhar Nagar, Jaipur.\nRajasthan, India',
                          style: TextStyle(color: AppColors.WHITE),
                        )
                      ],
                    ),
                    SizedBox(
                      height: 20,
                    ),
                    Row(
                      children: [
                        FaIcon(
                          FontAwesomeIcons.facebook,
                          color: AppColors.WHITE,
                        ),
                        SizedBox(
                          width: 24,
                        ),
                        FaIcon(
                          FontAwesomeIcons.linkedin,
                          color: AppColors.WHITE,
                        ),
                        SizedBox(
                          width: 24,
                        ),
                        FaIcon(
                          FontAwesomeIcons.twitter,
                          color: AppColors.WHITE,
                        ),
                      ],
                    ),
                  ],
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'About',
                      style: TextStyle(
                          color: AppColors.WHITE,
                          fontSize: 28,
                          fontWeight: FontWeight.bold),
                    ),
                    SizedBox(
                      height: 20,
                    ),
                    Text(
                      'About Us',
                      style: TextStyle(
                        color: AppColors.WHITE,
                      ),
                    ),
                    SizedBox(
                      height: 20,
                    ),
                    Text(
                      'How It Works',
                      style: TextStyle(
                        color: AppColors.WHITE,
                      ),
                    ),
                    SizedBox(
                      height: 20,
                    ),
                    Text(
                      'Get App',
                      style: TextStyle(
                        color: AppColors.WHITE,
                      ),
                    ),
                    SizedBox(
                      height: 20,
                    ),
                    Text(
                      'Help & Support',
                      style: TextStyle(
                        color: AppColors.WHITE,
                      ),
                    ),
                  ],
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Useful',
                      style: TextStyle(
                          color: AppColors.WHITE,
                          fontSize: 28,
                          fontWeight: FontWeight.bold),
                    ),
                    SizedBox(
                      height: 20,
                    ),
                    InkWell(
                      onTap: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (container) => Privacy()));
                      },
                      child: Text(
                        'Privacy Policy ',
                        style: TextStyle(
                          color: AppColors.WHITE,
                        ),
                      ),
                    ),
                    SizedBox(
                      height: 20,
                    ),
                    InkWell(
                      onTap: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (container) => Refund()));
                      },
                      child: Text(
                        'Refund Policy',
                        style: TextStyle(
                          color: AppColors.WHITE,
                        ),
                      ),
                    ),
                    SizedBox(
                      height: 20,
                    ),
                    InkWell(
                      onTap: () {
                        Navigator.push(context,
                            MaterialPageRoute(builder: (container) => Terms()));
                      },
                      child: Text(
                        'Terms of Service',
                        style: TextStyle(
                          color: AppColors.WHITE,
                        ),
                      ),
                    ),
                  ],
                ),
                Container(
                  height: screenSize.height * 0.4,
                  width: screenSize.width * 0.2,
                  color: Colors.transparent,
                  child: Column(
                    children: [
                      Container(
                        decoration: BoxDecoration(
                            color: AppColors.WHITE,
                            border: Border.all(color: Colors.black)),
                        child: TextField(
                          decoration: InputDecoration(
                              border: InputBorder.none,
                              focusedBorder: InputBorder.none,
                              enabledBorder: InputBorder.none,
                              errorBorder: InputBorder.none,
                              disabledBorder: InputBorder.none,
                              hintText: 'Email'),
                        ),
                      ),
                      SizedBox(
                        height: 12,
                      ),
                      Container(
                        decoration: BoxDecoration(
                            color: AppColors.WHITE,
                            border: Border.all(color: Colors.black)),
                        child: TextField(
                          decoration: InputDecoration(
                            border: InputBorder.none,
                            focusedBorder: InputBorder.none,
                            enabledBorder: InputBorder.none,
                            errorBorder: InputBorder.none,
                            disabledBorder: InputBorder.none,
                            hintText: 'Subject',
                            suffixIcon: Icon(Icons.arrow_drop_down_sharp),
                          ),
                        ),
                      ),
                      SizedBox(
                        height: 12,
                      ),
                      Container(
                        height: screenSize.height * 0.15,
                        decoration: BoxDecoration(
                            color: AppColors.WHITE,
                            border: Border.all(color: Colors.black)),
                        child: TextField(
                          decoration: InputDecoration(
                              border: InputBorder.none,
                              focusedBorder: InputBorder.none,
                              enabledBorder: InputBorder.none,
                              errorBorder: InputBorder.none,
                              disabledBorder: InputBorder.none,
                              hintText: 'Write Your Message Here...'),
                        ),
                      ),
                      SizedBox(
                        height: 12,
                      ),
                      Container(
                        height: screenSize.height * 0.065,
                        width: screenSize.width * 0.2,
                        decoration: BoxDecoration(
                            color: AppColors.BUTTON,
                            border: Border.all(color: Colors.black)),
                        child: TextButton(
                          child: Text('Send', style: TextStyle(color: AppColors.WHITE, fontWeight: FontWeight.bold),),
                          onPressed: () {},
                        ),
                      )
                    ],
                  ),
                )
              ],
            )
          ],
        ),
      ]),
    );
  }
}
