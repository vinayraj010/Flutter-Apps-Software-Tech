// ignore_for_file: prefer_const_constructors

import 'package:flutter/material.dart';
import 'package:jhatpat/footer.dart';
import 'package:jhatpat/header.dart';
import 'contants.dart';

class Refund extends StatelessWidget {
  const Refund({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    var screenSize = MediaQuery.of(context).size;
    return Scaffold(
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Header(),
            SizedBox(
              height: screenSize.height * 0.1,
            ),
            Center(
              child: Text(
                'Refund Policy',
                style: TextStyle(
                    color: AppColors.HEADING,
                    fontSize: 48,
                    fontWeight: FontWeight.bold),
              ),
            ),
            SizedBox(
              height: screenSize.height * 0.1,
            ),
            Padding(
              padding:
                  EdgeInsets.symmetric(horizontal: screenSize.width * 0.05),
              child: Text(
                  'Cancellation and Refund Policy\n\nThis Cancellation and Refund Policy shall apply to any cancellation of subscription of the JhatpatBill Products and applicable refunds. JhatpatBill shall not entertain any refund requests if cancellation of subscription is in violation of this policy or its Terms of Service or if JhatpatBill terminates the User account for violation of its Terms of Service.\nThis Cancellation and Refund Policy is part of and incorporated within, and is to be read along with the Terms of Service https//:bradvicepvt.com/termsofservice. The terms capitalised in this policy and not defined herein shall have the meaning assigned to them in the Terms of Service.\n\nJhatpatBill permits cancellation of subscription if a User is not satisfied with the product or service. Cancellation of a first-time subscription is eligible for refund only within 15 days from the date of purchase of subscription (“Purchase Date”).\nA User can only avail refund once. Renewal of subscription after the expiration of its term shall not entitle a User to avail refund.\nThe date on invoice for subscription shall be considered as final and conclusive for determining the Purchase Date.\nJhatpatBill may permit Users to upgrade their subscription by purchasing a higher priced subscription. Where a User upgrades its subscription, the refund shall be governed by the Purchase Date and not from the date of upgrade of subscription (“Upgrade Date”). To clarify, a User who avails an upgrade is eligible for refund upon cancellation of the subscription within 15 days from the Purchase Date only.\nUnder no circumstance shall a User be entitled to a refund upon cancellation of subscription after 15 days from the Purchase Date.\nAll requests for cancellation of subscription and refund should be raised only via the customer support helpline provided by JhatpatBill. Cancellation and refund requests raised through any other mode of communication will not be considered for refund.\nJhatpatBill has arrangements with banks, affiliates, payment gateways, payment aggregators and other financial service providers for processing refunds (“Service Providers”). JhatpatBill endeavours to ensure that eligible refunds are processed within 20 working days of your request for cancellation of subscription. However, this timeline is indicative and processing of refunds is subject to the time taken by the Service Providers.\nThe User agrees to provide any information required to facilitate refunds including but not limited to bank account details, bank branch names, UPI addresses, IFSC codes.\nThe User acknowledges and agrees that remittance of refund to the User is subject to the charges that may be levied by the Service Providers for such remittance. Such charges shall be deducted from the refund claimed by the User.\nNotwithstanding anything contained in any other clause of this policy, this Cancellation and Refund Policy shall not apply to the Users who register and purchase subscriptions of JhatpatBill Products using the referral code/referral link of existing JhatpatBill’ Users.\n\nModifying and Terminating our Services\nThe Terms of Service are liable to be updated or changed with time. The users will be notified for any changes in the existing Terms of service by means of posting the new document of the terms on the concerned webpage of our company website. The users will also be notified by means of an email as well as a notice prior to the implementation of the changed Terms of Service and an effective date will be updated at the top of this policy.\nHowever, the users are advised to re-examine the Terms of Service sporadically for any changes. Any changes to this policy would be effective only when they are mentioned on this page.\n\nContact Us\nAny queries about the Refund Policy, from the users, are welcome. The users can connect with us by:\nEmail: bradvicesolutionspvt@gmail.com\nVisiting our website: https//:bradvicepvt.com\nContact number: +91-7742330144\n\nConsent\nUsing our Mobile Application, Desktop Application, Website, Store or other product ensures your consent to our Privacy Policy as well as the terms and conditions as posted on the Mobile Application, Desktop Application, Website, Store or other product.\n'),
            ),
            SizedBox(
              height: screenSize.height * 0.1,
            ),
            Footer()
          ],
        ),
      ),
    );
  }
}
