// ignore_for_file: prefer_const_constructors

import 'package:flutter/material.dart';

import 'contants.dart';
import 'home_page.dart';

class Header extends StatelessWidget {
  const Header({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    var screenSize = MediaQuery.of(context).size;
    return Stack(children: [
      Container(
        height: screenSize.height * 0.1,
        width: screenSize.width * 0.70,
        decoration: const BoxDecoration(
            borderRadius: BorderRadius.only(bottomRight: Radius.circular(160)),
            gradient: LinearGradient(colors: [
              AppColors.HOMEPAGE_LINEAR_1,
              AppColors.HOMEPAGE_LINEAR_2
            ])),
      ),
      Padding(
        padding: EdgeInsets.only(top: screenSize.height * 0.03),
        child: Padding(
          padding: EdgeInsets.symmetric(horizontal: screenSize.width * 0.03),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'JhatPat Bill',
                style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                    color: AppColors.WHITE),
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  TextButton(
                      onPressed: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => HomePage()));
                      },
                      child: Text('Home',
                          style: TextStyle(color: AppColors.WHITE))),
                  SizedBox(
                    width: screenSize.width * 0.03,
                  ),
                  TextButton(
                      onPressed: () {},
                      child: Text('About Us',
                          style: TextStyle(color: AppColors.WHITE))),
                  SizedBox(
                    width: screenSize.width * 0.03,
                  ),
                  TextButton(
                      onPressed: () {},
                      child: Text('Features',
                          style: TextStyle(color: AppColors.WHITE))),
                  SizedBox(
                    width: screenSize.width * 0.03,
                  ),
                  TextButton(
                      onPressed: () {},
                      child: Text('Get App',
                          style: TextStyle(color: AppColors.WHITE))),
                  SizedBox(
                    width: screenSize.width * 0.03,
                  ),
                  TextButton(
                      onPressed: () {},
                      child: Text('Contact Us',
                          style: TextStyle(color: AppColors.WHITE))),
                ],
              ),
              Container(
                height: 40,
                width: 140,
                decoration: BoxDecoration(
                  color: AppColors.BUTTON,
                  borderRadius: BorderRadius.circular(16),
                ),
                child: TextButton(
                    onPressed: () {},
                    child: Container(
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(2),
                      ),
                      child: Text(
                        'Login/Signup',
                        style: TextStyle(color: AppColors.WHITE),
                      ),
                    )),
              ),
            ],
          ),
        ),
      ),
    ]);
  }
}
