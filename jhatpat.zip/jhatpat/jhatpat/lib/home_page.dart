// ignore_for_file: prefer_const_constructors, prefer_const_literals_to_create_immutables

import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:jhatpat/footer.dart';
import 'package:jhatpat/contants.dart';

class HomePage extends StatelessWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    var screenSize = MediaQuery.of(context).size;
    return Scaffold(
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            /// App Bar Start
            Stack(children: [
              Container(
                height: screenSize.height * 0.84,
                width: screenSize.width * 0.69,
                decoration: BoxDecoration(
                    color: AppColors.BACKGROUNDSTACK,
                    borderRadius:
                        BorderRadius.only(bottomRight: Radius.circular(160)),
                    border: Border.all(color: Colors.grey)),
              ),
              Container(
                height: screenSize.height * 0.8,
                width: screenSize.width * 0.67,
                decoration: const BoxDecoration(
                    borderRadius:
                        BorderRadius.only(bottomRight: Radius.circular(160)),
                    gradient: LinearGradient(colors: [
                      AppColors.HOMEPAGE_LINEAR_1,
                      AppColors.HOMEPAGE_LINEAR_2
                    ])),
              ),
              Padding(
                padding: EdgeInsets.only(top: screenSize.height * 0.03),
                child: Padding(
                  padding:
                      EdgeInsets.symmetric(horizontal: screenSize.width * 0.03),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            'JhatPat Bill',
                            style: TextStyle(
                                fontSize: 24,
                                fontWeight: FontWeight.bold,
                                color: AppColors.WHITE),
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceAround,
                            children: [
                              TextButton(
                                  onPressed: () {},
                                  child: Text('Home',
                                      style:
                                          TextStyle(color: AppColors.WHITE))),
                              SizedBox(
                                width: screenSize.width * 0.03,
                              ),
                              TextButton(
                                  onPressed: () {},
                                  child: Text('About Us',
                                      style:
                                          TextStyle(color: AppColors.WHITE))),
                              SizedBox(
                                width: screenSize.width * 0.03,
                              ),
                              TextButton(
                                  onPressed: () {},
                                  child: Text('Features',
                                      style:
                                          TextStyle(color: AppColors.WHITE))),
                              SizedBox(
                                width: screenSize.width * 0.03,
                              ),
                              TextButton(
                                  onPressed: () {},
                                  child: Text('Get App',
                                      style:
                                          TextStyle(color: AppColors.WHITE))),
                              SizedBox(
                                width: screenSize.width * 0.03,
                              ),
                              TextButton(
                                  onPressed: () {},
                                  child: Text('Contact Us',
                                      style:
                                          TextStyle(color: AppColors.WHITE))),
                            ],
                          ),
                          Container(
                            height: 40,
                            width: 140,
                            decoration: BoxDecoration(
                              color: AppColors.BUTTON,
                              borderRadius: BorderRadius.circular(16),
                            ),
                            child: TextButton(
                                onPressed: () {},
                                child: Container(
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(2),
                                  ),
                                  child: Text(
                                    'Login/Signup',
                                    style: TextStyle(color: AppColors.WHITE),
                                  ),
                                )),
                          ),
                        ],
                      ),
                      SizedBox(
                        height: screenSize.height * 0.15,
                      ),
                      Text(
                        'Invoicing Made\nEasy for your\nBusiness',
                        style: TextStyle(
                            fontSize: 48,
                            fontWeight: FontWeight.bold,
                            color: AppColors.WHITE),
                      ),
                      SizedBox(
                        height: screenSize.height * 0.05,
                      ),
                      Text(
                        'Simple GST Invoicing, Stock Management, eWaybill Creation\nApplication for your Business.',
                        style: TextStyle(color: AppColors.WHITE),
                      ),
                      SizedBox(
                        height: screenSize.height * 0.03,
                      ),
                      Container(
                        width: screenSize.width * 0.2,
                        height: screenSize.height * 0.05,
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(10),
                            color: AppColors.WHITE),
                        child: Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text('Enter Mobile Number'),
                              Container(
                                width: 100,
                                decoration: BoxDecoration(
                                  color: AppColors.BUTTON,
                                  borderRadius: BorderRadius.circular(8),
                                ),
                                child: TextButton(
                                    onPressed: () {},
                                    child: Container(
                                      decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(2),
                                      ),
                                      child: Text(
                                        'Let\'s Start',
                                        style:
                                            TextStyle(color: AppColors.WHITE),
                                      ),
                                    )),
                              )
                            ],
                          ),
                        ),
                      ),
                      SizedBox(
                        height: screenSize.height * 0.03,
                      ),
                      Container(
                        width: screenSize.width * 0.15,
                        height: screenSize.height * 0.07,
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(40),
                            color: AppColors.WHITE),
                        child: Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            children: [
                              Row(
                                children: [
                                  FaIcon(FontAwesomeIcons.apple),
                                  SizedBox(
                                    width: 12,
                                  ),
                                  FaIcon(FontAwesomeIcons.googlePlay),
                                ],
                              ),
                              TextButton(
                                  onPressed: () {},
                                  child: Container(
                                    decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(2),
                                    ),
                                    child: Text(
                                      'Download App',
                                    ),
                                  )),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Positioned(
                right: screenSize.width * 0.12,
                top: screenSize.height * 0.1,
                child: Image.asset('asset/appbar.png', scale: 1.4,))
            ]),
            SizedBox(
              height: screenSize.height * 0.1,
            ),

            /// First Element
            SizedBox(
              height: screenSize.height * 0.9,
              width: screenSize.width,
              child: Stack(
                children: [
                  Positioned(
                    right: 1,
                    child: Container(
                      height: screenSize.height * 0.88,
                      width: screenSize.width * 0.7,
                      decoration: BoxDecoration(
                          color: AppColors.WHITE,
                          borderRadius:
                              BorderRadius.only(topLeft: Radius.circular(160)),
                          border: Border.all(color: Colors.grey)),
                    ),
                  ),
                  Positioned(
                    right: 1,
                    bottom: 1,
                    child: Container(
                      height: screenSize.height * 0.86,
                      width: screenSize.width * 0.68,
                      decoration: BoxDecoration(
                          color: AppColors.BACKGROUNDSTACK,
                          borderRadius:
                              BorderRadius.only(topLeft: Radius.circular(160)),
                          border: Border.all(color: Colors.grey)),
                    ),
                  ),
                  Positioned(
                    right: 1,
                    child: Padding(
                      padding: EdgeInsets.symmetric(
                          vertical: screenSize.height * 0.1),
                      child: SizedBox(
                        height: screenSize.height * 0.85,
                        width: screenSize.width * 0.6,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Text(
                              'Easy Invoicing, Easy Sharing',
                              style: TextStyle(
                                  color: AppColors.ELEMENTHEADING,
                                  fontSize: 42,
                                  fontWeight: FontWeight.bold),
                            ),
                            Text(
                              'Jhatpat billing',
                              style: TextStyle(
                                  color: AppColors.ELEMENTHEADING,
                                  fontSize: 42,
                                  fontWeight: FontWeight.bold),
                            ),
                            SizedBox(
                              height: screenSize.height * 0.05,
                            ),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                SizedBox(
                                  height: screenSize.height * 0.15,
                                  width: screenSize.width * 0.3,
                                  child: Column(
                                    children: [
                                      Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.start,
                                        children: [
                                          Text(
                                            '\u2022',
                                            style: TextStyle(
                                                color: AppColors.ELEMENTHEADING,
                                                fontWeight: FontWeight.bold),
                                          ),
                                          Text(
                                            'Manage Your Inventory',
                                            style: TextStyle(
                                                color: AppColors.ELEMENTHEADING,
                                                fontWeight: FontWeight.bold),
                                          ),
                                        ],
                                      ),
                                      SizedBox(
                                        height: 30,
                                      ),
                                      Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.start,
                                        children: [
                                          Text(
                                            '\u2022',
                                            style: TextStyle(
                                                color: AppColors.ELEMENTHEADING,
                                                fontWeight: FontWeight.bold),
                                          ),
                                          Text(
                                            'Accounting Made Easy',
                                            style: TextStyle(
                                                color: AppColors.ELEMENTHEADING,
                                                fontWeight: FontWeight.bold),
                                          ),
                                        ],
                                      ),
                                      SizedBox(
                                        height: 30,
                                      ),
                                      Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.start,
                                        children: [
                                          Text(
                                            '\u2022',
                                            style: TextStyle(
                                                color: AppColors.ELEMENTHEADING,
                                                fontWeight: FontWeight.bold),
                                          ),
                                          Text(
                                            'Faster way to generate Invoicing',
                                            style: TextStyle(
                                                color: AppColors.ELEMENTHEADING,
                                                fontWeight: FontWeight.bold),
                                          ),
                                        ],
                                      ),
                                    ],
                                  ),
                                ),
                                SizedBox(
                                  height: screenSize.height * 0.15,
                                  width: screenSize.width * 0.3,
                                  child: Column(
                                    children: [
                                      Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.start,
                                        children: [
                                          Text(
                                            '\u2022',
                                            style: TextStyle(
                                                color: AppColors.ELEMENTHEADING,
                                                fontWeight: FontWeight.bold),
                                          ),
                                          Text(
                                            'Analyze Different business reports',
                                            style: TextStyle(
                                                color: AppColors.ELEMENTHEADING,
                                                fontWeight: FontWeight.bold),
                                          ),
                                        ],
                                      ),
                                      SizedBox(
                                        height: 30,
                                      ),
                                      Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.start,
                                        children: [
                                          Text('\u2022'),
                                          Text(
                                            'Quickest way to generate eWaybill',
                                            style: TextStyle(
                                                color: AppColors.ELEMENTHEADING,
                                                fontWeight: FontWeight.bold),
                                          ),
                                        ],
                                      ),
                                      SizedBox(
                                        height: 30,
                                      ),
                                      Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.start,
                                        children: [
                                          Text('\u2022'),
                                          Text(
                                            'Easy Importing Data from other platform',
                                            style: TextStyle(
                                                color: AppColors.ELEMENTHEADING,
                                                fontWeight: FontWeight.bold),
                                          ),
                                        ],
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    top: screenSize.height * 0.1,
                    right: screenSize.width * 0.6,
                    child: Image.asset('asset/element1.png', scale: 1.4,)),
                    Positioned(
                    top: screenSize.height * 0.45,
                    right: screenSize.width * 0.15,
                    child: Image.asset('asset/element1group.png', scale: 1.4,))
                ],
              ),
            ),
            SizedBox(
              height: screenSize.height * 0.1,
            ),

            /// 2nd Element
            SizedBox(
              width: screenSize.width,
              height: screenSize.height * 0.9,
              child: Stack(children: [
                Container(
                  height: screenSize.height * 0.88,
                  width: screenSize.width * 0.7,
                  decoration: BoxDecoration(
                      color: AppColors.BACKGROUNDSTACK,
                      borderRadius:
                          BorderRadius.only(topRight: Radius.circular(160)),
                      border: Border.all(color: Colors.grey)),
                ),
                Positioned(
                  bottom: 1,
                  child: Container(
                    height: screenSize.height * 0.86,
                    width: screenSize.width * 0.68,
                    decoration: const BoxDecoration(
                        borderRadius:
                            BorderRadius.only(topRight: Radius.circular(160)),
                        gradient: LinearGradient(colors: [
                          AppColors.HOMEPAGE_LINEAR_1,
                          AppColors.HOMEPAGE_LINEAR_2
                        ])),
                    child: Padding(
                      padding: EdgeInsets.symmetric(
                          vertical: screenSize.height * 0.1),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Text(
                            'Benefits of using JhatpatBill ',
                            style: TextStyle(
                                color: AppColors.WHITE,
                                fontSize: 42,
                                fontWeight: FontWeight.bold),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Padding(
                      padding: EdgeInsets.only(left: screenSize.width * 0.1),
                      child: Row(
                        children: [
                          Container(
                            width: screenSize.width * 0.15,
                            height: screenSize.height * 0.4,
                            color: AppColors.WHITE,
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.spaceAround,
                              children: [
                                Image.asset('asset/element2_1.png'),
                                Text(
                                  '24/7 Support',
                                  style: TextStyle(
                                      color: AppColors.ELEMENTHEADING,
                                      fontSize: 24,
                                      fontWeight: FontWeight.bold),
                                ),
                                Padding(
                                  padding: const EdgeInsets.all(16.0),
                                  child: Text(
                                    'Get answers to your issues from our superfast support team on Call/Email or on Whatsapp',
                                    textAlign: TextAlign.center,
                                  ),
                                )
                              ],
                            ),
                          ),
                          SizedBox(
                            width: screenSize.width * 0.1,
                          ),
                          Container(
                            width: screenSize.width * 0.15,
                            height: screenSize.height * 0.4,
                            color: AppColors.WHITE,
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.spaceAround,
                              children: [
                                Image.asset('asset/element2_2.png'),
                                Text(
                                  'Data Privacy',
                                  style: TextStyle(
                                      color: AppColors.ELEMENTHEADING,
                                      fontSize: 24,
                                      fontWeight: FontWeight.bold),
                                ),
                                Padding(
                                  padding: const EdgeInsets.all(16.0),
                                  child: Text(
                                    'Your data is 100% secure with us, always stored in an encrypted and anonymised format',
                                    textAlign: TextAlign.center,
                                  ),
                                )
                              ],
                            ),
                          ),
                          SizedBox(
                            width: screenSize.width * 0.1,
                          ),
                          Container(
                            width: screenSize.width * 0.15,
                            height: screenSize.height * 0.4,
                            color: AppColors.WHITE,
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.spaceAround,
                              children: [
                                Image.asset('asset/element2_3.png'),
                                Text(
                                  'Auto Backup',
                                  style: TextStyle(
                                      color: AppColors.ELEMENTHEADING,
                                      fontSize: 24,
                                      fontWeight: FontWeight.bold),
                                ),
                                Padding(
                                  padding: const EdgeInsets.all(16.0),
                                  child: Text(
                                    'Your Data is automatically backed up, so data lose is not a worry about you.',
                                    textAlign: TextAlign.center,
                                  ),
                                )
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                )
              ]),
            ),
            SizedBox(
              height: screenSize.height * 0.1,
            ),

            /// 3rd Element
            SizedBox(
              height: screenSize.height * 0.9,
              width: screenSize.width,
              child: Stack(
                children: [
                  Positioned(
                    right: 1,
                    child: Container(
                      height: screenSize.height * 0.88,
                      width: screenSize.width * 0.7,
                      decoration: BoxDecoration(
                          color: AppColors.WHITE,
                          borderRadius:
                              BorderRadius.only(topLeft: Radius.circular(160)),
                          border: Border.all(color: Colors.grey)),
                    ),
                  ),
                  Positioned(
                    right: 1,
                    bottom: 1,
                    child: Container(
                      height: screenSize.height * 0.86,
                      width: screenSize.width * 0.68,
                      decoration: BoxDecoration(
                          color: AppColors.BACKGROUNDSTACK,
                          borderRadius:
                              BorderRadius.only(topLeft: Radius.circular(160)),
                          border: Border.all(color: Colors.grey)),
                    ),
                  ),
                  Positioned(
                    right: 1,
                    child: Padding(
                      padding: EdgeInsets.symmetric(
                          vertical: screenSize.height * 0.1),
                      child: SizedBox(
                        height: screenSize.height * 0.85,
                        width: screenSize.width * 0.6,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Text(
                              'Features The App',
                              style: TextStyle(
                                  color: AppColors.ELEMENTHEADING,
                                  fontSize: 42,
                                  fontWeight: FontWeight.bold),
                            ),
                            SizedBox(
                              height: screenSize.height * 0.05,
                            ),
                            SizedBox(
                                width: screenSize.width * 0.5,
                                child: Text(
                                  'Jhatpat Bill Have so many different features for different businesses Like inventory management, Business reports, Invoicing, eWaybill, parties management some of them are',
                                  textAlign: TextAlign.center,
                                  style: TextStyle(fontSize: 16),
                                )),
                            SizedBox(
                              height: 30
                            ),
                            Padding(
                              padding:
                                  EdgeInsets.only(left: screenSize.width * 0.2),
                              child: Column(
                                children: [
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    children: [
                                      Image.asset('asset/element3_1.png'),
                                      SizedBox(
                                        width: 20,
                                      ),
                                      Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                            'Invoice/eWaybill Creation',
                                            style: TextStyle(
                                                color: AppColors.ELEMENTHEADING,
                                                fontSize:18,
                                                fontWeight: FontWeight.normal),
                                          ),
                                          SizedBox(
                                            height: 10,
                                          ),
                                          Text(
                                              'Create All type of invoice in faster way\nGenerate invoice in different format like Bill to ship to and regular\nOne click eWaybill generation\nManage and share digital invoice ')
                                        ],
                                      )
                                    ],
                                  ),
                                  SizedBox(
                                    height: 20,
                                  ),
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    children: [
                                      Image.asset('asset/element3_2.png'),
                                      SizedBox(
                                        width: 20,
                                      ),
                                      Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                            'Inventory Management',
                                            style: TextStyle(
                                                color: AppColors.ELEMENTHEADING,
                                                fontSize: 18,
                                                fontWeight: FontWeight.normal),
                                          ),
                                          SizedBox(
                                            height: 10,
                                          ),
                                          Text(
                                              'Manage Sales and purchase of different products\nCreate and manage products\nLow stock alerts')
                                        ],
                                      )
                                    ],
                                  ),
                                  SizedBox(
                                    height: 20,
                                  ),
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    children: [
                                      Image.asset('asset/element3_3.png'),
                                      SizedBox(
                                        width: 20,
                                      ),
                                      Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                            'Generating Business Reports',
                                            style: TextStyle(
                                                color: AppColors.ELEMENTHEADING,
                                                fontSize: 18,
                                                fontWeight: FontWeight.normal),
                                          ),
                                          SizedBox(
                                            height: 10,
                                          ),
                                          Text(
                                              '8+ Business Reports available with more to be added soon\nAnalyze your Sales through reports like \nitem sales, party wise sales etc\nRate List to share with customers')
                                        ],
                                      )
                                    ],
                                  ),
                                  SizedBox(
                                    height: 20,
                                  ),
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    children: [
                                      Image.asset('asset/element3_4.png'),
                                      SizedBox(
                                        width: 20,
                                      ),
                                      Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                            'Importing Data from other platform',
                                            style: TextStyle(
                                                color: AppColors.ELEMENTHEADING,
                                                fontSize: 18,
                                                fontWeight: FontWeight.normal),
                                          ),
                                          SizedBox(
                                            height: 10,
                                          ),
                                          Text(
                                              'Transfer your parties, sales, purchase and products from other software such\nas Tally & BG with ease in excel format.')
                                        ],
                                      )
                                    ],
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    top: screenSize.height * 0.1,
                    right: screenSize.width * 0.6,
                    child: Image.asset('asset/element3.png', scale: 1.4,))
                ],
              ),
            ),
            SizedBox(
              height: screenSize.height * 0.1,
            ),

            /// BottomBar
            Footer()
          ],
        ),
      ),
    );
  }
}
