// ignore_for_file: prefer_const_constructors, avoid_unnecessary_containers

import 'package:flutter/material.dart';
import 'package:jhatpat/footer.dart';
import 'package:jhatpat/header.dart';
import 'contants.dart';

class Terms extends StatelessWidget {
  const Terms({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    var screenSize = MediaQuery.of(context).size;
    return Scaffold(
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Header(),
            SizedBox(
              height: screenSize.height * 0.1,
            ),
            Center(
              child: Text(
                'Terms of Service',
                style: TextStyle(
                    color: AppColors.HEADING,
                    fontSize: 48,
                    fontWeight: FontWeight.bold),
              ),
            ),
            SizedBox(
              height: screenSize.height * 0.1,
            ),
            Padding(
              padding:
                  EdgeInsets.symmetric(horizontal: screenSize.width * 0.05),
              child: Text(
                  'JhatpatBill Terms of Services\nEffective May 27, 2019\n\nAt JhatpatBill reachable from https://www.bradvicepvt.com we consider this as an immense responsibility and make an effort to safeguard the privacy of our visitors with due diligence. This Privacy Policy is an overview of the type of information that we collect, how we use that information, and how you can take control of what you share with us. Provision to update, manipulate and delete their private information is available to the users if they require.\n\n​The Mobile Application (as defined hereinafter), the Desktop Application (as defined hereinafter) and the Website (as defined hereinafter) are provided by JhatpatBill is a property of Bradvice Solutions PVT Ltd, an Indian Company registered under the Companies Act of India having CIN U9000RJ2019PTC065044 with its registered office at FF-27, Cross Road mall, Central Spine, Vidhyadhar Nagar, Jaipur, Rajasthan, India 302039. In these Terms of Service, the term "User" or “You” refers to you, the Person or entity using the Mobile Application, Desktop Application, the Website and/or procuring any goods, service or product from JhatpatBill. It is clarified that in case of a company, partnership, trust or any other legal entity which uses or accesses the Services or the JhatpatBill Products, "User" shall include such company, partnership, trust or any other legal entity;\n\nJhatpatBill offers the Mobile Application, Desktop Application, Store, Website, platform and any other services conditioned upon the User’s acceptance of all terms, conditions, policies, and notices stated here. By procuring a service from JhatpatBill, or by use of the Mobile Application, Desktop Application, Store, Website or platform, the User agrees to be bound by these terms and conditions ("Terms of Service" or "Terms"), as applicable, to the use of the Mobile Application, Store, Desktop Application, Website, platform and any services provided by JhatpatBill.\n\nTerms and Conditions\n\nUsing the services of JhatpatBill Mobile Application, Desktop Application, Store, Website, platform and any other services, accessible from https//:bradvicepvt.com the user harmonizes with these terms and conditions within the applicable jurisdiction. The user is requested to read the document carefully. The terms represent a general framework of regulations laid down for the use of services provided by JhatpatBill.\n\nIf the user disagrees with any of these terms, he/she is requested not to use the services provided by JhatpatBill. The content of JhatpatBill Mobile Application, Desktop Application, Store, Website, platform and any other services is protected by copyright and trademark regulations and cannot be replicated by any means.\n\nLicense of use\n\nJhatpatBill does not allow more than one temporary copy of the content provided by us for personal or non-commercial application. This license does not authorize the transfer of title. The user is not allowed to:\n\nReproducing, replicating or modification of the content./nUtilization of material for commercial purposes.\nRemoval of copyright from the content documents.\nTransfer of materials to another individual or firm.\nUse of branding or logos used within the services.\nInterfering with the services provided by JhatpatBill.\nAccessing the services by methods which use some other interface and instructions.\n\nJhatpatBill reserves the right to terminate the account of the user for any violation of any of these restrictions. The users are advised to delete or destroy any content that they possess after the termination.\n\n Disclaimer\n\nJhatpatBill provides the services with commercially acceptable skills and we have a faith that the user will appreciate using them. The users are expected to be responsible enough for exercising suitable judgment vis-à-vis appropriate utilization of the resources of JhatpatBill in agreement with the JhatpatBill policies, guidelines, and specifications. JhatpatBill’ resources must not be used for any illegal or unauthorized purpose. Given that we exclude the following liabilities and warranties from our services:\n\nLiability for personal damage due to laxity.\nLiability for sham or deceptive practices.\nLiabilities not acceptable by the jurisdiction.\n\nWe do not make any expressed or implied assurance like non-infringement or fitness of a particular purpose. JhatpatBill provides the services “as is”.\n\nContent of the user\n\nServices provided by JhatpatBill allows the user to share and receive their content. The user retains the intellectual property rights of that content. By sharing and obtaining content through our services the gives JhatpatBill a worldwide license to reproduce and publish such content. The authorization granted by the user in this license is limited with respect to the purpose of operating and improving our services. The license does not terminate even after the user withdraws from availing our services.\n\nHyperlinking to our Content\n\nJhatpatBill does not evaluate the content of the pages linked to its website and excludes any liability to such content. JhatpatBill does not endorse any website due to the presence of any such link.\n\nExcept for the following organizations, every organization needs prior written approval from JhatpatBill for hyperlinking:\n\nGovernment organizations;\nSearch engines;\nNews and broadcasting agencies;\nOnline directory distributors.\n\nFollowing guidelines are indispensable to be followed while linking to our home page:\n\nThe link should not be deceptive or fraudulent.\nThe link should not imply false association and approval with the products and services provided by JhatpatBill.\n\nJhatpatBill will approve linking with the following types of businesses:\n\nOnline directory distributors\nInternet portals and dot com websites\nCharity websites and Non-governmental organizations.\nConsulting, accounting and legal organisations.\n\nThe interested organizations can contact JhatpatBill for further process and provide details like the name of the organization, contact information as well as URL of the website and expect the response within 1-2 weeks.\n\nUser’s Account\n\nThe user is requested to keep the login details as confidential as possible. He/she is solely responsible for the activity that occurs through the account. If the user notices an unusual activity or unauthorized use by a third-party agency, please inform JhatpatBill for further process.\n\nPrivacy and Copyright Protection\n\nThe privacy policy laid down by JhatpatBill mentions in detail about the protection of personal information when the user utilizes our services. JhatpatBill retains the right to use this information as per the guidelines of the privacy policy.\n\nJhatpatBill responds to the notices of contended copyright infringement and reserves the right to terminate the account of repeat violators.\n\nModifying and Terminating our Services\n\nThe Terms of Service are liable to be updated or changed with time. The users will be notified for any changes in the existing Terms of service by means of posting the new document of the terms on the concerned webpage of our company Mobile Application, Desktop Application, Store, Website, platform and any other services. The users will also be notified by means of an email as well as a notice prior to the implementation of the changed Terms of Service and an effective date will be updated at the top of this policy.\n\nHowever, the users are advised to re-examine the Terms of Service sporadically for any changes. Any changes to this policy would be effective only when they are mentioned on this page.\n\nContact Us\n\nAny queries about the privacy policy, from the users, are welcome. The users can connect with us by:\nEmail: bradvicesolutionspvt@gmail.com\nVisiting our website: https//:bradvicepvt.com\nContact number: +91-7742330144\n\nConsent\nUsing our Mobile Application, Desktop Application, Website, Store or other product ensures your consent to our Privacy Policy as well as the terms and conditions as posted on the Mobile Application, Desktop Application, Website, Store or other product.'),
            ),
            SizedBox(
              height: screenSize.height * 0.1,
            ),
            Footer()
          ],
        ),
      ),
    );
  }
}
