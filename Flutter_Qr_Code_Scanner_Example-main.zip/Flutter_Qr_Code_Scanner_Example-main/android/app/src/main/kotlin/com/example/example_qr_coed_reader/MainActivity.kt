package com.example.example_qr_coed_reader

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
