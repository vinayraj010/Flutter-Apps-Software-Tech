# example_qr_coed_reader

Flutter Qr code scanner example project.
